<?php
/**
 * Pełnoekranowy szablon strony magazynu (niezależny od motywu).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title><?php echo esc_html( 'System K-ERP – ' . get_bloginfo( 'name' ) ); ?></title>
<?php wp_head(); ?>
</head>
<body class="msm-body">
<?php
while ( have_posts() ) {
	the_post();
	echo do_shortcode( '[magazyn]' ); // Treść strony to aplikacja.
}
wp_footer();
?>
</body>
</html>
