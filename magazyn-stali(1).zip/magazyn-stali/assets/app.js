/* System K-ERP – aplikacja (vanilla JS, bez zależności) */
(function () {
	'use strict';

	var C = window.MSM;
	if (!C) return;
	var S = C.schema;
	var STOCK = ['stal', 'blachy_pelne', 'blachy_niepelne', 'kregi'];
	/* Progi ostrzeżeń w dniach (Ustawienia). */
	var PROG = { zlecenia: 7, elektro: 14, pomiar: 60 };
	if (C.progi) Object.keys(PROG).forEach(function (k) { if (+C.progi[k] > 0) PROG[k] = +C.progi[k]; });
	/* Zakładka → klucz uprawnienia (gdy różni się od nazwy trasy). */
	var TAB_KEY = { 'zam': 'zam_dost', 'produkcja': 'prod_zlecenia', 'prod-palety': 'prod_palety', 'prod-notatki': 'prod_notatki', 'prod-karty': 'prod_karty', 'wz': 'wz_dok', 'wz-odbiorcy': 'wz_odbiorcy', 'wz-przeznaczenie': 'wz_przeznaczenie', 'wz-transport': 'wz_transport', 'bhp': 'bhp_stan', 'narz-pomiarowe': 'narz_pomiarowe', 'narz-elektro': 'narz_elektro' };
	function tabOn(t) { return mOn(TAB_KEY[t] || t); }
	/* Stany widoczne dla tej osoby (Stal / Blachy / Kręgi można wyłączać osobno). */
	var STOCK_VIS = mOn('stany') ? STOCK.filter(tabOn) : [];
	/* Szybki inwentarz – stan z serwera (odświeżany co minutę). */
	var INW = (C.canEdit && C.inw) || { active: false };
	function canStock() { return !!(C.canEdit || INW.active); }
	/* Główne menu (zakładki widoczne na pasku): stal, blachy, kręgi + pobrania, wnioski. */
	var NAV_TABS = STOCK_VIS.concat(['pobrania', 'wnioski'].filter(tabOn));
	/* Pozycje przeniesione do rozwijanego menu „Menu”. */
	var MENU_TABS = (C.canEdit ? ['pz'] : []).concat(['rezerwacje', 'historia']).concat(C.canEdit ? ['import'] : []).filter(tabOn);
	var MENU_LABELS = { pz: 'Przyjęcia (PZ)', rezerwacje: 'Rezerwacje', historia: 'Historia zmian', import: 'Import' };
	/* Uprawnienia: które sekcje menu są widoczne. */
	function mOn(k) {
		if (!C.menu) return true;
		var p = C.menuParent && C.menuParent[k];
		return C.menu[k] !== false && (!p || C.menu[p] !== false);
	}

	function capOn(k) { return !C.caps || C.caps[k] !== false; }
	/* Edycja stanu (dodawanie/edycja/usuwanie/pobrania bezpośrednie) = rola admin + uprawnienie „edit”. */
	function cEdit() { return C.canEdit && capOn('edit'); }
	/* Grupy menu górnego: Magazyn (podmenu) + Techniczne (podmenu). [klucz trasy, etykieta, klucz-menu] */
	var MAG_MENU = [[STOCK_VIS[0] || 'stal', 'Stany', 'stany'], ['rezerwacje', 'Rezerwacje', 'rezerwacje'], ['pobrania', 'Pobrania', 'pobrania'], ['wnioski', 'Wnioski', 'wnioski'], ['zlecenie', 'Karta zlecenia', 'zlecenie']]
		.concat(C.canEdit ? [['zamowienia', 'Do zamówienia', 'zamowienia']] : [])
		.filter(function (it) { return mOn(it[2]) && (it[2] !== 'stany' || STOCK_VIS.length); });
	var TECH_LINKS = [['historia', 'Historia zmian', 'historia']]
		.concat(C.canEdit ? [['uzytkownicy', 'Użytkownicy', 'uzytkownicy'], ['kopia', 'Kopia danych', 'kopia'], ['szablony', 'Szablony e-maili', 'szablony'], ['logowania', 'Dziennik logowań', 'logowania']] : [])
		.concat(C.canSettings ? [['ustawienia', 'Ustawienia', 'ustawienia']] : [])
		.concat([['zmiany', 'Historia wersji', 'zmiany']])
		.filter(function (it) { return mOn(it[2]); });
	/* Ikony eksportu: plik z etykietą XLS (zielony) / CSV (szary). xbtn() – przycisk z samą ikoną, podpowiedzią i opisem dla czytników. */
	function fileIco(lbl, col, sz) {
		sz = sz || 22;
		return '<svg class="msm-xico" width="' + sz + '" height="' + sz + '" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 2h8l5 5v13a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2z" fill="#fff" stroke="' + col + '" stroke-width="1.6"/><path d="M14 2v5h5" fill="none" stroke="' + col + '" stroke-width="1.6"/><rect x="1.5" y="11" width="15" height="8" rx="1.6" fill="' + col + '"/><text x="9" y="17.2" text-anchor="middle" font-family="Arial,Helvetica,sans-serif" font-size="6.2" font-weight="700" fill="#fff">' + lbl + '</text></svg>';
	}
	var ICO_XLS = fileIco('XLS', '#1d6f42'), ICO_CSV = fileIco('CSV', '#5a6375');
	/* kind: 'xlsx' | 'csv'; attrs: atrybuty (data-…); href: dla linku; cls: dodatkowe klasy (np. msm-btn-sm). */
	function xbtn(kind, attrs, title, href, cls) {
		var t = title || (kind === 'csv' ? 'Eksport do CSV' : 'Eksport do Excela (.xlsx)');
		var c = 'msm-btn msm-btn-ico msm-xbtn' + (cls ? ' ' + cls : '');
		var ico = kind === 'csv' ? ICO_CSV : ICO_XLS;
		return href ? '<a class="' + c + '" href="' + esc(href) + '" ' + (attrs || '') + ' title="' + esc(t) + '" aria-label="' + esc(t) + '">' + ico + '</a>'
			: '<button type="button" class="' + c + '" ' + (attrs || '') + ' title="' + esc(t) + '" aria-label="' + esc(t) + '">' + ico + '</button>';
	}
	/* Menu „Techniczne” w grupach: [klucz trasy | 'grafik' | 'inw', etykieta, opis, ikona]. Historia wersji – w stopce menu. */
	var TI = function (p) { return '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + p + '</svg>'; };
	var TECH_IC = {
		grafik: TI('<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18M8 14h3M8 18h6"/>'),
		inw: TI('<path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/>'),
		import: TI('<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="M7 10l5 5 5-5M12 15V3"/>'),
		uzytkownicy: TI('<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>'),
		logowania: TI('<path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4M10 17l5-5-5-5M15 12H3"/>'),
		historia: TI('<path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5M12 7v5l4 2"/>'),
		kopia: TI('<ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5M3 12c0 1.66 4 3 9 3s9-1.34 9-3"/>'),
		ustawienia: TI('<path d="M4 21v-7M4 10V3M12 21v-9M12 8V3M20 21v-5M20 12V3M1 14h6M9 8h6M17 16h6"/>'),
		szablony: TI('<rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-10 5L2 7"/>')
	};
	var TECH_DESC = { grafik: 'Kto, kiedy i przy czym pracuje', inw: 'Spis z natury z telefonu', import: 'Wczytanie stanów z Excela', uzytkownicy: 'Konta, role i uprawnienia', logowania: 'Kto i kiedy się logował', historia: 'Każda zmiana w magazynie', kopia: 'Kopie zapasowe i import z Excela', ustawienia: 'Firma, progi, listy, lokalizacje', szablony: 'Treść powiadomień e-mail' };
	var TECH_HAS = {}; TECH_LINKS.forEach(function (it) { TECH_HAS[it[0]] = it[1]; });
	var TECH_INW = !!(C.canEdit && capOn('inwentarz'));
	var TECH_GRAFIK = C.grafik && mOn('grafik') ? C.grafik : '';
	var TECH_GROUPS = [
		['Na co dzień', ['grafik', 'inw']],
		['Ludzie i dostęp', ['uzytkownicy', 'logowania']],
		['Dane i historia', ['historia', 'kopia']],
		['Konfiguracja', ['ustawienia', 'szablony']]
	].map(function (g) {
		return [g[0], g[1].filter(function (k) { return k === 'grafik' ? !!TECH_GRAFIK : k === 'inw' ? TECH_INW : !!TECH_HAS[k]; })];
	}).filter(function (g) { return g[1].length; });
	function techItem(k, cls) {
		var lbl = k === 'grafik' ? 'Grafik pracy' : k === 'inw' ? 'Szybki inwentarz' : TECH_HAS[k];
		var inner = '<i class="msm-techm__ic">' + TECH_IC[k] + '</i><span class="msm-techm__t"><b' + (k === 'inw' ? ' class="msm-inwbtn__label" data-inwlabel' : '') + '>' + esc(lbl) + '</b><small>' + esc(TECH_DESC[k]) + '</small></span>';
		if (k === 'inw') return '<button type="button" class="' + cls + ' msm-techm__i" data-inwbtn>' + inner + '</button>';
		if (k === 'grafik') return '<a class="' + cls + ' msm-techm__i" href="' + esc(TECH_GRAFIK) + '">' + inner + '</a>';
		return '<a class="' + cls + ' msm-techm__i" href="#' + k + '" data-tab="' + k + '">' + inner + '</a>';
	}
	function techMenu(cls, mob) {
		return TECH_GROUPS.map(function (g) {
			return '<div class="msm-techm__g"><h6>' + esc(g[0]) + '</h6>' + g[1].map(function (k) { return techItem(k, cls); }).join('') + '</div>';
		}).join('') +
			'<div class="msm-techm__ft">' + (TECH_HAS.zmiany ? '<a href="#zmiany" data-tab="zmiany" class="' + (mob ? cls + ' ' : '') + 'msm-techm__ver">Historia wersji ›</a>' : '<span></span>') + '<span>System K-ERP ' + esc(C.version || '') + '</span></div>';
	}
	/* Dodatkowe trasy-raporty (nie są tabelami). */
	var REPORT_TABS = ['zlecenie'].concat(C.canEdit ? ['zamowienia', 'logowania', 'uzytkownicy', 'kopia', 'szablony'] : []).concat(C.canSettings ? ['ustawienia'] : []).concat(['zmiany']).filter(tabOn);
	/* Magazyny z rezerwacjami pod zlecenia (kręgi w kg). */
	var REZ_T = ['stal', 'blachy_pelne', 'blachy_niepelne', 'kregi'];
	var REZ_LABELS = { nowa: 'Oczekuje', aktywna: 'Aktywna', wydana: 'Wydana', anulowana: 'Anulowana', odrzucona: 'Odrzucona', wygasla: 'Wygasła' };
	/* Wszystkie trasy-strony (do walidacji hashy). */
	var NARZ_TABS = (C.canEdit || S.spr_prost) && mOn('narzedzia') ? ['spr_prost', 'prz_prost', 'spr_okr', 'prz_okr'].filter(function (k) { return S[k] && tabOn(k); }) : [];
	/* Narzędziownia: sprawdziany i przyrządy + przyrządy pomiarowe i elektronarzędzia (zakładki przygotowane, na razie puste). */
	var NARZ_NEW = mOn('narzedzia') ? ['narz-pomiarowe', 'narz-elektro'].filter(tabOn) : [];
	NARZ_TABS = NARZ_TABS.concat(NARZ_NEW);
	var NARZ_LABELS = { spr_prost: 'Sprawdziany prost.', prz_prost: 'Przyrządy prost.', spr_okr: 'Sprawdziany okrągłe', prz_okr: 'Przyrządy okrągłe', 'narz-pomiarowe': 'Przyrządy pomiarowe', 'narz-elektro': 'Elektronarzędzia' };
	var TABLICA = mOn('tablica');
	/* Strona główna: Tablica kierownika dla osób z tym uprawnieniem, dla pozostałych – Stal (albo pierwszy dostępny stan). */
	var HOME = TABLICA ? 'tablica' : (STOCK_VIS.indexOf('stal') >= 0 ? 'stal' : (STOCK_VIS[0] || ''));
	/* Produkcja: podmenu Zlecenia / Paletówki. */
	var PROD_TABS = (C.prod && mOn('produkcja')) ? ['produkcja', 'prod-palety', 'prod-notatki', 'prod-karty'].filter(function (t) { return t === 'prod-karty' ? !!(C.menu && C.menu.prod_karty) : tabOn(t); }) : [];
	var PROD_LABELS = { 'produkcja': 'Zlecenia', 'prod-palety': 'Paletówki', 'prod-notatki': 'Notatki', 'prod-karty': 'Karty zmian' };
	var TABS = (TABLICA ? ['tablica'] : []).concat(NAV_TABS).concat(MENU_TABS).concat(NARZ_TABS).concat(REPORT_TABS).concat(PROD_TABS);
	var TAB_LABELS = { import: 'Import', wnioski: 'Wnioski', wz: 'WZ', pz: 'Przyjęcia (PZ)' };
	/* Sekcja „Wydanie zewnętrzne” – osobne podmenu. */
	var WZ_TABS = mOn('wz') ? ['wz', 'wz-odbiorcy', 'wz-przeznaczenie', 'wz-transport'].filter(tabOn) : [];
	var WZ_TAB_LABELS = { 'wz': 'Dokumenty WZ', 'wz-odbiorcy': 'Odbiorcy', 'wz-przeznaczenie': 'Przeznaczenie', 'wz-transport': 'Środek transportu' };
	/* Magazyn BHP – osobny moduł: Stan BHP, Wydania (na osoby), Osoby. */
	var BHP_TABS = mOn('bhp') ? ['bhp', 'bhp_wyd', 'bhp_util', 'bhp_osoby', 'bhp_normy', 'bhp_wymiana'].filter(tabOn) : [];
	TABS = TABS.concat(BHP_TABS);
	/* Menu „Dokumenty”: Przyjęcia (PZ), Wydania (WZ), Przesyłki. */
	var PRZES = mOn('przesylki');
	if (PRZES) TABS.push('przesylki');
	var ZAMD = mOn('zam_dost');
	if (ZAMD) TABS.push('zam');
	var DOK_MENU = [].concat(C.canEdit && mOn('pz') ? [['pz', 'Przyjęcia (PZ)', 'pz']] : [])
		.concat(WZ_TABS.length ? [[WZ_TABS[0], 'Wydania (WZ)', 'wz']] : [])
		.concat(PRZES ? [['przesylki', 'Przesyłki', 'przesylki']] : [])
		.concat(ZAMD ? [['zam', 'Zamówienia', 'zam']] : []);
	var BHP_TAB_LABELS = { 'bhp': 'Stan BHP', 'bhp_wyd': 'Wydania', 'bhp_util': 'Utylizacje', 'bhp_osoby': 'Osoby', 'bhp_normy': 'Normy', 'bhp_wymiana': 'Do wymiany' };
	var SL_TYPES = { 'wz-odbiorcy': 'odbiorca', 'wz-przeznaczenie': 'przeznaczenie', 'wz-transport': 'transport' };
	var SL_INFO = {
		odbiorca: { title: 'Odbiorcy', one: 'odbiorcę', ph: 'np. ABC Sp. z o.o., ul. Przemysłowa 1, 46-250 Wołczyn' },
		przeznaczenie: { title: 'Przeznaczenie', one: 'przeznaczenie', ph: 'np. Do obróbki, Na budowę' },
		transport: { title: 'Środek transportu', one: 'środek transportu', ph: 'np. Transport własny, Kurier, OP 12345' }
	};
	var WZ_LABELS = { szkic: 'Szkic', do_zatwierdzenia: 'Do zatwierdzenia', wystawiona: 'Wystawiona', anulowana: 'Anulowana' };
	var W_LABELS = { nowy: 'Nowy', zaakceptowany: 'Do wydania', wydany: 'Wydany', odrzucony: 'Odrzucony', anulowany: 'Anulowany', potwierdzony: 'Jest na stanie', brak: 'Brak na stanie' };
	var W_TYPES = { pobranie: 'Pobranie', sprawdzenie: 'Sprawdzenie stanu' };
	var root = document.getElementById('msm-app');
	if (!root) return;

	/* ---------------- narzędzia ---------------- */

	function esc(s) {
		return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
			return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
		});
	}
	function fmtNum(v, dec) {
		if (v === null || v === undefined || v === '') return '';
		var n = Number(v);
		if (!isFinite(n)) return String(v);
		var d = dec == null ? 3 : dec;
		return n.toLocaleString('pl-PL', { minimumFractionDigits: 0, maximumFractionDigits: d });
	}
	function numIn(v) { return v === null || v === undefined || v === '' ? '' : String(Number(v)).replace('.', ','); }
	var ICO_GRIP = '<svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><circle cx="9" cy="5" r="1.6"/><circle cx="15" cy="5" r="1.6"/><circle cx="9" cy="12" r="1.6"/><circle cx="15" cy="12" r="1.6"/><circle cx="9" cy="19" r="1.6"/><circle cx="15" cy="19" r="1.6"/></svg>';
	function fmtDate(v) {
		if (!v) return '';
		var m = String(v).match(/^(\d{4})-(\d{2})-(\d{2})(?:[ T](\d{2}):(\d{2}))?/);
		if (!m) return v;
		return m[3] + '.' + m[2] + '.' + m[1] + (m[4] ? ' ' + m[4] + ':' + m[5] : '');
	}
	function fmtCell(col, v) {
		if (v === null || v === undefined || v === '') return '';
		switch (col.type) {
			case 'num': return fmtNum(v, col.decimals);
			case 'int': return String(v);
			case 'bool': return v ? 'tak' : 'nie';
			case 'date': case 'datetime': return fmtDate(v);
			default: return col.key === 'jednostka' && v === 'szt' ? 'szt.' : String(v);
		}
	}
	function debounce(fn, ms) {
		var t;
		return function () {
			var a = arguments, self = this;
			clearTimeout(t);
			t = setTimeout(function () { fn.apply(self, a); }, ms);
		};
	}
	function store(key, val) {
		try {
			if (val === undefined) return JSON.parse(localStorage.getItem('msm_' + key) || 'null');
			localStorage.setItem('msm_' + key, JSON.stringify(val));
		} catch (e) { return null; }
	}

	function buildUrl(path, params) {
		return withQuery(C.rest.replace(/\/$/, '') + path, params);
	}
	function printUrl(params) {
		return withQuery(String(C.appUrl).split('#')[0], params);
	}
	function withQuery(base, params) {
		var qs = [];
		Object.keys(params || {}).forEach(function (k) {
			var v = params[k];
			if (v === null || v === undefined || v === '') return;
			if (typeof v === 'object') {
				Object.keys(v).forEach(function (kk) {
					var vv = v[kk];
					if (vv === null || vv === undefined || vv === '' || (Array.isArray(vv) && !vv.length)) return;
					qs.push(encodeURIComponent(k + '[' + kk + ']') + '=' + encodeURIComponent(Array.isArray(vv) ? vv.join('||') : vv));
				});
			} else {
				qs.push(encodeURIComponent(k) + '=' + encodeURIComponent(v));
			}
		});
		return base + (qs.length ? (base.indexOf('?') >= 0 ? '&' : '?') + qs.join('&') : '');
	}

	function api(path, opts) {
		opts = opts || {};
		var init = { method: opts.method || 'GET', headers: { 'X-WP-Nonce': C.nonce, 'X-MSM-Inw': INW.active ? '1' : '0' }, credentials: 'same-origin' };
		if (opts.form) {
			init.body = opts.form;
		} else if (opts.body !== undefined) {
			init.headers['Content-Type'] = 'application/json';
			init.body = JSON.stringify(opts.body);
		}
		return fetch(buildUrl(path, opts.query), init).then(function (r) {
			return r.text().then(function (txt) {
				var data;
				try { data = txt ? JSON.parse(txt) : {}; } catch (e) { data = { message: 'Nieoczekiwana odpowiedź serwera.' }; }
				if (!r.ok) {
					var err = new Error(data.message || ('Błąd ' + r.status));
					err.data = data.data || {};
					err.status = r.status;
					if (r.status === 401 || (r.status === 403 && data.code === 'rest_cookie_invalid_nonce')) {
						err.message = 'Sesja wygasła – odśwież stronę i zaloguj się ponownie.';
					}
					throw err;
				}
				return data;
			});
		});
	}

	/* ---------------- powiadomienia i okna ---------------- */

	var toastBox = document.createElement('div');
	toastBox.className = 'msm-toasts';
	document.body.appendChild(toastBox);
	function toast(msg, type) {
		var el = document.createElement('div');
		el.className = 'msm-toast msm-toast-' + (type || 'ok');
		el.textContent = msg;
		toastBox.appendChild(el);
		setTimeout(function () { el.classList.add('out'); }, type === 'err' || type === 'warn' ? 6000 : 3500);
		setTimeout(function () { el.remove(); }, type === 'err' || type === 'warn' ? 6500 : 4000);
	}

	var modalEl = null;
	/* Podgląd załącznika w aplikacji (zdjęcie na pełnym ekranie, PDF – pobranie), bez opuszczania bieżącego ekranu.
	   Ważne w aplikacji na ekranie głównym telefonu: zwykły link otwierał plik zamiast aplikacji i nie było jak wrócić. */
	var VIEWER = null;
	function closeViewer(fromPop) {
		if (!VIEWER) return;
		var v = VIEWER; VIEWER = null; v.el.remove(); document.documentElement.classList.remove('msm-noscroll');
		if (!fromPop && v.pushed) { try { history.back(); } catch (e) {} }
	}
	function openViewer(url, name, isImg) {
		if (!isImg) {
			var a = document.createElement('a'); a.href = url; a.download = name || ''; a.rel = 'noopener';
			document.body.appendChild(a); a.click(); a.remove();
			return;
		}
		closeViewer(true);
		var el = document.createElement('div');
		el.className = 'msm-viewer'; el.setAttribute('role', 'dialog'); el.setAttribute('aria-label', 'Podgląd załącznika');
		el.innerHTML = '<header class="msm-viewer__bar"><span class="msm-viewer__n">' + esc(name || '') + '</span>' +
			'<a class="msm-viewer__btn" href="' + esc(url) + '" download="' + esc(name || '') + '">Pobierz</a>' +
			'<button type="button" class="msm-viewer__btn msm-viewer__x" data-vclose aria-label="Zamknij podgląd">✕</button></header>' +
			'<div class="msm-viewer__body" data-vbody><img src="' + esc(url) + '" alt="' + esc(name || '') + '" data-vimg></div>' +
			'<p class="msm-viewer__hint">Dotknij zdjęcia, aby powiększyć</p>';
		document.body.appendChild(el);
		document.documentElement.classList.add('msm-noscroll');
		var pushed = false;
		try { history.pushState({ msmViewer: 1 }, ''); pushed = true; } catch (e) {}
		VIEWER = { el: el, pushed: pushed };
		el.querySelector('[data-vclose]').addEventListener('click', function () { closeViewer(false); });
		var img = el.querySelector('[data-vimg]'), body = el.querySelector('[data-vbody]');
		img.addEventListener('click', function (e) {
			var r = img.getBoundingClientRect(), fx = (e.clientX - r.left) / r.width, fy = (e.clientY - r.top) / r.height;
			el.classList.toggle('is-zoom');
			if (el.classList.contains('is-zoom')) { body.scrollLeft = img.scrollWidth * fx - body.clientWidth / 2; body.scrollTop = img.scrollHeight * fy - body.clientHeight / 2; }
		});
		body.addEventListener('click', function (e) { if (e.target === body) closeViewer(false); });
	}
	window.addEventListener('popstate', function () { if (VIEWER) closeViewer(true); });
	document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && VIEWER) { e.stopPropagation(); closeViewer(false); } }, true);
	document.addEventListener('click', function (e) {
		var a = e.target.closest && e.target.closest('a[data-view]');
		if (!a || e.ctrlKey || e.metaKey || e.shiftKey) return;
		var img = a.getAttribute('data-view') === 'img';
		/* Plik (PDF) w zwykłej przeglądarce – nowa karta; w aplikacji z ekranu głównego – pobranie, bez opuszczania aplikacji. */
		var standalone = (window.matchMedia && window.matchMedia('(display-mode: standalone)').matches) || window.navigator.standalone === true;
		if (!img && !standalone) { if (a.getAttribute('data-open')) { e.preventDefault(); window.open(a.getAttribute('data-open'), '_blank', 'noopener'); } return; }
		e.preventDefault();
		openViewer(a.getAttribute('href'), a.getAttribute('data-name') || '', img);
	});

	function closeModal() {
		if (modalEl) { modalEl.remove(); modalEl = null; document.body.classList.remove('msm-noscroll'); }
	}
	function openModal(title, bodyHtml, footHtml, wide) {
		closeModal();
		modalEl = document.createElement('div');
		modalEl.className = 'msm-modal-wrap';
		modalEl.innerHTML = '<div class="msm-modal' + (wide ? ' wide' : '') + '" role="dialog" aria-modal="true">' +
			'<div class="msm-modal-head"><h2>' + esc(title) + '</h2><button type="button" class="msm-x" data-close aria-label="Zamknij">×</button></div>' +
			'<div class="msm-modal-body">' + bodyHtml + '</div>' +
			(footHtml ? '<div class="msm-modal-foot">' + footHtml + '</div>' : '') + '</div>';
		modalEl.addEventListener('mousedown', function (e) { if (e.target === modalEl) closeModal(); });
		modalEl.querySelectorAll('[data-close]').forEach(function (b) { b.addEventListener('click', closeModal); });
		document.body.appendChild(modalEl);
		document.body.classList.add('msm-noscroll');
		var f = modalEl.querySelector('input:not([type=hidden]):not([type=checkbox]):not([type=radio]),select,textarea');
		if (f) setTimeout(function () { f.focus(); }, 30);
		return modalEl;
	}
	document.addEventListener('keydown', function (e) { if (e.key === 'Escape') closeModal(); });

	function confirmBox(title, text, okLabel, danger) {
		return new Promise(function (resolve) {
			var m = openModal(title, '<p>' + text + '</p>',
				'<button type="button" class="msm-btn" data-close>Anuluj</button>' +
				'<button type="button" class="msm-btn ' + (danger ? 'msm-btn-danger' : 'msm-btn-primary') + '" data-ok>' + esc(okLabel || 'OK') + '</button>');
			var done = false;
			m.querySelector('[data-ok]').addEventListener('click', function () { done = true; closeModal(); resolve(true); });
			var obs = new MutationObserver(function () { if (!document.body.contains(m)) { obs.disconnect(); if (!done) resolve(false); } });
			obs.observe(document.body, { childList: true });
		});
	}

	/* ---------------- stan ---------------- */

	var state = {};
	function st(t) {
		if (!state[t]) {
			var saved = store('state_' + t) || {};
			state[t] = {
				q: saved.q || '', f: saved.f || {}, min: saved.min || {}, max: saved.max || {},
				orderby: saved.orderby || null, order: saved.order || null,
				page: 1, per_page: saved.per_page || 50, hide_zero: !!saved.hide_zero,
				selected: {}, options: null, data: null, loading: false
			};
		}
		return state[t];
	}
	function saveState(t) {
		var s = st(t);
		store('state_' + t, { q: s.q, f: s.f, min: s.min, max: s.max, orderby: s.orderby, order: s.order, per_page: s.per_page, hide_zero: s.hide_zero });
	}
	function queryParams(t) {
		var s = st(t);
		return { q: s.q, f: s.f, min: s.min, max: s.max, orderby: s.orderby, order: s.order, page: s.page, per_page: s.per_page, hide_zero: s.hide_zero ? 1 : '' };
	}
	function activeFilterCount(t) {
		var s = st(t), n = 0;
		Object.keys(s.f).forEach(function (k) { if (s.f[k]) n++; });
		Object.keys(s.min).forEach(function (k) { if (s.min[k] !== '' && s.min[k] != null) n++; });
		Object.keys(s.max).forEach(function (k) { if (s.max[k] !== '' && s.max[k] != null) n++; });
		return n;
	}

	var SVG = '<svg class="msm-ico" width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">';
	var ICON_EDIT = SVG + '<path d="M4 20h4L19 9l-4-4L4 16v4z"/><path d="m13.5 6.5 4 4"/></svg>';
	var ICON_HIST = SVG + '<path d="M3 12a9 9 0 1 0 3-6.7"/><path d="M3 4v5h5"/><path d="M12 8v4l3 2"/></svg>';
	var ICON_PRINT = SVG + '<path d="M7 9V3h10v6"/><rect x="3" y="9" width="18" height="8" rx="2"/><path d="M7 14h10v7H7z"/></svg>';
	var ICON_DEL = SVG + '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/></svg>';
	var ICON_MOVE = SVG + '<path d="M4 7h11M4 7l3-3M4 7l3 3"/><path d="M20 17H9M20 17l-3-3M20 17l-3 3"/></svg>';

	var current = null;

	/* ---------------- szkielet ---------------- */

	var ICO_WZ = '<svg class="msm-ico" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5M9 13h6M9 17h4"/></svg>';
	var ICO_MAG = '<svg class="msm-ico" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 21V9l9-6 9 6v12"/><path d="M7 21v-8h10v8M7 17h10"/></svg>';
	var ICO_MENU = '<svg class="msm-ico" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 6h16M4 12h16M4 18h16"/></svg>';
	var ICO_PZ = '<svg class="msm-ico" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 8v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8"/><path d="M3 8l2-4h14l2 4M12 4v9m0 0-3-3m3 3 3-3"/></svg>';
	var ICO_INW = '<svg class="msm-ico" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 4h6v3H9z"/><path d="M15 5h2a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2h2"/><path d="m9 14 2 2 4-4"/></svg>';
	var ICO_NARZ = '<svg class="msm-ico" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M14.7 6.3a4 4 0 0 1-5 5L4 17v3h3l5.7-5.7a4 4 0 0 0 5-5l-2.1 2.1-2.8-.7-.7-2.8z"/></svg>';
	var ICO_REZ = '<svg class="msm-ico" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="4" y="10" width="16" height="10" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg>';
	var ICO_PULPIT = '<svg class="msm-ico" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="3" width="7" height="9" rx="1"/><rect x="14" y="3" width="7" height="5" rx="1"/><rect x="14" y="12" width="7" height="9" rx="1"/><rect x="3" y="16" width="7" height="5" rx="1"/></svg>';
	var ICO_IMPORT = '<svg class="msm-ico" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3v12m0 0 4-4m-4 4-4-4"/><path d="M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"/></svg>';
	var ICO_BHP = '<svg class="msm-ico" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3a6 6 0 0 0-6 6v2H5a1 1 0 0 0-1 1v1h16v-1a1 1 0 0 0-1-1h-1V9a6 6 0 0 0-6-6z"/><path d="M12 3v4M4 16h16"/></svg>';
	var ICO_TAB = '<svg class="msm-ico" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="3" width="7" height="9" rx="1.5"/><rect x="14" y="3" width="7" height="5" rx="1.5"/><rect x="14" y="12" width="7" height="9" rx="1.5"/><rect x="3" y="16" width="7" height="5" rx="1.5"/></svg>';
	var ICO_PROD = '<svg class="msm-ico" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 21h18M4 21V9l6 4V9l6 4V9l4 3v9"/><path d="M7 21v-4h3v4"/></svg>';
	var ICO_TECH = '<svg class="msm-ico" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.6 1.6 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.6 1.6 0 0 0-1.8-.3 1.6 1.6 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.6 1.6 0 0 0-1-1.5 1.6 1.6 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.6 1.6 0 0 0 .3-1.8 1.6 1.6 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.6 1.6 0 0 0 1.5-1 1.6 1.6 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.6 1.6 0 0 0 1.8.3H9a1.6 1.6 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.6 1.6 0 0 0 1 1.5 1.6 1.6 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.6 1.6 0 0 0-.3 1.8V9a1.6 1.6 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.6 1.6 0 0 0-1.5 1z"/></svg>';
	/* Ustawia widoczność pasków nawigacji i podświetlenie aktywnej pozycji. */
	/* Do której grupy menu górnego należy dana zakładka. */
	function groupOf(t) {
		if (t === 'pz' || t === 'przesylki' || t === 'zam' || WZ_TABS.indexOf(t) >= 0) return 'dok';
		if (BHP_TABS.indexOf(t) >= 0) return 'bhp';
		if (NARZ_TABS.indexOf(t) >= 0) return 'narz';
		if (PROD_TABS.indexOf(t) >= 0) return 'produkcja';
		if (t === 'tablica') return 'tablica';
		if (t === 'historia' || t === 'import' || t === 'logowania' || t === 'uzytkownicy' || t === 'kopia' || t === 'szablony' || t === 'ustawienia' || t === 'zmiany') return 'tech';
		return 'mag';
	}

	function syncNav(t) {
		var g = groupOf(t);
		var inStock = STOCK.indexOf(t) >= 0;
		var sN = root.querySelector('[data-stocknav]'), wzNav = root.querySelector('[data-wznav]'), narzNav = root.querySelector('[data-narznav]'), bhpNav = root.querySelector('[data-bhpnav]'), prodNav = root.querySelector('[data-prodnav]');
		if (prodNav) prodNav.hidden = g !== 'produkcja';
		if (sN) sN.hidden = g !== 'mag';
		if (wzNav) wzNav.hidden = WZ_TABS.indexOf(t) < 0;
		var dokNav = root.querySelector('[data-doknav]');
		if (dokNav) {
			dokNav.hidden = g !== 'dok';
			dokNav.querySelectorAll('a[data-dok]').forEach(function (a) { a.classList.toggle('active', a.getAttribute('data-dok') === (WZ_TABS.indexOf(t) >= 0 ? 'wz' : t)); });
		}
		if (narzNav) narzNav.hidden = g !== 'narz';
		if (bhpNav) bhpNav.hidden = g !== 'bhp';
		// Podświetlenie pozycji górnego menu wg grupy.
		root.querySelectorAll('[data-top]').forEach(function (a) {
			var on = a.getAttribute('data-top') === g;
			a.classList.toggle('active', on);
			if (a.hasAttribute('aria-selected')) a.setAttribute('aria-selected', on ? 'true' : 'false');
		});
		// Podświetlenie zakładek w paskach kontekstowych.
		root.querySelectorAll('.msm-subnav a[data-tab]').forEach(function (a) {
			a.classList.toggle('active', a.getAttribute('data-tab') === t);
		});
		// Zaznaczenie bieżącej pozycji w rozwijanych podmenu.
		root.querySelectorAll('.msm-navmenu__item[data-tab]').forEach(function (a) {
			a.classList.toggle('is-current', a.getAttribute('data-tab') === t);
		});
		root.querySelectorAll('.msm-navmenu').forEach(function (d) { d.classList.remove('open'); });
		// Menu mobilne: podświetlenie + zamknięcie.
		root.querySelectorAll('.msm-mobmenu__item').forEach(function (a) {
			var tab = a.getAttribute('data-tab'), top = a.getAttribute('data-top');
			a.classList.toggle('is-current', (tab && tab === t) || (top && top === g) || (a.hasAttribute('data-stany') && inStock));
		});
		var mt = root.querySelector('[data-mobtech]');
		if (mt) mt.open = g === 'tech';
		var mob = root.querySelector('[data-mobmenu]');
		if (mob) mob.hidden = true;
		var bg = root.querySelector('[data-burger]');
		if (bg) { bg.setAttribute('aria-expanded', 'false'); bg.classList.remove('is-open'); }
	}

	/* Automatyczne wylogowanie po godzinie bezczynności (aktywność zeruje licznik). */
	function startIdleLogout() {
		if (!C.logout) return;
		var LIMIT = 60 * 60 * 1000; // 1 godzina
		var WARN = 60 * 1000;       // ostrzeżenie na minutę przed
		var tOut, tWarn, warned = false, last = 0;
		function doLogout() { window.location.href = C.logout; }
		function reset() {
			warned = false;
			clearTimeout(tOut); clearTimeout(tWarn);
			tWarn = setTimeout(function () { warned = true; toast('Za minutę nastąpi automatyczne wylogowanie (brak aktywności).', 'warn'); }, LIMIT - WARN);
			tOut = setTimeout(doLogout, LIMIT);
		}
		function onActivity() { var now = Date.now(); if (warned || now - last > 5000) { last = now; reset(); } }
		['mousemove', 'mousedown', 'keydown', 'touchstart', 'scroll', 'click'].forEach(function (ev) {
			window.addEventListener(ev, onActivity, { passive: true });
		});
		reset();
	}

	function shell() {
		var initials = String(C.user || '?').split(/\s+/).filter(Boolean).slice(0, 2).map(function (w) { return w.charAt(0).toUpperCase(); }).join('');
		var chev = '<svg class="msm-ico msm-navmenu__chev" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m6 9 6 6 6-6"/></svg>';
		root.innerHTML =
			'<header class="msm-header">' +
			'<div class="msm-container msm-header__row">' + String(C.logo || '').replace(/(href="[^"#]*)#stal"/, '$1#' + (HOME || TABS[0] || 'stal') + '"').replace('title="System K-ERP – strona główna"', 'title="Strona główna"') +
			'<div class="msm-header__tools">' +
			(TECH_GRAFIK ? '<a class="msm-btn msm-hgraf' + (C.shellOnly === 'grafik' ? ' is-on' : '') + '" href="' + esc(TECH_GRAFIK) + '" title="Grafik pracy">' + TECH_IC.grafik + '<span>Grafik pracy</span></a>' : '') +
			'<button type="button" class="msm-burger" data-burger aria-label="Menu" aria-expanded="false">' + ICO_MENU + '</button>' +
			'<details class="msm-user"><summary><span class="msm-avatar">' + esc(initials) + '</span>' +
			'<span class="msm-user__name"><b class="msm-user-name">' + esc(C.user) + '</b><small class="msm-role">' + esc(C.role) + '</small></span>' +
			'<svg class="msm-ico" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m6 9 6 6 6-6"/></svg></summary>' +
			'<div class="msm-user__menu"><a href="#profil">Mój profil</a>' +
			'<button type="button" data-notif hidden>Powiadomienia</button><button type="button" data-install hidden>Zainstaluj aplikację</button><button type="button" data-howto hidden>Jak zainstalować?</button>' +
			'<a href="' + esc(C.logout) + '">Wyloguj</a></div></details>' +
			'</div></div>' +
			'<nav class="msm-nav"><div class="msm-container msm-nav__row msm-topnav" role="tablist">' +
			(TABLICA ? '<a href="#tablica" class="msm-nav__tab" data-top="tablica" role="tab">' + ICO_TAB + '<span>Pulpit</span></a>' : '') +
			(MAG_MENU.length ? '<a href="#' + MAG_MENU[0][0] + '" class="msm-nav__tab" data-top="mag" role="tab">' + ICO_MAG + '<span>Magazyn</span><span class="msm-count is-hot" data-rezcount hidden></span></a>' : '') +
			(DOK_MENU.length ? '<a href="#' + DOK_MENU[0][0] + '" class="msm-nav__tab" data-top="dok" role="tab">' + ICO_WZ + '<span>Dokumenty</span><span class="msm-count is-hot" data-wzcount hidden></span></a>' : '') +
			(BHP_TABS.length ? '<a href="#' + BHP_TABS[0] + '" class="msm-nav__tab" data-top="bhp" role="tab">' + ICO_BHP + '<span>Magazyn BHP</span></a>' : '') +
			(PROD_TABS.length ? '<a href="#' + PROD_TABS[0] + '" class="msm-nav__tab" data-top="produkcja" role="tab">' + ICO_PROD + '<span>Produkcja</span></a>' : '') +
			(NARZ_TABS.length ? '<a href="#' + NARZ_TABS[0] + '" class="msm-nav__tab" data-top="narz" role="tab">' + ICO_NARZ + '<span>Narzędziownia</span></a>' : '') +
			(TECH_LINKS.length || TECH_INW || TECH_GRAFIK ?
			'<div class="msm-navmenu" data-navmenu="tech">' +
			'<a href="#' + (TECH_LINKS[0] ? TECH_LINKS[0][0] : 'historia') + '" class="msm-nav__tab msm-navmenu__label" data-top="tech" role="tab">' + ICO_TECH + '<span>Techniczne</span></a>' +
			'<button type="button" class="msm-navmenu__toggle" data-navtoggle aria-label="Rozwiń menu Techniczne">' + chev + '</button>' +
			'<div class="msm-navmenu__menu msm-techm">' + techMenu('msm-navmenu__item', false) + '</div></div>' : '') +
			'</div>' +
			// Menu mobilne (hamburger) – tylko główne sekcje; podstrony są w pasku pod nagłówkiem.
			'<div class="msm-container msm-mobmenu" data-mobmenu hidden>' +
			(TABLICA ? '<a class="msm-mobmenu__item" href="#tablica" data-top="tablica">' + ICO_TAB + '<span>Pulpit</span></a>' : '') +
			(MAG_MENU.length ? '<a class="msm-mobmenu__item" href="#' + MAG_MENU[0][0] + '" data-top="mag">' + ICO_MAG + '<span>Magazyn</span>' +
				'<span class="msm-count" data-wcount hidden></span><span class="msm-count is-hot" data-rezcount hidden></span></a>' : '') +
			(DOK_MENU.length ? '<a class="msm-mobmenu__item" href="#' + DOK_MENU[0][0] + '" data-top="dok">' + ICO_WZ + '<span>Dokumenty</span><span class="msm-count is-hot" data-wzcount hidden></span></a>' : '') +
			(BHP_TABS.length ? '<a class="msm-mobmenu__item" href="#' + BHP_TABS[0] + '" data-top="bhp">' + ICO_BHP + '<span>Magazyn BHP</span></a>' : '') +
			(PROD_TABS.length ? '<a class="msm-mobmenu__item" href="#' + PROD_TABS[0] + '" data-top="produkcja">' + ICO_PROD + '<span>Produkcja</span></a>' : '') +
			(NARZ_TABS.length ? '<a class="msm-mobmenu__item" href="#' + NARZ_TABS[0] + '" data-top="narz">' + ICO_NARZ + '<span>Narzędziownia</span></a>' : '') +
			/* „Techniczne” nie ma paska podstron – rozwijana grupa. */
			(TECH_LINKS.length || TECH_INW || TECH_GRAFIK ?
			'<details class="msm-mobmenu__more" data-mobtech><summary class="msm-mobmenu__item msm-mobmenu__sum" data-top="tech">' + ICO_TECH + '<span>Techniczne</span>' + chev + '</summary>' +
			'<div class="msm-mobmenu__sub msm-techm msm-techm--mob">' + techMenu('msm-mobmenu__item', true) + '</div></details>' : '') +
			'<div class="msm-mobmenu__sep"></div>' +
			'<a class="msm-mobmenu__item" href="#profil"><span>Mój profil</span></a>' +
			'<button type="button" class="msm-mobmenu__item" data-notif hidden><span>Powiadomienia</span></button>' +
			'<button type="button" class="msm-mobmenu__item" data-install hidden><span>Zainstaluj aplikację</span></button>' +
			'<button type="button" class="msm-mobmenu__item" data-howto hidden><span>Jak zainstalować na telefonie?</span></button>' +
			'<a class="msm-mobmenu__item" href="' + esc(C.logout) + '"><span>Wyloguj</span></a>' +
			'</div>' +
			'<div class="msm-container msm-nav__row msm-tabs msm-subnav" data-stocknav role="tablist" hidden>' +
			STOCK_VIS.map(function (t) {
				return '<a href="#' + t + '" class="msm-nav__tab" data-tab="' + t + '" role="tab">' + esc(S[t].label) + '</a>';
			}).join('') +
			(function () {
				var rest = MAG_MENU.filter(function (it) { return it[2] !== 'stany'; });
				return rest.length ? '<span class="msm-subnav__right">' + rest.map(function (it) {
					return '<a href="#' + it[0] + '" class="msm-nav__tab" data-tab="' + it[0] + '" role="tab">' + esc(it[1]) +
						(it[0] === 'rezerwacje' ? '<span class="msm-count is-hot" data-rezcount hidden></span>' : '') +
						(it[0] === 'zamowienia' ? '<span class="msm-count is-hot" data-zamcount hidden></span>' : '') +
						'</a>';
				}).join('') + '</span>' : '';
			})() + '</div>' +
			'<div class="msm-container msm-nav__row msm-tabs msm-subnav" data-doknav role="tablist" hidden>' +
			'<span class="msm-subnav__title">Dokumenty</span>' +
			DOK_MENU.map(function (it) {
				return '<a href="#' + it[0] + '" class="msm-nav__tab" data-dok="' + (it[2] === 'wz' ? 'wz' : it[0]) + '" role="tab">' + esc(it[1]) + (it[2] === 'wz' ? '<span class="msm-count is-hot" data-wzcount hidden></span>' : '') + '</a>';
			}).join('') + '</div>' +
			'<div class="msm-container msm-nav__row msm-tabs msm-subnav msm-subnav--sub" data-wznav role="tablist" hidden>' +
			'<span class="msm-subnav__title">Wydania (WZ)</span>' +
			WZ_TABS.map(function (t) {
				return '<a href="#' + t + '" class="msm-nav__tab" data-tab="' + t + '" role="tab">' + esc(WZ_TAB_LABELS[t]) + '</a>';
			}).join('') + '</div>' +
			'<div class="msm-container msm-nav__row msm-tabs msm-subnav" data-narznav role="tablist" hidden>' +
			'<span class="msm-subnav__title">Narzędziownia</span>' +
			NARZ_TABS.map(function (t) {
				return '<a href="#' + t + '" class="msm-nav__tab" data-tab="' + t + '" role="tab">' + esc(NARZ_LABELS[t]) + '</a>';
			}).join('') + '</div>' +
			'<div class="msm-container msm-nav__row msm-tabs msm-subnav" data-prodnav role="tablist" hidden>' +
			'<span class="msm-subnav__title">Produkcja</span>' +
			PROD_TABS.map(function (t) {
				return '<a href="#' + t + '" class="msm-nav__tab" data-tab="' + t + '" role="tab">' + esc(PROD_LABELS[t]) + '</a>';
			}).join('') + '</div>' +
			'<div class="msm-container msm-nav__row msm-tabs msm-subnav" data-bhpnav role="tablist" hidden>' +
			'<span class="msm-subnav__title">Magazyn BHP</span>' +
			BHP_TABS.map(function (t) {
				return '<a href="#' + t + '" class="msm-nav__tab" data-tab="' + t + '" role="tab">' + esc(BHP_TAB_LABELS[t]) + '</a>';
			}).join('') + '</div></nav>' +
			'</header><main class="msm-main msm-container" id="msm-main"></main>';
		document.addEventListener('click', function (e) {
			var burger = e.target.closest('[data-burger]');
			var mob = root.querySelector('[data-mobmenu]');
			if (burger) {
				e.preventDefault();
				var willOpen = mob.hidden;
				mob.hidden = !willOpen;
				burger.setAttribute('aria-expanded', willOpen ? 'true' : 'false');
				burger.classList.toggle('is-open', willOpen);
				return;
			}
			if (mob && !mob.hidden && !mob.contains(e.target)) {
				mob.hidden = true;
				var bb = root.querySelector('[data-burger]');
				if (bb) { bb.setAttribute('aria-expanded', 'false'); bb.classList.remove('is-open'); }
			}
			if (e.target.closest('.msm-mobmenu__item') && !e.target.closest('.msm-mobmenu__sum') && mob) {
				mob.hidden = true;
				var bc = root.querySelector('[data-burger]');
				if (bc) { bc.setAttribute('aria-expanded', 'false'); bc.classList.remove('is-open'); }
			}
			var tog = e.target.closest('[data-navtoggle]');
			if (tog) {
				e.preventDefault();
				var own = tog.closest('.msm-navmenu');
				root.querySelectorAll('.msm-navmenu.open').forEach(function (d) { if (d !== own) d.classList.remove('open'); });
				own.classList.toggle('open');
				return;
			}
			root.querySelectorAll('.msm-user[open]').forEach(function (d) { if (!d.contains(e.target)) d.open = false; });
			root.querySelectorAll('.msm-navmenu.open').forEach(function (d) { if (!d.contains(e.target)) d.classList.remove('open'); });
			if (e.target.closest('.msm-navmenu__item') || e.target.closest('.msm-navmenu__label')) {
				root.querySelectorAll('.msm-navmenu.open').forEach(function (d) { d.classList.remove('open'); });
			}
		});
	}

	function route() {
		var t = (location.hash || '').replace('#', '');
		var um = root.querySelector('.msm-user');
		if (um) um.open = false;
		/* Skróty aplikacji na telefonie: #pz-new – nowe PZ (aparat), #przesylki-new – nowa przesyłka. */
		var quick = { 'pz-new': ['pz', '[data-pznew]'], 'przesylki-new': ['przesylki', '[data-przadd]'] }[t];
		if (quick) {
			history.replaceState(null, '', '#' + quick[0]);
			t = quick[0];
			(function wait(n) { var b = document.querySelector(quick[1]); if (b) b.click(); else if (n > 0) setTimeout(function () { wait(n - 1); }, 150); })(40);
		}
		var sendMatch = t.match(/^wyslij-(\d+)$/);
		if (sendMatch) {
			history.replaceState(null, '', '#wnioski');
			t = 'wnioski';
			setTimeout(function () { openSendFromLink(+sendMatch[1]); }, 50);
		}
		if (t === 'profil') {
			current = 'profil';
			root.querySelectorAll('[data-top], .msm-subnav a, .msm-navmenu__item, .msm-mobmenu__item').forEach(function (a) { a.classList.remove('active'); a.classList.remove('is-current'); });
			root.querySelectorAll('[data-stocknav],[data-wznav],[data-doknav],[data-narznav],[data-bhpnav],[data-mobmenu]').forEach(function (n) { n.hidden = true; });
			return renderProfile();
		}
		/* Strona zlecenia produkcyjnego: #prod-<id>[-szczegoly|-paletowki|-notatki[-<id notatki>]] */
		var prodMatch = t.match(/^prod-(\d+)(?:-(szczegoly|paletowki|notatki|przesylki|karty|pobrania)(?:-(\d+))?)?$/);
		if (prodMatch && C.prod && (tabOn('produkcja') || tabOn('prod-palety') || tabOn('prod-notatki'))) {
			current = 'produkcja';
			syncNav('produkcja');
			return renderProdukcja(+prodMatch[1], prodMatch[2] || 'karta', prodMatch[3] ? +prodMatch[3] : 0);
		}
		/* Karta zmiany: #prod-karty-new, #prod-karty-<id> */
		var kzMatch = t.match(/^prod-karty-(new|\d+)$/);
		if (kzMatch && PROD_TABS.indexOf('prod-karty') >= 0) {
			current = 'prod-karty';
			syncNav('prod-karty');
			return renderKartaZmiany(kzMatch[1] === 'new' ? 0 : +kzMatch[1]);
		}
		/* Szczegóły elektronarzędzia: #narz-elektro-<id> */
		var elMatch = t.match(/^narz-elektro-(\d+)$/);
		if (elMatch && NARZ_TABS.indexOf('narz-elektro') >= 0) {
			current = 'narz-elektro';
			syncNav('narz-elektro');
			return renderElektroItem(+elMatch[1]);
		}
		/* Szczegóły zamówienia do dostawcy: #zam-<id> */
		var zamMatch = t.match(/^zam-(\d+)$/);
		if (zamMatch && ZAMD) {
			current = 'zam';
			syncNav('zam');
			return renderZamItem(+zamMatch[1]);
		}
		/* Szczegóły przyrządu pomiarowego: #narz-pomiarowe-<id> */
		var pmMatch = t.match(/^narz-pomiarowe-(\d+)$/);
		if (pmMatch && NARZ_TABS.indexOf('narz-pomiarowe') >= 0) {
			current = 'narz-pomiarowe';
			syncNav('narz-pomiarowe');
			return renderPomiarItem(+pmMatch[1]);
		}
		var inWz = WZ_TABS.indexOf(t) >= 0;
		var inBhp = BHP_TABS.indexOf(t) >= 0;
		if (!inWz && !inBhp) {
			if (TABS.indexOf(t) < 0) t = HOME || TABS[0];
			if (TABS.indexOf(t) < 0) t = TABS[0] || WZ_TABS[0] || BHP_TABS[0] || 'stal'; // pierwsza dostępna pozycja
			if (WZ_TABS.indexOf(t) >= 0 || BHP_TABS.indexOf(t) >= 0) { location.replace('#' + t); return; }
			if (location.hash && location.hash.slice(1) !== t) history.replaceState(null, '', '#' + t); // ukryta zakładka → adres pierwszej dostępnej
			if (NAV_TABS.indexOf(t) >= 0) store('tab', t);
		}
		current = t;
		syncNav(t);
		if (t === 'bhp_wyd') return renderWydaniaBhp();
		if (t === 'bhp_util') return renderUtylizacje();
		if (t === 'bhp_wymiana') return renderDoWymiany();
		if (SL_TYPES[t]) return renderSlownik(SL_TYPES[t]);
		if (t === 'import') return renderImport();
		if (t === 'zlecenie') return renderZlecenie();
		if (t === 'zamowienia') return renderZamowienia();
		if (t === 'logowania') return renderLogowania();
		if (t === 'uzytkownicy') return renderUsers();
		if (t === 'kopia') return renderKopia();
		if (t === 'szablony') return renderMailTemplates();
		if (t === 'ustawienia') return renderUstawienia();
		if (t === 'zmiany') return renderZmiany();
		if (t === 'produkcja') return renderProdukcja();
		if (t === 'prod-palety') return renderPaletyAll();
		if (t === 'prod-notatki') return renderNotatkiAll();
		if (t === 'prod-karty') return renderKartyZmian();
		if (t === 'przesylki') return renderPrzesylki();
		if (t === 'zam') return renderZam();
		if (t === 'narz-elektro') return renderElektro();
		if (t === 'narz-pomiarowe') return renderPomiar();
		if (t === 'tablica') return renderTablica();
		renderTableView(t);
	}

	/* ---------------- widok tabeli ---------------- */

	function colsFor(t) { return S[t].cols; }

	function renderTableView(t) {
		var s = st(t);
		var main = document.getElementById('msm-main');
		var stock = S[t].stock;
		main.innerHTML =
			'<div class="msm-cat">' +
			'<div class="msm-pagehead"><div><h1>' + esc(S[t].label) + '</h1><p class="msm-muted" data-count>&nbsp;</p></div>' +
			'<div class="msm-pagehead__tools">' +
			(((cEdit() || INW.active) && stock) || (S[t].edit && cEdit()) ? '<button type="button" class="msm-btn msm-btn-primary" data-add>+ Dodaj</button>' : '') +
			(t === 'wnioski' ? '<button type="button" class="msm-btn" data-printlist>Drukuj listę</button>' : '') +
			(stock || S[t].narzedzia ? '<button type="button" class="msm-btn" data-printstock>Drukuj listę</button>' : '') +
			(t === 'pz' && capOn('pz') ? '<button type="button" class="msm-btn msm-btn-primary" data-pznew>+ Nowe PZ (skan / zdjęcie)</button>' : '') +
			(t === 'wz' ? '<button type="button" class="msm-btn msm-btn-primary" data-wznew>+ Nowa WZ</button><button type="button" class="msm-btn" data-printlist>Drukuj listę</button>' : '') +
			xbtn('xlsx', 'data-export="xlsx"') + xbtn('csv', 'data-export="csv"') +
			'<button type="button" class="msm-btn msm-ftoggle" data-ftoggle aria-expanded="true">' + ICON_FILTER + '<span data-ftlabel>Ukryj filtry</span><span class="msm-badge" data-ftcount hidden></span></button>' +
			'</div></div>' +
			(INW.active && stock ? inwBanner() : '') +
			'<div class="msm-filters" aria-label="Filtry"><div class="msm-filters__body" data-filters><div class="msm-loading">Ładowanie filtrów…</div></div></div>' +
			'<div class="msm-bulk" data-bulk hidden></div>' +
			'<div class="msm-table-wrap" data-tablewrap><div class="msm-loading">Ładowanie…</div></div>' +
			'<div class="msm-foot" data-foot></div>' +
			'</div>';
		watchFilters(main.querySelector('.msm-filters'));
		applyFiltersHidden();
		main.querySelector('[data-ftoggle]').addEventListener('click', function () {
			store('filters_hidden', !store('filters_hidden'));
			applyFiltersHidden();
		});

		var add = main.querySelector('[data-add]');
		if (add) add.addEventListener('click', function () { openForm(t, null); });
		var pzn = main.querySelector('[data-pznew]');
		if (pzn) pzn.addEventListener('click', function () { openPZ(null); });
		var wn = main.querySelector('[data-wznew]');
		if (wn) wn.addEventListener('click', function () { openWZ(null); });
		var pl = main.querySelector('[data-printlist]');
		if (pl) pl.addEventListener('click', function () {
			var p = queryParams(t);
			delete p.page; delete p.per_page; delete p.hide_zero;
			p.msm_print = t === 'wz' ? 'wzlista' : 'wnioski';
			window.open(printUrl(p), '_blank');
		});
		var ps = main.querySelector('[data-printstock]');
		if (ps) ps.addEventListener('click', function () {
			var p = queryParams(t);
			delete p.page; delete p.per_page;
			p.msm_print = 'lista'; p.t = t;
			window.open(printUrl(p), '_blank');
		});
		main.querySelectorAll('[data-export]').forEach(function (b) {
			b.addEventListener('click', function () {
				var p = queryParams(t);
				delete p.page; delete p.per_page;
				p.format = b.getAttribute('data-export');
				p._wpnonce = C.nonce;
				window.location.href = buildUrl('/export/' + t, p);
			});
		});

		loadFilterOptions(t).then(function () { renderFilters(t); });
		loadOptions(t);
		load(t);
	}

	/* Opcje list w filtrach – liczone w obrębie pozostałych filtrów (pokazują tylko to, co da wynik). */
	function loadFilterOptions(t) {
		var s = st(t);
		var q = queryParams(t);
		delete q.page; delete q.per_page; delete q.orderby; delete q.order;
		q.filtered = 1;
		return api('/t/' + t + '/options', { query: q }).then(function (o) { s.fopts = o; return o; }).catch(function () { s.fopts = s.fopts || {}; return s.fopts; });
	}

	function selectOptionsHtml(t, c) {
		var s = st(t);
		var opts = (s.fopts && s.fopts[c.key]) || [];
		var sel = String(s.f[c.key] || '');
		if (c.type === 'enum' && c.options) {
			var have = {};
			opts.forEach(function (o) { have[o.v] = o; });
			opts = c.options.map(function (v) { return have[v] || { v: v, label: v, n: 0 }; }).concat(have.__empty__ ? [have.__empty__] : []);
		}
		opts = opts.filter(function (o) { return o.n > 0 || String(o.v) === sel; });
		if (sel && !opts.some(function (o) { return String(o.v) === sel; })) opts.unshift({ v: sel, label: sel, n: 0 });
		return '<option value="">Wszystkie</option>' + opts.map(function (o) {
			if (t === 'wz' && c.key === 'status') { return '<option value="' + esc(o.v) + '"' + (String(o.v) === sel ? ' selected' : '') + '>' + esc(WZ_LABELS[o.v] || o.v) + ' (' + o.n + ')</option>'; }
			var label = t === 'wnioski' && c.key === 'status' ? (W_LABELS[o.v] || o.label) : (t === 'wnioski' && c.key === 'typ' ? (W_TYPES[o.v] || o.label) : o.label);
			return '<option value="' + esc(o.v) + '"' + (String(o.v) === sel ? ' selected' : '') + '>' + esc(label) + ' (' + o.n + ')</option>';
		}).join('');
	}

	/* Po zmianie filtrów odśwież tylko zawartość list (bez przebudowy pól – nie gubi kursora). */
	function refreshFilterSelects(t) {
		return loadFilterOptions(t).then(function () {
			if (current !== t) return;
			colsFor(t).forEach(function (c) {
				if (c.filter !== 'select') return;
				var el = document.querySelector('[data-f="' + c.key + '"]');
				if (el) el.innerHTML = selectOptionsHtml(t, c);
			});
		});
	}

	/* Wysokość przyklejonego paska filtrów → nagłówek tabeli przykleja się tuż pod nim. */
	var filtersRO = null;
	function watchFilters(el) {
		if (filtersRO) filtersRO.disconnect();
		if (!el || !window.ResizeObserver) return;
		filtersRO = new ResizeObserver(function () {
			root.style.setProperty('--msm-filtersh', el.offsetHeight + 'px');
		});
		filtersRO.observe(el);
	}

	function loadOptions(t, force) {
		var s = st(t);
		if (s.options && !force) return Promise.resolve(s.options);
		return api('/t/' + t + '/options').then(function (o) { s.options = o; return o; }).catch(function () { s.options = {}; return {}; });
	}

	function renderFilters(t) {
		if (current !== t) return;
		var s = st(t);
		var box = document.querySelector('[data-filters]');
		if (!box) return;
		var html = '';
		colsFor(t).forEach(function (c) {
			if (!c.filter) return;
			if (c.filter === 'select') {
				html += '<label class="msm-f"><span>' + esc(c.label) + '</span><select data-f="' + c.key + '">' + selectOptionsHtml(t, c) + '</select></label>';
			} else if (c.filter === 'text') {
				html += '<label class="msm-f"><span>' + esc(c.label) + '</span><input type="search" class="msm-f-text" data-ftext="' + c.key + '" value="' + esc(s.f[c.key] || '') + '" placeholder="wpisz fragment"></label>';
			} else if (c.filter === 'range') {
				var type = (c.type === 'date' || c.type === 'datetime') ? 'date' : 'text';
				var im = type === 'text' ? ' inputmode="decimal"' : '';
				html += '<div class="msm-f msm-f-range"' + (c.exact_single ? ' title="Wpisz jedną wartość, aby szukać dokładnie tego wymiaru; obie – aby podać zakres od–do."' : '') + '><span>' + esc(c.label) + '</span><div>' +
					'<input type="' + type + '"' + im + ' placeholder="' + (c.exact_single ? 'wymiar' : 'od') + '" aria-label="' + esc(c.label) + ' od" data-min="' + c.key + '" value="' + esc(s.min[c.key] || '') + '">' +
					'<i></i>' +
					'<input type="' + type + '"' + im + ' placeholder="do" aria-label="' + esc(c.label) + ' do" data-max="' + c.key + '" value="' + esc(s.max[c.key] || '') + '">' +
					'</div></div>';
			}
		});
		if (S[t].stock || t === 'bhp') {
			html += '<label class="msm-check msm-f-check"><input type="checkbox" data-hidezero' + (s.hide_zero ? ' checked' : '') + '> ' + (t === 'bhp' ? 'Ukryj puste pozycje' : 'Ukryj zerowe stany') + '</label>';
		}
		html += '<div class="msm-f msm-f-search"><span class="msm-f-search__label"><label for="msm-q">Szukaj</label>' +
			'<button type="button" class="msm-link" data-clear>Wyczyść filtry <span class="msm-badge" data-fcount hidden></span></button></span>' +
			'<input type="search" id="msm-q" placeholder="np. płaskownik 50x30 S235" value="' + esc(s.q) + '" data-q></div>';
		box.innerHTML = html;
		box.querySelector('[data-clear]').addEventListener('click', function () {
			s.f = {}; s.min = {}; s.max = {}; s.q = ''; s.hide_zero = false; s.page = 1; saveState(t);
			load(t); loadFilterOptions(t).then(function () { renderFilters(t); });
		});

		var reload = debounce(function () { s.page = 1; saveState(t); updateFilterBadge(t); load(t); refreshFilterSelects(t); }, 350);
		box.querySelectorAll('[data-f]').forEach(function (el) {
			el.addEventListener('change', function () { s.f[el.getAttribute('data-f')] = el.value; reload(); });
		});
		box.querySelectorAll('[data-ftext]').forEach(function (el) {
			el.addEventListener('input', function () { var k = el.getAttribute('data-ftext'); if (el.value.trim()) s.f[k] = el.value.trim(); else delete s.f[k]; reload(); });
		});
		box.querySelectorAll('[data-min],[data-max]').forEach(function (el) {
			el.addEventListener('input', function () {
				var k = el.getAttribute('data-min') || el.getAttribute('data-max');
				(el.hasAttribute('data-min') ? s.min : s.max)[k] = el.value.trim();
				reload();
			});
		});
		var hz = box.querySelector('[data-hidezero]');
		if (hz) hz.addEventListener('change', function () { s.hide_zero = hz.checked; reload(); });
		var q = box.querySelector('[data-q]');
		q.addEventListener('input', debounce(function () { s.q = q.value; s.page = 1; saveState(t); updateFilterBadge(t); load(t); refreshFilterSelects(t); }, 300));
		updateFilterBadge(t);
	}

	function updateFilterBadge(t) {
		var n = activeFilterCount(t) + (st(t).q ? 1 : 0) + (st(t).hide_zero ? 1 : 0);
		['[data-fcount]', '[data-ftcount]'].forEach(function (sel) {
			var b = document.querySelector(sel);
			if (b) { b.textContent = n ? n : ''; b.hidden = !n; }
		});
	}

	/* Przycisk „Ukryj / Pokaż filtry” – stan zapamiętany w przeglądarce. */
	var ICON_FILTER = '<svg class="msm-ico" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 5h18l-7 8v6l-4 2v-8z"/></svg>';
	function applyFiltersHidden() {
		var hidden = !!store('filters_hidden');
		var f = document.querySelector('.msm-filters'), b = document.querySelector('[data-ftoggle]');
		if (f) f.hidden = hidden;
		if (!f || hidden) root.style.setProperty('--msm-filtersh', '0px');
		if (b) {
			b.querySelector('[data-ftlabel]').textContent = hidden ? 'Pokaż filtry' : 'Ukryj filtry';
			b.setAttribute('aria-expanded', hidden ? 'false' : 'true');
			b.classList.toggle('is-off', hidden);
		}
	}

	var loadSeq = 0;
	function load(t) {
		var s = st(t);
		var seq = ++loadSeq;
		var wrap = document.querySelector('[data-tablewrap]');
		if (wrap) wrap.classList.add('is-loading');
		return api('/t/' + t, { query: queryParams(t) }).then(function (d) {
			if (seq !== loadSeq || current !== t) return;
			s.data = d;
			if (d.rows.length === 0 && d.total > 0 && s.page > 1) { s.page = 1; return load(t); }
			renderTable(t);
		}).catch(function (e) {
			if (wrap) wrap.innerHTML = '<div class="msm-empty msm-err">' + esc(e.message) + '</div>';
		}).then(function () { if (wrap) wrap.classList.remove('is-loading'); });
	}

	function rowTitle(t, r) {
		switch (t) {
			case 'stal':
				var d = [r.szer, r.wys, r.scianka].filter(function (v) { return v; }).map(function (v) { return fmtNum(v); }).join('×');
				return (r.opis || '') + ' ' + d + (r.gatunek ? ' ' + r.gatunek : '') + (r.dlugosc ? ', L=' + fmtNum(r.dlugosc) + ' m' : '');
			case 'blachy_pelne':
			case 'blachy_niepelne':
				var dim = r.ksztalt === 'koło' ? 'Ø' + fmtNum(r.wymiar_a) : fmtNum(r.wymiar_a) + '×' + fmtNum(r.wymiar_b);
				return 'Blacha ' + (r.gatunek || '') + ' gr. ' + fmtNum(r.grubosc) + ' ' + dim + (r.material ? ' ' + r.material : '');
			case 'kregi':
				return 'Krąg ' + (r.oznaczenie || '') + ' ' + (r.izolacja || '') + ' ' + fmtNum(r.grubosc) + '×' + fmtNum(r.szerokosc) + (r.lokalizacja ? ' (' + r.lokalizacja + ')' : '');
			case 'bhp':
				return (r.kategoria ? r.kategoria + ' – ' : '') + (r.nazwa || '') + (r.producent_id ? ' (' + r.producent_id + ')' : '') + (r.rozmiar ? ', rozm. ' + r.rozmiar : '');
			case 'bhp_osoby':
				return (r.imie_nazwisko || '') + (r.dzial ? ' (' + r.dzial + ')' : '');
		}
		return '#' + r.id;
	}

	function renderTable(t) {
		var s = st(t), d = s.data, cols = colsFor(t).filter(function (c) { return !c.hidden; });
		var wrap = document.querySelector('[data-tablewrap]');
		var stock = S[t].stock;
		var canSel = ((canStock() || C.canPurge) && stock) || (S[t].edit && C.canEdit) || (C.canPurge && t === 'historia');
		var actions = stock || S[t].narzedzia || t === 'historia' || t === 'wnioski' || t === 'wz' || t === 'pz' || t === 'rezerwacje' || (C.canEdit && (t === 'pobrania' || S[t].edit));
		if (!wrap) return;

		if (!d.rows.length) {
			wrap.innerHTML = '<div class="msm-empty">Brak pozycji spełniających kryteria.</div>';
		} else {
			var orderby = s.orderby || null;
			var html = '<table class="msm-table msm-t-' + t + '"><thead><tr>' +
				(canSel ? '<th class="msm-sel"><input type="checkbox" data-selall aria-label="Zaznacz wszystkie"></th>' : '') +
				cols.map(function (c) {
					var cls = (c.type === 'num' || c.type === 'int') ? 'num' : '';
					var arrow = orderby === c.key ? (s.order === 'desc' ? ' ▼' : ' ▲') : '';
					return '<th class="' + cls + '" data-sort="' + c.key + '" title="Sortuj">' + esc(c.label) + '<span class="msm-arrow">' + arrow + '</span></th>';
				}).join('') +
				(actions ? '<th class="msm-act-h"></th>' : '') + '</tr></thead><tbody>';

			d.rows.forEach(function (r) {
				var zero = stock && Number(r.ilosc) === 0;
				html += '<tr data-id="' + r.id + '" class="' + (zero ? 'is-zero' : '') + '">' +
					(canSel ? '<td class="msm-sel"><input type="checkbox" data-sel="' + r.id + '"' + (s.selected[r.id] ? ' checked' : '') + ' aria-label="Zaznacz"></td>' : '');
				cols.forEach(function (c) {
					var v = r[c.key];
					var txt = fmtCell(c, v);
					if (t === 'wz' && c.key === 'numer' && txt && !/^WZ\b/.test(txt)) txt = 'WZ ' + txt; // jednolity zapis numerów: „WZ 04/11/2026”
					var cls = (c.type === 'num' || c.type === 'int') ? 'num' : '';
					if (c.computed && (v === null || v === undefined)) {
						txt = '<span class="msm-muted" title="Brak wymiarów potrzebnych do obliczenia">—</span>';
					} else {
						txt = esc(txt);
					}
					if (c.key === 'ilosc' && zero) txt = '<span class="msm-zero">0</span>';
					if (t === 'bhp' && c.key === 'ilosc') { var _q = Number(r.ilosc) || 0; var _cls = _q <= 0 ? 'red' : (_q < 3 ? 'yellow' : 'green'); var _mn = Number(r.st_mag_nowy) || 0, _mu = Number(r.st_mag_uzywany) || 0, _sn = Number(r.st_szafa_nowy) || 0, _su = Number(r.st_szafa_uzywany) || 0; txt = '<span class="msm-bhp-dot msm-bhp-dot--' + _cls + '" title="Magazyn: nowy ' + _mn + ' / uż. ' + _mu + ' · Szafa BHP: nowy ' + _sn + ' / uż. ' + _su + '"></span>' + txt; }
					if (c.key === 'ilosc' && r.odc_txt) txt += '<small class="msm-odc-cell">' + esc(r.odc_txt) + '</small>';
					if (REZ_T.indexOf(t) >= 0 && c.key === 'ilosc' && r._rez > 0) txt += '<small class="msm-rez-cell" title="Zarezerwowane pod zlecenia – dostępne ' + fmtNum(Math.max(0, r.ilosc - r._rez)) + ' z ' + fmtNum(r.ilosc) + ' ' + U(t) + '">rez. ' + fmtNum(r._rez) + ' · dost. ' + fmtNum(Math.max(0, r.ilosc - r._rez)) + '</small>';
					if (c.key === 'ilosc' && stock && INW.active) txt = '<span class="msm-inw-qtywrap"><input type="text" inputmode="decimal" class="msm-inw-qty" data-qty="' + r.id + '" value="' + esc(numIn(v)) + '" aria-label="Ilość [' + U(t) + ']" title="Wpisz nową ilość albo +/− zmianę (np. +50, -12,5) i naciśnij Enter"><small>' + (isKg(t) ? 'kg' : 'szt') + '</small></span>';
					if (c.key === 'akcja') txt = '<span class="msm-tag msm-tag-' + esc(String(v).split(/[\s:]/)[0]) + '">' + txt + '</span>';
					if (t === 'wz' && c.key === 'status') txt = '<span class="msm-tag msm-tag-wz-' + esc(v) + '">' + esc(WZ_LABELS[v] || v) + '</span>';
					if (t === 'pz' && c.key === 'status') txt = '<span class="msm-tag msm-tag-pz-' + esc(v) + '">' + esc(PZ_LABELS[v] || v) + '</span>';
					if (t === 'pz' && c.key === 'numer') txt = '<b>' + esc(v) + '</b>';
					if (t === 'wz' && c.key === 'numer') txt = v ? '<b>' + esc(v) + '</b>' : '<span class="msm-muted">—</span>';
					if (t === 'wnioski' && c.key === 'typ') txt = '<span class="msm-tag msm-tag-typ-' + esc(v) + '">' + esc(W_TYPES[v] || v) + '</span>';
					if (t === 'wnioski' && c.key === 'status') txt = '<span class="msm-tag msm-tag-st-' + esc(v) + '">' + esc(W_LABELS[v] || v) + '</span>';
					if (t === 'rezerwacje' && c.key === 'status') txt = '<span class="msm-tag msm-tag-rez-' + esc(v) + '">' + esc(REZ_LABELS[v] || v) + '</span>';
					if (t === 'rezerwacje' && c.key === 'ilosc') { txt = esc(fmtNum(v) + (r.tryb === 'odcinek' ? ' m' : ' szt.')); if (r.odc_txt) txt += '<small class="msm-odc-cell">' + esc(r.odc_txt) + '</small>'; }
					if (t === 'rezerwacje' && c.key === 'termin') txt = v ? esc(fmtDate(v)) : '<span class="msm-muted">bez terminu</span>';
					if (c.key === 'wpisana') txt = v ? '<span class="msm-tag msm-tag-ok">tak</span>' : '<span class="msm-tag msm-tag-no">nie</span>';
					if (S[t].narzedzia && c.key === 'status' && v) txt = '<span class="msm-tag ' + (/tak/i.test(v) ? 'msm-tag-ok' : 'msm-tag-no') + '">' + esc(v) + '</span>';
					if (S[t].narzedzia && c.key === 'regal') txt = /^HALA$/i.test(String(v || '').trim()) ? '<span class="msm-tag msm-tag-hala">HALA</span>' : (v ? esc(v) : '<span class="msm-muted">—</span>');
					if (S[t].narzedzia && c.key === 'uzyty' && v) txt = splitTags(v).map(function (tg) { return '<span class="msm-chip msm-chip-sm">' + esc(tg) + '</span>'; }).join(' ');
					html += '<td class="' + cls + (c.long ? ' long' : '') + '" data-label="' + esc(c.label) + '">' + txt + '</td>';
				});
				if (actions) {
					html += '<td class="msm-act">';
					if (stock && INW.active) {
						html += r._hist
							? '<button type="button" class="msm-iconbtn msm-iconbtn-hist" data-hist="' + r.id + '" title="Historia pozycji" aria-label="Historia">' + ICON_HIST + '</button>'
							: '<span class="msm-iconbtn msm-iconbtn-empty" aria-hidden="true"></span>';
						html += '<button type="button" class="msm-iconbtn" data-edit="' + r.id + '" title="Edytuj" aria-label="Edytuj">' + ICON_EDIT + '</button>' +
							'<button type="button" class="msm-iconbtn msm-iconbtn-danger" data-del="' + r.id + '" title="Usuń" aria-label="Usuń">' + ICON_DEL + '</button>';
					} else if (stock) {
						html += r.ilosc > 0
							? '<button type="button" class="msm-btn msm-btn-sm msm-btn-primary" data-pobierz="' + r.id + '"' + (C.canEdit ? '' : ' title="Złóż wniosek o pobranie – zatwierdza administrator"') + '>Pobierz</button>'
							: '<span class="msm-btn msm-btn-sm msm-btn-spacer" aria-hidden="true">Pobierz</span>';
						if (REZ_T.indexOf(t) >= 0) html += (r.ilosc > 0
							? '<button type="button" class="msm-iconbtn msm-iconbtn-rez" data-rezerwuj="' + r.id + '" title="Rezerwuj pod zlecenie" aria-label="Rezerwuj">' + ICO_REZ + '</button>'
							: '<span class="msm-iconbtn msm-iconbtn-empty" aria-hidden="true"></span>');
						html += r._hist
							? '<button type="button" class="msm-iconbtn msm-iconbtn-hist" data-hist="' + r.id + '" title="Historia pozycji – pobrania, sprawdzenia, zmiany" aria-label="Historia">' + ICON_HIST + '</button>'
							: '<span class="msm-iconbtn msm-iconbtn-empty" aria-hidden="true"></span>';
						if (cEdit()) {
							if (t === 'blachy_pelne') {
								html += '<button type="button" class="msm-iconbtn" data-toniep="' + r.id + '" title="Przenieś do blach niepełnych" aria-label="Przenieś do blach niepełnych">' + ICON_MOVE + '</button>';
							}
							html += '<button type="button" class="msm-iconbtn" data-edit="' + r.id + '" title="Edytuj" aria-label="Edytuj">' + ICON_EDIT + '</button>' +
								'<button type="button" class="msm-iconbtn msm-iconbtn-danger" data-del="' + r.id + '" title="Usuń" aria-label="Usuń">' + ICON_DEL + '</button>';
						}
					} else if (t === 'pobrania') {
						html += '<button type="button" class="msm-iconbtn" data-edit="' + r.id + '" title="Edytuj" aria-label="Edytuj">' + ICON_EDIT + '</button>';
						if (cEdit() && ['stal', 'blachy_pelne', 'blachy_niepelne'].indexOf(r.item_table) >= 0) {
							html += '<button type="button" class="msm-btn msm-btn-sm" data-pzwrot="' + r.id + '" title="Zwróć resztę na magazyn jako nową pozycję (nowe wymiary)">Zwrot na magazyn</button>';
						}
						html += '<button type="button" class="msm-btn msm-btn-sm msm-btn-danger-ghost" data-cancel="' + r.id + '">Anuluj</button>';
					} else if (t === 'wz') {
						var wzAdminEdit = C.canEdit && capOn('wz') && r.status === 'wystawiona';
						var editable = (r.status === 'szkic' || (C.canEdit && r.status === 'do_zatwierdzenia') || wzAdminEdit);
						html += '<button type="button" class="msm-btn msm-btn-sm' + (editable ? ' msm-btn-primary' : '') + '" data-wzopen="' + r.id + '"' + (wzAdminEdit ? ' data-wzedit-direct' : '') + '>' + (editable ? 'Edytuj' : 'Otwórz') + '</button>' +
							'<button type="button" class="msm-iconbtn" data-wzprint="' + r.id + '" title="Drukuj (A4, Oryginał + Kopia)" aria-label="Drukuj">' + ICON_PRINT + '</button>';
					} else if (t === 'pz') {
						html += '<button type="button" class="msm-btn msm-btn-sm" data-pzopen="' + r.id + '">Otwórz</button>';
					} else if (t === 'wnioski') {
						html += '<button type="button" class="msm-iconbtn" data-print="' + r.id + '" title="Drukuj (A4, 2 kopie)" aria-label="Drukuj">' + ICON_PRINT + '</button>';
						if (r.status === 'nowy' && r.user_id === C.userId) html += '<button type="button" class="msm-btn msm-btn-sm" data-wedit="' + r.id + '" title="Popraw wniosek – magazyn dostanie e-mail z poprawioną wersją">Popraw</button>';
						if (r.typ === 'sprawdzenie') {
							if (C.canEdit && r.status === 'nowy') {
								html += '<button type="button" class="msm-btn msm-btn-sm msm-btn-primary" data-wact="jest" data-wid="' + r.id + '">Jest na stanie</button>' +
									'<button type="button" class="msm-btn msm-btn-sm msm-btn-danger-ghost" data-wact="brak" data-wid="' + r.id + '">Brak</button>';
							} else if (!C.canEdit && r.status === 'nowy') {
								html += '<button type="button" class="msm-btn msm-btn-sm msm-btn-danger-ghost" data-wact="anuluj" data-wid="' + r.id + '">Anuluj</button>';
							} else if (r.status === 'potwierdzony' && r.next_id) {
								html += '<span class="msm-muted msm-small">Wysłano jako #' + r.next_id + '</span>';
							} else if (r.status === 'potwierdzony' && (!C.canEdit || r.user_id === C.userId)) {
								html += '<button type="button" class="msm-btn msm-btn-sm msm-btn-primary" data-wsend="' + r.id + '">Wyślij zapotrzebowanie</button>';
							}
						} else if (C.canEdit && r.status === 'nowy') {
							html += '<button type="button" class="msm-btn msm-btn-sm msm-btn-primary" data-wact="akceptuj" data-wid="' + r.id + '">Akceptuj</button>' +
								'<button type="button" class="msm-btn msm-btn-sm msm-btn-danger-ghost" data-wact="odrzuc" data-wid="' + r.id + '">Odrzuć</button>';
						} else if (C.canEdit && r.status === 'zaakceptowany') {
							html += '<button type="button" class="msm-btn msm-btn-sm msm-btn-primary" data-wact="wydaj" data-wid="' + r.id + '">Wydano</button>' +
								(['stal', 'blachy_pelne', 'blachy_niepelne'].indexOf(r.item_table) >= 0 ? '<button type="button" class="msm-btn msm-btn-sm" data-wzwrot="' + r.id + '" title="Zwróć resztę na magazyn jako nową pozycję (nowe wymiary)">Zwrot na magazyn</button>' : '') +
								'<button type="button" class="msm-btn msm-btn-sm msm-btn-danger-ghost" data-wact="odrzuc" data-wid="' + r.id + '">Odrzuć</button>';
						} else if (!C.canEdit && r.status === 'nowy') {
							html += '<button type="button" class="msm-btn msm-btn-sm msm-btn-danger-ghost" data-wact="anuluj" data-wid="' + r.id + '">Anuluj wniosek</button>';
						}
					} else if (S[t].narzedzia) {
						if (cEdit()) {
							var onHala = /^HALA$/i.test(String(r.regal || '').trim());
							html += onHala
								? '<button type="button" class="msm-btn msm-btn-sm msm-btn-primary" data-zwrot="' + r.id + '" title="Zwróć na regał">Zwróć</button>'
								: '<button type="button" class="msm-btn msm-btn-sm" data-hala="' + r.id + '" title="Pobierz – wydaj na halę">Pobierz</button>';
							html += '<button type="button" class="msm-iconbtn" data-edit="' + r.id + '" title="Edytuj" aria-label="Edytuj">' + ICON_EDIT + '</button>' +
								'<button type="button" class="msm-iconbtn msm-iconbtn-danger" data-del="' + r.id + '" title="Usuń" aria-label="Usuń">' + ICON_DEL + '</button>';
						}
					} else if (t === 'rezerwacje') {
						if (C.canEdit && r.status === 'nowa') {
							html += '<button type="button" class="msm-btn msm-btn-sm msm-btn-primary" data-ract="akceptuj" data-rid="' + r.id + '">Zatwierdź</button>' +
								'<button type="button" class="msm-btn msm-btn-sm msm-btn-danger-ghost" data-ract="odrzuc" data-rid="' + r.id + '">Odrzuć</button>';
						} else if (C.canEdit && r.status === 'aktywna') {
							html += '<button type="button" class="msm-btn msm-btn-sm msm-btn-primary" data-ract="wydaj" data-rid="' + r.id + '">Wydaj z rezerwacji</button>' +
								'<button type="button" class="msm-btn msm-btn-sm msm-btn-danger-ghost" data-ract="anuluj" data-rid="' + r.id + '">Anuluj</button>';
						} else if (!C.canEdit && (r.status === 'nowa' || r.status === 'aktywna')) {
							html += '<button type="button" class="msm-btn msm-btn-sm msm-btn-danger-ghost" data-ract="anuluj" data-rid="' + r.id + '">Anuluj</button>';
						}
					} else if (t === 'historia' && r.dane) {
						html += '<button type="button" class="msm-btn msm-btn-sm" data-details="' + r.id + '">Szczegóły</button>';
					} else if (S[t].edit && cEdit()) {
						if (t === 'bhp') {
							if (r.ilosc > 0) html += '<button type="button" class="msm-btn msm-btn-sm msm-btn-primary" data-bhpwydaj="' + r.id + '" title="Wydaj tę pozycję na osobę">Wydaj</button>';
							html += r._hist
								? '<button type="button" class="msm-iconbtn msm-iconbtn-hist" data-hist="' + r.id + '" title="Historia pozycji – wydania, zmiany stanu" aria-label="Historia">' + ICON_HIST + '</button>'
								: '<span class="msm-iconbtn msm-iconbtn-empty" aria-hidden="true"></span>';
						} else if (t === 'bhp_osoby') {
							html += '<button type="button" class="msm-iconbtn" data-bhposoba="' + r.id + '" title="Karta wyposażenia / wydruk wydań" aria-label="Karta / wydruk">' + ICON_PRINT + '</button>';
						}
						html += '<button type="button" class="msm-iconbtn" data-edit="' + r.id + '" title="Edytuj" aria-label="Edytuj">' + ICON_EDIT + '</button>' +
							'<button type="button" class="msm-iconbtn msm-iconbtn-danger" data-del="' + r.id + '" title="Usuń" aria-label="Usuń">' + ICON_DEL + '</button>';
					}
					html += '</td>';
				}
				html += '</tr>';
			});
			html += '</tbody></table>';
			wrap.innerHTML = html;
			bindTable(t, wrap);
		}
		renderFoot(t);
		renderBulk(t);
	}

	function findRow(t, id) {
		var rows = st(t).data ? st(t).data.rows : [];
		for (var i = 0; i < rows.length; i++) if (rows[i].id === id) return rows[i];
		return null;
	}

	function bindTable(t, wrap) {
		var s = st(t);
		wrap.querySelectorAll('[data-sort]').forEach(function (th) {
			th.addEventListener('click', function () {
				var k = th.getAttribute('data-sort');
				if (s.orderby === k) { s.order = s.order === 'desc' ? 'asc' : 'desc'; } else { s.orderby = k; s.order = 'asc'; }
				saveState(t); load(t);
			});
		});
		wrap.querySelectorAll('[data-edit]').forEach(function (b) {
			b.addEventListener('click', function () { openForm(t, findRow(t, +b.getAttribute('data-edit'))); });
		});
		wrap.querySelectorAll('[data-hala]').forEach(function (b) {
			b.addEventListener('click', function () { narzHala(t, +b.getAttribute('data-hala'), b); });
		});
		wrap.querySelectorAll('[data-zwrot]').forEach(function (b) {
			b.addEventListener('click', function () { narzZwrot(t, findRow(t, +b.getAttribute('data-zwrot'))); });
		});
		wrap.querySelectorAll('[data-qty]').forEach(function (inp) {
			var orig = inp.value;
			var r = findRow(t, +inp.getAttribute('data-qty'));
			function saveQty() {
				var v = inp.value.trim().replace(/\s/g, '').replace('−', '-');
				if (v === orig) return;
				var rel = /^[+-]/.test(v) && orig !== '';
				var num = Number(v.replace(',', '.'));
				if (v === '' || !isFinite(num)) { toast('Wpisz liczbę, np. 250 albo +50 / -12,5.', 'err'); inp.value = orig; return; }
				if (rel) {
					num = Math.round((Number(orig.replace(',', '.')) + num) * 1000) / 1000;
					if (num < 0) { toast('Stan nie może być ujemny.', 'err'); inp.value = orig; return; }
					v = numIn(num);
					inp.value = v;
				}
				var prev = orig;
				orig = v;
				api('/t/' + t + '/' + r.id, { method: 'POST', body: { ilosc: v } }).then(function (row) {
					orig = inp.value = numIn(row.ilosc); r.ilosc = row.ilosc; r._hist = true;
					inp.classList.add('is-saved'); setTimeout(function () { inp.classList.remove('is-saved'); }, 1400);
					inp.closest('tr').classList.toggle('is-zero', Number(row.ilosc) === 0);
					toast('Zapisano: ' + rowTitle(t, r) + ' → ' + fmtNum(row.ilosc) + ' ' + U(t));
					if (state[t]) state[t].options = null;
					pollInw();
				}).catch(function (e) { toast(e.message, 'err'); orig = prev; inp.value = prev; });
			}
			inp.addEventListener('keydown', function (e) {
				if (e.key === 'Enter') { e.preventDefault(); saveQty(); var all = Array.prototype.slice.call(wrap.querySelectorAll('[data-qty]')); var nx = all[all.indexOf(inp) + 1]; if (nx) { nx.focus(); nx.select(); } }
				if (e.key === 'Escape') { inp.value = orig; inp.blur(); }
			});
			inp.addEventListener('blur', saveQty);
			inp.addEventListener('focus', function () { inp.select(); });
		});
		wrap.querySelectorAll('[data-del]').forEach(function (b) {
			b.addEventListener('click', function () {
				var r = findRow(t, +b.getAttribute('data-del'));
				confirmBox('Usunąć pozycję?', esc(rowTitle(t, r)) + '<br><span class="msm-muted">Operacja zostanie zapisana w historii zmian.</span>', 'Usuń', true).then(function (ok) {
					if (!ok) return;
					api('/t/' + t + '/' + r.id, { method: 'DELETE' }).then(function () {
						toast('Usunięto pozycję.'); delete s.selected[r.id]; refresh(t);
					}).catch(function (e) { toast(e.message, 'err'); });
				});
			});
		});
		wrap.querySelectorAll('[data-bhpwydaj]').forEach(function (b) {
			b.addEventListener('click', function () { openWydanieBhp(findRow(t, +b.getAttribute('data-bhpwydaj'))); });
		});
		wrap.querySelectorAll('[data-bhposoba]').forEach(function (b) {
			b.addEventListener('click', function () { openOsobaKarta(findRow(t, +b.getAttribute('data-bhposoba'))); });
		});
		wrap.querySelectorAll('[data-toniep]').forEach(function (b) {
			b.addEventListener('click', function () {
				var r = findRow(t, +b.getAttribute('data-toniep'));
				confirmBox('Przenieść do blach niepełnych?', esc(rowTitle(t, r)) + '<br><span class="msm-muted">Pozycja zniknie z „Blach pełnych" i pojawi się w „Blachach niepełnych" (kształt: prostokąt). Zapisane w historii.</span>', 'Przenieś', false).then(function (ok) {
					if (!ok) return;
					api('/blacha/' + r.id + '/do-niepelnych', { method: 'POST' }).then(function (res) {
						toast(res.message || 'Przeniesiono do blach niepełnych.'); delete s.selected[r.id];
						invalidate('blachy_pelne'); invalidate('blachy_niepelne'); refresh('blachy_pelne');
					}).catch(function (e) { toast(e.message, 'err'); });
				});
			});
		});
		wrap.querySelectorAll('[data-pobierz]').forEach(function (b) {
			b.addEventListener('click', function () { openPobranie(t, findRow(t, +b.getAttribute('data-pobierz'))); });
		});
		wrap.querySelectorAll('[data-cancel]').forEach(function (b) {
			b.addEventListener('click', function () {
				var r = findRow(t, +b.getAttribute('data-cancel'));
				confirmBox('Anulować pobranie?', 'Na stan wróci <b>' + esc(fmtNum(r.ilosc) + ' ' + r.jednostka) + '</b>: ' + esc(r.material) + '.', 'Anuluj pobranie', true).then(function (ok) {
					if (!ok) return;
					api('/t/pobrania/' + r.id, { method: 'DELETE' }).then(function (res) {
						if (res.warning) toast(res.warning, 'warn'); else toast('Pobranie anulowane, stan przywrócony.');
						refresh(t); invalidate(r.item_table);
					}).catch(function (e) { toast(e.message, 'err'); });
				});
			});
		});
		wrap.querySelectorAll('[data-pzopen]').forEach(function (b) {
			b.addEventListener('click', function () { openPZ(+b.getAttribute('data-pzopen')); });
		});
		wrap.querySelectorAll('[data-wzopen]').forEach(function (b) {
			b.addEventListener('click', function () { openWZ(+b.getAttribute('data-wzopen'), b.hasAttribute('data-wzedit-direct')); });
		});
		wrap.querySelectorAll('[data-wzprint]').forEach(function (b) {
			b.addEventListener('click', function () { window.open(printUrl({ msm_print: 'wz', id: b.getAttribute('data-wzprint') }), '_blank'); });
		});
		wrap.querySelectorAll('[data-hist]').forEach(function (b) {
			b.addEventListener('click', function () { openItemHistory(t, +b.getAttribute('data-hist')); });
		});
		wrap.querySelectorAll('[data-print]').forEach(function (b) {
			b.addEventListener('click', function () { window.open(printUrl({ msm_print: 'wniosek', id: b.getAttribute('data-print') }), '_blank'); });
		});
		wrap.querySelectorAll('[data-wsend]').forEach(function (b) {
			b.addEventListener('click', function () { sendFromCheck(findRow(t, +b.getAttribute('data-wsend')), b); });
		});
		wrap.querySelectorAll('[data-wedit]').forEach(function (b) {
			b.addEventListener('click', function () { wniosekEdit(findRow(t, +b.getAttribute('data-wedit'))); });
		});
		wrap.querySelectorAll('[data-wact]').forEach(function (b) {
			b.addEventListener('click', function () { wniosekAction(findRow(t, +b.getAttribute('data-wid')), b.getAttribute('data-wact')); });
		});
		wrap.querySelectorAll('[data-pzwrot]').forEach(function (b) {
			b.addEventListener('click', function () { openZwrot(findRow(t, +b.getAttribute('data-pzwrot')), 'pobrania'); });
		});
		wrap.querySelectorAll('[data-wzwrot]').forEach(function (b) {
			b.addEventListener('click', function () { openZwrot(findRow(t, +b.getAttribute('data-wzwrot'))); });
		});
		wrap.querySelectorAll('[data-rezerwuj]').forEach(function (b) {
			b.addEventListener('click', function () { openRezerwacja(findRow(t, +b.getAttribute('data-rezerwuj')), t); });
		});
		wrap.querySelectorAll('[data-ract]').forEach(function (b) {
			b.addEventListener('click', function () { rezerwacjaAction(findRow(t, +b.getAttribute('data-rid')), b.getAttribute('data-ract')); });
		});
		wrap.querySelectorAll('[data-details]').forEach(function (b) {
			b.addEventListener('click', function () { openDetails(findRow(t, +b.getAttribute('data-details'))); });
		});
		var all = wrap.querySelector('[data-selall]');
		if (all) {
			all.addEventListener('change', function () {
				wrap.querySelectorAll('[data-sel]').forEach(function (cb) {
					cb.checked = all.checked;
					if (all.checked) s.selected[cb.getAttribute('data-sel')] = true; else delete s.selected[cb.getAttribute('data-sel')];
				});
				renderBulk(t);
			});
		}
		wrap.querySelectorAll('[data-sel]').forEach(function (cb) {
			cb.addEventListener('change', function () {
				if (cb.checked) s.selected[cb.getAttribute('data-sel')] = true; else delete s.selected[cb.getAttribute('data-sel')];
				renderBulk(t);
			});
		});
	}

	function renderBulk(t) {
		var s = st(t);
		var box = document.querySelector('[data-bulk]');
		if (!box) return;
		var selectable = ((canStock() || C.canPurge) && S[t].stock) || (S[t].edit && C.canEdit) || (C.canPurge && t === 'historia');
		var total = (s.data && s.data.total) || 0;
		var ids = Object.keys(s.selected);
		if (!ids.length) {
			if (!selectable || !total) { box.hidden = true; box.innerHTML = ''; box.classList.remove('msm-bulk--idle'); return; }
			box.hidden = false; box.classList.add('msm-bulk--idle');
			box.innerHTML = '<span>Zaznaczanie</span><button type="button" class="msm-btn msm-btn-sm" data-selall-all>Zaznacz wszystkie (' + total + ')</button>';
			box.querySelector('[data-selall-all]').addEventListener('click', function () { selectAllFiltered(t); });
			return;
		}
		box.hidden = false; box.classList.remove('msm-bulk--idle');
		box.innerHTML = '<span>Zaznaczono: <b>' + ids.length + '</b>' + (total && ids.length < total ? ' z ' + total : '') + '</span><button type="button" class="msm-btn msm-btn-sm" data-unsel>Odznacz</button>' +
			(total && ids.length < total ? '<button type="button" class="msm-btn msm-btn-sm" data-selall-all>Zaznacz wszystkie (' + total + ')</button>' : '') +
			((canStock() || (S[t].edit && C.canEdit)) && t !== 'historia' && t !== 'pobrania' ? '<button type="button" class="msm-btn msm-btn-sm msm-btn-primary" data-bulkedit>Edytuj zaznaczone</button>' : '') +
			(canStock() || (S[t].edit && C.canEdit) ? '<button type="button" class="msm-btn msm-btn-sm msm-btn-danger" data-bulkdel>Usuń zaznaczone</button>' : '') +
			(t !== 'historia' ? '<button type="button" class="msm-btn msm-btn-sm" data-printsel>Drukuj zaznaczone</button>' : '') +
			(C.canPurge && t === 'historia' ? '<button type="button" class="msm-btn msm-btn-sm msm-btn-danger" data-histpurge title="Trwałe usunięcie wybranych wpisów historii">Usuń zaznaczone wpisy</button>' : '') +
			(C.canPurge && t !== 'historia' ? '<button type="button" class="msm-btn msm-btn-sm msm-btn-danger-ghost" data-purge title="Trwałe usunięcie bez śladu w systemie">Usuń trwale bez śladu</button>' : '');
		var psel = box.querySelector('[data-printsel]');
		if (psel) psel.addEventListener('click', function () {
			window.open(printUrl({ msm_print: 'lista', t: t, ids: ids.join(',') }), '_blank');
		});
		var hp = box.querySelector('[data-histpurge]');
		if (hp) hp.addEventListener('click', function () {
			confirmBox('Usunąć ' + ids.length + ' wpis(ów) historii?', 'Zaznaczone wpisy dziennika zmian zostaną <b>trwale usunięte bez śladu</b>. Tej operacji nie można cofnąć. Uprawnienie ma tylko super administrator.', 'Usuń wpisy', true).then(function (ok) {
				if (!ok) return;
				api('/t/historia/purge', { method: 'POST', body: { ids: ids.map(Number) } }).then(function (r) {
					toast('Usunięto ' + r.deleted + ' wpis(ów) historii.'); s.selected = {}; refresh('historia');
				}).catch(function (e) { toast(e.message, 'err'); });
			});
		});
		var pg = box.querySelector('[data-purge]');
		if (pg) pg.addEventListener('click', function () {
			var mm = openModal('Usunąć trwale bez śladu?', '<p>Zaznaczone pozycje (' + ids.length + ') zostaną usunięte <b>razem z całą historią i powiązanymi pobraniami</b>. W systemie nie zostanie żaden wpis o usunięciu. <b>Tej operacji nie da się cofnąć.</b></p>' +
				'<label class="msm-field full"><span>Aby potwierdzić, wpisz: USUŃ</span><input type="text" name="confirm" autocomplete="off"></label>',
				'<button type="button" class="msm-btn" data-close>Anuluj</button><button type="button" class="msm-btn msm-btn-danger" data-ok disabled>Usuń trwale</button>');
			var inp = mm.querySelector('[name=confirm]'), okb = mm.querySelector('[data-ok]');
			inp.addEventListener('input', function () { okb.disabled = inp.value.trim().toUpperCase() !== 'USUŃ'; });
			okb.addEventListener('click', function () {
				okb.disabled = true;
				api('/t/' + t + '/purge', { method: 'POST', body: { ids: ids.map(Number) } }).then(function (r) {
					closeModal(); toast('Usunięto trwale ' + r.deleted + ' poz.'); s.selected = {}; invalidate('pobrania'); invalidate('historia'); refresh(t);
				}).catch(function (e) { okb.disabled = false; toast(e.message, 'err'); });
			});
		});
		box.querySelector('[data-unsel]').addEventListener('click', function () { s.selected = {}; renderTable(t); });
		var sa = box.querySelector('[data-selall-all]');
		if (sa) sa.addEventListener('click', function () { selectAllFiltered(t); });
		var be = box.querySelector('[data-bulkedit]');
		if (be) be.addEventListener('click', function () { openBulkEdit(t, ids.map(Number)); });
		var bd = box.querySelector('[data-bulkdel]');
		if (bd) bd.addEventListener('click', function () {
			confirmBox('Usunąć ' + ids.length + ' poz.?', 'Zaznaczone pozycje zostaną usunięte. Operacja zostanie zapisana w historii zmian.', 'Usuń', true).then(function (ok) {
				if (!ok) return;
				api('/t/' + t + '/bulk-delete', { method: 'POST', body: { ids: ids.map(Number) } }).then(function (r) {
					toast('Usunięto ' + r.deleted + ' poz.'); s.selected = {}; refresh(t);
				}).catch(function (e) { toast(e.message, 'err'); });
			});
		});
	}

	function renderFoot(t) {
		var s = st(t), d = s.data;
		var foot = document.querySelector('[data-foot]');
		if (!foot || !d) return;
		var sums = [];
		sums.push('<span>Pozycji: <b>' + d.total + '</b></span>');
		colsFor(t).forEach(function (c) {
			if (c.sum && d.sums && d.sums[c.key] !== undefined && d.sums[c.key] !== null) {
				sums.push('<span>' + esc(c.label.replace(/\s*\[.*\]/, '')) + ': <b>' + fmtNum(d.sums[c.key], c.decimals != null ? c.decimals : 2) + '</b></span>');
			}
		});
		var cnt = document.querySelector('[data-count]');
		if (cnt) cnt.textContent = d.total + ' ' + (d.total === 1 ? 'pozycja' : (d.total % 10 >= 2 && d.total % 10 <= 4 && (d.total % 100 < 10 || d.total % 100 >= 20) ? 'pozycje' : 'pozycji'));
		var pages = Math.max(1, Math.ceil(d.total / d.per_page));
		foot.innerHTML = '<div class="msm-sums">' + sums.join('') + '</div>' +
			'<div class="msm-pager">' +
			'<select data-pp aria-label="Na stronie">' + [25, 50, 100, 250, 0].map(function (n) {
				return '<option value="' + n + '"' + (Number(s.per_page) === n ? ' selected' : '') + '>' + (n ? n + ' / str.' : 'wszystkie') + '</option>';
			}).join('') + '</select>' +
			(pages > 1 ? '<button type="button" class="msm-btn msm-btn-sm" data-pg="-1"' + (s.page <= 1 ? ' disabled' : '') + '>‹</button>' +
				'<span>' + s.page + ' / ' + pages + '</span>' +
				'<button type="button" class="msm-btn msm-btn-sm" data-pg="1"' + (s.page >= pages ? ' disabled' : '') + '>›</button>' : '') +
			'</div>';
		foot.querySelector('[data-pp]').addEventListener('change', function (e) { s.per_page = Number(e.target.value); s.page = 1; saveState(t); load(t); });
		foot.querySelectorAll('[data-pg]').forEach(function (b) {
			b.addEventListener('click', function () {
				s.page = Math.min(pages, Math.max(1, s.page + Number(b.getAttribute('data-pg'))));
				load(t);
				document.getElementById('msm-main').scrollIntoView({ behavior: 'smooth' });
			});
		});
	}

	function selectAllFiltered(t) {
		var s = st(t);
		var q = queryParams(t); q.page = 1; q.per_page = 5000;
		api('/t/' + t, { query: q }).then(function (d) {
			(d.rows || []).forEach(function (r) { s.selected[r.id] = true; });
			renderTable(t);
			toast('Zaznaczono ' + Object.keys(s.selected).length + ' poz.' + ((d.total && d.total > 5000) ? ' (pierwsze 5000)' : ''));
		}).catch(function (e) { toast(e.message, 'err'); });
	}

	function openBulkEdit(t, ids) {
		var cols = colsFor(t).filter(function (c) { return !c.computed && c.key !== 'id' && !c.taglist && !c.pool; });
		if (!cols.length) { toast('Brak pól do edycji.', 'err'); return; }
		var body = '<form class="msm-form" novalidate><div class="msm-form-err msm-alert msm-alert-err" hidden></div>' +
			'<p class="msm-muted msm-small">Zmiana zostanie zastosowana do <b>' + ids.length + '</b> zaznaczonych pozycji i zapisana w historii zmian.</p>' +
			'<label class="msm-field"><span>Pole do zmiany</span><select name="__field">' + cols.map(function (c) { return '<option value="' + esc(c.key) + '">' + esc(c.label) + '</option>'; }).join('') + '</select></label>' +
			'<div data-valwrap></div></form>';
		var m = openModal('Edytuj zaznaczone (' + ids.length + ')', body, '<button type="button" class="msm-btn" data-close>Anuluj</button><button type="button" class="msm-btn msm-btn-primary" data-save>Zastosuj do ' + ids.length + ' poz.</button>', true);
		var form = m.querySelector('form');
		var fsel = form.querySelector('[name=__field]');
		var wrap = form.querySelector('[data-valwrap]');
		function colOf(k) { return cols.filter(function (x) { return x.key === k; })[0]; }
		function renderVal() {
			var c = colOf(fsel.value);
			wrap.innerHTML = fieldHtml(t, c, (c.default !== undefined ? c.default : ''), st(t).options || {});
			var np = wrap.querySelector('[data-normapick]'); if (np) fillNormaSelect(np, '');
		}
		fsel.addEventListener('change', renderVal); renderVal();
		m.querySelector('[data-save]').addEventListener('click', function () {
			var field = fsel.value;
			var el = wrap.querySelector('[name="' + field + '"]');
			var value = el ? (el.type === 'checkbox' ? el.checked : el.value) : '';
			var btn = this; btn.disabled = true;
			api('/t/' + t + '/bulk-edit', { method: 'POST', body: { ids: ids, field: field, value: value } }).then(function (r) {
				closeModal(); toast('Zmieniono „' + ((colOf(field) || {}).label || field) + '” w ' + r.updated + ' poz.'); st(t).selected = {}; refresh(t);
			}).catch(function (e) { btn.disabled = false; toast(e.message, 'err'); });
		});
	}

	function invalidate(t) { if (state[t]) { state[t].options = null; state[t].data = null; } }
	function refresh(t) {
		loadOptions(t, true);
		loadFilterOptions(t).then(function () { if (current === t) renderFilters(t); });
		load(t);
	}

	/* ---------------- formularz dodawania / edycji ---------------- */

	function splitTags(v) {
		return String(v == null ? '' : v).split(/[\n,;]+/).map(function (s) { return s.trim(); }).filter(Boolean);
	}
	function taglistField(c, val) {
		var tags = splitTags(val);
		var req = c.required ? ' <i class="msm-req">*</i>' : '';
		return '<div class="msm-field full msm-taglist" data-field="' + c.key + '" data-taglist>' +
			'<span>' + esc(c.label) + req + '</span>' +
			'<input type="hidden" name="' + c.key + '" value="' + esc(tags.join(', ')) + '">' +
			'<div class="msm-tags" data-tags></div>' +
			'<div class="msm-taglist__add"><input type="text" class="msm-taginput" data-taginput autocomplete="off" placeholder="np. B71200 – Enter lub „Dodaj”"><button type="button" class="msm-btn msm-btn-sm" data-tagadd>Dodaj</button></div>' +
			'<em class="msm-ferr"></em></div>';
	}
	function bindTaglists(form) {
		form.querySelectorAll('[data-taglist]').forEach(function (box) {
			var hid = box.querySelector('input[type=hidden]');
			var wrap = box.querySelector('[data-tags]');
			var inp = box.querySelector('[data-taginput]');
			var tags = splitTags(hid.value);
			function render() {
				wrap.innerHTML = tags.length
					? tags.map(function (tg, i) { return '<span class="msm-chip">' + esc(tg) + '<button type="button" class="msm-chip__x" data-rm="' + i + '" aria-label="Usuń">×</button></span>'; }).join('')
					: '<span class="msm-muted msm-small">Brak — dodaj numery zleceń.</span>';
				hid.value = tags.join(', ');
				wrap.querySelectorAll('[data-rm]').forEach(function (b) {
					b.addEventListener('click', function () { tags.splice(+b.getAttribute('data-rm'), 1); render(); });
				});
			}
			function add() {
				splitTags(inp.value).forEach(function (p) { if (tags.indexOf(p) < 0) tags.push(p); });
				inp.value = ''; render(); inp.focus();
			}
			box.querySelector('[data-tagadd]').addEventListener('click', add);
			inp.addEventListener('keydown', function (e) {
				if (e.key === 'Enter') { e.preventDefault(); e.stopPropagation(); add(); }
			});
			render();
		});
	}

	function fieldHtml(t, c, v, opts) {
		var id = 'msm-f-' + c.key;
		var req = c.required ? ' <i class="msm-req">*</i>' : '';
		var input;
		var val = v === null || v === undefined ? '' : v;
		if (c.taglist) { return taglistField(c, val); }
		if (c.normapick) {
			input = '<select id="' + id + '" name="' + c.key + '" data-normapick><option value="">— brak (bez normy) —</option>' + (val ? '<option value="' + esc(val) + '" selected>' + esc(val) + '</option>' : '') + '</select>';
			return '<label class="msm-field" data-field="' + c.key + '"><span>' + esc(c.label) + req + '</span>' + input + '<em class="msm-ferr"></em></label>';
		}
		switch (c.type) {
			case 'enum':
				input = '<select id="' + id + '" name="' + c.key + '">' + (c.required ? '<option value="">— wybierz —</option>' : '') +
					c.options.map(function (o) { return '<option' + (String(val) === o ? ' selected' : '') + '>' + esc(o) + '</option>'; }).join('') + '</select>';
				break;
			case 'num':
				input = '<input id="' + id + '" name="' + c.key + '" type="text" inputmode="decimal" autocomplete="off" value="' + esc(val === '' ? '' : String(val).replace('.', ',')) + '">';
				break;
			case 'int':
				input = '<input id="' + id + '" name="' + c.key + '" type="number" min="0" step="1" value="' + esc(val) + '">';
				break;
			case 'bool':
				return '<label class="msm-check msm-field-check"><input type="checkbox" name="' + c.key + '"' + (val ? ' checked' : '') + '> ' + esc(c.label) + '</label>';
			case 'date':
				input = '<input id="' + id + '" name="' + c.key + '" type="date" value="' + esc(val) + '">';
				break;
			default:
				if (c.long) {
					input = '<textarea id="' + id + '" name="' + c.key + '" rows="2">' + esc(val) + '</textarea>';
				} else {
					var list = (opts && opts[c.key]) || [];
					input = '<input id="' + id + '" name="' + c.key + '" type="text" autocomplete="off" value="' + esc(val) + '"' + (list.length ? ' list="' + id + '-dl"' : '') + '>' +
						(list.length ? '<datalist id="' + id + '-dl">' + list.filter(function (o) { return o.v !== '__empty__'; }).map(function (o) { return '<option value="' + esc(o.v) + '">'; }).join('') + '</datalist>' : '');
				}
		}
		return '<label class="msm-field' + (c.long ? ' full' : '') + '" data-field="' + c.key + '"><span>' + esc(c.label) + req + '</span>' + input + '<em class="msm-ferr"></em></label>';
	}

	function fillNormaSelect(el, cur) {
		api('/bhp/normy').then(function (list) {
			el.innerHTML = '<option value="">— brak (bez normy) —</option>' + (list || []).map(function (n) { return '<option value="' + esc(n.kategoria) + '"' + (n.kategoria === cur ? ' selected' : '') + '>' + esc(n.kategoria) + (n.limit ? ' (max ' + n.limit + ')' : '') + '</option>'; }).join('');
			if (cur && !(list || []).some(function (n) { return n.kategoria === cur; })) { el.insertAdjacentHTML('beforeend', '<option value="' + esc(cur) + '" selected>' + esc(cur) + '</option>'); }
		}).catch(function () {});
	}

	function readForm(form) {
		var out = {};
		form.querySelectorAll('[name]').forEach(function (el) {
			out[el.name] = el.type === 'checkbox' ? el.checked : el.value;
		});
		return out;
	}

	function showErrors(form, e) {
		form.querySelectorAll('.msm-ferr').forEach(function (x) { x.textContent = ''; });
		form.querySelectorAll('.has-err').forEach(function (x) { x.classList.remove('has-err'); });
		var fields = (e.data && e.data.fields) || {};
		Object.keys(fields).forEach(function (k) {
			var f = form.querySelector('[data-field="' + k + '"]');
			if (f) { f.classList.add('has-err'); f.querySelector('.msm-ferr').textContent = fields[k]; }
		});
		var g = form.querySelector('.msm-form-err');
		if (g) { g.textContent = e.message; g.hidden = false; }
	}

	// Widżet stanu BHP: wiersze (lokalizacja → stan → ilość) mapowane na 4 pule.
	function bhpStanyHtml() {
		return '<div class="msm-field full msm-stany-field" data-field="stany"><span>Stan magazynowy</span>' +
			'<div class="msm-stany" data-stany></div>' +
			'<button type="button" class="msm-btn msm-btn-sm msm-stany-add" data-stadd>+ Dodaj wiersz</button>' +
			'<input type="hidden" name="st_mag_nowy"><input type="hidden" name="st_mag_uzywany">' +
			'<input type="hidden" name="st_szafa_nowy"><input type="hidden" name="st_szafa_uzywany">' +
			'<em class="msm-ferr"></em></div>';
	}

	function bindBhpStany(form, row) {
		var box = form.querySelector('[data-stany]');
		if (!box) return;
		var pools = [['magazyn', 'nowy', 'st_mag_nowy'], ['magazyn', 'uzywany', 'st_mag_uzywany'], ['szafa', 'nowy', 'st_szafa_nowy'], ['szafa', 'uzywany', 'st_szafa_uzywany']];
		var rows = [];
		if (row) pools.forEach(function (p) { var q = Number(row[p[2]]) || 0; if (q > 0) rows.push({ loc: p[0], st: p[1], q: q }); });
		if (!rows.length) rows.push({ loc: 'magazyn', st: 'nowy', q: '' });
		function keyOf(loc, st) { return 'st_' + (loc === 'szafa' ? 'szafa' : 'mag') + '_' + (st === 'uzywany' ? 'uzywany' : 'nowy'); }
		function updateHidden() {
			var s = { st_mag_nowy: 0, st_mag_uzywany: 0, st_szafa_nowy: 0, st_szafa_uzywany: 0 };
			rows.forEach(function (r) { var q = parseInt(r.q, 10) || 0; if (q > 0) s[keyOf(r.loc, r.st)] += q; });
			Object.keys(s).forEach(function (k) { var el = form.querySelector('[name=' + k + ']'); if (el) el.value = s[k]; });
		}
		function render() {
			box.innerHTML = rows.map(function (r, i) {
				return '<div class="msm-stan-row" data-sr="' + i + '">' +
					'<select class="msm-stan-loc" data-sloc="' + i + '"><option value="magazyn"' + (r.loc !== 'szafa' ? ' selected' : '') + '>Magazyn</option><option value="szafa"' + (r.loc === 'szafa' ? ' selected' : '') + '>Szafa BHP</option></select>' +
					'<select class="msm-stan-st" data-sst="' + i + '"><option value="nowy"' + (r.st !== 'uzywany' ? ' selected' : '') + '>Nowy</option><option value="uzywany"' + (r.st === 'uzywany' ? ' selected' : '') + '>Używany</option></select>' +
					'<input type="number" min="0" step="1" inputmode="numeric" class="msm-stan-q" data-sq="' + i + '" value="' + (r.q === '' ? '' : esc(String(r.q))) + '" placeholder="szt">' +
					'<button type="button" class="msm-iconbtn msm-iconbtn-danger" data-srem="' + i + '" aria-label="Usuń wiersz">' + ICON_DEL + '</button>' +
				'</div>';
			}).join('');
			box.querySelectorAll('[data-sloc]').forEach(function (s) { s.addEventListener('change', function () { rows[+s.getAttribute('data-sloc')].loc = s.value; updateHidden(); }); });
			box.querySelectorAll('[data-sst]').forEach(function (s) { s.addEventListener('change', function () { rows[+s.getAttribute('data-sst')].st = s.value; updateHidden(); }); });
			box.querySelectorAll('[data-sq]').forEach(function (inp) { inp.addEventListener('input', function () { rows[+inp.getAttribute('data-sq')].q = inp.value; updateHidden(); }); });
			box.querySelectorAll('[data-srem]').forEach(function (b) { b.addEventListener('click', function () { rows.splice(+b.getAttribute('data-srem'), 1); if (!rows.length) rows.push({ loc: 'magazyn', st: 'nowy', q: '' }); render(); updateHidden(); }); });
			updateHidden();
		}
		var add = form.querySelector('[data-stadd]');
		if (add) add.addEventListener('click', function () { rows.push({ loc: 'magazyn', st: 'nowy', q: '' }); render(); });
		render();
	}

	function openForm(t, row) {
		var editing = !!row;
		var editable = S[t].editable;
		var cols = colsFor(t).filter(function (c) { return !c.computed && !c.pool && (!editable || editable.indexOf(c.key) >= 0); });
		var pobOpts = st(t).options || {};
		var body = '<form class="msm-form" novalidate><div class="msm-form-err msm-alert msm-alert-err" hidden></div>' +
			(editing && t === 'pobrania' ? '<p class="msm-muted">' + esc(row.material) + ' – ' + esc(fmtNum(row.ilosc) + ' ' + row.jednostka) + '</p>' : '') +
			'<div class="msm-grid">' + cols.map(function (c) {
				var v = editing ? row[c.key] : (c.default !== undefined ? c.default : '');
				return fieldHtml(t, c, v, pobOpts);
			}).join('') + '</div>' +
			(t === 'bhp' ? bhpStanyHtml() : '') +
			(S[t].stock ? '<p class="msm-muted msm-small">Pola kg/m, Suma mb i Suma kg liczą się automatycznie po zapisie.</p>' : '') +
			'</form>';
		var m = openModal((editing ? 'Edycja – ' : 'Nowa pozycja – ') + S[t].label, body,
			'<button type="button" class="msm-btn" data-close>Anuluj</button>' +
			(editing && S[t].stock ? '<button type="button" class="msm-btn" data-saveas>Zapisz jako nową</button>' : '') +
			'<button type="button" class="msm-btn msm-btn-primary" data-save>' + (editing ? 'Zapisz zmiany' : 'Dodaj') + '</button>', true);
		var form = m.querySelector('form');
		bindTaglists(form);
		if (t === 'bhp') bindBhpStany(form, editing ? row : null);

		// Norma przydziału (produkt BHP): wypełnij listę nazwami norm z zakładki Normy.
		var np = form.querySelector('[data-normapick]');
		if (np) fillNormaSelect(np, np.value);

		// Blachy niepełne: przy kole ukryj wymiar B.
		var ks = form.querySelector('[name=ksztalt]');
		function syncShape() {
			var b = form.querySelector('[data-field=wymiar_b]');
			if (ks && b) b.hidden = ks.value === 'koło';
		}
		if (ks) { ks.addEventListener('change', syncShape); syncShape(); }

		function submit(asNew) {
			var data = readForm(form);
			var btns = m.querySelectorAll('.msm-modal-foot .msm-btn');
			btns.forEach(function (b) { b.disabled = true; });
			var req = (editing && !asNew)
				? api('/t/' + t + '/' + row.id, { method: 'POST', body: data })
				: api('/t/' + t, { method: 'POST', body: data });
			req.then(function () {
				closeModal();
				toast(editing && !asNew ? 'Zapisano zmiany.' : 'Dodano pozycję.');
				refresh(t);
			}).catch(function (e) {
				btns.forEach(function (b) { b.disabled = false; });
				showErrors(form, e);
			});
		}
		m.querySelector('[data-save]').addEventListener('click', function () { submit(false); });
		var sa = m.querySelector('[data-saveas]');
		if (sa) sa.addEventListener('click', function () { submit(true); });
		form.addEventListener('submit', function (e) { e.preventDefault(); submit(false); });
		form.addEventListener('keydown', function (e) { if (e.key === 'Enter' && e.target.tagName !== 'TEXTAREA') { e.preventDefault(); submit(false); } });
	}

	/* ---------- sprawdziany/przyrządy: wydanie na halę / zwrot na regał ---------- */

	function narzHala(t, id, btn) {
		if (btn) btn.disabled = true;
		api('/t/' + t + '/' + id + '/hala', { method: 'POST', body: { action: 'hala' } })
			.then(function () { toast('Pobrano – na hali.'); refresh(t); })
			.catch(function (e) { if (btn) btn.disabled = false; toast(e.message || 'Nie udało się.', 'err'); });
	}

	function narzZwrot(t, row) {
		if (!row) return;
		var body = '<form class="msm-form" novalidate><div class="msm-form-err msm-alert msm-alert-err" hidden></div>' +
			'<p class="msm-muted">' + esc(row.numer || '') + ' — obecnie na hali.</p>' +
			'<div class="msm-grid"><label class="msm-field full" data-field="regal"><span>Na jaki regał odkładasz? <i class="msm-req">*</i></span>' +
			'<input name="regal" type="text" autocomplete="off" placeholder="np. R12"><em class="msm-ferr"></em></label></div></form>';
		var m = openModal('Zwrot na regał – ' + (row.numer || ''), body,
			'<button type="button" class="msm-btn" data-close>Anuluj</button>' +
			'<button type="button" class="msm-btn msm-btn-primary" data-save>Zwróć na regał</button>', false);
		var form = m.querySelector('form');
		function submit() {
			var regal = (form.querySelector('[name=regal]').value || '').trim();
			var btn = m.querySelector('[data-save]');
			btn.disabled = true;
			api('/t/' + t + '/' + row.id + '/hala', { method: 'POST', body: { action: 'zwrot', regal: regal } })
				.then(function () { closeModal(); toast('Zwrócono na regał ' + regal + '.'); refresh(t); })
				.catch(function (e) { btn.disabled = false; showErrors(form, e); });
		}
		m.querySelector('[data-save]').addEventListener('click', submit);
		form.addEventListener('keydown', function (e) { if (e.key === 'Enter' && e.target.tagName !== 'TEXTAREA') { e.preventDefault(); submit(); } });
	}

	/* ---------------- pobranie z magazynu ---------------- */

	function openPobranie(t, row) {
		if (!cEdit()) return openWniosek(t, row);
		var isStal = t === 'stal';
		loadOptions('pobrania').then(function (po) {
			var odb = (po && po.odbiorca) || [];
			var body = '<form class="msm-form" novalidate><div class="msm-form-err msm-alert msm-alert-err" hidden></div>' +
				itemBox(t, row) +
				(isStal ? '<div class="msm-seg" role="radiogroup"><label><input type="radio" name="tryb" value="szt" checked> Całe sztuki</label><label><input type="radio" name="tryb" value="odcinek"> Odcinek (cięcie)</label></div>' : '') +
				'<div class="msm-grid">' +
				qtyInput(t, row) +
				(isStal ? odcFields(row, ' Reszta zostanie na stanie.') : '') +
				zlecField(t) +
				'<label class="msm-field" data-field="data"><span>Data</span><input name="data" type="date" value="' + esc(C.today) + '"><em class="msm-ferr"></em></label>' +
				'<label class="msm-field" data-field="odbiorca"><span>Pobrał / dla kogo</span><input name="odbiorca" type="text" autocomplete="off" list="msm-odb"><datalist id="msm-odb">' +
				odb.filter(function (o) { return o.v !== '__empty__'; }).map(function (o) { return '<option value="' + esc(o.v) + '">'; }).join('') + '</datalist><em class="msm-ferr"></em></label>' +
				'<label class="msm-field full" data-field="uwagi"><span>Uwagi / cel</span><textarea name="uwagi" rows="2"></textarea><em class="msm-ferr"></em></label>' +
				'<label class="msm-check msm-field-check"><input type="checkbox" name="wpisana"> Wpisana do systemu</label>' +
				'</div></form>';
			var m = openModal('Pobranie z magazynu', body,
				'<button type="button" class="msm-btn msm-btn-ghost msm-foot-left" data-towniosek title="Zamiast pobierać od razu – wyślij zapotrzebowanie albo prośbę o sprawdzenie stanu">Wyślij wniosek / sprawdzenie…</button>' +
				'<button type="button" class="msm-btn" data-close>Anuluj</button><button type="button" class="msm-btn msm-btn-primary" data-save>Pobierz</button>', true);
			m.querySelector('[data-towniosek]').addEventListener('click', function () { openWniosek(t, row); });
			var form = m.querySelector('form');
			if (isStal) {
				bindOdc(form);
				form.querySelectorAll('[name=tryb]').forEach(function (r) {
					r.addEventListener('change', function () {
						var odc = form.querySelector('[name=tryb]:checked').value === 'odcinek';
						form.querySelector('[data-field=ilosc]').hidden = odc;
						form.querySelectorAll('[data-odc]').forEach(function (el) { el.hidden = !odc; });
					});
				});
			}
			function submit() {
				var data = readForm(form);
				if (isStal) data.tryb = form.querySelector('[name=tryb]:checked').value;
				data.tabela = t;
				data.item_id = row.id;
				var btn = m.querySelector('[data-save]');
				btn.disabled = true;
				api('/pobranie', { method: 'POST', body: data }).then(function (res) {
					closeModal();
					toast(res.message || 'Zapisano pobranie.');
					invalidate('pobrania');
					refresh(t);
				}).catch(function (e) { btn.disabled = false; showErrors(form, e); });
			}
			m.querySelector('[data-save]').addEventListener('click', submit);
			form.addEventListener('keydown', function (e) { if (e.key === 'Enter' && e.target.tagName !== 'TEXTAREA') { e.preventDefault(); submit(); } });
		});
	}

	/* Numer zlecenia – wymagany przy pobraniu blachy pełnej. */
	function zlecField(t) {
		var req = t === 'blachy_pelne';
		return '<label class="msm-field" data-field="zlecenie"><span>Numer zlecenia' + (req ? ' <i class="msm-req">*</i>' : '') + '</span><input name="zlecenie" type="text" autocomplete="off" placeholder="np. B71200" maxlength="60"' + (req ? ' required' : '') + '><em class="msm-ferr"></em>' +
			(req ? '<small class="msm-muted">Wymagany przy blasze pełnej – o pobraniu zostanie wysłany e-mail.</small>' : '') + '</label>';
	}

	/* Numer rysunku – przy pobraniu detalu blach i stali (obok numeru zlecenia). */
	function rysField(t) {
		if (t === 'kregi') return '';
		return '<label class="msm-field" data-field="rysunek"><span>Numer rysunku</span><input name="rysunek" type="text" autocomplete="off" placeholder="np. K3-3120001" maxlength="190"><em class="msm-ferr"></em></label>';
	}

	/* Odcinki: liczba sztuk × długość jednego odcinka, z podsumowaniem. */
	function odcFields(row, note) {
		return '<label class="msm-field" data-field="odc_szt" data-odc hidden><span>Ilość odcinków [szt] <i class="msm-req">*</i></span><input name="odc_szt" type="number" min="1" step="1" value="1"><em class="msm-ferr"></em></label>' +
			'<label class="msm-field" data-field="dlugosc" data-odc hidden><span>Długość jednego odcinka [m] <i class="msm-req">*</i></span><input name="dlugosc" type="text" inputmode="decimal" placeholder="np. 0,4"><em class="msm-ferr"></em></label>' +
			'<div class="msm-odc-sum full" data-odc data-odcsum hidden data-len="' + esc(row.dlugosc || '') + '" data-note="' + esc(note || '') + '"></div>';
	}
	function bindOdc(form) {
		var box = form.querySelector('[data-odcsum]');
		if (!box) return;
		function upd() {
			var n = parseInt(form.querySelector('[name=odc_szt]').value, 10) || 0;
			var l = Number(String(form.querySelector('[name=dlugosc]').value).replace(/\s/g, '').replace(',', '.')) || 0;
			var len = Number(box.getAttribute('data-len')) || 0;
			var tot = Math.round(n * l * 1000) / 1000;
			var over = len && tot > len + 1e-9;
			box.classList.toggle('is-over', !!over);
			box.innerHTML = n && l
				? 'Razem: <b>' + n + ' × ' + fmtNum(l) + ' m = ' + fmtNum(tot) + ' m</b> · ze sztuki ' + fmtNum(len) + ' m' +
					(over ? ' – <b>za mało w jednej sztuce</b>' : (len ? ', zostanie ' + fmtNum(Math.round((len - tot) * 1000) / 1000) + ' m.' + (box.getAttribute('data-note') || '') : ''))
				: 'Ze sztuki ' + fmtNum(len) + ' m. Wpisz ilość odcinków i długość jednego odcinka.';
		}
		form.querySelector('[name=odc_szt]').addEventListener('input', upd);
		form.querySelector('[name=dlugosc]').addEventListener('input', upd);
		upd();
	}

	/* ---------------- wnioski o pobranie ---------------- */

	/* Zwrot reszty na magazyn (po zaakceptowanym zapotrzebowaniu) – nowa pozycja z nowymi wymiarami. */
	function openZwrot(w, kind) {
		if (!w) return;
		var direct = (kind === 'pobrania');
		var t = w.item_table;
		if (['stal', 'blachy_pelne', 'blachy_niepelne'].indexOf(t) < 0) { toast('Zwrot na magazyn dotyczy stali i blach.', 'err'); return; }
		var prefill = w.item_id ? api('/t/' + t + '/' + w.item_id).catch(function () { return {}; }) : Promise.resolve({});
		prefill.then(function (item) {
			item = item || {};
			var cols = colsFor(t).filter(function (c) { return !c.computed; });
			var body = '<form class="msm-form" novalidate><div class="msm-form-err msm-alert msm-alert-err" hidden></div>' +
				'<div class="msm-alert msm-wn-info"><p>Zwrot reszty na magazyn ze zlecenia <b>' + esc(w.zlecenie || '—') + '</b>' + (w.rysunek ? ' · rys. <b>' + esc(w.rysunek) + '</b>' : '') + '.<br>Zmień <b>wymiary na nowe</b> (to, co zostaje) i podaj ilość – powstanie <b>nowa pozycja</b> na stanie. Wartości podpowiedziane z pobieranej pozycji.</p></div>' +
				'<div class="msm-grid">' + cols.map(function (c) {
					var v = (c.key === 'ilosc') ? '' : (item[c.key] !== undefined && item[c.key] !== null ? item[c.key] : (c.default !== undefined ? c.default : ''));
					return fieldHtml(t, c, v, {});
				}).join('') + '</div></form>';
			var m = openModal('Zwrot na magazyn – ' + S[t].label, body,
				'<button type="button" class="msm-btn" data-close>Anuluj</button><button type="button" class="msm-btn msm-btn-primary" data-save>Dodaj na magazyn</button>', true);
			var form = m.querySelector('form');
			var ks = form.querySelector('[name=ksztalt]');
			function syncShape() { var bb = form.querySelector('[data-field=wymiar_b]'); if (ks && bb) bb.hidden = ks.value === 'koło'; }
			if (ks) { ks.addEventListener('change', syncShape); syncShape(); }
			m.querySelector('[data-save]').addEventListener('click', function () {
				var data = readForm(form); var btn = this; btn.disabled = true;
				if (direct) { data.tabela = t; data.zlecenie = w.zlecenie || ''; data.rysunek = w.rysunek || ''; data.pobranie_id = w.id; }
				api(direct ? '/zwrot' : ('/wnioski/' + w.id + '/zwrot'), { method: 'POST', body: data }).then(function (r) {
					closeModal(); toast(r.message || 'Dodano zwrot na magazyn.'); STOCK.forEach(invalidate); refresh(t); if (current === 'wnioski') refresh('wnioski'); if (current === 'pobrania') refresh('pobrania');
				}).catch(function (e) { btn.disabled = false; showErrors(form, e); });
			});
		}).catch(function (e) { toast(e.message, 'err'); });
	}

	function openWniosek(t, row) {
		var isStal = t === 'stal';
		var body = '<form class="msm-form" novalidate><div class="msm-form-err msm-alert msm-alert-err" hidden></div>' +
			itemBox(t, row) +
			'<div class="msm-alert msm-wn-info"><p>Informacja trafi do magazyniera (w powiadomieniu oraz e-mailem). Stan zmniejszy się dopiero, gdy magazynier potwierdzi fizyczne wydanie materiału lub odłożenie go do konkretnego zlecenia.</p>' +
			'<p><b>Sprawdź zapotrzebowanie</b> – magazynier tylko potwierdzi, czy materiał fizycznie jest na stanie (nic nie jest pobierane).<br><b>Wyślij zapotrzebowanie</b> – prośba o wydanie materiału.</p></div>' +
			(isStal ? '<div class="msm-seg" role="radiogroup"><label><input type="radio" name="tryb" value="szt" checked> Całe sztuki</label><label><input type="radio" name="tryb" value="odcinek"> Odcinek (cięcie)</label></div>' : '') +
			'<div class="msm-grid">' +
			qtyInput(t, row) +
			(isStal ? odcFields(row, '') : '') +
			zlecField(t) +
			rysField(t) +
			'<label class="msm-field full" data-field="uwagi"><span>Cel / uwagi</span><textarea name="uwagi" rows="2" placeholder="np. do spawania ramy"></textarea><em class="msm-ferr"></em></label>' +
			'</div></form>';
		var m = openModal('Wniosek o pobranie', body,
			(C.canEdit ? '<button type="button" class="msm-btn msm-btn-ghost msm-foot-left" data-topobranie title="Zdejmij materiał ze stanu od razu, bez wniosku">← Pobierz od razu</button>' : '') +
			'<button type="button" class="msm-btn msm-btn-ghost" data-close>Anuluj</button><button type="button" class="msm-btn" data-check>Sprawdź zapotrzebowanie</button><button type="button" class="msm-btn msm-btn-primary" data-save>Wyślij zapotrzebowanie</button>', true);
		var form = m.querySelector('form');
		var tp = m.querySelector('[data-topobranie]');
		if (tp) tp.addEventListener('click', function () { openPobranie(t, row); });
		if (isStal) {
			bindOdc(form);
			form.querySelectorAll('[name=tryb]').forEach(function (r) {
				r.addEventListener('change', function () {
					var odc = form.querySelector('[name=tryb]:checked').value === 'odcinek';
					form.querySelector('[data-field=ilosc]').hidden = odc;
					form.querySelectorAll('[data-odc]').forEach(function (el) { el.hidden = !odc; });
				});
			});
		}
		function submit(typ) {
			var data = readForm(form);
			if (isStal) data.tryb = form.querySelector('[name=tryb]:checked').value;
			data.tabela = t;
			data.item_id = row.id;
			data.typ = typ;
			var btns = m.querySelectorAll('[data-save],[data-check]');
			btns.forEach(function (b) { b.disabled = true; });
			api('/wnioski', { method: 'POST', body: data }).then(function (res) {
				closeModal();
				toast(res.message || 'Wysłano.');
				invalidate('wnioski');
				pollWnioski();
			}).catch(function (e) { btns.forEach(function (b) { b.disabled = false; }); showErrors(form, e); });
		}
		m.querySelector('[data-save]').addEventListener('click', function () { submit('pobranie'); });
		m.querySelector('[data-check]').addEventListener('click', function () { submit('sprawdzenie'); });
		form.addEventListener('keydown', function (e) { if (e.key === 'Enter' && e.target.tagName !== 'TEXTAREA') { e.preventDefault(); submit('pobranie'); } });
	}

	function wniosekAction(r, action) {
		if (!r) return;
		var what = '<b>' + esc(fmtNum(r.ilosc) + ' ' + r.jednostka) + '</b> – ' + esc(r.material) + '<br><span class="msm-muted">Wnioskuje: ' + esc(r.user_name) + (r.zlecenie ? ' · zlecenie <b>' + esc(r.zlecenie) + '</b>' : '') + (r.uwagi ? ' · ' + esc(r.uwagi) : '') + '</span>';
		var cfg = {
			akceptuj: { title: 'Zaakceptować wniosek?', text: what + '<br><br>Wnioskujący dostanie e-mail. Stan magazynu zmieni się dopiero po kliknięciu „Wydano”.', ok: 'Akceptuj', note: true },
			odrzuc: { title: 'Odrzucić wniosek?', text: what, ok: 'Odrzuć', danger: true, note: true },
			wydaj: { title: 'Potwierdzić wydanie?', text: what + '<br><br>Potwierdzasz, że materiał został <b>fizycznie wydany</b>. Stan zmniejszy się, a pobranie zapisze się w zakładce „Pobrania”.', ok: 'Wydano – zmniejsz stan', note: true, noteLabel: 'Uwagi do pobrania (opcjonalnie – będą widoczne w zakładce Pobrania)' },
			anuluj: { title: 'Anulować?', text: what, ok: 'Anuluj', danger: true },
			jest: { title: 'Materiał jest na stanie?', text: what + '<br><br>Potwierdzasz, że materiał <b>fizycznie jest na stanie</b>. Stan magazynu się nie zmienia.', ok: 'Tak, jest na stanie', note: true },
			brak: { title: 'Brak na stanie?', text: what + '<br><br>Wnioskujący dostanie informację, że materiału fizycznie nie ma. Jeśli w systemie jest błędny stan, popraw pozycję w magazynie.', ok: 'Brak na stanie', danger: true, note: true }
		}[action];
		var m = openModal(cfg.title, '<p>' + cfg.text + '</p>' +
			(cfg.note ? '<label class="msm-field full"><span>' + esc(cfg.noteLabel || 'Odpowiedź dla wnioskującego (opcjonalnie)') + '</span><textarea name="note" rows="2"></textarea></label>' : ''),
			'<button type="button" class="msm-btn" data-close>Wróć</button><button type="button" class="msm-btn ' + (cfg.danger ? 'msm-btn-danger' : 'msm-btn-primary') + '" data-ok>' + esc(cfg.ok) + '</button>');
		var ok = m.querySelector('[data-ok]');
		ok.addEventListener('click', function () {
			var note = m.querySelector('[name=note]');
			ok.disabled = true;
			api('/wnioski/' + r.id + '/' + action, { method: 'POST', body: { note: note ? note.value : '' } }).then(function (res) {
				closeModal();
				toast(res.message || 'Zapisano.');
				if (action === 'wydaj') { invalidate(r.item_table); invalidate('pobrania'); }
				refresh('wnioski');
				pollWnioski();
			}).catch(function (e) { ok.disabled = false; closeModal(); toast(e.message, 'err'); refresh('wnioski'); });
		});
	}

	/* Poprawka wniosku przez wnioskodawcę (status „nowy”) – magazyn dostaje e-mail z poprawioną wersją. */
	function wniosekEdit(r) {
		if (!r) return;
		var check = r.typ === 'sprawdzenie', odc = r.tryb === 'odcinek', kg = r.jednostka === 'kg';
		var body = '<form class="msm-form" novalidate><div class="msm-form-err msm-alert msm-alert-err" hidden></div>' +
			'<p class="msm-muted">' + esc(r.material) + '</p><div class="msm-grid">' +
			(odc ? '<div class="msm-field"><span>Ilość</span><p class="msm-wedit-fix"><b>' + esc(fmtNum(r.ilosc) + ' ' + r.jednostka) + '</b><br><small class="msm-muted">Odcinków nie można zmienić – anuluj i złóż nowy wniosek.</small></p></div>'
				: '<label class="msm-field" data-field="ilosc"><span>Ilość [' + esc(kg ? 'kg' : 'szt.') + '] <i class="msm-req">*</i></span><input name="ilosc" type="text" inputmode="decimal" value="' + esc(String(r.ilosc).replace('.', ',')) + '"><em class="msm-ferr"></em></label>') +
			'<label class="msm-field" data-field="zlecenie"><span>Numer zlecenia' + (r.item_table === 'blachy_pelne' && !check ? ' <i class="msm-req">*</i>' : '') + '</span><input name="zlecenie" type="text" maxlength="60" autocomplete="off" value="' + esc(r.zlecenie || '') + '"><em class="msm-ferr"></em></label>' +
			'<label class="msm-field" data-field="rysunek"><span>Numer rysunku</span><input name="rysunek" type="text" maxlength="190" autocomplete="off" value="' + esc(r.rysunek || '') + '"><em class="msm-ferr"></em></label>' +
			'<label class="msm-field full" data-field="uwagi"><span>Uwagi / cel</span><textarea name="uwagi" rows="3">' + esc(r.uwagi || '') + '</textarea><em class="msm-ferr"></em></label>' +
			'</div><p class="msm-muted msm-small">Po zapisaniu magazyn dostanie nowy e-mail z poprawioną wersją i listą zmian.</p></form>';
		var m = openModal((check ? 'Popraw prośbę #' : 'Popraw wniosek #') + r.id, body,
			'<button type="button" class="msm-btn" data-close>Anuluj</button><button type="button" class="msm-btn msm-btn-primary" data-ok>Zapisz i wyślij poprawkę</button>');
		var f = m.querySelector('form'), ok = m.querySelector('[data-ok]'), err = f.querySelector('.msm-form-err');
		function go() {
			f.querySelectorAll('.has-err').forEach(function (x) { x.classList.remove('has-err'); x.querySelector('.msm-ferr').textContent = ''; });
			err.hidden = true;
			var b = { zlecenie: f.zlecenie.value, rysunek: f.rysunek.value, uwagi: f.uwagi.value };
			if (!odc) b.ilosc = f.ilosc.value.replace(/\s/g, '').replace(',', '.');
			ok.disabled = true;
			api('/wnioski/' + r.id + '/popraw', { method: 'POST', body: b }).then(function (res) {
				closeModal(); toast(res.message || 'Zapisano.'); refresh('wnioski'); pollWnioski();
			}).catch(function (e) {
				ok.disabled = false;
				var fl = (e.data && e.data.fields) || {};
				Object.keys(fl).forEach(function (k) { var el = f.querySelector('[data-field="' + k + '"]'); if (el) { el.classList.add('has-err'); el.querySelector('.msm-ferr').textContent = fl[k]; } });
				err.textContent = e.message; err.hidden = false;
				if (e.status === 409) refresh('wnioski');
			});
		}
		ok.addEventListener('click', go);
		f.addEventListener('submit', function (e) { e.preventDefault(); go(); });
	}

	/* Po potwierdzeniu „Jest na stanie” przeglądający może jednym kliknięciem wysłać zapotrzebowanie. */
	function sendFromCheck(r, btn) {
		if (!r) return;
		if (btn) btn.disabled = true;
		return api('/wnioski/' + r.id + '/zapotrzebowanie', { method: 'POST' }).then(function (res) {
			toast(res.message || 'Zapotrzebowanie wysłane.');
			refresh('wnioski');
			pollWnioski();
		}).catch(function (e) { if (btn) btn.disabled = false; toast(e.message, 'err'); refresh('wnioski'); });
	}

	/* Link z e-maila: #wyslij-ID – okno z jednym przyciskiem „Wyślij zapotrzebowanie”. */
	function openSendFromLink(id) {
		api('/t/wnioski/' + id).then(function (r) {
			if (r.typ !== 'sprawdzenie' || r.status !== 'potwierdzony') { toast('Ta prośba nie czeka już na wysłanie zapotrzebowania.', 'warn'); return; }
			if (r.next_id) { toast('Zapotrzebowanie zostało już wysłane (wniosek #' + r.next_id + ').', 'warn'); return; }
			var m = openModal('Wyślij zapotrzebowanie',
				'<div class="msm-item-box"><b>' + esc(r.material) + '</b><span>Ilość: <b>' + esc(fmtNum(r.ilosc) + ' ' + r.jednostka) + '</b>' + (r.zlecenie ? ' · zlecenie <b>' + esc(r.zlecenie) + '</b>' : '') + (r.uwagi ? ' · ' + esc(r.uwagi) : '') + '</span></div>' +
				'<p class="msm-alert msm-wn-info">Magazynier potwierdził, że materiał jest na stanie' + (r.admin_note ? ' (' + esc(r.admin_note) + ')' : '') + '. Wyślij zapotrzebowanie – stan zmniejszy się dopiero po wydaniu.</p>',
				'<button type="button" class="msm-btn" data-close>Nie teraz</button><button type="button" class="msm-btn msm-btn-primary" data-ok>Wyślij zapotrzebowanie</button>');
			m.querySelector('[data-ok]').addEventListener('click', function () {
				this.disabled = true;
				sendFromCheck(r).then(function () { closeModal(); });
			});
		}).catch(function (e) { toast(e.message, 'err'); });
	}

	/* Licznik wniosków w zakładce (admin: nowe + do wydania; przeglądający: własne oczekujące). */
	var lastMaxId = null, lastDoWyslania = null;
	var lastWz = null;
	function pollWZ() {
		if (!C.canEdit) return;
		api('/wz/count').then(function (c) {
			root.querySelectorAll('[data-wzcount]').forEach(function (el) { el.textContent = c.do_zatwierdzenia; el.hidden = !c.do_zatwierdzenia; el.title = 'WZ do zatwierdzenia: ' + c.do_zatwierdzenia; });
			if (lastWz !== null && c.do_zatwierdzenia > lastWz) {
				toast('Nowa WZ czeka na zatwierdzenie – „Wydanie zewnętrzne”.', 'warn');
				pwaNotify('WZ do zatwierdzenia', 'Nowa WZ czeka na zatwierdzenie.', 'wz');
				if (current === 'wz') refresh('wz');
			}
			lastWz = c.do_zatwierdzenia;
		}).catch(function () {});
	}

	/* ---------------- szybki inwentarz ---------------- */

	function inwBanner() {
		return '<div class="msm-inwbar" data-inwbar><div><b>Tryb szybkiego inwentarza</b> – wpisz ilość w kolumnie (albo zmianę, np. +50 / -12,5) i naciśnij Enter; możesz też dodawać, edytować i usuwać pozycje. ' +
			'Bez wniosków i e-maili – w historii zmiany mają adnotację „szybki inwentarz”.</div>' +
			'<div class="msm-inwbar__sum" data-inwsum>' + inwSum() + '</div>' +
			(C.canEdit ? '<button type="button" class="msm-btn msm-btn-sm" data-inwstop>Zakończ inwentarz</button>' : '') + '</div>';
	}
	function inwSum() {
		return 'Zmian: dodano <b>' + (INW['dodanie'] || 0) + '</b> · edytowano <b>' + (INW['edycja'] || 0) + '</b> · usunięto <b>' + (INW['usunięcie'] || 0) + '</b>';
	}
	function syncInwUi() {
		root.querySelectorAll('[data-inwbtn]').forEach(function (b) {
			b.classList.toggle('is-on', !!INW.active);
			var lab = b.querySelector('[data-inwlabel]');
			if (lab) lab.textContent = INW.active ? 'Zakończ szybki inwentarz' : 'Szybki inwentarz';
			b.title = INW.active ? 'Szybki inwentarz jest włączony – kliknij, aby zakończyć' : 'Włącz szybki inwentarz';
		});
		var more = root.querySelector('[data-navmenu="tech"]');
		if (more) more.classList.toggle('is-inw', !!INW.active);
		var sm = document.querySelector('[data-inwsum]');
		if (sm) sm.innerHTML = inwSum();
	}
	function setInw(s) {
		var was = !!INW.active;
		INW = s || { active: false };
		syncInwUi();
		if (was !== !!INW.active && current && S[current] && S[current].stock) { STOCK.forEach(invalidate); renderTableView(current); }
	}
	function pollInw() { if (!C.canEdit) return Promise.resolve(); return api('/inwentarz').then(setInw).catch(function () {}); }
	function inwStart() {
		confirmBox('Włączyć szybki inwentarz?', 'Ilości wpiszesz bezpośrednio w tabeli (Enter = zapis), możesz też dodawać i usuwać pozycje – bez wniosków i e-maili.<br>Tryb jest tylko dla administratorów; każda zmiana zapisze się w historii z adnotacją „szybki inwentarz”.', 'Włącz').then(function (ok) {
			if (!ok) return;
			api('/inwentarz/start', { method: 'POST' }).then(function (s) { setInw(s); toast('Szybki inwentarz włączony (nr ' + s.nr + ').'); }).catch(function (e) { toast(e.message, 'err'); });
		});
	}
	function inwStop() {
		confirmBox('Zakończyć szybki inwentarz?', 'Zmiany w tej sesji: dodano ' + (INW['dodanie'] || 0) + ', edytowano ' + (INW['edycja'] || 0) + ', usunięto ' + (INW['usunięcie'] || 0) + '.<br>Tabele wrócą do zwykłego widoku.', 'Zakończ').then(function (ok) {
			if (!ok) return;
			api('/inwentarz/stop', { method: 'POST' }).then(function (s) { setInw(s); toast('Szybki inwentarz zakończony.'); }).catch(function (e) { toast(e.message, 'err'); });
		});
	}
	document.addEventListener('click', function (e) {
		if (e.target.closest('[data-inwstop]')) { inwStop(); return; }
		var b = e.target.closest('[data-inwbtn]');
		if (!b) return;
		if (INW.active) inwStop(); else inwStart();
	});

	function pollWnioski() {
		pollWZ();
		pollInw();
		pollRez();
		return api('/wnioski/count').then(function (c) {
			var n = c.nowe + c.do_wydania + (c.do_wyslania || 0);
			root.querySelectorAll('[data-wcount]').forEach(function (el) {
				el.textContent = n;
				el.hidden = !n;
				el.classList.toggle('is-hot', C.canEdit && c.nowe > 0);
				el.title = C.canEdit ? ('Nowe: ' + c.nowe + ', do wydania: ' + c.do_wydania) : ('Oczekujące: ' + n);
			});
			if (C.canEdit && lastMaxId !== null && c.max_id > lastMaxId && c.nowe > 0) {
				toast('Nowy wniosek o pobranie – zobacz zakładkę „Wnioski”.', 'warn');
				pwaNotify('Nowy wniosek o pobranie', 'Wniosek czeka na decyzję w zakładce „Wnioski”.', 'wnioski');
				invalidate('wnioski');
				if (current === 'wnioski') refresh('wnioski');
			}
			if (!C.canEdit && lastDoWyslania !== null && c.do_wyslania > lastDoWyslania) {
				toast('Magazynier potwierdził: materiał jest na stanie. Możesz wysłać zapotrzebowanie w zakładce „Wnioski”.', 'warn');
				pwaNotify('Materiał jest na stanie', 'Możesz wysłać zapotrzebowanie w zakładce „Wnioski”.', 'wnioski');
				if (current === 'wnioski') refresh('wnioski');
			}
			lastDoWyslania = c.do_wyslania || 0;
			lastMaxId = c.max_id;
		}).catch(function () {});
	}

	/* ---------------- historia pojedynczej pozycji ---------------- */

	var HIST_ICONS = {
		pobranie: '<path d="M12 4v12"/><path d="m7 11 5 5 5-5"/><path d="M5 20h14"/>',
		zwrot: '<path d="M12 20V8"/><path d="m7 13 5-5 5 5"/><path d="M5 4h14"/>',
		sprawdzenie: '<path d="m5 12 4 4 10-10"/>',
		brak: '<path d="M6 6l12 12M18 6 6 18"/>',
		zapotrzebowanie: '<path d="M7 3h7l5 5v13H7z"/><path d="M14 3v5h5"/>',
		akceptacja: '<path d="m5 12 4 4 10-10"/>',
		wydanie: '<path d="M3 7h13v10H3z"/><path d="M16 10h3l2 3v4h-5"/><circle cx="7" cy="18" r="1.6"/><circle cx="17" cy="18" r="1.6"/>',
		odrzucenie: '<path d="M6 6l12 12M18 6 6 18"/>',
		edycja: '<path d="M4 20h4L19 9l-4-4L4 16v4z"/>',
		dodanie: '<path d="M12 5v14M5 12h14"/>',
		reszta: '<path d="M4 12h7M15 12h5"/><path d="m11 8 4 8"/>',
		usuniecie: '<path d="M4 7h16M6 7l1 13h10l1-13M9 7V4h6v3"/>',
		inne: '<circle cx="12" cy="12" r="3"/>'
	};

	function plural(n, one, few, many) {
		if (n === 1) return one;
		var d = n % 10, h = n % 100;
		return d >= 2 && d <= 4 && (h < 12 || h > 14) ? few : many;
	}

	/* Jednostka stanu magazynu: kręgi w kg, reszta w sztukach. */
	function isKg(t) { return !!(S[t] && S[t].unit === 'kg'); }
	function U(t) { return isKg(t) ? 'kg' : 'szt.'; }
	function qtyInput(t, row) {
		return isKg(t)
			? '<label class="msm-field" data-field="ilosc"><span>Ilość [kg] <i class="msm-req">*</i></span><input name="ilosc" type="text" inputmode="decimal" placeholder="np. 250"><em class="msm-ferr"></em></label>'
			: '<label class="msm-field" data-field="ilosc"><span>Ilość [szt] <i class="msm-req">*</i></span><input name="ilosc" type="number" min="1" max="' + row.ilosc + '" step="1" value="1"><em class="msm-ferr"></em></label>';
	}

	function openItemHistory(t, id) {
		var m = openModal('Historia pozycji', '<div class="msm-loading">Ładowanie…</div>', '<button type="button" class="msm-btn" data-close>Zamknij</button>', true);
		m.querySelector('.msm-modal').classList.add('msm-hist');
		api('/t/' + t + '/' + id + '/historia').then(function (h) {
			var s = h.summary;
			var stock = h.item
				? '<div class="msm-hist__stock"><span class="lbl">Na stanie teraz</span><b>' + fmtNum(h.item.ilosc) + ' ' + U(t) + '</b>' + (h.item.dlugosc ? '<small>po ' + fmtNum(h.item.dlugosc) + ' m</small>' : '') + '</div>'
				: '<div class="msm-hist__stock"><b>usunięta</b></div>';
			var picked = [s.szt ? fmtNum(s.szt) + ' szt.' : '', s.m ? fmtNum(s.m) + ' m' : '', s.kg ? fmtNum(s.kg) + ' kg' : ''].filter(Boolean).join(' + ') || '0';
			var isBhp = t === 'bhp';
			var stats = isBhp
				? '<div class="msm-hist__stats msm-hist__stats--bhp"><div><span>Wydano łącznie</span><b>' + picked + '</b><small>' + s.pobrania + ' ' + plural(s.pobrania, 'wydanie', 'wydania', 'wydań') + '</small></div></div>'
				: '<div class="msm-hist__stats">' +
				'<div><span>Pobrano łącznie</span><b>' + picked + '</b><small>' + s.pobrania + ' ' + plural(s.pobrania, 'pobranie', 'pobrania', 'pobrań') + '</small></div>' +
				'<div><span>Sprawdzenia stanu</span><b>' + s.sprawdzenia + '</b></div>' +
				'<div><span>Zapotrzebowania</span><b>' + s.zapotrzebowania + '</b>' + (s.w_toku ? '<small class="hot">' + s.w_toku + ' w toku</small>' : '') + '</div>' +
				'</div>';
			var counts = { all: h.events.length, pobrania: 0, wnioski: 0, zmiany: 0 };
			h.events.forEach(function (e) { counts[e.group] = (counts[e.group] || 0) + 1; });
			var tabDefs = isBhp ? [['all', 'Wszystko'], ['pobrania', 'Wydania'], ['zmiany', 'Zmiany']] : [['all', 'Wszystko'], ['pobrania', 'Pobrania'], ['wnioski', 'Wnioski'], ['zmiany', 'Zmiany']];
			var tabs = '<div class="msm-seg msm-seg--sm msm-hist__tabs" role="tablist">' +
				tabDefs.map(function (x, i) {
					return '<label><input type="radio" name="hf" value="' + x[0] + '"' + (i ? '' : ' checked') + '> ' + x[1] + ' <em>' + (counts[x[0]] || 0) + '</em></label>';
				}).join('') + '</div>';

			function diffHtml(e) {
				if (!e.diff || !e.diff.przed) return '';
				return '<div class="msm-tl-diff">' + Object.keys(e.diff.przed).map(function (k) {
					var col = null;
					S[t].cols.forEach(function (c) { if (c.key === k) col = c; });
					var c2 = col || { type: 'text' };
					return '<span>' + esc(col ? col.label : k) + ':</span> <s>' + esc(fmtCell(c2, e.diff.przed[k]) || '—') + '</s> → <b>' + esc(fmtCell(c2, e.diff.po[k]) || '—') + '</b>';
				}).join('<br>') + '</div>';
			}
			function listHtml(filter) {
				var ev = h.events.filter(function (e) { return filter === 'all' || e.group === filter; });
				if (!ev.length) return '<p class="msm-empty">Brak zdarzeń w tej kategorii.</p>';
				var out = '', day = '';
				ev.forEach(function (e) {
					var d = fmtDate(e.czas).slice(0, 10), tm = fmtDate(e.czas).slice(11);
					if (d !== day) { if (day) out += '</ol>'; out += '<div class="msm-tl-day">' + esc(d) + '</div><ol class="msm-tl">'; day = d; }
					out += '<li class="k-' + esc(e.kind) + '"><span class="msm-tl-ico">' + SVG + (HIST_ICONS[e.kind] || HIST_ICONS.inne) + '</svg></span>' +
						'<div class="msm-tl-main"><div class="msm-tl-title">' + esc(e.title) + '</div>' +
						(e.detail ? '<div class="msm-tl-detail">' + esc(e.detail) + '</div>' : '') +
						(e.stock ? '<div class="msm-tl-detail">stan: ' + fmtNum(e.stock[0]) + ' → <b>' + fmtNum(e.stock[1]) + ' ' + U(t) + '</b></div>' : '') +
						diffHtml(e) + '</div>' +
						'<div class="msm-tl-meta"><div class="msm-tl-when"><span class="msm-tl-date">' + esc(d) + '</span><span class="msm-tl-time">' + esc(tm) + '</span></div>' +
						'<span class="msm-tl-who">' + esc(e.user_name) + '</span></div></li>';
				});
				return out + '</ol>';
			}

			m.querySelector('.msm-modal-head h2').textContent = 'Historia: ' + h.title;
			m.querySelector('.msm-modal-body').innerHTML =
				'<div class="msm-hist__top">' + stock + stats + '</div>' + tabs + '<div class="msm-hist__list">' + listHtml('all') + '</div>';
			m.querySelectorAll('[name=hf]').forEach(function (r) {
				r.addEventListener('change', function () { m.querySelector('.msm-hist__list').innerHTML = listHtml(r.value); });
			});
		}).catch(function (e) { m.querySelector('.msm-modal-body').innerHTML = '<div class="msm-alert msm-alert-err">' + esc(e.message) + '</div>'; });
	}

	/* ---------------- szczegóły historii ---------------- */

	function openDetails(r) {
		var d = r.dane || {};
		var key = r.tabela_key && S[r.tabela_key] ? r.tabela_key : null;
		var label = function (k) {
			if (key) for (var i = 0; i < S[key].cols.length; i++) if (S[key].cols[i].key === k) return S[key].cols[i].label;
			return k;
		};
		var colOf = function (k) {
			if (key) for (var i = 0; i < S[key].cols.length; i++) if (S[key].cols[i].key === k) return S[key].cols[i];
			return { type: 'text' };
		};
		var keys = {};
		Object.keys(d.przed || {}).forEach(function (k) { keys[k] = 1; });
		Object.keys(d.po || {}).forEach(function (k) { keys[k] = 1; });
		var both = d.przed && d.po;
		var html = '<p><b>' + esc(r.akcja) + '</b> · ' + esc(fmtDate(r.czas)) + ' · ' + esc(r.user_name) + '</p><p>' + esc(r.opis) + '</p>' +
			'<table class="msm-table msm-diff"><thead><tr><th>Pole</th>' + (d.przed ? '<th>Przed</th>' : '') + (d.po ? '<th>Po</th>' : '') + '</tr></thead><tbody>' +
			Object.keys(keys).map(function (k) {
				var a = d.przed ? d.przed[k] : undefined, b = d.po ? d.po[k] : undefined;
				var c = colOf(k);
				var changed = both && String(a) !== String(b);
				return '<tr' + (changed ? ' class="changed"' : '') + '><td>' + esc(label(k)) + '</td>' +
					(d.przed ? '<td>' + esc(fmtCell(c, a)) + '</td>' : '') + (d.po ? '<td>' + esc(fmtCell(c, b)) + '</td>' : '') + '</tr>';
			}).join('') + '</tbody></table>';
		openModal('Szczegóły zmiany', html, '<button type="button" class="msm-btn" data-close>Zamknij</button>', true);
	}

	/* ---------------- rezerwacje (stal, blachy, kręgi) ---------------- */

	/* opts (z Produkcji): { zlecenie, prod_det_id, uwagi, onDone } */
	function openRezerwacja(row, t, opts) {
		t = t || 'stal'; opts = opts || {};
		var canEdit = C.canEdit, isStal = t === 'stal';
		api('/rezerwacje/item/' + row.id, { query: { table: t } }).then(function (info) {
			if (info && info.stan !== undefined) { row = Object.assign({}, row, { ilosc: info.stan, _rez: info.zarezerwowane }); }
			var rezList = (info && info.rezerwacje || []).map(function (x) {
				return '<li>' + esc(x.zlecenie) + ' – ' + fmtNum(x.ilosc) + ' ' + esc(x.jednostka) + (x.odc_txt ? ' (' + esc(x.odc_txt) + ')' : '') + ' · ' + esc(x.user) + (x.termin ? ' · do ' + esc(fmtDate(x.termin)) : '') + '</li>';
			}).join('');
			var body = '<form class="msm-form" novalidate><div class="msm-form-err msm-alert msm-alert-err" hidden></div>' +
				itemBox(t, row) +
				'<div class="msm-alert msm-wn-info">Rezerwacja blokuje materiał pod zlecenie, <b>nie zdejmując go ze stanu</b>. ' +
				(canEdit ? 'Materiał będzie można wydać tylko przez zakładkę „Rezerwacje”.' : 'Prośba trafi do administratora do zatwierdzenia (powiadomienie i e-mail).') + '</div>' +
				(isStal ? '<div class="msm-seg" role="radiogroup"><label><input type="radio" name="tryb" value="szt" checked> Całe sztuki</label><label><input type="radio" name="tryb" value="odcinek"> Odcinek (cięcie)</label></div>' : '') +
				'<div class="msm-grid">' +
				qtyInput(t, row) +
				(isStal ? odcFields(row, '') : '') +
				'<label class="msm-field" data-field="zlecenie"><span>Numer zlecenia <i class="msm-req">*</i></span><input name="zlecenie" type="text" autocomplete="off" placeholder="np. B71200" maxlength="60" value="' + esc(opts.zlecenie || '') + '"' + (opts.zlecenie ? ' readonly' : '') + '><em class="msm-ferr"></em></label>' +
				'<label class="msm-field" data-field="termin"><span>Termin ważności (opcjonalnie)</span><input name="termin" type="date" min="' + esc(C.today) + '"><em class="msm-ferr"></em><small class="msm-muted">Po tej dacie rezerwacja wygasa i zwalnia materiał.</small></label>' +
				'<label class="msm-field full" data-field="uwagi"><span>Uwagi</span><textarea name="uwagi" rows="2">' + esc(opts.uwagi || '') + '</textarea><em class="msm-ferr"></em></label>' +
				'</div>' + (rezList ? '<div class="msm-rez-existing"><b>Aktywne rezerwacje tej pozycji:</b><ul>' + rezList + '</ul></div>' : '') + '</form>';
			var m = openModal(isStal ? 'Rezerwacja stali' : t === 'kregi' ? 'Rezerwacja kręgu' : 'Rezerwacja blachy', body,
				'<button type="button" class="msm-btn" data-close>Anuluj</button><button type="button" class="msm-btn msm-btn-primary" data-save>' + (canEdit ? 'Zarezerwuj' : 'Wyślij prośbę o rezerwację') + '</button>', true);
			var form = m.querySelector('form');
			if (isStal) bindOdc(form);
			form.querySelectorAll('[name=tryb]').forEach(function (rb) {
				rb.addEventListener('change', function () {
					var odc = form.querySelector('[name=tryb]:checked').value === 'odcinek';
					form.querySelector('[data-field=ilosc]').hidden = odc;
					form.querySelectorAll('[data-odc]').forEach(function (el) { el.hidden = !odc; });
				});
			});
			m.querySelector('[data-save]').addEventListener('click', function () {
				var data = readForm(form);
				data.tryb = isStal ? form.querySelector('[name=tryb]:checked').value : 'szt';
				data.item_id = row.id;
				data.item_table = t;
				if (opts.prod_det_id) data.prod_det_id = opts.prod_det_id;
				var btn = this; btn.disabled = true;
				api('/rezerwacje', { method: 'POST', body: data }).then(function (res) {
					closeModal(); toast(res.message); invalidate(t); if (current === t) refresh(t); pollRez();
					if (opts.onDone) opts.onDone(res);
				}).catch(function (e) { btn.disabled = false; showErrors(form, e); });
			});
		}).catch(function (e) { toast(e.message, 'err'); });
	}

	function rezerwacjaAction(r, action) {
		if (!r) return;
		var what = '<b>' + esc(fmtNum(r.ilosc) + ' ' + (r.tryb === 'odcinek' ? 'm' : 'szt')) + '</b> – ' + esc(r.material) + '<br><span class="msm-muted">Zlecenie <b>' + esc(r.zlecenie) + '</b> · ' + esc(r.user_name) + (r.termin ? ' · termin ' + esc(fmtDate(r.termin)) : '') + '</span>';
		var cfg = {
			akceptuj: { title: 'Zatwierdzić rezerwację?', text: what + '<br><br>Materiał zostanie zablokowany pod zlecenie. Wnioskujący dostanie e-mail.', ok: 'Zatwierdź', note: true, noteLabel: 'Uwagi (opcjonalnie)' },
			odrzuc: { title: 'Odrzucić prośbę?', text: what, ok: 'Odrzuć', danger: true, note: true, noteLabel: 'Powód (opcjonalnie)' },
			wydaj: { title: 'Wydać z rezerwacji?', text: what + '<br><br>Materiał zostanie <b>zdjęty ze stanu</b> (pobranie), a rezerwacja oznaczona jako wydana.', ok: 'Wydaj – zmniejsz stan', note: true, noteLabel: 'Uwagi do pobrania (opcjonalnie)' },
			anuluj: { title: 'Anulować rezerwację?', text: what + '<br><br>Materiał wróci do dostępnych.', ok: 'Anuluj rezerwację', danger: true, note: true, noteLabel: 'Powód (opcjonalnie)' }
		}[action];
		var m = openModal(cfg.title, '<p>' + cfg.text + '</p>' +
			(cfg.note ? '<label class="msm-field full"><span>' + esc(cfg.noteLabel) + '</span><textarea name="note" rows="2"></textarea></label>' : ''),
			'<button type="button" class="msm-btn" data-close>Wróć</button><button type="button" class="msm-btn ' + (cfg.danger ? 'msm-btn-danger' : 'msm-btn-primary') + '" data-ok>' + esc(cfg.ok) + '</button>');
		var ok = m.querySelector('[data-ok]');
		ok.addEventListener('click', function () {
			var note = m.querySelector('[name=note]');
			ok.disabled = true;
			api('/rezerwacje/' + r.id + '/' + action, { method: 'POST', body: { note: note ? note.value : '' } }).then(function (res) {
				closeModal(); toast(res.message || 'Zapisano.');
				if (action === 'wydaj') invalidate('stal');
				refresh('rezerwacje'); pollRez();
			}).catch(function (e) { ok.disabled = false; closeModal(); toast(e.message, 'err'); refresh('rezerwacje'); });
		});
	}

	var lastRezNowe = null;
	function pollRez() {
		return api('/rezerwacje/count').then(function (c) {
			var n = C.canEdit ? c.nowe : (c.moje || 0);
			root.querySelectorAll('[data-rezcount]').forEach(function (el) { el.textContent = n; el.hidden = !n; el.classList.toggle('is-hot', C.canEdit && c.nowe > 0); });
			if (C.canEdit && lastRezNowe !== null && c.nowe > lastRezNowe) { toast('Nowa prośba o rezerwację – zobacz „Rezerwacje”.', 'warn'); pwaNotify('Nowa prośba o rezerwację', 'Zobacz zakładkę „Rezerwacje”.', 'rezerwacje'); if (current === 'rezerwacje') refresh('rezerwacje'); }
			lastRezNowe = c.nowe;
		}).catch(function () {});
	}

	/* ================= Pulpit / Karta zlecenia / Do zamówienia / Dziennik logowań ================= */

	function kgFmt(v) { return fmtNum(Math.round((+v || 0) * 10) / 10) + ' kg'; }

	function renderPulpit() {
		var main = document.getElementById('msm-main');
		main.innerHTML = '<div class="msm-cat"><div class="msm-pagehead"><div><h1>Pulpit</h1><p class="msm-muted">Przegląd stanu magazynu i aktywności</p></div></div>' +
			'<div class="msm-dash" data-dash><div class="msm-loading">Ładowanie…</div></div></div>';
		var box = main.querySelector('[data-dash]');
		api('/dashboard').then(function (d) {
			var stan = d.stan.map(function (s) {
				return '<div class="msm-dash-row"><span>' + esc(s.label) + '</span><b>' + kgFmt(s.kg) + '</b></div>';
			}).join('');
			var top = d.top.length ? d.top.map(function (r, i) {
				return '<div class="msm-dash-row"><span>' + (i + 1) + '. ' + esc(r.material) + '</span><b>' + r.n + '×</b></div>';
			}).join('') : '<p class="msm-muted">Brak pobrań.</p>';
			box.innerHTML =
				'<div class="msm-dash-grid">' +
				'<div class="msm-dash-card"><h3>Stan magazynu (kg)</h3>' + stan +
				'<div class="msm-dash-row msm-dash-total"><span>Razem</span><b>' + kgFmt(d.stan_total) + '</b></div></div>' +
				'<div class="msm-dash-card"><h3>Pobrania</h3>' +
				'<div class="msm-stat"><b>' + d.pob_week + '</b><span>w tym tygodniu</span></div>' +
				'<div class="msm-stat"><b>' + d.pob_month + '</b><span>w tym miesiącu</span></div></div>' +
				'<div class="msm-dash-card"><h3>Wnioski czekające</h3>' +
				'<a class="msm-stat msm-stat-link" href="#wnioski"><b>' + d.wnioski.nowe + '</b><span>nowe do decyzji</span></a>' +
				'<a class="msm-stat msm-stat-link" href="#wnioski"><b>' + d.wnioski.do_wydania + '</b><span>do wydania</span></a>' +
				(C.canEdit ? '<a class="msm-stat msm-stat-link' + (d.lowstock ? ' is-warn' : '') + '" href="#zamowienia"><b>' + d.lowstock + '</b><span>poniżej stanu min.</span></a>' : '') +
				'</div>' +
				'<div class="msm-dash-card"><h3>Najczęściej pobierane</h3>' + top + '</div>' +
				'</div>';
		}).catch(function (e) { box.innerHTML = '<p class="msm-alert msm-alert-err">' + esc(e.message) + '</p>'; });
	}

	function renderZlecenie() {
		var main = document.getElementById('msm-main');
		var last = store('zlecenie_nr') || '';
		main.innerHTML = '<div class="msm-cat"><div class="msm-pagehead"><div><h1>Karta zlecenia</h1><p class="msm-muted">Wpisz numer zlecenia, aby zobaczyć cały pobrany materiał i przesyłki, które do niego dotarły</p></div></div>' +
			'<form class="msm-card msm-zlec-search" data-zf autocomplete="off"><label class="msm-field"><span>Numer zlecenia</span>' +
			'<input type="text" name="nr" value="' + esc(last) + '" placeholder="np. B71200" autocomplete="off"></label>' +
			'<button type="submit" class="msm-btn msm-btn-primary">Pokaż</button></form>' +
			'<div data-zres></div></div>';
		var form = main.querySelector('[data-zf]'), res = main.querySelector('[data-zres]');
		function go(nr) {
			nr = (nr || '').trim(); if (!nr) { res.innerHTML = ''; return; }
			store('zlecenie_nr', nr);
			res.innerHTML = '<div class="msm-loading">Szukam…</div>';
			api('/zlecenie/' + encodeURIComponent(nr)).then(function (d) { res.innerHTML = zlecView(d); }).catch(function (e) { res.innerHTML = '<p class="msm-alert msm-alert-err">' + esc(e.message) + '</p>'; });
		}
		form.addEventListener('submit', function (e) { e.preventDefault(); go(form.nr.value); });
		if (last) go(last);
	}
	/* ---------- Produkcja → zlecenie → zakładka „Pobrania” (materiał pobrany do zlecenia) ---------- */
	function renderPobraniaZlec(tb, o) {
		var nr = String(o.nr_zlec || '').trim();
		if (!nr) { tb.innerHTML = '<p class="msm-muted">Zlecenie nie ma numeru – pobrania łączą się po numerze zlecenia wpisanym przy pobraniu.</p>'; return; }
		tb.innerHTML = '<div class="msm-loading">Ładowanie pobrań…</div>';
		api('/zlecenie/' + encodeURIComponent(nr)).then(function (d) {
			var L = d.pobrania || [], bn = document.querySelector('[data-pbtn]');
			o.pobrania_n = L.length; if (bn) { bn.textContent = L.length; bn.hidden = !L.length; }
			var karta = '<a class="msm-btn" href="#zlecenie" data-pbkarta>Karta zlecenia ›</a>';
			var head = '<div class="msm-ptool"><span class="msm-muted">' + (L.length ? esc(plN(L.length, 'pobranie', 'pobrania', 'pobrań')) + ' materiału do zlecenia <b>' + esc(nr) + '</b>' : 'Nie pobrano jeszcze materiału do zlecenia <b>' + esc(nr) + '</b>.') + '</span><span class="msm-ptool__btns">' + karta + '</span></div>';
			if (!L.length) { tb.innerHTML = head; return pbBind(); }
			var S = d.sumy || {}, last = L[0], unit = function (v, u) { return v ? '<b>' + esc(fmtNum(Math.round(v * 100) / 100)) + '</b> ' + u : ''; };
			var mats = {}; L.forEach(function (r) { if (r.material) mats[r.material] = 1; });
			var nw = L.filter(function (r) { return r.wpisana != 1; }).length;
			var tile = function (cls, lbl, val, sub) { return '<div class="msm-kzst__t' + cls + '"><span>' + lbl + '</span><b>' + val + '</b>' + (sub ? '<small>' + sub + '</small>' : '') + '</div>'; };
			var sums = [unit(S.kg, 'kg'), unit(S.mb, 'mb'), unit(S.szt, 'szt.')].filter(Boolean);
			var ilo = function (r) { return fmtNum(r.ilosc) + ' ' + (r.jednostka === 'szt' ? 'szt.' : (r.jednostka || '')); };
			var odc = function (r) { return r.tryb === 'odcinek' && r.odc_szt ? ' <small class="msm-muted">(' + r.odc_szt + ' szt. × ' + fmtNum(r.odc_dl) + ' m)</small>' : ''; };
			var up = function (v) { return v ? esc(v) : '<span class="msm-muted">—</span>'; };
			var MAG = { stal: 'Stal', blachy_pelne: 'Blachy pełne', blachy_niepelne: 'Blachy niepełne', kregi: 'Kręgi', blachy: 'Blachy' };
			tb.innerHTML = head +
				'<div class="msm-kzst msm-pbst">' +
				tile(' is-main', 'Pobrano razem', sums.length ? sums.join('<i>·</i>') : '—', esc(plN(Object.keys(mats).length, 'materiał', 'materiały', 'materiałów'))) +
				tile('', 'Pobrania', esc(L.length), nw ? '<em class="msm-kz-bad">' + esc(nw) + ' niewpisane do systemu</em>' : 'wszystkie wpisane') +
				tile('', 'Ostatnie', esc(fmtDate(last.data).slice(0, 5)), esc(fmtDate(last.data).slice(6)) + (last.odbiorca ? ' · ' + esc(last.odbiorca) : '')) +
				'</div>' +
				'<div class="msm-table-wrap"><table class="msm-table msm-pbz"><thead><tr><th>Data</th><th>Magazyn</th><th>Materiał</th><th class="num">Ilość</th><th>Pobrał / dla kogo</th><th>Wprowadził</th><th>Wpisana</th><th>Uwagi / cel</th></tr></thead><tbody>' +
				L.map(function (r) {
					return '<tr><td data-label="Data"><b>' + esc(fmtDate(r.data)) + '</b></td><td data-label="Magazyn">' + up(MAG[r.tabela] || r.tabela) + '</td>' +
						'<td data-label="Materiał">' + esc(r.material || '') + odc(r) + '</td><td data-label="Ilość" class="num"><b>' + esc(ilo(r)) + '</b></td>' +
						'<td data-label="Pobrał / dla kogo">' + up(r.odbiorca) + '</td><td data-label="Wprowadził">' + up(r.user_name) + '</td>' +
						'<td data-label="Wpisana">' + (r.wpisana == 1 ? '<span class="msm-tag msm-tag-ok">tak</span>' : '<span class="msm-tag msm-tag-no">nie</span>') + '</td>' +
						'<td data-label="Uwagi / cel" class="long">' + up(r.uwagi) + '</td></tr>';
				}).join('') + '</tbody></table></div>';
			pbBind();
		}).catch(function (e) { tb.innerHTML = '<p class="msm-alert msm-alert-err">' + esc(e.message) + '</p>'; });
		function pbBind() {
			var a = tb.querySelector('[data-pbkarta]');
			if (a) a.addEventListener('click', function () { store('zlecenie_nr', nr); }); // Karta zlecenia otworzy się od razu na tym numerze
		}
	}

	function zlecView(d) {
		d.rezerwacje = d.rezerwacje || [];
		var przOn = Array.isArray(d.przesylki); // null = brak dostępu do zakładki Przesyłki
		var prz = przOn ? d.przesylki : [];
		var empty = !d.pobrania.length && !d.wnioski.length && !d.wz.length && !d.rezerwacje.length && !prz.length;
		/* Dane projektu z Produkcji: klient, nr zlecenia klienta, start i koniec. */
		var P = d.projekt;
		var info = P ? '<dl class="msm-zlec-info">' +
			'<div><dt>Klient</dt><dd>' + (P.klient ? esc(P.klient) : '<span class="msm-muted">—</span>') + '</dd></div>' +
			'<div><dt>Nr zlecenia klienta</dt><dd>' + (P.nr_zlec_klienta ? esc(P.nr_zlec_klienta) : '<span class="msm-muted">—</span>') + '</dd></div>' +
			'<div><dt>Start projektu</dt><dd>' + (P.start ? esc(P.start) : '<span class="msm-muted">—</span>') + '</dd></div>' +
			'<div><dt>Koniec projektu</dt><dd>' + (P.koniec ? esc(P.koniec) : '<span class="msm-muted">—</span>') + '</dd></div></dl>' +
			(P.link ? '<a class="msm-link msm-zlec-prod" href="#prod-' + P.id + '">Otwórz zlecenie w Produkcji ›</a>' : '') : '';
		if (empty) return '<div class="msm-card msm-zlec-head"><div class="msm-zlec-head__t"><h2>Zlecenie ' + esc(d.nr) + (P && P.nazwa ? ' <span class="msm-zlec-head__n">' + esc(P.nazwa) + '</span>' : '') + '</h2>' + info + '<p class="msm-muted msm-zlec-none">Brak pobranego materiału ani przesyłek do tego zlecenia.</p></div></div>';
		function ilo(r) { return fmtNum(r.ilosc) + ' ' + (r.jednostka === 'szt' ? 'szt.' : (r.jednostka || '')); }
		function odc(r) { return r.tryb === 'odcinek' && r.odc_szt ? ' <small class="msm-muted">(' + r.odc_szt + ' szt. × ' + fmtNum(r.odc_dl) + ' m)</small>' : ''; }
		function up(v) { return v ? esc(v) : '<span class="msm-muted">—</span>'; }
		var chips = '<div class="msm-zlec-chips">' +
			'<span class="msm-chip msm-chip-sm">Pobrania: ' + d.pobrania.length + '</span>' +
			'<span class="msm-chip msm-chip-sm">Wnioski: ' + d.wnioski.length + '</span>' +
			'<span class="msm-chip msm-chip-sm">Pozycje WZ: ' + d.wz.length + '</span>' +
			'<span class="msm-chip msm-chip-sm">Rezerwacje: ' + d.rezerwacje.length + '</span>' +
			(przOn ? '<span class="msm-chip msm-chip-sm">Przesyłki: ' + prz.length + '</span>' : '') + '</div>';
		// generic table builder: col = [label, fn, isLong]
		function tbl(title, rows, cols) {
			if (!rows.length) return '';
			return '<div class="msm-zlec-sec"><h3>' + esc(title) + ' <span class="msm-muted">(' + rows.length + ')</span></h3>' +
				'<div class="msm-table-wrap"><table class="msm-table msm-zlec-tbl"><thead><tr>' + cols.map(function (c) { return '<th' + (c[2] ? ' class="long"' : '') + '>' + esc(c[0]) + '</th>'; }).join('') + '</tr></thead><tbody>' +
				rows.map(function (r) { return '<tr>' + cols.map(function (c) { return '<td data-label="' + esc(c[0]) + '"' + (c[2] ? ' class="long"' : '') + '><span class="msm-zt__v">' + c[1](r) + '</span></td>'; }).join('') + '</tr>'; }).join('') +
				'</tbody></table></div></div>';
		}
		var pob = tbl('Pobrania', d.pobrania, [
			['Data', function (r) { return esc(fmtDate(r.data)); }],
			['Magazyn', function (r) { return up(r.tabela); }],
			['Materiał', function (r) { return esc(r.material || '') + odc(r); }],
			['Ilość', function (r) { return esc(ilo(r)); }],
			['Pobrał / dla kogo', function (r) { return up(r.odbiorca); }],
			['Wprowadził', function (r) { return up(r.user_name); }],
			['Wpisana', function (r) { return r.wpisana == 1 ? '<span class="msm-tag msm-tag-ok">tak</span>' : '<span class="msm-tag msm-tag-no">nie</span>'; }],
			['Uwagi / cel', function (r) { return up(r.uwagi); }, true]
		]);
		var wn = tbl('Wnioski', d.wnioski, [
			['Data', function (r) { return esc(fmtDate(r.data)); }],
			['Typ', function (r) { return '<span class="msm-tag msm-tag-typ-' + esc(r.typ) + '">' + esc(W_TYPES[r.typ] || r.typ) + '</span>'; }],
			['Wnioskujący', function (r) { return up(r.user_name); }],
			['Materiał', function (r) { return esc(r.material || ''); }],
			['Rysunek', function (r) { return up(r.rysunek); }],
			['Ilość', function (r) { return esc(ilo(r)); }],
			['Status', function (r) { return '<span class="msm-tag msm-tag-st-' + esc(r.status) + '">' + esc(W_LABELS[r.status] || r.status) + '</span>'; }],
			['Rozpatrzył', function (r) { return up(r.decided_name); }],
			['Odpowiedź', function (r) { return up(r.admin_note); }, true],
			['Cel / uwagi', function (r) { return up(r.uwagi); }, true]
		]);
		var wz = tbl('Pozycje WZ', d.wz, [
			['WZ', function (r) { return r.numer ? '<b>' + esc(/^WZ\b/.test(r.numer) ? r.numer : 'WZ ' + r.numer) + '</b>' : '<span class="msm-muted">szkic</span>'; }],
			['Data', function (r) { return esc(fmtDate(r.data_wysylki)); }],
			['Odbiorca', function (r) { return up(r.odbiorca); }],
			['Przeznaczenie', function (r) { return up(r.przeznaczenie); }],
			['Transport', function (r) { return up(r.transport); }],
			['Status', function (r) { return '<span class="msm-tag msm-tag-wz-' + esc(r.status) + '">' + esc(WZ_LABELS[r.status] || r.status) + '</span>'; }],
			['Indeks', function (r) { return up(r.indeks); }],
			['Rysunek', function (r) { return up(r.rysunek); }],
			['Materiał', function (r) { return esc(r.material || '') + (r.src === 'magazyn' ? ' <small class="msm-muted">(z magazynu)</small>' : ''); }],
			['Ilość', function (r) { return esc(ilo(r)); }],
			['Uwagi WZ', function (r) { return up(r.uwagi); }, true]
		]);
		var rez = tbl('Rezerwacje', d.rezerwacje, [
			['Złożono', function (r) { return esc(fmtDate(r.created_at)); }],
			['Materiał', function (r) { return esc(r.material || ''); }],
			['Ilość', function (r) { return esc(fmtNum(r.ilosc) + (r.tryb === 'odcinek' ? ' m' : ' szt.')); }],
			['Termin', function (r) { return r.termin ? esc(fmtDate(r.termin)) : '<span class="msm-muted">bez terminu</span>'; }],
			['Status', function (r) { return '<span class="msm-tag msm-tag-rez-' + esc(r.status) + '">' + esc(REZ_LABELS[r.status] || r.status) + '</span>'; }],
			['Zarezerwował', function (r) { return up(r.user_name); }],
			['Rozpatrzył', function (r) { return up(r.decided_name); }],
			['Uwagi', function (r) { return up(r.uwagi); }, true]
		]);
		// Przesyłki przychodzące: pokazujemy tylko pozycje do tego zlecenia (pozostałe – jako liczba).
		var przT = tbl('Przesyłki przychodzące', prz, [
			['Data dostawy', function (r) { var dt = przDT(r.data_spr); return esc(dt.d) + (dt.t ? ' <small class="msm-muted">' + esc(dt.t) + '</small>' : ''); }],
			['Nadawca', function (r) { return up(r.nadawca); }],
			['Zlecenie', function (r) { var x = r.pozycje[0] || {}; return przZlLink(x.zlec_id, x.zlecenie); }],
			['Zawartość', function (r) {
				return r.pozycje.map(function (x) {
					return '<div>' + (x.opis ? esc(x.opis) : '<span class="msm-muted">—</span>') + (przIl(x) ? ' · <b>' + esc(przIl(x)) + '</b>' : '') + (x.uwagi ? ' <small class="msm-muted">' + esc(/^\(.*\)$/.test(x.uwagi.trim()) ? x.uwagi.trim() : '(' + x.uwagi + ')') + '</small>' : '') + '</div>';
				}).join('') + (r.inne ? '<small class="msm-muted">+ ' + r.inne + ' poz. do innych zleceń</small>' : '');
			}, true],
			['Faktura', function (r) { return r.faktura ? '<span class="msm-tag msm-tag-ok">tak</span>' : '<span class="msm-tag msm-tag-no">nie</span>'; }],
			['Stan', function (r) { return r.uszkodzona ? '<span class="msm-tag msm-tag-st-odrzucony">uszkodzona</span>' : '<span class="msm-muted">bez uwag</span>'; }],
			['Sprawdził', function (r) { return up(r.sprawdzil); }],
			['Uwagi', function (r) { return up(r.uwagi); }, true]
		]);
		var pdfU = function (dl) { return buildUrl('/zlecenie/' + encodeURIComponent(d.nr) + '/pdf', dl ? { _wpnonce: C.nonce, pobierz: 1 } : { _wpnonce: C.nonce }); };
		var pdfB = '<a class="msm-btn msm-zlec-pdf" href="' + esc(pdfU(true)) + '" data-view="file" data-open="' + esc(pdfU(false)) + '" data-name="' + esc('karta-zlecenia-' + d.nr.replace(/[\s\/]+/g, '-') + '.pdf') + '">' +
			'<svg class="msm-ico" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5M12 12v6M9 15l3 3 3-3"/></svg>PDF</a>';
		return '<div class="msm-card msm-zlec-head"><div class="msm-zlec-head__t"><div class="msm-zlec-head__row"><h2>Zlecenie ' + esc(d.nr) + (P && P.nazwa ? ' <span class="msm-zlec-head__n">' + esc(P.nazwa) + '</span>' : '') + '</h2>' + pdfB + '</div>' + chips + info + '</div></div>' + pob + wn + wz + rez + przT;
	}

	function renderZamowienia() {
		var main = document.getElementById('msm-main');
		main.innerHTML = '<div class="msm-cat"><div class="msm-pagehead"><div><h1>Do zamówienia</h1><p class="msm-muted">Braki materiału dla zleceń i blachy pełne poniżej stanu minimalnego</p></div>' +
			'<div class="msm-pagehead__tools" data-zamtools hidden>' +
			'<button type="button" class="msm-btn msm-btn-primary" data-zamorder disabled hidden>Utwórz zamówienie</button>' +
			'<button type="button" class="msm-btn" data-zamprint>Drukuj listę</button>' +
			'<button type="button" class="msm-btn" data-zamprintsel disabled>Drukuj zaznaczone</button>' +
			'<button type="button" class="msm-btn msm-ftoggle" data-ftoggle aria-expanded="true">' + ICON_FILTER + '<span data-ftlabel>Ukryj filtry</span><span class="msm-badge" data-ftcount hidden></span></button>' +
			'</div></div>' +
			'<section class="msm-zb" data-zbraki hidden></section>' +
			'<h2 class="msm-zb__h" data-zminh hidden>Poniżej stanu minimalnego</h2>' +
			'<div class="msm-filters" aria-label="Filtry" data-zamfwrap hidden><div class="msm-filters__body" data-zamflt></div></div>' +
			'<div class="msm-table-wrap" data-zam><div class="msm-loading">Ładowanie…</div></div></div>';
		var box = main.querySelector('[data-zam]');
		var fltBox = main.querySelector('[data-zamflt]');
		var all = [];
		var sel = { gat: {}, mat: {}, grub: {}, rozm: {} };
		var selIds = {}; // zaznaczone rozmiary (po id pozycji magazynowej)

		function zamMat(r) { return r.stal || r.material || ''; }
		function chosen(k) { return Object.keys(sel[k]).filter(function (v) { return sel[k][v]; }); }
		function selectedIds() { return Object.keys(selIds).filter(function (id) { return selIds[id]; }); }

		function passFilter(r) {
			var g = chosen('gat'), ma = chosen('mat'), gr = chosen('grub'), ro = chosen('rozm');
			if (g.length && g.indexOf(r.gatunek) < 0) return null;
			if (ma.length && ma.indexOf(zamMat(r)) < 0) return null;
			if (gr.length && gr.indexOf(String(r.grubosc)) < 0) return null;
			var sizes = r.sizes || [];
			if (ro.length) { sizes = sizes.filter(function (s) { return ro.indexOf(s.rozmiar) >= 0; }); if (!sizes.length) return null; }
			var c = {}; for (var k in r) c[k] = r[k]; c.sizes = sizes; return c;
		}

		function visibleSizeIds() {
			var ids = [];
			box.querySelectorAll('.msm-zam-cb').forEach(function (cb) { ids.push(+cb.getAttribute('data-sid')); });
			return ids;
		}

		function updateSelUI() {
			box.querySelectorAll('.msm-zam-cb').forEach(function (cb) { cb.checked = !!selIds[+cb.getAttribute('data-sid')]; });
			box.querySelectorAll('.msm-zam-gcb').forEach(function (g) {
				var gids = (g.getAttribute('data-gids') || '').split(',').filter(Boolean).map(Number);
				var on = gids.filter(function (id) { return selIds[id]; }).length;
				g.checked = on > 0 && on === gids.length;
				g.indeterminate = on > 0 && on < gids.length;
			});
			var vis = visibleSizeIds();
			var selVis = vis.filter(function (id) { return selIds[id]; });
			var master = box.querySelector('.msm-zam-master');
			if (master) { master.checked = vis.length > 0 && selVis.length === vis.length; master.indeterminate = selVis.length > 0 && selVis.length < vis.length; }
			var n = selectedIds().length;
			var btn = main.querySelector('[data-zamprintsel]');
			if (btn) { btn.disabled = n === 0; btn.textContent = 'Drukuj zaznaczone' + (n ? ' (' + n + ')' : ''); }
			syncOrderBtn();
		}

		function renderTable() {
			var rows = all.map(passFilter).filter(Boolean);
			if (!rows.length) { box.innerHTML = '<div class="msm-card msm-empty"><p class="msm-muted">Brak blach spełniających filtr.</p></div>'; updateSelUI(); return; }
			box.innerHTML = '<table class="msm-table msm-zam-tab"><thead><tr><th>Rozmiar</th><th>Stan</th><th>Min.</th><th>Brakuje</th><th class="msm-zam-chk"><input type="checkbox" class="msm-zam-master" aria-label="Zaznacz wszystkie"></th></tr></thead><tbody>' +
				rows.map(function (r) {
					var gids = r.sizes.map(function (s) { return s.id; }).join(',');
					var head = '<tr class="msm-zam-ghead"><td colspan="4" data-label="Blacha"><b class="msm-zam-ident">' + esc(r.nazwa) + '</b></td>' +
						'<td class="msm-zam-chk" data-label="Zaznacz blachę"><input type="checkbox" class="msm-zam-gcb" data-gids="' + gids + '" aria-label="Zaznacz całą blachę"></td></tr>';
					var body = r.sizes.map(function (s) {
						var brak = s.low ? '<b class="msm-brak">' + fmtNum(s.brak) + ' szt.</b>' : '<span class="msm-zam-ok">na stanie</span>';
						return '<tr class="msm-zam-srow' + (s.low ? ' is-low' : '') + '">' +
							'<td data-label="Rozmiar"><b>' + esc(s.rozmiar) + '</b>' + (s.opis ? ' <small class="msm-muted" title="Pozycja zapisana w magazynie jako: ' + esc(s.opis) + '">' + esc(s.opis) + '</small>' : '') + '</td>' +
							'<td data-label="Stan">' + fmtNum(s.ilosc) + ' szt.</td>' +
							'<td data-label="Min.">' + (s.min_stan > 0 ? fmtNum(s.min_stan) + ' szt.' : '—') + '</td>' +
							'<td data-label="Brakuje">' + brak + '</td>' +
							'<td class="msm-zam-chk" data-label="Do druku"><input type="checkbox" class="msm-zam-cb" data-sid="' + s.id + '" aria-label="Zaznacz rozmiar"></td></tr>';
					}).join('');
					return head + body;
				}).join('') + '</tbody></table>';
			box.querySelectorAll('.msm-zam-cb').forEach(function (cb) {
				cb.addEventListener('change', function () { selIds[+cb.getAttribute('data-sid')] = cb.checked; updateSelUI(); });
			});
			box.querySelectorAll('.msm-zam-gcb').forEach(function (g) {
				g.addEventListener('change', function () {
					(g.getAttribute('data-gids') || '').split(',').filter(Boolean).map(Number).forEach(function (id) { selIds[id] = g.checked; });
					updateSelUI();
				});
			});
			var master = box.querySelector('.msm-zam-master');
			if (master) master.addEventListener('change', function () { visibleSizeIds().forEach(function (id) { selIds[id] = master.checked; }); updateSelUI(); });
			updateSelUI();
		}

		/* Liczba aktywnych filtrów – na plakietce „Wyczyść filtry” i przycisku „Pokaż filtry”. */
		function syncCount() {
			var n = chosen('gat').length + chosen('mat').length + chosen('grub').length + chosen('rozm').length;
			main.querySelectorAll('[data-zamfcount],[data-ftcount]').forEach(function (el) { el.textContent = n; el.hidden = !n; });
		}

		function buildFilters() {
			var gats = [], mats = [], grubs = [], rozms = [];
			all.forEach(function (r) {
				if (r.gatunek && gats.indexOf(r.gatunek) < 0) gats.push(r.gatunek);
				if (zamMat(r) && mats.indexOf(zamMat(r)) < 0) mats.push(zamMat(r));
				if ((r.grubosc || r.grubosc === 0) && grubs.indexOf(String(r.grubosc)) < 0) grubs.push(String(r.grubosc));
				(r.sizes || []).forEach(function (s) { if (s.rozmiar && s.rozmiar !== '—' && rozms.indexOf(s.rozmiar) < 0) rozms.push(s.rozmiar); });
			});
			gats.sort(); mats.sort(); rozms.sort();
			grubs.sort(function (a, b) { return parseFloat(a) - parseFloat(b); });

			/* Pole filtra w stylu listy wyboru, ale z wielokrotnym wyborem (checkboxy w rozwijanym panelu). */
			function field(label, key, vals, suffix) {
				if (!vals.length) return '';
				return '<div class="msm-f msm-ms" data-ms="' + key + '"><span>' + label + '</span>' +
					'<button type="button" class="msm-ms__btn" data-msbtn aria-haspopup="listbox" aria-expanded="false"><span data-mstxt>Wszystkie</span></button>' +
					'<div class="msm-ms__pop" data-mspop hidden role="listbox" aria-multiselectable="true">' +
					vals.map(function (v) {
						return '<label class="msm-ms__opt"><input type="checkbox" data-fk="' + key + '" value="' + esc(v) + '"><span>' + esc(v) + (suffix || '') + '</span></label>';
					}).join('') +
					'<button type="button" class="msm-ms__clr" data-msclr>Wyczyść</button></div></div>';
			}
			function label(key, suffix) {
				var c = chosen(key);
				if (!c.length) return 'Wszystkie';
				if (c.length === 1) return c[0] + (suffix || '');
				return c.length + ' wybrane';
			}
			var SUF = { gat: '', mat: '', grub: ' mm', rozm: '' };
			function refreshField(f) {
				var k = f.getAttribute('data-ms');
				f.querySelector('[data-mstxt]').textContent = label(k, SUF[k]);
				f.classList.toggle('is-on', chosen(k).length > 0);
				f.querySelectorAll('input[data-fk]').forEach(function (cb) { cb.checked = !!sel[k][cb.value]; });
			}
			function closeAll(except) {
				fltBox.querySelectorAll('.msm-ms.is-open').forEach(function (f) {
					if (f === except) return;
					f.classList.remove('is-open'); f.querySelector('[data-mspop]').hidden = true; f.querySelector('[data-msbtn]').setAttribute('aria-expanded', 'false');
				});
			}

			main.querySelector('[data-zamfwrap]').hidden = false;
			main.querySelector('[data-zamtools]').hidden = false;
			fltBox.innerHTML = field('Gatunek', 'gat', gats, '') + field('Materiał', 'mat', mats, '') + field('Grubość [mm]', 'grub', grubs, ' mm') + field('Rozmiar', 'rozm', rozms, '') +
				'<div class="msm-f msm-zam-fclear"><button type="button" class="msm-link" data-zamclear>Wyczyść filtry <span class="msm-badge" data-zamfcount hidden></span></button></div>';

			fltBox.querySelectorAll('.msm-ms').forEach(function (f) {
				var pop = f.querySelector('[data-mspop]'), btn = f.querySelector('[data-msbtn]');
				btn.addEventListener('click', function (e) {
					e.stopPropagation();
					var open = pop.hidden;
					closeAll(f);
					pop.hidden = !open; f.classList.toggle('is-open', open); btn.setAttribute('aria-expanded', open ? 'true' : 'false');
				});
				pop.addEventListener('click', function (e) { e.stopPropagation(); });
				f.querySelectorAll('input[data-fk]').forEach(function (cb) {
					cb.addEventListener('change', function () {
						sel[cb.getAttribute('data-fk')][cb.value] = cb.checked;
						refreshField(f); syncCount(); renderTable();
					});
				});
				f.querySelector('[data-msclr]').addEventListener('click', function () {
					sel[f.getAttribute('data-ms')] = {};
					refreshField(f); syncCount(); renderTable();
				});
			});
			/* Zamknięcie panelu: klik poza nim albo Esc (nasłuch usuwa się sam po zmianie strony). */
			function outside() { if (!document.body.contains(fltBox)) { document.removeEventListener('click', outside); document.removeEventListener('keydown', esc_); return; } closeAll(null); }
			function esc_(e) { if (e.key === 'Escape') outside(); }
			document.addEventListener('click', outside);
			document.addEventListener('keydown', esc_);

			fltBox.querySelector('[data-zamclear]').addEventListener('click', function () {
				sel = { gat: {}, mat: {}, grub: {}, rozm: {} };
				fltBox.querySelectorAll('.msm-ms').forEach(refreshField);
				syncCount(); renderTable();
			});
			main.querySelector('[data-zamprint]').addEventListener('click', function () {
				window.open(printUrl({ msm_print: 'zamowienia', gat: chosen('gat').join('|'), mat: chosen('mat').join('|'), grub: chosen('grub').join('|'), rozm: chosen('rozm').join('|') }), '_blank');
			});
			main.querySelector('[data-zamprintsel]').addEventListener('click', function () {
				var ids = selectedIds();
				if (!ids.length) return;
				window.open(printUrl({ msm_print: 'zamowienia', ids: ids.join(',') }), '_blank');
			});
			/* „Ukryj / Pokaż filtry” – ten sam zapamiętany stan co w pozostałych zakładkach. */
			applyFiltersHidden();
			main.querySelector('[data-ftoggle]').addEventListener('click', function () {
				store('filters_hidden', !store('filters_hidden'));
				applyFiltersHidden();
			});
			syncCount();
		}

		/* ---- Braki dla zleceń (zapotrzebowania z produkcji) ---- */
		var BR = [], BRsel = {}, BRedit = false;
		var bBox = main.querySelector('[data-zbraki]');
		function syncOrderBtn() {
			var b = main.querySelector('[data-zamorder]'); if (!b) return;
			var n = Object.keys(BRsel).filter(function (k) { return BRsel[k]; }).length + selectedIds().length;
			b.hidden = !BRedit; b.disabled = !n; b.textContent = 'Utwórz zamówienie' + (n ? ' (' + n + ')' : '');
		}
		function renderBraki() {
			bBox.hidden = !BR.length;
			main.querySelector('[data-zminh]').hidden = !BR.length || !all.length;
			if (!BR.length) return;
			bBox.innerHTML = '<header class="msm-zb__head"><h2 class="msm-zb__h">Braki dla zleceń</h2><span class="msm-muted msm-small">Materiał zgłoszony w zleceniach produkcji, którego zabrakło na magazynie.</span></header>' +
				'<div class="msm-table-wrap"><table class="msm-table msm-zbt"><thead><tr><th>Materiał</th><th>Zlecenia</th><th class="num">Brakuje</th><th>Na zamówieniu</th><th class="num">Do zamówienia</th>' + (BRedit ? '<th class="msm-zam-chk"></th>' : '') + '</tr></thead><tbody>' +
				BR.map(function (g) {
					var u = g.jm === 'kg' ? 'kg' : 'szt.';
					return '<tr class="' + (g.do_zam > 0 ? 'is-late' : 'is-ordered') + '"><td data-label="Materiał"><span class="msm-zb__v"><b>' + esc(g.opis) + '</b><small class="msm-muted">' + esc(g.magazyn) + '</small></span></td>' +
						'<td data-label="Zlecenia"><span class="msm-zb__v msm-zb__zl">' + g.zap.map(function (z) { return '<a class="msm-chip msm-chip-sm" href="#prod-' + z.zlec_id + '-szczegoly" title="Zgłosił(a) ' + esc(z.kto) + '">' + esc(z.nr_zlec) + ' · ' + fmtNum(z.brak) + ' ' + u + '</a>'; }).join('') + '</span></td>' +
						'<td data-label="Brakuje" class="num"><b class="msm-brak">' + fmtNum(g.brak) + ' ' + u + '</b></td>' +
						'<td data-label="Na zamówieniu">' + (g.na_zam > 0 ? '<span class="msm-zb__v">' + fmtNum(g.na_zam) + ' ' + u + ' <small class="msm-muted">' + g.zam.map(esc).join(', ') + '</small></span>' : '<span class="msm-muted">—</span>') + '</td>' +
						'<td data-label="Do zamówienia" class="num">' + (g.do_zam > 0 ? '<b>' + fmtNum(g.do_zam) + ' ' + u + '</b>' : '<span class="msm-zam-ok">zamówione</span>') + '</td>' +
						(BRedit ? '<td class="msm-zam-chk" data-label="Zamów"><input type="checkbox" data-brk="' + g.klucz + '"' + (g.do_zam > 0 ? '' : ' disabled') + (BRsel[g.klucz] ? ' checked' : '') + ' aria-label="Zaznacz do zamówienia"></td>' : '') + '</tr>';
				}).join('') + '</tbody></table></div>';
			bBox.querySelectorAll('[data-brk]').forEach(function (cb) { cb.addEventListener('change', function () { BRsel[cb.getAttribute('data-brk')] = cb.checked; syncOrderBtn(); }); });
		}
		main.querySelector('[data-zamorder]').addEventListener('click', function () {
			var poz = [];
			BR.forEach(function (g) { if (BRsel[g.klucz] && g.do_zam > 0) poz.push({ tabela: g.tabela, spec: g.spec, ilosc: g.do_zam, zap: g.zap.map(function (z) { return z.id; }), opis: g.opis, jm: g.jm, zlecenia: g.zap.map(function (z) { return z.nr_zlec; }) }); });
			var ids = selectedIds().map(Number);
			all.forEach(function (r) { (r.sizes || []).forEach(function (s) { if (ids.indexOf(s.id) >= 0) poz.push({ tabela: r.tabela || 'blachy_pelne', item_id: s.id, ilosc: s.brak > 0 ? s.brak : Math.max(1, (s.min_stan || 0) - (s.ilosc || 0)) || 1, opis: r.nazwa + ' ' + s.rozmiar, jm: 'szt', zlecenia: [] }); }); });
			zamCreate(poz);
		});

		Promise.all([api('/do-zamowienia'), api('/zam/braki').catch(function () { return { braki: [], edycja: false }; })]).then(function (res) {
			all = res[0] || [];
			BR = res[1].braki || []; BRedit = !!res[1].edycja;
			if (!all.length && !BR.length) { box.innerHTML = '<div class="msm-card msm-empty"><p class="msm-muted">Nic nie brakuje: brak zgłoszonych braków dla zleceń, a blachy są powyżej stanu minimalnego. 👍</p><p class="msm-small msm-muted">Brak dla zlecenia zgłosisz w Produkcji → Szczegóły projektu → „Zapotrzebowanie”. Stan minimalny ustawisz w edycji pozycji.</p></div>'; return; }
			main.querySelector('[data-zamtools]').hidden = false;
			renderBraki();
			syncOrderBtn();
			if (!all.length) { box.innerHTML = '<div class="msm-card msm-empty msm-zb__none"><p class="msm-muted">Blachy pełne są powyżej stanu minimalnego.</p></div>'; ['[data-zamprint]', '[data-zamprintsel]', '[data-ftoggle]'].forEach(function (s) { var x = main.querySelector(s); if (x) x.hidden = true; }); return; }
			buildFilters();
			renderTable();
		}).catch(function (e) { box.innerHTML = '<p class="msm-alert msm-alert-err">' + esc(e.message) + '</p>'; });
	}

	/* ---------------- dokumenty WZ ---------------- */

	var IDX_PREFIX = { stal: 'STAL', blachy_pelne: 'BLP', blachy_niepelne: 'BLN', kregi: 'KRG' };

	/* Podpis odbierającego – rysowanie palcem/rysikiem na telefonie/tablecie. Zwraca data URL PNG albo ''. */
	function signaturePad() {
		return new Promise(function (resolve) {
			var body = '<p class="msm-muted msm-small">Poproś odbierającego o podpis palcem lub rysikiem. Podpis zapisze się na dokumencie WZ.</p>' +
				'<div class="msm-sig"><canvas class="msm-sig__c" width="760" height="260" data-sig></canvas><span class="msm-sig__hint" data-sighint>podpis tutaj</span></div>';
			var m = openModal('Podpis odbierającego', body,
				'<button type="button" class="msm-btn msm-btn-ghost msm-foot-left" data-sigskip>Pomiń (bez podpisu)</button>' +
				'<button type="button" class="msm-btn" data-sigclear>Wyczyść</button>' +
				'<button type="button" class="msm-btn msm-btn-primary" data-sigok>Zatwierdź podpis</button>', false);
			var cv = m.querySelector('[data-sig]'), ctx = cv.getContext('2d');
			var hint = m.querySelector('[data-sighint]');
			// skaluj do rzeczywistego rozmiaru wyświetlania
			function fit() {
				var r = cv.getBoundingClientRect();
				var dpr = window.devicePixelRatio || 1;
				cv.width = Math.round(r.width * dpr); cv.height = Math.round(r.height * dpr);
				ctx.scale(dpr, dpr); ctx.lineWidth = 2.2; ctx.lineCap = 'round'; ctx.lineJoin = 'round'; ctx.strokeStyle = '#0b1020';
			}
			setTimeout(fit, 30);
			var drawing = false, used = false, lastX = 0, lastY = 0;
			function pos(e) {
				var r = cv.getBoundingClientRect();
				var t = e.touches ? e.touches[0] : e;
				return { x: t.clientX - r.left, y: t.clientY - r.top };
			}
			function start(e) { e.preventDefault(); drawing = true; used = true; if (hint) hint.style.display = 'none'; var p = pos(e); lastX = p.x; lastY = p.y; }
			function move(e) { if (!drawing) return; e.preventDefault(); var p = pos(e); ctx.beginPath(); ctx.moveTo(lastX, lastY); ctx.lineTo(p.x, p.y); ctx.stroke(); lastX = p.x; lastY = p.y; }
			function end() { drawing = false; }
			cv.addEventListener('mousedown', start); cv.addEventListener('mousemove', move); window.addEventListener('mouseup', end);
			cv.addEventListener('touchstart', start, { passive: false }); cv.addEventListener('touchmove', move, { passive: false }); cv.addEventListener('touchend', end);
			m.querySelector('[data-sigclear]').addEventListener('click', function () { ctx.clearRect(0, 0, cv.width, cv.height); used = false; if (hint) hint.style.display = ''; });
			function finish(val) { window.removeEventListener('mouseup', end); closeModal(); resolve(val); }
			m.querySelector('[data-sigskip]').addEventListener('click', function () { finish(''); });
			m.querySelector('[data-sigok]').addEventListener('click', function () {
				if (!used) { toast('Brak podpisu – podpisz lub kliknij „Pomiń”.', 'err'); return; }
				// Wytnij na biało i wyeksportuj PNG.
				var out = document.createElement('canvas'); out.width = cv.width; out.height = cv.height;
				var octx = out.getContext('2d'); octx.fillStyle = '#fff'; octx.fillRect(0, 0, out.width, out.height); octx.drawImage(cv, 0, 0);
				finish(out.toDataURL('image/png'));
			});
		});
	}

	function openWZ(id, startEdit) {
		var p = id ? api('/wz/' + id) : Promise.resolve(null);
		Promise.all([p, loadOptions('wz'), api('/slowniki').catch(function () { return null; })]).then(function (res) {
			var opts = Object.assign({}, res[1] || {});
			var sl = res[2] && res[2].all;
			if (sl) {
				opts._def = {};
				Object.keys(sl).forEach(function (k) {
					var seen = {}, list = [];
					sl[k].forEach(function (r) { if (r.domyslny) opts._def[k] = r.nazwa; seen[r.nazwa.toLowerCase()] = 1; list.push({ v: r.nazwa }); });
					(opts[k] || []).forEach(function (o) { if (o.v !== '__empty__' && !seen[String(o.v).toLowerCase()]) list.push(o); });
					opts[k] = list;
				});
			}
			var doc = res[0];
			// Administrator: wystawioną WZ otwórz od razu w trybie edycji (korekta).
			var kor = startEdit && doc && doc.can_korekta && doc.status === 'wystawiona';
			renderWZ(doc, opts, kor ? { korekta: true } : undefined);
		}).catch(function (e) { toast(e.message, 'err'); });
	}

	function renderWZ(doc, opts, mode) {
		var kor = !!(mode && mode.korekta && doc && doc.can_korekta);
		var isNew = !doc;
		var def = opts._def || {};
		doc = doc || { status: 'szkic', can_edit: true, lines: [], data_wysylki: C.today, wystawil: C.user, odbiorca: def.odbiorca || '', przeznaczenie: def.przeznaczenie || '', transport: def.transport || '', wydal: '', data_dok: '', uwagi: '' };
		var ed = !!doc.can_edit || kor;
		var lines = (doc.lines || []).map(function (l) { return Object.assign({}, l); });
		if (isNew) lines.push({ src: 'reczna', indeks: '', zlecenie: '', rysunek: '', nazwa: '', ilosc: '', jm: 'szt.' });
		var dis = ed ? '' : ' disabled';

		function dl(key, idv) {
			var list = (opts[key] || []).filter(function (o) { return o.v !== '__empty__'; });
			return list.length ? '<datalist id="' + idv + '">' + list.map(function (o) { return '<option value="' + esc(o.v) + '">'; }).join('') + '</datalist>' : '';
		}
		function inp(name, label, val, extra, cls) {
			return '<label class="msm-field ' + (cls || '') + '"><span>' + label + '</span><input name="' + name + '" type="' + (extra && extra.type || 'text') + '" value="' + esc(val || '') + '"' +
				(extra && extra.list ? ' list="' + extra.list + '" autocomplete="off"' : '') + dis + '></label>';
		}
		/* Lista wyboru ze słownika + „Inna – wpisz ręcznie”. Wartość trafia do ukrytego/odkrytego pola tekstowego o tej nazwie. */
		function sel(name, label, val, cls) {
			val = val || '';
			var list = (opts[name] || []).filter(function (o) { return o.v !== '__empty__' && o.v !== ''; }).map(function (o) { return String(o.v); });
			var known = !val || list.some(function (v) { return v === val; });
			if (!known && !ed) { list.unshift(val); known = true; }
			var o = '<option value="">— wybierz —</option>' + list.map(function (v) {
				return '<option value="' + esc(v) + '"' + (v === val ? ' selected' : '') + '>' + esc(v) + (def[name] === v ? ' (domyślny)' : '') + '</option>';
			}).join('') + (ed ? '<option value="__other__"' + (known ? '' : ' selected') + '>+ Inny – wpisz ręcznie…</option>' : '');
			return '<div class="msm-field msm-wz-sel ' + (cls || '') + '"><label for="wzs-' + name + '"><span>' + label + '</span></label>' +
				'<select id="wzs-' + name + '" data-sel="' + name + '"' + dis + '>' + o + '</select>' +
				'<input name="' + name + '" type="text" value="' + esc(val) + '" placeholder="Wpisz – zostanie dodane do listy" autocomplete="off"' + (known ? ' hidden' : '') + dis + '></div>';
		}
		function locked(l) { return kor && l.id && (l.src === 'magazyn' || l.src === 'wniosek'); }
		var title = kor ? 'Edycja WZ ' + doc.numer : doc.numer ? 'WZ ' + doc.numer : (isNew ? 'Nowa WZ' : 'WZ – ' + (WZ_LABELS[doc.status] || doc.status));
		var head = '<div class="msm-wz-status"><span class="msm-tag msm-tag-wz-' + esc(doc.status) + '">' + esc(WZ_LABELS[doc.status] || doc.status) + '</span>' +
			(doc.created_name ? '<span class="msm-muted">utworzył: ' + esc(doc.created_name) + '</span>' : '') +
			(doc.issued_name ? '<span class="msm-muted">wystawił w systemie: ' + esc(doc.issued_name) + ', ' + esc(fmtDate(doc.issued_at)) + '</span>' : '') +
			(doc.canceled_name ? '<span class="msm-muted">anulował: ' + esc(doc.canceled_name) + ', ' + esc(fmtDate(doc.canceled_at)) + '</span>' : '') +
			(doc.edit_count ? '<span class="msm-tag msm-tag-wz-edit" title="Informacja tylko w systemie – nie pojawia się na wydruku">edytowano ' + doc.edit_count + '× · ostatnio ' + esc(doc.edited_name || '') + ', ' + esc(fmtDate(doc.edited_at)) + '</span>' : '') +
			(doc.id && doc.status !== 'szkic' ? '<button type="button" class="msm-btn msm-btn-sm msm-btn-ghost" data-wzhist>Historia zmian</button>' : '') + '</div>' +
			(kor ? '<div class="msm-alert msm-wz-koralert">Edytujesz wystawioną WZ – <b>numer pozostaje bez zmian</b>. Każda zmiana zostanie zapisana w historii dokumentu (nie jest widoczna na wydruku). ' +
				'Ilości pozycji pobranych z magazynu i z zapotrzebowań są zablokowane – stan został już zdjęty' + (C.canEdit ? '; usunięcie takiej pozycji zwróci stan na magazyn.' : '.') + '</div>' : '') +
			'<div class="msm-form-err msm-alert msm-alert-err" hidden></div>' +
			'<div class="msm-wz-head">' +
			sel('odbiorca', 'Odbiorca <i class="msm-req">*</i>', doc.odbiorca, 'wide') +
			sel('przeznaczenie', 'Przeznaczenie', doc.przeznaczenie) +
			sel('transport', 'Środek transportu', doc.transport) +
			inp('data_wysylki', 'Data wysyłki', doc.data_wysylki, { type: 'date' }) +
			'</div>' + dl('wystawil', 'wz-wys') + dl('wydal', 'wz-wyd');

		var tools = ed ? '<div class="msm-wz-tools">' +
			'<button type="button" class="msm-btn msm-btn-sm" data-add-manual>+ Wiersz ręczny</button>' +
			(kor && !C.canEdit ? '' : '<button type="button" class="msm-btn msm-btn-sm" data-panel="mag">+ Z magazynu</button>') +
			'<button type="button" class="msm-btn msm-btn-sm" data-panel="zap">+ Z wydanych zapotrzebowań</button>' +
			'<button type="button" class="msm-btn msm-btn-sm" data-panel="ocr">+ Z pliku / OCR</button>' +
			'<span class="msm-spacer"></span>' +
			'<label class="msm-wz-zl">Zlecenie dla wszystkich wierszy <input type="text" data-zlall placeholder="np. B71007"><button type="button" class="msm-btn msm-btn-sm msm-btn-ghost" data-zlset>Ustaw</button></label>' +
			'</div>' +
			'<div class="msm-wz-panel" data-pn="mag" hidden><div class="msm-wz-panel__bar"><select data-magt>' + STOCK.map(function (k) { return '<option value="' + k + '">' + esc(S[k].label) + '</option>'; }).join('') + '</select>' +
			'<input type="search" data-magq placeholder="Szukaj, np. płaskownik 50x30 S235"></div><div data-magres class="msm-wz-res"><p class="msm-muted">Wpisz, czego szukasz.</p></div></div>' +
			'<div class="msm-wz-panel" data-pn="zap" hidden><div class="msm-wz-panel__bar"><input type="text" data-zapzl placeholder="Numer zlecenia, np. B71007"><button type="button" class="msm-btn msm-btn-sm" data-zapgo>Pokaż wydane</button></div><div data-zapres class="msm-wz-res"></div></div>' +
			'<div class="msm-wz-panel" data-pn="ocr" hidden>' +
			'<p class="msm-muted msm-small">Wgraj PDF lub zdjęcie (np. wydruk maila) albo wklej tekst. Odczytam <b>numer rysunku</b>, <b>numer zlecenia</b> i <b>ilość</b> i dodam pozycje do WZ (możesz je potem poprawić).</p>' +
			(C.vendor
				? '<div class="msm-wz-panel__bar"><label class="msm-btn msm-btn-sm" style="cursor:pointer"><input type="file" accept="image/*,application/pdf" multiple data-wzocrfile hidden>Wybierz plik(i)</label>' +
				  '<button type="button" class="msm-btn msm-btn-sm msm-btn-primary" data-wzocrgo disabled>Rozpoznaj (OCR)</button><span class="msm-muted msm-small" data-wzocrst></span></div>'
				: '<p class="msm-alert msm-wn-info msm-small">Rozpoznawanie z pliku (OCR) wymaga wtyczki „Magazyn OCR”. Bez niej wklej tekst poniżej.</p>') +
			ocrOldHint() +
			'<textarea data-wzocrtext rows="4" placeholder="…albo wklej tutaj tekst z maila / PDF (rysunek, zlecenie, ilość w każdej linii) i kliknij „Przetwórz tekst”."></textarea>' +
			'<button type="button" class="msm-btn msm-btn-sm" data-wzocrparse>Przetwórz tekst</button>' +
			'</div>' : '';

		var foot = '<div class="msm-wz-foot">' +
			'<label class="msm-field wide"><span>Uwagi</span><textarea name="uwagi" rows="2"' + dis + '>' + esc(doc.uwagi || '') + '</textarea></label>' +
			inp('wystawil', 'Wystawił', doc.wystawil, { list: 'wz-wys' }) + inp('wydal', 'Wydał', doc.wydal, { list: 'wz-wyd' }) + inp('data_dok', 'Data (wydania)', doc.data_dok, { type: 'date' }) +
			'</div>';

		var body = head + '<h3 class="msm-wz-h">Pozycje</h3>' + tools + '<div data-lines></div>' + foot;

		var btns = '<button type="button" class="msm-btn msm-btn-ghost" data-close>Zamknij</button>';
		if (kor) btns = '<button type="button" class="msm-btn msm-btn-ghost" data-korback>Anuluj edycję</button><button type="button" class="msm-btn msm-btn-primary" data-wzkor>Zapisz zmiany</button>';
		else {
		if (doc.id) btns += '<button type="button" class="msm-btn" data-wzprintdoc>Drukuj' + (ed ? ' podgląd' : '') + '</button>';
		if (doc.id && !ed) btns += xbtn('xlsx', '', 'Pobierz WZ w Excelu (.xlsx)', printUrl({ msm_print: 'wzxlsx', id: doc.id })) + '<button type="button" class="msm-btn" data-wzdup>Duplikuj</button>';
		if (doc.id && !ed && C.canEdit && doc.status === 'wystawiona') btns += '<button type="button" class="msm-btn msm-btn-danger-ghost" data-wzcancel>Anuluj WZ</button>';
		if (ed && doc.id && (doc.status === 'szkic')) btns += '<button type="button" class="msm-btn msm-btn-danger-ghost" data-wzdel>Usuń szkic</button>';
		if (ed && C.canEdit && doc.status === 'do_zatwierdzenia') btns += '<button type="button" class="msm-btn msm-btn-danger-ghost" data-wzreject>Zwróć do poprawy</button>';
		if (doc.id && !ed && doc.can_korekta) btns += '<button type="button" class="msm-btn msm-btn-primary" data-wzedit>Edytuj WZ</button>';
		if (ed) btns += '<button type="button" class="msm-btn" data-wzsave>Zapisz szkic</button>' + ((!C.canEdit || capOn('wz')) ? '<button type="button" class="msm-btn msm-btn-primary" data-wzissue></button>' : '');
		}

		var m = openModal(title, body, btns, true);
		m.querySelector('.msm-modal').classList.add('msm-wzmodal');
		var issueBtn = m.querySelector('[data-wzissue]');
		m.querySelectorAll('[data-sel]').forEach(function (sl) {
			var tx = m.querySelector('input[name=' + sl.getAttribute('data-sel') + ']');
			sl.addEventListener('change', function () {
				if (sl.value === '__other__') { tx.hidden = false; tx.value = ''; tx.focus(); }
				else { tx.hidden = true; tx.value = sl.value; }
			});
		});

		function syncLines() {
			m.querySelectorAll('[data-li]').forEach(function (tr) {
				var l = lines[+tr.getAttribute('data-li')];
				tr.querySelectorAll('[data-f]').forEach(function (el) { l[el.getAttribute('data-f')] = el.value; });
			});
		}
		function updateIssueLabel() {
			if (!issueBtn) return;
			var hasStock = lines.some(function (l) { return l.src === 'magazyn'; });
			if (C.canEdit) issueBtn.textContent = doc.status === 'do_zatwierdzenia' ? 'Zatwierdź i wystaw' : 'Wystaw WZ';
			else issueBtn.textContent = hasStock ? 'Wyślij do zatwierdzenia' : 'Wystaw WZ';
		}
		function renderLines() {
			var box = m.querySelector('[data-lines]');
			if (!lines.length) { box.innerHTML = '<p class="msm-empty">Brak pozycji. Dodaj wiersz ręczny, z magazynu albo z zapotrzebowań.</p>'; updateIssueLabel(); return; }
			box.innerHTML = '<table class="msm-table msm-wz-lines"><colgroup><col style="width:44px"><col style="width:13%"><col style="width:12%"><col style="width:13%"><col><col style="width:84px"><col style="width:118px">' + (ed ? '<col style="width:46px">' : '') + '</colgroup><thead><tr><th class="num">Lp.</th><th>Nr indeksu</th><th>Nr zlecenia</th><th>Nr rysunku</th><th>Nazwa</th><th class="num">Ilość</th><th>j.m.</th>' + (ed ? '<th></th>' : '') + '</tr></thead><tbody>' +
				lines.map(function (l, i) {
					var src = '';
					if (l.src === 'magazyn') src = '<small class="msm-wz-src mag">z magazynu: ' + esc(S[l.item_table] ? S[l.item_table].label : '') + (l.stock !== null && l.stock !== undefined ? ' · na stanie ' + fmtNum(l.stock) + ' ' + U(l.item_table) + (l.stock_len ? ' po ' + fmtNum(l.stock_len) + ' m' : '') : '') + (doc.status === 'wystawiona' ? (l.id ? ' · zdjęto ze stanu' : ' · zdejmie stan przy zapisie') : ' · zdejmie stan przy wystawieniu') + '</small>';
					if (l.src === 'wniosek') src = '<small class="msm-wz-src zap">wydane wg zapotrzebowania #' + l.wniosek_id + ' – stan już zdjęty</small>';
					var lk = locked(l);
					var jm = lk ? '<input type="text" data-f="jm" value="' + esc(l.jm || 'szt.') + '" readonly title="Stan już zdjęty – j.m. bez zmian">' : (l.src === 'magazyn')
						? (l.item_table === 'stal' ? '<select data-f="jm"' + dis + '><option' + (l.jm !== 'm' ? ' selected' : '') + '>szt.</option><option value="m"' + (l.jm === 'm' ? ' selected' : '') + '>m (odcinek)</option></select>' : '<input type="text" data-f="jm" value="' + U(l.item_table) + '" readonly>')
						: '<input type="text" data-f="jm" value="' + esc(l.jm || 'szt.') + '" list="wz-jm"' + dis + '>';
					return '<tr data-li="' + i + '"><td class="num">' + (i + 1) + '.</td>' +
						'<td data-label="Nr indeksu"><input type="text" placeholder="Nr indeksu" data-f="indeks" value="' + esc(l.indeks || '') + '"' + dis + '></td>' +
						'<td data-label="Nr zlecenia"><input type="text" placeholder="Nr zlecenia" data-f="zlecenie" value="' + esc(l.zlecenie || '') + '"' + dis + '></td>' +
						'<td data-label="Nr rysunku"><input type="text" placeholder="Nr rysunku" data-f="rysunek" value="' + esc(l.rysunek || '') + '"' + dis + '></td>' +
						'<td class="w-name" data-label="Nazwa"><input type="text" placeholder="Nazwa" data-f="nazwa" value="' + esc(l.nazwa || '') + '"' + dis + '>' + src + '</td>' +
						'<td class="w-qty" data-label="Ilość"><input type="text" placeholder="Ilość" data-f="ilosc" inputmode="decimal" value="' + esc(l.ilosc === '' || l.ilosc === null || l.ilosc === undefined ? '' : String(l.ilosc).replace('.', ',')) + '"' + (l.src === 'wniosek' || lk ? ' readonly' + (lk ? ' title="Stan już zdjęty – ilość bez zmian"' : '') : dis) + '></td>' +
						'<td class="w-jm" data-label="J.m.">' + jm + '</td>' +
						(ed ? '<td>' + (kor && l.id && l.src === 'magazyn' && !C.canEdit ? '' : '<button type="button" class="msm-iconbtn msm-iconbtn-danger" data-rm="' + i + '" title="' + (kor && l.pobranie_id ? 'Usuń wiersz – stan wróci na magazyn' : 'Usuń wiersz') + '">' + ICON_DEL + '</button>') + '</td>' : '') + '</tr>';
				}).join('') + '</tbody></table><datalist id="wz-jm"><option value="szt."><option value="kpl."><option value="kg"><option value="m"><option value="mb"></datalist>';
			box.querySelectorAll('[data-rm]').forEach(function (b) {
				b.addEventListener('click', function () { syncLines(); lines.splice(+b.getAttribute('data-rm'), 1); renderLines(); });
			});
			updateIssueLabel();
		}
		renderLines();

		function collect() {
			syncLines();
			var h = {};
			['odbiorca', 'przeznaczenie', 'transport', 'data_wysylki', 'wystawil', 'wydal', 'data_dok', 'uwagi'].forEach(function (k) {
				var el = m.querySelector('[name=' + k + ']'); h[k] = el ? el.value : '';
			});
			return { header: h, lines: lines };
		}
		function showErr(e) {
			var g = m.querySelector('.msm-form-err');
			g.innerHTML = esc(e.message).replace(/\n/g, '<br>'); g.hidden = false;
			m.querySelector('.msm-modal-body').scrollTop = 0;
		}
		function save() {
			return api(doc.id ? '/wz/' + doc.id : '/wz', { method: 'POST', body: collect() }).then(function (d) { doc = d; return d; });
		}
		function done(msg) { closeModal(); toast(msg); refresh('wz'); pollWZ(); }

		if (ed) {
			m.querySelector('[data-add-manual]').addEventListener('click', function () {
				syncLines();
				var zl = m.querySelector('[data-zlall]').value.trim();
				lines.push({ src: 'reczna', indeks: '', zlecenie: zl, rysunek: '', nazwa: '', ilosc: '', jm: 'szt.' });
				renderLines();
				var last = m.querySelectorAll('[data-f=nazwa]'); if (last.length) last[last.length - 1].focus();
			});
			m.querySelector('[data-zlset]').addEventListener('click', function () {
				syncLines();
				var zl = m.querySelector('[data-zlall]').value.trim().toUpperCase();
				if (!zl) return;
				lines.forEach(function (l) { l.zlecenie = zl; });
				renderLines();
			});
			m.querySelectorAll('[data-panel]').forEach(function (b) {
				b.addEventListener('click', function () {
					var k = b.getAttribute('data-panel');
					m.querySelectorAll('[data-pn]').forEach(function (p) { p.hidden = p.getAttribute('data-pn') !== k ? true : !p.hidden; });
					var f = m.querySelector('[data-pn="' + k + '"] input:not([type=file])'); if (f) f.focus();
				});
			});
			// OCR / z pliku
			var wzOcrFiles = [];
			var wzOcrFile = m.querySelector('[data-wzocrfile]'), wzOcrGo = m.querySelector('[data-wzocrgo]'), wzOcrSt = m.querySelector('[data-wzocrst]');
			if (wzOcrFile) wzOcrFile.addEventListener('change', function () {
				wzOcrFiles = Array.prototype.slice.call(wzOcrFile.files);
				if (wzOcrGo) wzOcrGo.disabled = !wzOcrFiles.length;
				if (wzOcrSt) wzOcrSt.textContent = wzOcrFiles.length ? wzOcrFiles.length + ' plik(ów) gotowych' : '';
			});
			function wzAddParsed(rows) {
				if (!rows.length) { toast('Nie rozpoznano pozycji – wklej tekst albo dodaj ręcznie.', 'err'); return; }
				syncLines();
				rows.forEach(function (r) { lines.push(r); });
				renderLines();
				toast('Dodano ' + rows.length + ' pozycji z OCR. Sprawdź i popraw w razie potrzeby.');
			}
			if (wzOcrGo) wzOcrGo.addEventListener('click', function () {
				if (!wzOcrFiles.length) return;
				wzOcrGo.disabled = true; var total = wzOcrFiles.length, fileNo = 0, texts = [], geo = { pages: [] };
				if (wzOcrSt) wzOcrSt.textContent = 'Wczytywanie modułu OCR…';
				var chain = getOcr(function (mm) {
					if (mm.status === 'recognizing text' && wzOcrSt) wzOcrSt.textContent = 'Rozpoznawanie… ' + Math.round(mm.progress * 100) + '% (plik ' + (fileNo + 1) + '/' + total + ')';
				});
				wzOcrFiles.forEach(function (f, i) {
					chain = chain.then(function (w) {
						fileNo = i;
						return pdfRead(f).then(function (pr) {
							if (pr.text && pr.text.replace(/\s/g, '').length > 40) { texts.push(pr.text); geo.pages = geo.pages.concat(pr.geo.pages); return w; }
							return fileToCanvases(f).then(function (cvs) { var c2 = Promise.resolve(); cvs.forEach(function (cv) { c2 = c2.then(function () { return ocrRead(w, cv); }).then(function (r) { texts.push(r.text); geo.pages.push(r.page); }); }); return c2.then(function () { return w; }); });
						});
					});
				});
				chain.then(function () {
					var txt = texts.join('\n');
					var ta = m.querySelector('[data-wzocrtext]'); if (ta) ta.value = txt;
					if (wzOcrSt) wzOcrSt.textContent = 'Gotowe.';
					wzAddParsed(parseWZDoc(txt, geo));
				}).catch(function (e) { if (wzOcrSt) wzOcrSt.textContent = ''; toast(e.message || 'Błąd OCR.', 'err'); }).then(function () { wzOcrGo.disabled = false; });
			});
			var wzOcrParse = m.querySelector('[data-wzocrparse]');
			if (wzOcrParse) wzOcrParse.addEventListener('click', function () {
				var ta = m.querySelector('[data-wzocrtext]');
				wzAddParsed(parseWZ(ta ? ta.value : ''));
			});
			// z magazynu
			var magq = m.querySelector('[data-magq]'), magt = m.querySelector('[data-magt]');
			var searchMag = debounce(function () {
				var t2 = magt.value, q = magq.value.trim(), out = m.querySelector('[data-magres]');
				if (!q) { out.innerHTML = '<p class="msm-muted">Wpisz, czego szukasz.</p>'; return; }
				api('/t/' + t2, { query: { q: q, per_page: 15, hide_zero: 1 } }).then(function (d) {
					if (!d.rows.length) { out.innerHTML = '<p class="msm-muted">Brak pozycji na stanie.</p>'; return; }
					out.innerHTML = d.rows.map(function (r) {
						return '<div class="msm-wz-hit"><span><b>' + esc(rowTitle(t2, r)) + '</b><small>na stanie ' + fmtNum(r.ilosc) + ' ' + U(t2) + (r.uwagi ? ' · ' + esc(r.uwagi) : '') + '</small></span>' +
							'<input type="text" inputmode="decimal" value="1" data-q>' + '<button type="button" class="msm-btn msm-btn-sm msm-btn-primary" data-pick="' + r.id + '">Dodaj</button></div>';
					}).join('');
					out.querySelectorAll('[data-pick]').forEach(function (b) {
						b.addEventListener('click', function () {
							var r = d.rows.filter(function (x) { return x.id === +b.getAttribute('data-pick'); })[0];
							syncLines();
							var zl = m.querySelector('[data-zlall]').value.trim().toUpperCase();
							lines.push({ src: 'magazyn', item_table: t2, item_id: r.id, indeks: IDX_PREFIX[t2] + '-' + r.id, zlecenie: zl, rysunek: '', nazwa: rowTitle(t2, r), ilosc: b.parentNode.querySelector('[data-q]').value, jm: U(t2), stock: r.ilosc, stock_len: r.dlugosc || null });
							renderLines();
							toast('Dodano: ' + rowTitle(t2, r));
						});
					});
				}).catch(function (e) { out.innerHTML = '<p class="msm-err">' + esc(e.message) + '</p>'; });
			}, 300);
			magq.addEventListener('input', searchMag);
			magt.addEventListener('change', searchMag);
			// z zapotrzebowań
			m.querySelector('[data-zapgo]').addEventListener('click', function () {
				var zl = m.querySelector('[data-zapzl]').value.trim(), out = m.querySelector('[data-zapres]');
				if (!zl) return;
				api('/wz/zlecenie', { query: { zl: zl } }).then(function (rows) {
					if (!rows.length) { out.innerHTML = '<p class="msm-muted">Brak wydanych zapotrzebowań dla tego zlecenia.</p>'; return; }
					out.innerHTML = rows.map(function (r) {
						var used = r.on_wz || lines.some(function (l) { return l.wniosek_id === r.id; });
						return '<div class="msm-wz-hit"><span><b>#' + r.id + ' ' + esc(r.material) + '</b><small>' + esc(fmtNum(r.ilosc) + ' ' + r.jednostka) + ' · ' + esc(r.user_name) + ' · wydano ' + esc(fmtDate(r.issued_at)) + (used ? ' · już na WZ' : '') + '</small></span>' +
							'<button type="button" class="msm-btn msm-btn-sm' + (used ? '' : ' msm-btn-primary') + '" data-zap="' + r.id + '"' + (used ? ' disabled' : '') + '>Dodaj</button></div>';
					}).join('');
					out.querySelectorAll('[data-zap]').forEach(function (b) {
						b.addEventListener('click', function () {
							var r = rows.filter(function (x) { return x.id === +b.getAttribute('data-zap'); })[0];
							syncLines();
							lines.push({ src: 'wniosek', wniosek_id: r.id, item_table: r.item_table, item_id: r.item_id, indeks: (IDX_PREFIX[r.item_table] || '') + '-' + r.item_id, zlecenie: zl.toUpperCase(), rysunek: '', nazwa: r.material, ilosc: r.ilosc, jm: r.jednostka === 'm' ? 'm' : (r.jednostka === 'kg' ? 'kg' : 'szt.') });
							renderLines(); b.disabled = true; b.classList.remove('msm-btn-primary');
						});
					});
				}).catch(function (e) { out.innerHTML = '<p class="msm-err">' + esc(e.message) + '</p>'; });
			});

			if (!kor) m.querySelector('[data-wzsave]').addEventListener('click', function () {
				save().then(function () { done('Zapisano szkic WZ.'); }).catch(showErr);
			});
			if (kor) {
				m.querySelector('[data-korback]').addEventListener('click', function () { openWZ(doc.id); });
				m.querySelector('[data-wzkor]').addEventListener('click', function () {
					var data = collect();
					var keep = function () { return Object.assign({}, doc, data.header, { lines: data.lines }); };
					var removedStock = (doc.lines || []).filter(function (o) { return o.pobranie_id && !data.lines.some(function (l) { return l.id === o.id; }); }).length;
					var addedStock = data.lines.filter(function (l) { return !l.id && l.src === 'magazyn'; }).length;
					var mm = openModal('Zapisać zmiany w WZ ' + doc.numer + '?',
						'<p>Numer dokumentu pozostanie bez zmian. W historii WZ zapisze się, kto i kiedy edytował oraz co zmieniono – na wydruku tej informacji nie będzie.</p>' +
						(addedStock ? '<p><b>Ze stanu zostanie zdjętych ' + addedStock + ' nowych poz.</b></p>' : '') +
						(removedStock ? '<p><b>Na magazyn wróci stan z ' + removedStock + ' usuniętych poz.</b></p>' : '') +
						'<label class="msm-field full"><span>Powód zmiany (opcjonalnie)</span><input type="text" name="powod" maxlength="500" placeholder="np. korekta adresu odbiorcy"></label>',
						'<button type="button" class="msm-btn" data-back>Wróć do edycji</button><button type="button" class="msm-btn msm-btn-primary" data-ok>Zapisz zmiany</button>');
					mm.querySelector('[data-back]').addEventListener('click', function () { renderWZ(keep(), opts, { korekta: true }); });
					mm.querySelector('[data-ok]').addEventListener('click', function () {
						var body = Object.assign({}, data, { powod: mm.querySelector('[name=powod]').value });
						api('/wz/' + doc.id + '/korekta', { method: 'POST', body: body }).then(function (r) {
							if (addedStock || removedStock) { STOCK.forEach(invalidate); invalidate('pobrania'); }
							toast(r.message, r.unchanged ? 'warn' : 'ok'); refresh('wz');
							renderWZ(r.doc, opts);
						}).catch(function (e) {
							renderWZ(keep(), opts, { korekta: true });
							setTimeout(function () { var g = document.querySelector('.msm-form-err'); if (g) { g.innerHTML = esc(e.message).replace(/\n/g, '<br>'); g.hidden = false; } else toast(e.message, 'err'); }, 50);
						});
					});
				});
			}
			if (issueBtn) issueBtn.addEventListener('click', function () {
				var stockN = (syncLines(), lines.filter(function (l) { return l.src === 'magazyn'; }).length);
				var msg = C.canEdit
					? 'Dokument dostanie numer. Później nadal będzie można go edytować – każda zmiana zapisze się w historii WZ (bez wpływu na wydruk).' + (stockN ? '<br><b>Ze stanu zostanie zdjętych ' + stockN + ' poz.</b>' : '')
					: (stockN ? 'WZ zawiera ' + stockN + ' poz. z magazynu – trafi do zatwierdzenia przez administratora (powiadomienie i e-mail).' : 'Dokument dostanie numer. Później nadal będzie można go edytować – każda zmiana zapisze się w historii WZ (bez wpływu na wydruk).');
				var data = collect();
				var keep = function () { return Object.assign({}, doc, data.header, { lines: data.lines, can_edit: true, status: doc.status || 'szkic' }); };
				var willIssue = C.canEdit || stockN === 0; // powstanie dokument wystawiony (nie „do zatwierdzenia”)
				confirmBox(issueBtn.textContent + '?', msg, issueBtn.textContent).then(function (ok) {
					if (!ok) { renderWZ(keep(), opts); return; }
					(willIssue ? signaturePad() : Promise.resolve('')).then(function (podpis) {
					api(doc.id ? '/wz/' + doc.id : '/wz', { method: 'POST', body: data }).then(function (d) {
						doc = d;
						return api('/wz/' + d.id + '/wystaw', { method: 'POST', body: { podpis: podpis } });
					}).then(function (r) {
						STOCK.forEach(invalidate); invalidate('pobrania');
						done(r.message);
						if (r.doc && r.doc.status === 'wystawiona') window.open(printUrl({ msm_print: 'wz', id: r.doc.id }), '_blank');
					}).catch(function (e) {
						renderWZ(keep(), opts);
						setTimeout(function () { var g = document.querySelector('.msm-form-err'); if (g) { g.innerHTML = esc(e.message).replace(/\n/g, '<br>'); g.hidden = false; } else toast(e.message, 'err'); }, 50);
					});
				});
				});
			});
		}
		var pd = m.querySelector('[data-wzprintdoc]');
		if (pd) pd.addEventListener('click', function () {
			if (!ed) { window.open(printUrl({ msm_print: 'wz', id: doc.id }), '_blank'); return; }
			save().then(function (d) { window.open(printUrl({ msm_print: 'wz', id: d.id }), '_blank'); refresh('wz'); }).catch(showErr);
		});
		var we = m.querySelector('[data-wzedit]');
		if (we) we.addEventListener('click', function () { renderWZ(doc, opts, { korekta: true }); });
		var wh = m.querySelector('[data-wzhist]');
		if (wh) wh.addEventListener('click', function () { openWZHistory(doc, opts, kor ? { korekta: true } : undefined); });
		var dup = m.querySelector('[data-wzdup]');
		if (dup) dup.addEventListener('click', function () {
			api('/wz/' + doc.id + '/duplikuj', { method: 'POST' }).then(function (r) { toast(r.message); refresh('wz'); renderWZ(r.doc, opts); }).catch(function (e) { toast(e.message, 'err'); });
		});
		var del = m.querySelector('[data-wzdel]');
		if (del) del.addEventListener('click', function () {
			confirmBox('Usunąć szkic?', 'Szkic WZ zostanie usunięty.', 'Usuń', true).then(function (ok) {
				if (!ok) return;
				api('/wz/' + doc.id, { method: 'DELETE' }).then(function (r) { toast(r.message); refresh('wz'); }).catch(function (e) { toast(e.message, 'err'); });
			});
		});
		var cn = m.querySelector('[data-wzcancel]');
		if (cn) cn.addEventListener('click', function () {
			var mm = openModal('Anulować WZ ' + doc.numer + '?', '<p>Stan z pozycji pobranych z magazynu wróci na magazyn. Numer zostanie w rejestrze jako „anulowana”.</p><label class="msm-field full"><span>Powód (opcjonalnie)</span><textarea name="note" rows="2"></textarea></label>',
				'<button type="button" class="msm-btn" data-close>Wróć</button><button type="button" class="msm-btn msm-btn-danger" data-ok>Anuluj WZ</button>');
			mm.querySelector('[data-ok]').addEventListener('click', function () {
				api('/wz/' + doc.id + '/anuluj', { method: 'POST', body: { note: mm.querySelector('[name=note]').value } }).then(function (r) {
					STOCK.forEach(invalidate); invalidate('pobrania'); done(r.message);
				}).catch(function (e) { toast(e.message, 'err'); });
			});
		});
		var rj = m.querySelector('[data-wzreject]');
		if (rj) rj.addEventListener('click', function () {
			var mm = openModal('Zwrócić do poprawy?', '<p>Dokument wróci do autora jako szkic (dostanie e-mail).</p><label class="msm-field full"><span>Co poprawić?</span><textarea name="note" rows="2"></textarea></label>',
				'<button type="button" class="msm-btn" data-close>Wróć</button><button type="button" class="msm-btn msm-btn-danger" data-ok>Zwróć</button>');
			mm.querySelector('[data-ok]').addEventListener('click', function () {
				api('/wz/' + doc.id + '/zwroc', { method: 'POST', body: { note: mm.querySelector('[name=note]').value } }).then(function (r) { done(r.message); }).catch(function (e) { toast(e.message, 'err'); });
			});
		});
	}

	function openWZHistory(doc, opts, mode) {
		api('/wz/' + doc.id + '/historia').then(function (rows) {
			var html = rows.length ? '<ol class="msm-wzh">' + rows.map(function (r) {
				var ch = r.zmiany ? '<table class="msm-wzh__diff"><tbody>' + r.zmiany.map(function (c) {
					return '<tr><th>' + esc(c.pole) + '</th><td><s>' + esc(c.przed || '—') + '</s></td><td>→</td><td><b>' + esc(c.po || '—') + '</b></td></tr>';
				}).join('') + '</tbody></table>' : '<p>' + esc(r.opis) + '</p>';
				return '<li class="msm-wzh__item' + (r.akcja === 'edycja' ? ' is-edit' : '') + '"><div class="msm-wzh__head"><span class="msm-tag' + (r.akcja === 'edycja' ? ' msm-tag-wz-edit' : '') + '">' + esc(r.akcja) + '</span>' +
					'<b>' + esc(r.user) + '</b><span class="msm-wzh__when">' + esc(fmtDate(r.czas)) + '</span></div>' +
					(r.powod ? '<p class="msm-wzh__why">Powód: ' + esc(r.powod) + '</p>' : '') + ch + '</li>';
			}).join('') + '</ol>' : '<p class="msm-muted">Brak wpisów.</p>';
			var mm = openModal('Historia WZ ' + (doc.numer || ''), '<p class="msm-muted msm-small">Informacje widoczne tylko w systemie – nie pojawiają się na wydruku WZ.</p>' + html,
				'<button type="button" class="msm-btn msm-btn-primary" data-back>' + (mode && mode.korekta ? 'Wróć do edycji' : 'Wróć do dokumentu') + '</button>', true);
			mm.querySelector('[data-back]').addEventListener('click', function () { renderWZ(doc, opts, mode); });
		}).catch(function (e) { toast(e.message, 'err'); });
	}

	/* ======================================================================
	 * PZ – przyjęcie zewnętrzne: skany/zdjęcia, OCR w przeglądarce (Tesseract.js),
	 * rozpoznanie pozycji, formularz i przyjęcie na stan.
	 * ==================================================================== */

	var PZ_LABELS = { przyjety: 'Przyjęty', anulowany: 'Anulowany' };
	var PZ_MATCH_KEYS = {
		stal: ['opis', 'szer', 'wys', 'scianka', 'gatunek', 'dlugosc'],
		blachy_pelne: ['gatunek', 'grubosc', 'wymiar_a', 'wymiar_b', 'material'],
		blachy_niepelne: ['gatunek', 'grubosc', 'ksztalt', 'wymiar_a', 'wymiar_b'],
		kregi: ['oznaczenie', 'izolacja', 'grubosc', 'szerokosc', 'lokalizacja']
	};

	function loadScript(src) {
		return new Promise(function (res, rej) {
			if (document.querySelector('script[data-src="' + src + '"]')) return res();
			var s = document.createElement('script');
			s.src = src; s.async = true; s.setAttribute('data-src', src);
			s.onload = function () { res(); };
			s.onerror = function () { rej(new Error('Nie udało się wczytać modułu OCR.')); };
			document.head.appendChild(s);
		});
	}

	/* --- OCR --- */
	/* Ostrzeżenie, gdy wtyczka „Magazyn OCR” jest starsza niż wymaga magazyn. */
	function ocrOldHint() {
		return C.vendor && C.ocrOld ? '<p class="msm-alert msm-alert-err msm-small">Wtyczka „Magazyn OCR” jest nieaktualna (wersja ' + esc(C.ocrOld) + '). Poproś administratora o wgranie nowszej – rozpoznawanie może działać niepoprawnie.</p>' : '';
	}
	var ocrWorker = null;
	function getOcr(onProgress) {
		var V = C.vendor;
		if (!V) return Promise.reject(new Error('Moduł OCR nie jest zainstalowany – włącz wtyczkę „Magazyn OCR”.'));
		return loadScript(V + 'tesseract/tesseract.min.js').then(function () {
			if (ocrWorker) return ocrWorker;
			return window.Tesseract.createWorker('pol', 1, {
				workerPath: V + 'tesseract/worker.min.js',
				corePath: V + 'tesseract/core',
				langPath: V + 'tesseract/lang',
				gzip: true,
				logger: function (m) { if (onProgress) onProgress(m); }
			}).then(function (w) {
				ocrWorker = w;
				return w.setParameters({ preserve_interword_spaces: '1', tessedit_pageseg_mode: '6' }).then(function () { return w; });
			});
		});
	}
	/* Obraz → płótno: skala do ~2400 px szerokości, odcienie szarości, wzmocniony kontrast. */
	function prepCanvas(src, w, h) {
		var scale = Math.min(3, Math.max(1, 2400 / w));
		var c = document.createElement('canvas');
		c.width = Math.round(w * scale); c.height = Math.round(h * scale);
		var g = c.getContext('2d');
		g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height);
		g.drawImage(src, 0, 0, c.width, c.height);
		/* Wyrównanie tła (cienie, odblaski folii, zdjęcie pod kątem): tło = mocno rozmyty obraz,
		   tekst = o ile piksel jest ciemniejszy od tła; potem rozciągnięcie kontrastu. */
		var W = c.width, H = c.height, d = g.getImageData(0, 0, W, H), px = d.data, n = W * H, gray = new Float32Array(n), i;
		for (i = 0; i < n; i++) gray[i] = 0.299 * px[i * 4] + 0.587 * px[i * 4 + 1] + 0.114 * px[i * 4 + 2];
		var sw = Math.max(8, Math.round(W / 40)), sh = Math.max(8, Math.round(H / 40));
		var sm = document.createElement('canvas'); sm.width = sw; sm.height = sh;
		var sg = sm.getContext('2d'); sg.imageSmoothingEnabled = true; sg.imageSmoothingQuality = 'high';
		sg.drawImage(c, 0, 0, sw, sh);
		var bgc = document.createElement('canvas'); bgc.width = W; bgc.height = H;
		var bg2 = bgc.getContext('2d'); bg2.imageSmoothingEnabled = true; bg2.imageSmoothingQuality = 'high';
		bg2.filter = 'blur(2px)'; bg2.drawImage(sm, 0, 0, W, H);
		var bp = bg2.getImageData(0, 0, W, H).data, diff = new Float32Array(n), hist = new Uint32Array(256);
		for (i = 0; i < n; i++) {
			var b = 0.299 * bp[i * 4] + 0.587 * bp[i * 4 + 1] + 0.114 * bp[i * 4 + 2];
			var v = Math.max(0, b - gray[i]);
			diff[i] = v; hist[Math.min(255, v | 0)]++;
		}
		var acc = 0, top = 255, lim = n * 0.995; // 99,5 percentyl różnicy = najciemniejszy tekst
		for (i = 0; i < 256; i++) { acc += hist[i]; if (acc >= lim) { top = Math.max(24, i); break; } }
		for (i = 0; i < n; i++) {
			var y = 255 - Math.min(255, diff[i] * 255 / top);
			px[i * 4] = px[i * 4 + 1] = px[i * 4 + 2] = y; px[i * 4 + 3] = 255;
		}
		g.putImageData(d, 0, 0);
		return c;
	}
	function fileToCanvases(file) {
		if (file.type === 'application/pdf' || /\.pdf$/i.test(file.name)) {
			return getPdfjs().then(function (pdfjs) {
				return file.arrayBuffer().then(function (buf) { return pdfjs.getDocument({ data: buf }).promise; }).then(function (pdf) {
					var out = [], n = Math.min(pdf.numPages, 5), chain = Promise.resolve();
					for (var i = 1; i <= n; i++) {
						(function (no) {
							chain = chain.then(function () { return pdf.getPage(no); }).then(function (page) {
								var vp = page.getViewport({ scale: 2.5 });
								var c = document.createElement('canvas'); c.width = vp.width; c.height = vp.height;
								return page.render({ canvasContext: c.getContext('2d'), viewport: vp }).promise.then(function () { out.push(prepCanvas(c, c.width, c.height)); });
							});
						})(i);
					}
					return chain.then(function () { return out; });
				});
			});
		}
		return new Promise(function (res, rej) {
			var img = new Image();
			img.onload = function () { res([prepCanvas(img, img.naturalWidth, img.naturalHeight)]); URL.revokeObjectURL(img.src); };
			img.onerror = function () { rej(new Error('Nie można odczytać obrazu: ' + file.name)); };
			img.src = URL.createObjectURL(file);
		});
	}

	/* Ładowanie pdf.js niezależne od MIME serwera: pobierz plik i wczytaj jako moduł-blob
	   (hosting często podaje .mjs ze złym Content-Type, przez co zwykły import() pada). */
	// Polyfill Promise.withResolvers – pdf.js 4.x go wymaga, a starsze przeglądarki go nie mają.
	var PDF_POLY = 'if(typeof Promise.withResolvers!=="function"){Promise.withResolvers=function(){var a,b;var p=new Promise(function(x,y){a=x;b=y;});return{promise:p,resolve:a,reject:b};};}\n';
	if (typeof Promise.withResolvers !== 'function') { Promise.withResolvers = function () { var a, b; var p = new Promise(function (x, y) { a = x; b = y; }); return { promise: p, resolve: a, reject: b }; }; }
	var _pdfjs = null;
	function getPdfjs() {
		if (_pdfjs) return _pdfjs;
		if (!C.vendor) return Promise.reject(new Error('Moduł OCR nie jest zainstalowany – włącz wtyczkę „Magazyn OCR”.'));
		var base = C.vendor + 'pdfjs/';
		_pdfjs = fetch(base + 'pdf.min.mjs').then(function (r) { if (!r.ok) throw new Error('Brak pdf.js (zaktualizuj wtyczkę „Magazyn OCR”).'); return r.text(); })
			.then(function (src) { return import(URL.createObjectURL(new Blob([PDF_POLY + src], { type: 'text/javascript' }))); })
			.then(function (pdfjs) {
				return fetch(base + 'pdf.worker.min.mjs').then(function (r) { return r.ok ? r.text() : ''; }).then(function (wsrc) {
					try { pdfjs.GlobalWorkerOptions.workerSrc = wsrc ? URL.createObjectURL(new Blob([PDF_POLY + wsrc], { type: 'text/javascript' })) : (base + 'pdf.worker.min.mjs'); } catch (e) {}
					return pdfjs;
				});
			}).catch(function (e) { _pdfjs = null; throw e; });
		return _pdfjs;
	}

	/* Odczyt warstwy tekstowej PDF (dokładny – bez OCR). Zwraca tekst lub '' gdy PDF nie ma tekstu. */
	function pdfText(file) { return pdfRead(file).then(function (r) { return r.text; }); }
	/* Tekst + położenie słów (do odczytu tabeli po kolumnach). */
	function pdfRead(file) {
		var none = { text: '', geo: null };
		if (!(file.type === 'application/pdf' || /\.pdf$/i.test(file.name))) return Promise.resolve(none);
		return getPdfjs().then(function (pdfjs) {
			return file.arrayBuffer().then(function (buf) { return pdfjs.getDocument({ data: buf }).promise; }).then(function (pdf) {
				var n = Math.min(pdf.numPages, 10), chain = Promise.resolve(), pages = [], geo = { pages: [] };
				for (var i = 1; i <= n; i++) {
					(function (no) {
						chain = chain.then(function () { return pdf.getPage(no); }).then(function (page) {
							return page.getTextContent().then(function (tc) { pages.push(reconstructText(tc)); geo.pages.push(pdfGeoPage(tc, page.getViewport({ scale: 1 }))); });
						});
					})(i);
				}
				return chain.then(function () { return { text: pages.join('\n').trim(), geo: geo }; });
			});
		}).catch(function () { return none; });
	}
	/* OCR obrazu z położeniem słów (tesseract.js: wynik „blocks”). */
	function ocrRead(w, cv) {
		/* Starsza wersja silnika OCR bez wyniku „blocks” – sam tekst (bez położenia słów), jak dotąd. */
		return w.recognize(cv, {}, { text: true, blocks: true }).catch(function () { return w.recognize(cv); }).then(function (r) {
			var out = { text: r.data.text || '', page: ocrGeoPage(r.data, cv.width, cv.height) };
			if (docNumber(out.text)) return out;
			/* Tryb tabelowy OCR gubi duży tytuł („WZ 12/2026”) – drugi, szybki odczyt samej góry strony w trybie automatycznym. */
			var top = document.createElement('canvas');
			top.width = cv.width; top.height = Math.round(cv.height * 0.3);
			top.getContext('2d').drawImage(cv, 0, 0, cv.width, top.height, 0, 0, cv.width, top.height);
			return w.setParameters({ tessedit_pageseg_mode: '3' })
				.then(function () { return w.recognize(top); })
				.then(function (t) { var nr = docNumber(t.data.text || ''); if (nr) out.text = nr + '\n' + out.text; }) // tylko numer – reszta góry strony jest już w tekście
				.catch(function () {})
				.then(function () { return w.setParameters({ tessedit_pageseg_mode: '6' }); })
				.then(function () { return out; });
		});
	}
	/* Odtworzenie układu wierszy z elementów tekstowych PDF (grupowanie po Y, sortowanie po X). */
	function reconstructText(tc) {
		var rows = [];
		(tc.items || []).forEach(function (it) {
			if (!it.str || !it.str.trim()) return;
			var x = it.transform[4], y = it.transform[5];
			var row = null;
			for (var i = 0; i < rows.length; i++) { if (Math.abs(rows[i].y - y) <= 3) { row = rows[i]; break; } }
			if (!row) { row = { y: y, items: [] }; rows.push(row); }
			row.items.push({ x: x, s: it.str });
		});
		return rows.sort(function (a, b) { return b.y - a.y; }).map(function (r) {
			return r.items.sort(function (a, b) { return a.x - b.x; }).map(function (o) { return o.s; }).join(' ').replace(/\s+/g, ' ').trim();
		}).filter(Boolean).join('\n');
	}

	/* --- rozpoznawanie treści dokumentu --- */
	function fold(s) { return String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/ł/g, 'l'); }
	function pnum(s) { var n = Number(String(s).replace(/\s/g, '').replace(',', '.')); return isFinite(n) ? n : null; }
	function numStr(n) { return n === null || n === undefined ? '' : String(Math.round(n * 1000) / 1000).replace('.', ','); }

	/* Gęstość [kg/dm³] wg gatunku – odpowiednik MSM_Calc::density (PHP). */
	function densityOf(gat) {
		var g = String(gat || '').toUpperCase();
		if (/^(CU|MIED)/.test(g)) return 8.9;
		if (/^(AL|ALU)/.test(g)) return 2.7;
		if (/^(MO|MOSI|CUZN)/.test(g)) return 8.5;
		if (/^(SS|INOX|NIERDZ|304|316|1\.4)/.test(g)) return 7.9;
		return 7.85;
	}
	/* Pole przekroju profilu [mm²] – odpowiednik MSM_Calc::stal_area (PHP). */
	function stalAreaJS(opis, b, c, t) {
		b = pnum(b); c = pnum(c); t = pnum(t);
		switch (opis) {
			case 'PROFIL': return (b && c && t && b > 2 * t && c > 2 * t) ? b * c - (b - 2 * t) * (c - 2 * t) : null;
			case 'PROFIL OTWARTY': return (b && c && t) ? t * (b + 2 * c - 2 * t) : null;
			case 'KĄTOWNIK L': return (b && t) ? t * (b + (c || b) - t) : null;
			case 'PŁASKOWNIK': case 'PRZYGOTÓWKA': return (b && c) ? b * c : null;
			case 'PRĘT KWADRATOWY': return b ? b * (c || b) : null;
			case 'PRĘT OKRĄGŁY': case 'PRĘT CIĄGNIONY': return b ? Math.PI * b * b / 4 : null;
			case 'PRĘT SZEŚCIOKĄTNY': return b ? Math.sqrt(3) / 2 * b * b : null;
			case 'RURA': return (b && t && b > 2 * t) ? Math.PI / 4 * (b * b - (b - 2 * t) * (b - 2 * t)) : null;
		}
		return null;
	}
	/* Przelicz dostawę w kg na sztuki dla rozpoznanej pozycji (blacha/profil). Zwraca liczbę szt lub null. */
	function kgToSzt(tabela, f, kg) {
		kg = pnum(kg);
		if (!kg || kg <= 0) return null;
		if (tabela === 'blachy_pelne' || tabela === 'blachy_niepelne') {
			var a = pnum(f.wymiar_a), b = pnum(f.wymiar_b), t = pnum(f.grubosc);
			if (a && b && t) { var kgszt = a * b * t * densityOf(f.gatunek) / 1e6; if (kgszt > 0) return Math.max(1, Math.round(kg / kgszt)); }
		} else if (tabela === 'stal') {
			var area = stalAreaJS(f.opis, f.szer, f.wys, f.scianka), len = pnum(f.dlugosc);
			if (area && len) { var kgm = area * densityOf(f.gatunek) / 1000, per = kgm * len; if (per > 0) return Math.max(1, Math.round(kg / per)); }
		}
		return null;
	}

	var GATUNEK_RE = /\b(S\s?2[35]5\s?(?:JR|J0|J2|JRG2|JRC|MC|N)?|S\s?355\s?(?:JR|J0|J2|J2\+N|MC|N)?|S\s?420\s?MC|S\s?460\s?MC|S\s?500\s?MC|S\s?700\s?MC|DC0[1-6]|DX5[1-4]D?|DD1[1-4]|1\.4301|1\.4404|1\.4307|AISI\s?3\d\d\w?|30[14]L?|316L?|St3S?|St37|18G2A?|C45|P265GH|P235GH|DOMEX\s?\d{3}\s?MC|Hardox\s?\d{3}|Raex\s?\d{3}|AlMg3|AW-\d{4}|PA\d{1,2}|M[0-9]{3}-[0-9]{2}[A-Z]?)\b/i;
	function findOpis(line) {
		var col = (S.stal.cols || []).filter(function (c) { return c.key === 'opis'; })[0];
		var opts = (col && col.options) || [];
		var f = fold(line), best = null, bestScore = 0;
		opts.forEach(function (o) {
			var words = fold(o).split(/\s+/).filter(function (w) { return w.length > 1; });
			if (!words.length) return;
			var stem = words[0].slice(0, Math.max(5, words[0].length - 2));
			if (!new RegExp('(^|[^a-z0-9])' + stem).test(f)) return;
			var score = 1 + words.slice(1).filter(function (w) { return f.indexOf(w.slice(0, Math.max(3, w.length - 2))) >= 0; }).length;
			if (score > bestScore) { bestScore = score; best = o; }
		});
		return best;
	}
	function parseQty(line) {
		var re = /(\d+(?:[.,]\d+)?)\s*(szt\.?|sztuk[a-z]*|kg|mb|m\.b\.|tona|t)(?![a-ząćęłńóśźż])/gi, m, last = null;
		while ((m = re.exec(line))) last = { n: pnum(m[1]), u: fold(m[2]).replace(/\./g, '') };
		if (last) {
			if (last.u.indexOf('szt') === 0) last.u = 'szt';
			if (last.u === 't' || last.u === 'tona') { last.u = 'kg'; last.n = last.n * 1000; }
		}
		return last;
	}
	/* Parsowanie tekstu (mail/PDF) na pozycje WZ: numer rysunku, numer zlecenia, ilość. */
	function parseWZ(text) {
		var out = [];
		String(text || '').split(/\r?\n/).forEach(function (raw) {
			var line = raw.replace(/\s+/g, ' ').trim();
			if (line.length < 2) return;
			if (/^(l\.?p|lp|nazwa|opis|ilo|zlecenie|rysunek|razem|suma)\b/i.test(fold(line)) && !/\d/.test(line)) return;
			// numer zlecenia: najpierw po słowie „zlecenie/zlec/zl”, potem wzór litera(y)+cyfry bez myślnika (np. B71007)
			var zk = line.match(/\bz(?:lecenie|lec|l)\.?\s*(?:nr\.?|:|#)?\s*([A-Za-z]{0,3}\d{3,7})\b/i);
			var zl = zk ? zk[1].toUpperCase() : '';
			if (!zl) { var zm = line.match(/\b([A-Z]{1,2}\d{4,7})\b/); if (zm) zl = zm[1].toUpperCase(); }
			// ilość: liczba przy „szt”, albo przy „x”, albo samotna na końcu
			var qm = line.match(/(\d+(?:[.,]\d+)?)\s*(?:szt\.?|sztuk|pcs|kpl)\b/i) || line.match(/(?:^|\s)x\s*(\d+(?:[.,]\d+)?)\b/i) || line.match(/(\d+(?:[.,]\d+)?)\s*x\b/i);
			var qty = qm ? qm[1].replace(',', '.') : '';
			if (!qty) { var tm = line.match(/(?:^|\s)(\d{1,5})\s*$/); if (tm && tm[1] !== zl.replace(/\D/g, '')) qty = tm[1]; }
			// numer rysunku: po słowie „rys”, albo kod z cyfrą i separatorem (-, /, .) różny od zlecenia
			var ry = line.match(/rys(?:unek|\.)?\s*(?:nr\.?|:|#)?\s*([A-Za-z0-9][A-Za-z0-9\-\.\/_]{1,})/i);
			var rys = ry ? ry[1] : '';
			if (!rys) {
				var toks = line.split(' ');
				for (var i = 0; i < toks.length; i++) {
					var tk = toks[i].replace(/^[,:;]+|[.,;:]+$/g, '');
					if (tk.length >= 3 && /\d/.test(tk) && /[\-\/_]|[A-Za-z]{2,}/.test(tk) && tk.toUpperCase() !== zl && (!qm || tk !== qm[0].trim()) && !/^(szt|sztuk|pcs|kpl)$/i.test(tk)) { rys = tk; break; }
				}
			}
			if (!zl && !rys && !qty) return;
			// nazwa: reszta wiersza bez rozpoznanych tokenów
			var nazwa = line;
			[zl, rys].forEach(function (x) { if (x) nazwa = nazwa.replace(new RegExp('\\b' + x.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\b', 'i'), ' '); });
			if (qm) nazwa = nazwa.replace(qm[0], ' ');
			nazwa = nazwa.replace(/\b(rys(unek)?\.?|nr\.?|zlec(enie)?\.?|szt\.?|pcs|kpl|x)\b/gi, ' ').replace(/[,;]+/g, ' ').replace(/\s+/g, ' ').replace(/^[\-–:\s]+|[\-–:\s]+$/g, '').trim();
			out.push({ src: 'reczna', indeks: '', zlecenie: zl, rysunek: rys, nazwa: nazwa, ilosc: qty, jm: 'szt.' });
		});
		return out;
	}

	function parseLine(raw) {
		var line = raw.replace(/[|]/g, ' ').replace(/\s+/g, ' ').trim()
			.replace(/\bDC[O0]([1-6])\b/gi, 'DC0$1').replace(/\b[S5]\s?(2[35]5|355)\s?[I1l|\/]R\b/g, 'S$1JR').replace(/\b5(2[35]5|355)(?=JR|J0|J2|MC)/g, 'S$1').replace(/\bS([23])([0-9O]{1})([0-9O])\b/g, function (m0, a, b, c) { return 'S' + a + b.replace('O', '0') + c.replace('O', '0'); })
			.replace(/(\d)\s*[xX×]\s*(?=\d)/g, '$1x');
		var f = fold(line);
		if (line.length < 4) return null;
		var dims = line.match(/(\d+(?:[.,]\d+)?)\s*[x×X*]\s*(\d+(?:[.,]\d+)?)(?:\s*[x×X*]\s*(\d+(?:[.,]\d+)?))?/);
		var fi = line.match(/(?:fi|ø|Ø|φ)\s*(\d+(?:[.,]\d+)?)/i);
		var gat = line.match(GATUNEK_RE);
		var qty = parseQty(line);
		var tabela = null, fields = {};
		var isKreg = /\bkr[ae]g|\bkregi\b|\bcoil|\btasm|\bM\d{3}-\d{2}A?\b/i.test(f) || /\bM\d{3}-\d{2}[A-Z]?\b/.test(line);
		var isBlacha = /\bblach/.test(f) || /\barkusz/.test(f) || /\bbl\s*\.?\s*[gz]\s*[\/\\l1i|]?\s*w\b/.test(f);
		var opis = !isKreg && !isBlacha ? findOpis(line) : null;
		if (isKreg) {
			tabela = 'kregi';
			var oz = line.match(/\b(M\d{3}-\d{2}[A-Z]?|\d{3}-\d{2,3}[A-Z]{1,3}\s?\d*\s?G?\d*)\b/);
			fields.oznaczenie = oz ? oz[1] : (gat ? gat[1] : '');
			if (dims) { fields.grubosc = numStr(pnum(dims[1])); fields.szerokosc = numStr(pnum(dims[2])); }
			var iz = line.match(/\b(C[3-6]|bez lakieru|EC-?\d)\b/i); if (iz) fields.izolacja = iz[1];
			fields.lokalizacja = 'Magazyn Ligota';
		} else if (isBlacha) {
			tabela = 'blachy_pelne';
			if (gat) fields.gatunek = gat[1].replace(/\s+/g, ' ').toUpperCase();
			var gr = line.match(/gr\.?\s*(\d+(?:[.,]\d+)?)/i);
			if (dims) {
				var a = pnum(dims[1]), b = pnum(dims[2]), c3 = dims[3] ? pnum(dims[3]) : null;
				if (c3 !== null && a <= 100) { fields.grubosc = numStr(a); fields.wymiar_a = numStr(b); fields.wymiar_b = numStr(c3); }
				else { fields.wymiar_a = numStr(a); fields.wymiar_b = numStr(b); if (c3 !== null) fields.grubosc = numStr(c3); }
			}
			if (gr) fields.grubosc = numStr(pnum(gr[1]));
		} else if (opis) {
			tabela = 'stal';
			fields.opis = opis;
			if (gat) fields.gatunek = gat[1].replace(/\s+/g, '').toUpperCase();
			if (dims) {
				fields.szer = numStr(pnum(dims[1]));
				if (/^RURA/.test(opis) && !dims[3]) fields.scianka = numStr(pnum(dims[2]));
				else { fields.wys = numStr(pnum(dims[2])); if (dims[3]) fields.scianka = numStr(pnum(dims[3])); }
			} else if (fi) fields.szer = numStr(pnum(fi[1]));
			var L = line.match(/\b(?:L|dl\.?|dł\.?|dług\.?|długość)\s*[=:]?\s*(\d+(?:[.,]\d+)?)\s*(mm|m)?/i);
			var len = null;
			if (L) { len = pnum(L[1]); if ((L[2] || '').toLowerCase() === 'mm' || len > 100) len = len / 1000; }
			else {
				var Lm = line.match(/(\d+(?:[.,]\d+)?)\s*mm\b/i);
				if (Lm && pnum(Lm[1]) >= 500) len = pnum(Lm[1]) / 1000;
			}
			if (len) fields.dlugosc = numStr(len);
			if (qty && qty.u === 'mb' && len) { qty = { n: Math.max(1, Math.round(qty.n / len)), u: 'szt' }; }
		}
		if (!tabela) return null;
		if (!dims && !fi && !qty) return null;
		var ilosc = '';
		if (qty) {
			if (tabela === 'kregi') ilosc = qty.u === 'kg' ? numStr(qty.n) : '';
			else ilosc = qty.u === 'szt' ? String(Math.round(qty.n)) : '';
		}
		if (!ilosc && tabela !== 'kregi') {
			var tail = line.replace(dims ? dims[0] : '', ' ').match(/(\d+)\s*$/);
			if (tail && Number(tail[1]) > 0 && Number(tail[1]) < 1000) ilosc = tail[1];
		}
		return { tabela: tabela, fields: fields, ilosc: ilosc, raw: raw.trim() };
	}
	/* Numer dokumentu: najpierw wzór „PZ 0081/20”, potem po słowie nr/faktura. */
	function findDocNo(text) {
		var full = text.match(/\b((?:PZ|WZ|FV|FA|RW|MM)\s*\/\s*\d{1,7}\s*\/\s*20\d{2}(?:\s*\/\s*[A-Z0-9]{1,8})?)\b/i); // np. WZ/13739/2026/WRMC
		if (full) return full[1].replace(/\s+/g, '').toUpperCase();
		var m = text.match(/\b(PZ|WZ|FV|FA|RW|MM)\b[\s:/\-]*?(\d{1,6}\s*[\/\-]\s*\d{2,4})/i);
		if (m) return (m[1].toUpperCase() + ' ' + m[2].replace(/\s+/g, '')).trim();
		var g = text.match(/\b(?:nr|numer|dokument|faktura|FV|dowód dostawy)\b\.?\s*(?:nr\.?)?\s*[:#]?\s*([A-Z0-9][A-Z0-9\/\-.]{2,})/i);
		return g && /\d/.test(g[1]) ? g[1].replace(/[.,]$/, '') : '';
	}

	function findData(text) {
		var d2 = text.match(/\b(20\d{2})-(\d{2})-(\d{2})\b/);
		if (d2) return d2[1] + '-' + d2[2] + '-' + d2[3];
		var d = text.match(/\b(\d{1,2})[.\-\/](\d{1,2})[.\-\/](20\d{2})\b/);
		return d ? d[3] + '-' + ('0' + d[2]).slice(-2) + '-' + ('0' + d[1]).slice(-2) : '';
	}

	/* Blachy stalowe jak w magazynie: gatunek „CZARNA”, stal w polu Materiał (S235JR → S235). DC01, nierdzewka itp. bez zmian. */
	function pzSheetNorm(out) {
		(out && out.lines || []).forEach(function (l) {
			if (l.tabela !== 'blachy_pelne' || !l.fields) return;
			var g = String(l.fields.gatunek || '').toUpperCase().replace(/\s+/g, ''), m = g.match(/^(S\d{3})/);
			if (!m) return;
			if (!l.fields.material) l.fields.material = m[1];
			l.fields.gatunek = 'CZARNA';
		});
		return out;
	}
	function parsePZ(text) { return pzSheetNorm(parsePZRaw(text)); }
	/* Odczyt PZ z tekstu i położenia słów: zapamiętany układ dostawcy → sprawdzone układy (WF-Mag, Optima/ANER)
	   → tabela po kolumnach (dowolny program) → dotychczasowy odczyt wiersz po wierszu. */
	function parsePZDoc(text, geo) {
		var base = parsePZRaw(text), special = /WF-?Mag|DOKUMENT PRZYJ|Nr katalogowy/i.test(text) ? 'WF-Mag' : (isOptima(text) ? 'Comarch Optima' : '');
		if (!geo || !geo.pages || !geo.pages.length) { base.how = special; return pzSheetNorm(base); }
		var d = docParse(geo), lines = [], other = [];
		d.recs.forEach(function (rec) { var p = docRecToPz(rec); if (p) lines.push(p); else other.push(rec.nazwa || rec.kod); });
		var useDoc = d.how === 'wzor' ? lines.length > 0 : (special ? lines.length > base.lines.length : lines.length >= Math.max(1, base.lines.length));
		var out = useDoc ? { lines: lines, other: other, how: d.how } : { lines: base.lines, other: [], how: special || (base.lines.length ? 'wiersze tekstu' : '') };
		out.data = d.data || docDate(text) || base.data;
		out.nr_dok = d.nr_dok || docNumber(text) || base.nr_dok;
		out.dostawca = (special ? base.dostawca : '') || d.dostawca || base.dostawca;
		out.nip = d.nip;
		return pzSheetNorm(out);
	}
	/* Tabela WZ (nasze WZ z listy klienta / dokumentu): pozycje z kolumn, zlecenie i rysunek z nazwy. */
	function parseWZDoc(text, geo) {
		if (geo && geo.pages && geo.pages.length) {
			var d = docParse(geo);
			if (d.recs.length) {
				return d.recs.map(function (rec) {
					var x = parseWZ([rec.nazwa, rec.kod].join(' '))[0] || {};
					var u = docUnit(rec.jm);
					return { src: 'reczna', indeks: rec.kod || '', zlecenie: x.zlecenie || '', rysunek: x.rysunek || '', nazwa: rec.nazwa || x.nazwa || '', ilosc: rec.ilosc !== null ? String(rec.ilosc).replace('.', ',') : (x.ilosc || ''), jm: u === 'szt' || !u ? 'szt.' : (u === 't' ? 't' : rec.jm) };
				});
			}
		}
		return parseWZ(text);
	}
	function parsePZRaw(text) {
		if (/WF-?Mag|DOKUMENT PRZYJ|Nr katalogowy/i.test(text)) return parseWfMag(text);
		if (isOptima(text)) return parseOptima(text);
		var lines = String(text || '').split(/\r?\n/).map(function (l) { return l.trim(); }).filter(Boolean);
		var out = { data: findData(text), dostawca: '', nr_dok: findDocNo(text), lines: [] };
		for (var i = 0; i < lines.length && !out.dostawca; i++) {
			var m = /odbiorc|kisielewski/i.test(lines[i]) ? null : lines[i].match(/^(?:dostawca|sprzedawca|nadawca|wystawca|dostawa od)\b\s*:?\s*(.*)$/i);
			if (m) out.dostawca = (m[1] && m[1].length > 3 ? m[1] : (lines[i + 1] || '')).trim();
		}
		if (!out.dostawca) {
			var co = lines.filter(function (l) { return /(sp\.?\s*z\s*[o0]\.?\s*[o0]|s\.a\.|sp\.\s?[jk]\.|spółka)/i.test(l) && !/kisielewski/i.test(l); })[0];
			if (co) out.dostawca = co;
		}
		out.dostawca = out.dostawca.replace(/^[^A-Za-zĄĆĘŁŃÓŚŹŻąćęłńóśźż0-9]+/, '').slice(0, 180);
		lines.forEach(function (l) { var p = parseLine(l); if (p) out.lines.push(p); });
		return out;
	}

	/* ----------------------------------------------------------------
	   Dokumenty z Comarch ERP Optima (np. „Wydanie WZ” od ANER STAL):
	   pozycje „BL.G/W 4.00X1250X2500 S235JR  kg 200  ARK. 2.00”, gdzie Ilość = kg,
	   a liczba arkuszy jest w kolumnie J.m.p. („ARK.”). OCR często przesuwa „ARK. 2.00”
	   do sąsiedniego wiersza, więc arkusze są przypisywane do blach w kolejności występowania.
	   ---------------------------------------------------------------- */
	var OPT_BL_RE = /\bBL\s*\.?\s*([GZ])\s*[\/\\lI1|]?\s*W\b\.?/i;
	function isOptima(text) {
		return /Comarch|ERP\s*Optima|J\s*\.?\s*m\s*\.?\s*p\b|ANER\s*STAL/i.test(text) || (text.match(new RegExp(OPT_BL_RE.source, 'gi')) || []).length >= 2;
	}
	function parseOptima(text) {
		var lines = String(text || '').split(/\r?\n/).map(function (l) { return l.replace(/\s+/g, ' ').trim(); }).filter(Boolean);
		var out = { data: '', dostawca: '', nr_dok: findDocNo(text), lines: [] };
		var dw = text.match(/Data\s+wydania\s*:?\s*(20\d{2}-\d{2}-\d{2})/i);
		out.data = dw ? dw[1] : findData(text);
		/* Dostawca: pierwsza nazwa firmy WIELKIMI literami przed „Sp. z o.o.” (z pominięciem Kisielewski). */
		var coRe = /([A-ZĄĆĘŁŃÓŚŹŻ0-9][A-ZĄĆĘŁŃÓŚŹŻ0-9&'".\- ]{1,40}?)\s+Sp\s*\.?\s*z\s*[o0]\s*\.?\s*[o0]\s*\.?(\s*Sp\s*\.?\s*k\s*\.?)?/g, cm, sup = '';
		while ((cm = coRe.exec(text)) && !sup) { if (!/KISIELEWSKI/i.test(cm[1])) sup = cm[1].trim().replace(/^["']+|["']+$/g, '') + ' Sp. z o.o.' + (cm[2] ? ' Sp.k.' : ''); }
		out.dostawca = sup.slice(0, 180);
		/* Obszar tabeli: od nagłówka „Nazwa towaru” do „SUMA”. */
		var a = 0, b = lines.length;
		lines.forEach(function (l, i) { if (!a && /Nazwa\s+towaru|J\s*\.?\s*m\s*\.?\s*p/i.test(l)) a = i + 1; if (a && i >= a && b === lines.length && /^SUMA\b|\bSUMA\s+\d/i.test(l)) b = i; });
		var tab = lines.slice(a, b), items = [], arks = [];
		tab.forEach(function (l) {
			var bl = l.match(OPT_BL_RE);
			if (bl) {
				var rest = l.slice(bl.index + bl[0].length);
				var kg = rest.match(/\bk[gęq9]\s*[._\-~]*\s*(\d{1,3}(?:[ \u00a0]\d{3})+(?:[.,]\d+)?|\d+(?:[.,]\d+)?)\b/i); // „1 000” tak, ale nie „200 2” (dopisek ręczny)
				var ark1 = rest.match(/\bA\s*R\s*K\s*\.?\s*(\d+(?:[.,]\d{1,2})?)/i); // arkusze w tym samym wierszu
				var cut = function (x) { return x.replace(/\s+k[gęq9]\b.*$/i, '').replace(/\s+A\s*R\s*K\b.*$/i, ''); };
				items.push({ rodzaj: bl[1].toUpperCase() === 'G' ? 'gorącowalcowana' : 'zimnowalcowana', name: cut(l.slice(bl.index)).trim(), body: cut(rest), kg: kg ? pnum(kg[1].replace(/\s/g, '')) : null, ark: ark1 ? pnum(ark1[1]) : null, paczka: false });
				return;
			} else if (items.length && /Opis\s*:?\s*PACZK/i.test(l)) {
				items[items.length - 1].paczka = true;
			}
			/* Waga w osobnym wierszu (np. przy „Opis: PACZKA”) → do ostatniej blachy bez wagi. */
			var kgOnly = !bl && l.match(/(?:^|\s)k[gęq9]\s*[._\-~]*\s*(\d{1,3}(?:[ \u00a0]\d{3})+|\d+)(?:[.,]\d+)?\b/i);
			if (kgOnly && items.length && items[items.length - 1].kg == null) items[items.length - 1].kg = pnum(kgOnly[1].replace(/\s/g, ''));
			var re = /\bA\s*R\s*K\s*\.?\s*(\d+(?:[.,]\d{1,2})?)/gi, m;
			while ((m = re.exec(l))) arks.push(pnum(m[1]));
		});
		/* „ARK.” w osobnych wierszach (OCR przesunął kolumnę) → do blach bez arkuszy, w kolejności, gdy liczba się zgadza. */
		var need = items.filter(function (it) { return it.ark == null; });
		if (need.length && arks.length === need.length) need.forEach(function (it, i) { it.ark = arks[i]; });
		items.forEach(function (it) {
			var p = parseLine('Blacha ' + it.body);
			if (!p || p.tabela !== 'blachy_pelne') return;
			var ilosc = '', note = [];
			if (it.kg) note.push(fmtNum(it.kg) + ' kg');
			if (it.ark != null && it.ark > 0) {
				ilosc = String(Math.max(1, Math.round(it.ark)));
				if (Math.abs(it.ark - Math.round(it.ark)) > 0.001) note.push('≈ ' + String(it.ark).replace('.', ',') + ' ark. – sprawdź liczbę arkuszy');
				else note.push(Math.round(it.ark) + ' ark.');
			} else if (it.kg) {
				var sz = kgToSzt(p.tabela, p.fields, it.kg);
				if (sz) { ilosc = String(sz); note.push('~' + sz + ' ark. z wagi – sprawdź'); } else note.push('podaj liczbę arkuszy');
			}
			if (it.paczka) note.push('paczka');
			out.lines.push({ tabela: p.tabela, fields: p.fields, ilosc: ilosc, raw: it.name + ' (blacha ' + it.rodzaj + (note.length ? '; ' + note.join(', ') : '') + ')' });
		});
		return out;
	}

	/* Parser dokumentów WF-Mag (DOKUMENT PRZYJĘCIA): nagłówek + tabela pozycji. */
	function parseWfMag(text) {
		var lines = String(text || '').split(/\r?\n/).map(function (l) { return l.replace(/\s+/g, ' ').trim(); }).filter(Boolean);
		var out = { data: findData(text), dostawca: '', nr_dok: findDocNo(text), lines: [] };
		for (var i = 0; i < lines.length && !out.dostawca; i++) {
			var md = /odbiorc|kisielewski/i.test(lines[i]) ? null : lines[i].match(/^Dostawca\b\s*:?\s*(.*)$/i);
			if (md) out.dostawca = (md[1] && md[1].length > 3 ? md[1] : (lines[i + 1] || '')).trim();
		}
		out.dostawca = out.dostawca.replace(/^[^A-Za-zĄĆĘŁŃÓŚŹŻąćęłńóśźż0-9]+/, '').slice(0, 180);

		var itemRe = /^(\d{1,3})\s+(.+?)\s+(szt|kg|mb|m)\.?\s+(\d+)\b/i;
		var stopRe = /XXXX|Sporządził|Zatwierdził|Przyjął|Wydrukowano|^Razem\b|^L\s?p\b|Nr katalogowy/i;
		var cur = null;
		function flush() {
			if (!cur) return;
			var p = parseLine(cur.head);
			if (p && ['stal', 'blachy_pelne', 'blachy_niepelne', 'kregi'].indexOf(p.tabela) >= 0) {
				var ilosc = '', note = '';
				if (cur.unit === 'kg') {
					var s = kgToSzt(p.tabela, p.fields, cur.qty);
					if (s) { ilosc = String(s); note = ' [dostawa ' + cur.qty + ' kg → ~' + s + ' szt]'; }
					else { note = ' [dostawa ' + cur.qty + ' kg – podaj liczbę szt]'; }
				} else {
					ilosc = String(Math.round(cur.qty));
				}
				out.lines.push({ tabela: p.tabela, fields: p.fields, ilosc: ilosc, raw: (cur.head + note).trim() });
			}
			cur = null;
		}
		lines.forEach(function (l) {
			if (stopRe.test(l)) { flush(); return; }
			var m = l.match(itemRe);
			if (m) { flush(); cur = { head: (m[2] || '').trim(), unit: fold(m[3]).replace(/\./g, ''), qty: pnum(m[4]) }; }
			else if (cur && l.length <= 50) { cur.head += ' ' + l; } // wiersz kontynuacji (wymiary, L=…)
		});
		flush();
		return out;
	}

	/* --- formularz PZ --- */
	function pzFieldCols(t) {
		return S[t].cols.filter(function (c) { return !c.computed && c.key !== 'ilosc' && !c.hidden; });
	}
	function openPZ(id) {
		if (id) {
			api('/pz/' + id).then(renderPZView).catch(function (e) { toast(e.message, 'err'); });
			return;
		}
		loadOptions('pz').then(function (opts) { renderPZForm(opts || {}); });
	}

	/* Formularz PZ – nowy dokument albo edycja przyjętego (doc): wiersze przyjęte (ilość / usunięcie) + nowe wiersze + skany. */
	function renderPZForm(opts, doc) {
		var ED = !!doc;
		var st = { files: [], lines: [], ocr: '', busy: false, old: ED ? doc.lines.map(function (l) { return { l: l, ilosc: String(l.ilosc).replace('.', ','), usun: false }; }) : [], oldFiles: ED ? doc.files.map(function (f) { return { f: f, usun: false }; }) : [] };
		var dost = (opts.dostawca || []).filter(function (o) { return o.v !== '__empty__'; });
		var body =
			'<div class="msm-form-err msm-alert msm-alert-err" hidden></div>' +
			'<div class="msm-pz-grid">' +
			'<section class="msm-pz-scan">' +
			'<h3 class="msm-wz-h">1. Skan lub zdjęcie PZ</h3>' +
			'<label class="msm-pz-drop" data-drop><input type="file" accept="image/*,application/pdf" multiple data-file hidden>' +
			'<b>Wgraj skan albo zrób zdjęcie</b><span>JPG, PNG lub PDF · możesz wybrać kilka plików · na telefonie otworzy się aparat</span></label>' +
			'<div class="msm-pz-files" data-files></div>' +
			(ED ? '<div class="msm-pz-oldfiles" data-oldfiles></div>' : C.vendor
				? '<div class="msm-pz-ocrbar"><button type="button" class="msm-btn msm-btn-primary" data-ocr disabled>Rozpoznaj tekst (OCR)</button><span class="msm-muted msm-small" data-ocrst>Rozpoznawanie działa w przeglądarce – dokument nie jest nigdzie wysyłany.</span></div>'
				: '<div class="msm-pz-ocrbar msm-pz-ocrbar--off"><span class="msm-muted msm-small">Automatyczne rozpoznawanie (OCR) wymaga wtyczki „Magazyn OCR”. Skany możesz dołączyć, a dane dokumentu wpisać ręcznie poniżej.</span></div>') +
			(ED ? '' : ocrOldHint()) +
			'<div class="msm-pz-progress" data-prog hidden><i></i></div>' +
			'<details class="msm-pz-raw" data-raw hidden><summary>Rozpoznany tekst (możesz poprawić i przetworzyć ponownie)</summary><textarea rows="10" data-rawtxt></textarea><button type="button" class="msm-btn msm-btn-sm" data-reparse>Przetwórz tekst ponownie</button></details>' +
			'</section>' +
			'<section class="msm-pz-form">' +
			'<h3 class="msm-wz-h">2. Dane dokumentu</h3>' +
			'<div class="msm-pz-head">' +
			'<label class="msm-field"><span>Data przyjęcia</span><input type="date" name="data" value="' + esc(ED ? doc.data : C.today) + '"></label>' +
			'<label class="msm-field wide"><span>Dostawca <i class="msm-req">*</i></span><input type="text" name="dostawca" list="pz-dost" autocomplete="off" value="' + esc(ED ? doc.dostawca : '') + '"><datalist id="pz-dost">' + dost.map(function (o) { return '<option value="' + esc(o.v) + '">'; }).join('') + '</datalist></label>' +
			'<label class="msm-field"><span>Nr dokumentu dostawcy</span><input type="text" name="nr_dok" placeholder="np. WZ/123/2026" value="' + esc(ED ? doc.nr_dok || '' : '') + '"></label>' +
			'<label class="msm-field wide"><span>Uwagi</span><input type="text" name="uwagi" value="' + esc(ED ? doc.uwagi || '' : '') + '"></label>' +
			'</div>' +
			(ED ? '<h3 class="msm-wz-h">3. Pozycje przyjęte</h3><p class="msm-muted msm-small">Zmiana ilości od razu koryguje stan magazynu o różnicę. Nie da się cofnąć więcej, niż jest na stanie, ani zejść poniżej ilości zaliczonej na zamówienie.</p><div data-oldlines></div>' +
				'<h3 class="msm-wz-h">4. Nowe pozycje</h3>' : '<h3 class="msm-wz-h">3. Pozycje do przyjęcia</h3>') +
			'<div data-plines></div>' +
			'<button type="button" class="msm-btn msm-btn-sm" data-padd>+ Dodaj pozycję</button>' +
			'<div class="msm-pzzam" data-pzzam hidden></div>' +
			'</section></div>';
		var m = openModal(ED ? 'Edycja ' + doc.numer : 'Nowe przyjęcie (PZ)', body,
			'<button type="button" class="msm-btn msm-btn-ghost" data-close>Anuluj</button><button type="button" class="msm-btn msm-btn-primary" data-psave>' + (ED ? 'Zapisz zmiany' : 'Przyjmij na stan') + '</button>', true);
		m.querySelector('.msm-modal').classList.add('msm-pzmodal');
		if (ED) {
			m.querySelector('.msm-pz-scan .msm-wz-h').textContent = '1. Skany dokumentu';
			var oldBox = m.querySelector('[data-oldlines]'), ofBox = m.querySelector('[data-oldfiles]');
			var drawOld = function () {
				oldBox.innerHTML = '<div class="msm-pzed">' + st.old.map(function (o, i) {
					var l = o.l, min = Math.max(l.stock === null ? l.ilosc : l.ilosc - l.stock, l.zam || 0, 0);
					var lock = l.stock === null; // pozycja usunięta z magazynu – bez zmian
					var hint = lock ? 'pozycja usunięta z magazynu – bez zmian' : 'stan teraz: ' + fmtNum(l.stock) + ' ' + l.jednostka + (min > 0 ? ' · najmniej: ' + fmtNum(min) + ' ' + l.jednostka + (l.zam ? ' (zamówienie)' : ' (już pobrano)') : '');
					return '<div class="msm-pzed__r' + (o.usun ? ' is-del' : '') + '" data-ol="' + i + '"><span class="msm-pz-lp">' + l.lp + '.</span>' +
						'<div class="msm-pzed__d"><b>' + esc(l.opis) + '</b><small>' + esc(l.magazyn) + ' · ' + (l.akcja === 'nowa' ? 'nowa pozycja' : 'dodano do istniejącej') + ' · ' + esc(hint) + '</small></div>' +
						'<label class="msm-pzed__q"><input type="text" inputmode="decimal" data-oq value="' + esc(o.ilosc) + '"' + (o.usun || lock ? ' disabled' : '') + '><span>' + esc(l.jednostka) + '</span></label>' +
						(lock ? '<span></span>' : o.usun ? '<button type="button" class="msm-btn msm-btn-sm" data-ou>Przywróć</button>' : '<button type="button" class="msm-iconbtn msm-iconbtn-danger" data-ou' + (min > 0 ? ' disabled title="Nie można usunąć – ' + (l.zam ? 'ilość zaliczona na zamówienie' : 'część materiału już pobrano') + '"' : ' title="Usuń wiersz (cofnie ilość ze stanu)"') + '>' + ICON_DEL + '</button>') + '</div>';
				}).join('') + '</div>';
				oldBox.querySelectorAll('[data-ol]').forEach(function (r) {
					var o = st.old[+r.getAttribute('data-ol')], q = r.querySelector('[data-oq]'), b = r.querySelector('[data-ou]');
					q.addEventListener('input', function () { o.ilosc = q.value; });
					if (b) b.addEventListener('click', function () { o.usun = !o.usun; drawOld(); });
				});
			};
			var drawOf = function () {
				ofBox.innerHTML = st.oldFiles.map(function (o, i) {
					var f = o.f, img = /^image\//.test(f.mime);
					return '<div class="msm-pz-file' + (o.usun ? ' is-err' : '') + '">' + (img ? '<img src="' + esc(f.url) + '" alt="">' : '<span class="msm-pz-pdf">PDF</span>') + '<div><b>' + esc(f.nazwa) + '</b><small>' + (o.usun ? 'zostanie usunięty' : 'dołączony') + '</small></div>' +
						(o.usun ? '<button type="button" class="msm-btn msm-btn-sm" data-ofu="' + i + '">Przywróć</button>' : '<button type="button" class="msm-iconbtn msm-iconbtn-danger" data-ofu="' + i + '" title="Usuń skan">' + ICON_DEL + '</button>') + '</div>';
				}).join('');
				ofBox.querySelectorAll('[data-ofu]').forEach(function (b) { b.addEventListener('click', function () { var o = st.oldFiles[+b.getAttribute('data-ofu')]; o.usun = !o.usun; drawOf(); }); });
			};
			drawOld(); drawOf();
		}
		var fileIn = m.querySelector('[data-file]'), filesBox = m.querySelector('[data-files]'), ocrBtn = m.querySelector('[data-ocr]');
		var ocrSt = m.querySelector('[data-ocrst]'), prog = m.querySelector('[data-prog]');

		function renderFiles() {
			filesBox.innerHTML = st.files.map(function (f, i) {
				var thumb = f.file.type.indexOf('image/') === 0 ? '<img src="' + f.preview + '" alt="">' : '<span class="msm-pz-pdf">PDF</span>';
				return '<div class="msm-pz-file' + (f.err ? ' is-err' : '') + '">' + thumb + '<div><b>' + esc(f.file.name) + '</b><small>' + (f.err ? esc(f.err) : (f.id ? 'wgrano' : 'wgrywanie…')) + '</small></div>' +
					'<button type="button" class="msm-iconbtn msm-iconbtn-danger" data-frm="' + i + '" title="Usuń">' + ICON_DEL + '</button></div>';
			}).join('');
			filesBox.querySelectorAll('[data-frm]').forEach(function (b) { b.addEventListener('click', function () { st.files.splice(+b.getAttribute('data-frm'), 1); renderFiles(); }); });
			if (ocrBtn) ocrBtn.disabled = !st.files.length || st.busy;
		}
		function addFiles(list) {
			Array.prototype.forEach.call(list, function (file) {
				var f = { file: file, id: null, err: '', preview: file.type.indexOf('image/') === 0 ? URL.createObjectURL(file) : '' };
				st.files.push(f);
				var fd = new FormData(); fd.append('file', file);
				api('/pz/upload', { method: 'POST', form: fd }).then(function (r) { f.id = r.id; renderFiles(); }).catch(function (e) { f.err = e.message; renderFiles(); });
			});
			renderFiles();
		}
		fileIn.addEventListener('change', function () { addFiles(fileIn.files); fileIn.value = ''; });
		var drop = m.querySelector('[data-drop]');
		['dragover', 'dragenter'].forEach(function (ev) { drop.addEventListener(ev, function (e) { e.preventDefault(); drop.classList.add('is-over'); }); });
		['dragleave', 'drop'].forEach(function (ev) { drop.addEventListener(ev, function (e) { e.preventDefault(); drop.classList.remove('is-over'); }); });
		drop.addEventListener('drop', function (e) { if (e.dataTransfer && e.dataTransfer.files.length) addFiles(e.dataTransfer.files); });

		function setProg(p, txt) {
			prog.hidden = p === null;
			if (p !== null) prog.querySelector('i').style.width = Math.round(p * 100) + '%';
			if (txt && ocrSt) ocrSt.textContent = txt;
		}
		if (ocrBtn) ocrBtn.addEventListener('click', function () {
			if (st.busy || !st.files.length) return;
			st.busy = true; ocrBtn.disabled = true;
			var texts = [], total = st.files.length, worker = null;
			st.geo = { pages: [] };
			setProg(0.03, 'Odczyt dokumentów…');
			var chain = Promise.resolve();
			st.files.forEach(function (f, i) {
				chain = chain.then(function () {
					setProg(i / total, 'Odczyt pliku ' + (i + 1) + ' z ' + total + '…');
					// Najpierw spróbuj odczytać warstwę tekstową PDF (dokładnie, bez OCR).
					return pdfRead(f.file).then(function (pr) {
						var txt = pr.text;
						if (txt && txt.replace(/\s/g, '').length > 40) { texts.push(txt); if (pr.geo) st.geo.pages = st.geo.pages.concat(pr.geo.pages); return; }
						// Brak tekstu (obraz lub skan) → OCR; moduł ładujemy dopiero tu.
						var wp = worker ? Promise.resolve(worker) : getOcr(function (mm) {
							if (mm.status === 'recognizing text') setProg((i + mm.progress) / total, 'OCR… ' + Math.round(mm.progress * 100) + '% (plik ' + (i + 1) + ' z ' + total + ')');
							else if (/load|initializ/i.test(mm.status)) setProg(0.05, 'Przygotowanie OCR (pierwszy raz może potrwać kilkanaście sekund): ' + mm.status + '…');
						}).then(function (w) { worker = w; return w; });
						return wp.then(function (w) {
							return fileToCanvases(f.file).then(function (canvases) {
								var c2 = Promise.resolve();
								canvases.forEach(function (cv) { c2 = c2.then(function () { return ocrRead(w, cv); }).then(function (r) { texts.push(r.text); st.geo.pages.push(r.page); }); });
								return c2;
							});
						});
					});
				});
			});
			chain.then(function () { return ocrWzory(); }).then(function () {
				st.ocr = texts.join('\n\n');
				m.querySelector('[data-rawtxt]').value = st.ocr;
				m.querySelector('[data-raw]').hidden = false;
				applyParsed(parsePZDoc(st.ocr, st.geo), true);
				setProg(1, 'Gotowe – sprawdź rozpoznane pozycje.');
			}).catch(function (e) {
				toast(e.message || 'Błąd odczytu.', 'err');
				setProg(null, 'Nie udało się odczytać – uzupełnij pozycje ręcznie.');
			}).then(function () { st.busy = false; renderFiles(); });
		});
		m.querySelector('[data-reparse]').addEventListener('click', function () {
			st.ocr = m.querySelector('[data-rawtxt]').value;
			st.geo = null; // tekst poprawiony ręcznie – bez położenia słów
			applyParsed(parsePZ(st.ocr), false);
		});

		function applyParsed(res, first) {
			var hd = { data: res.data, dostawca: res.dostawca, nr_dok: res.nr_dok };
			Object.keys(hd).forEach(function (k) { var el = m.querySelector('[name=' + k + ']'); if (el && hd[k] && (!el.value || !first || k === 'data')) el.value = hd[k]; });
			syncLines();
			st.lines = st.lines.filter(function (l) { return !l.fromOcr || l.touched; });
			res.lines.forEach(function (l) { st.lines.push({ tabela: l.tabela, fields: l.fields, ilosc: l.ilosc, raw: l.raw, item_id: 0, matches: null, fromOcr: true }); });
			renderLines();
			st.lines.forEach(function (l, i) { if (l.matches === null) matchLine(i); });
			setProg(null, res.lines.length
				? 'Rozpoznano ' + res.lines.length + ' poz. – sprawdź i popraw dane przed przyjęciem.'
				: 'Nie rozpoznano pozycji automatycznie – dodaj je ręcznie (tekst z dokumentu jest niżej).');
			st.res = res;
			var info = m.querySelector('[data-pzhow]');
			if (!info) { info = document.createElement('div'); info.className = 'msm-pz-how'; info.setAttribute('data-pzhow', ''); m.querySelector('[data-raw]').insertAdjacentElement('beforebegin', info); }
			var how = res.how === 'wzor' ? 'Odczytano wg zapamiętanego układu dostawcy' + (res.prof && res.prof.nazwa ? ' <b>' + esc(res.prof.nazwa) + '</b>' : '') + '.'
				: res.how === 'kolumny' ? 'Odczytano tabelę pozycji po kolumnach dokumentu.'
				: res.how ? 'Odczytano układ: ' + esc(res.how) + '.' : '';
			var other = (res.other || []).length ? ' Pominięto ' + plN(res.other.length, 'pozycję', 'pozycje', 'pozycji') + ' spoza magazynu materiałów: ' + esc(res.other.slice(0, 3).join('; ')) + (res.other.length > 3 ? '…' : '') + '.' : '';
			info.innerHTML = (how || other ? '<span>' + how + other + '</span>' : '') +
				(OCR_LEARN && st.geo && st.geo.pages.length && C.canEdit ? '<button type="button" class="msm-link" data-pzlearn>' + (res.how === 'wzor' ? 'Zmień układ kolumn tego dostawcy' : 'Źle odczytane? Wskaż kolumny dla tego dostawcy') + '</button>' : '');
			info.hidden = !info.innerHTML;
			var lb = info.querySelector('[data-pzlearn]');
			if (lb) lb.addEventListener('click', function () {
				docLearn(st.geo, m.querySelector('[name=dostawca]').value, function () { applyParsed(parsePZDoc(st.ocr, st.geo), false); });
			});
		}

		var linesBox = m.querySelector('[data-plines]');
		function lineHtml(l, i) {
			var t = l.tabela;
			var magSel = '<select data-lf="tabela">' + STOCK.map(function (k) { return '<option value="' + k + '"' + (k === t ? ' selected' : '') + '>' + esc(S[k].label) + '</option>'; }).join('') + '</select>';
			var match = '<select data-lf="item_id"><option value="0">Nowa pozycja w magazynie</option>' +
				(l.matches || []).map(function (x) { return '<option value="' + x.id + '"' + (+l.item_id === x.id ? ' selected' : '') + '>Dodaj do: ' + esc(x.opis) + ' (stan ' + fmtNum(x.ilosc) + ' ' + U(t) + (x.uwagi ? ', ' + esc(x.uwagi) : '') + ')</option>'; }).join('') + '</select>';
			var flds = pzFieldCols(t).map(function (c) {
				var v = l.fields[c.key] !== undefined ? l.fields[c.key] : (c['default'] !== undefined ? c['default'] : '');
				var inp = c.type === 'enum'
					? '<select data-ff="' + c.key + '"><option value=""></option>' + c.options.map(function (o) { return '<option' + (String(o) === String(v) ? ' selected' : '') + '>' + esc(o) + '</option>'; }).join('') + '</select>'
					: '<input type="text" data-ff="' + c.key + '" value="' + esc(v) + '"' + (c.type === 'num' || c.type === 'int' ? ' inputmode="decimal"' : '') + '>';
				return '<label class="msm-field' + (c.long || c.key === 'opis' || c.key === 'oznaczenie' ? ' wide' : '') + '"><span>' + esc(c.label) + (c.required ? ' <i class="msm-req">*</i>' : '') + '</span>' + inp + '</label>';
			}).join('');
			return '<div class="msm-pz-line' + (+l.item_id ? ' is-existing' : '') + '" data-pl="' + i + '">' +
				'<div class="msm-pz-line__top"><span class="msm-pz-lp">' + (i + 1) + '.</span>' +
				'<label class="msm-field"><span>Magazyn</span>' + magSel + '</label>' +
				'<label class="msm-field msm-pz-qty"><span>Ilość [' + (isKg(t) ? 'kg' : 'szt') + '] <i class="msm-req">*</i></span><input type="text" inputmode="decimal" data-lf="ilosc" value="' + esc(l.ilosc) + '"></label>' +
				'<label class="msm-field msm-pz-match"><span>Przyjmij jako</span>' + match + '</label>' +
				'<button type="button" class="msm-iconbtn msm-iconbtn-danger" data-prm title="Usuń pozycję">' + ICON_DEL + '</button></div>' +
				'<div class="msm-pz-fields"' + (+l.item_id ? ' hidden' : '') + '>' + flds + '</div>' +
				(+l.item_id ? '<p class="msm-muted msm-small msm-pz-note">Ilość zostanie dodana do istniejącej pozycji. Aby utworzyć nową, wybierz „Nowa pozycja w magazynie”.</p>' : '') +
				(l.raw ? '<p class="msm-pz-src">Z dokumentu: <code>' + esc(l.raw) + '</code></p>' : '') +
				'</div>';
		}
		function syncLines() {
			linesBox.querySelectorAll('[data-pl]').forEach(function (el) {
				var l = st.lines[+el.getAttribute('data-pl')];
				if (!l) return;
				l.ilosc = el.querySelector('[data-lf=ilosc]').value;
				l.item_id = +el.querySelector('[data-lf=item_id]').value || 0;
				el.querySelectorAll('[data-ff]').forEach(function (f) { l.fields[f.getAttribute('data-ff')] = f.value; });
			});
		}
		/* ---- Zamówienia do dostawców: dopasowanie pozycji dostawy (do potwierdzenia) ---- */
		var zamBox = m.querySelector('[data-pzzam]'), zamCand = [], zamPick = {};
		var zamRefresh = debounce(function () {
			if (ED) { zamBox.hidden = true; return; } // zaliczenie na zamówienia – tylko przy przyjęciu
			var lines = st.lines.map(function (l) { return { tabela: l.tabela, item_id: +l.item_id || 0, fields: l.fields, ilosc: l.ilosc }; });
			if (!lines.length) { zamBox.hidden = true; return; }
			api('/zam/dopasuj', { method: 'POST', body: { dostawca: m.querySelector('[name=dostawca]').value, lines: lines } }).then(function (r) {
				zamCand = r.linie || [];
				zamCand.forEach(function (c, i) {
					var cur = zamPick[i];
					if (cur && c.some(function (x) { return x.poz === cur.poz; })) return;
					var best = c[0];
					zamPick[i] = best ? { poz: best.poz, on: !!best.ten_dostawca, ilosc: Math.min(palNumPZ(st.lines[i] && st.lines[i].ilosc) || best.pozostalo, best.pozostalo) } : null;
				});
				drawZam();
			}).catch(function () { zamBox.hidden = true; });
		}, 600);
		function palNumPZ(v) { v = String(v || '').replace(/\s/g, '').replace(',', '.'); return v === '' || isNaN(+v) ? 0 : +v; }
		function drawZam() {
			var any = zamCand.some(function (c) { return c && c.length; });
			zamBox.hidden = !any;
			if (!any) return;
			zamBox.innerHTML = '<h3 class="msm-wz-h">4. Zamówienia do dostawców</h3><p class="msm-small msm-muted">Te pozycje pasują do otwartych zamówień. Zaznaczone zaliczą się na zamówienie, a przyjęty materiał od razu zarezerwuje się dla zleceń, które na niego czekały.</p>' +
				zamCand.map(function (c, i) {
					if (!c || !c.length) return '';
					var pk = zamPick[i] || { poz: c[0].poz, on: false, ilosc: c[0].pozostalo };
					var cur = c.filter(function (x) { return x.poz === pk.poz; })[0] || c[0];
					return '<div class="msm-pzzam__row' + (pk.on ? ' is-on' : '') + '" data-zl="' + i + '"><label class="msm-check"><input type="checkbox" data-zon' + (pk.on ? ' checked' : '') + '> <span>Poz. ' + (i + 1) + '</span></label>' +
						'<select data-zpoz>' + c.map(function (x) { return '<option value="' + x.poz + '"' + (x.poz === cur.poz ? ' selected' : '') + '>' + esc(x.numer + ' · ' + x.dostawca + ' · ' + x.opis + ' – pozostało ' + fmtNum(x.pozostalo) + ' ' + (x.jm === 'kg' ? 'kg' : 'szt.')) + '</option>'; }).join('') + '</select>' +
						'<label class="msm-pzzam__q"><input type="text" inputmode="decimal" data-zq value="' + esc(String(pk.ilosc).replace('.', ',')) + '"><span>' + (cur.jm === 'kg' ? 'kg' : 'szt.') + '</span></label>' +
						(cur.ten_dostawca ? '' : '<small class="msm-pzzam__warn">inny dostawca na zamówieniu</small>') + '</div>';
				}).join('');
			zamBox.querySelectorAll('[data-zl]').forEach(function (row) {
				var i = +row.getAttribute('data-zl');
				function upd() { zamPick[i] = { poz: +row.querySelector('[data-zpoz]').value, on: row.querySelector('[data-zon]').checked, ilosc: row.querySelector('[data-zq]').value }; row.classList.toggle('is-on', zamPick[i].on); }
				row.querySelector('[data-zon]').addEventListener('change', upd);
				row.querySelector('[data-zq]').addEventListener('input', upd);
				row.querySelector('[data-zpoz]').addEventListener('change', function () { upd(); drawZam(); });
			});
		}
		m.querySelector('[name=dostawca]').addEventListener('input', zamRefresh);
		m.querySelector('[name=dostawca]').addEventListener('change', zamRefresh);

		function renderLines() {
			zamRefresh();
			linesBox.innerHTML = st.lines.length ? st.lines.map(lineHtml).join('') : '<p class="msm-muted">' + (ED ? 'Brak nowych pozycji – dodaj, jeśli dostawa zawierała coś jeszcze.' : 'Brak pozycji. Wgraj skan i kliknij „Rozpoznaj tekst”, albo dodaj pozycję ręcznie.') + '</p>';
			linesBox.querySelectorAll('[data-pl]').forEach(function (el) {
				var i = +el.getAttribute('data-pl'), l = st.lines[i];
				el.querySelector('[data-prm]').addEventListener('click', function () { syncLines(); st.lines.splice(i, 1); renderLines(); });
				el.querySelector('[data-lf=tabela]').addEventListener('change', function (e) {
					syncLines(); l.tabela = e.target.value; l.fields = {}; l.item_id = 0; l.matches = null; l.touched = true; renderLines(); matchLine(i);
				});
				el.querySelector('[data-lf=item_id]').addEventListener('change', function () { syncLines(); l.touched = true; l.userPicked = true; renderLines(); });
				el.querySelector('[data-lf=ilosc]').addEventListener('input', function () { l.touched = true; });
				var deb = debounce(function () { syncLines(); matchLine(i); }, 450);
				el.querySelectorAll('[data-ff]').forEach(function (f) { f.addEventListener('input', function () { l.touched = true; deb(); }); f.addEventListener('change', deb); });
			});
		}
		function matchLine(i) {
			var l = st.lines[i];
			if (!l) return;
			var keys = PZ_MATCH_KEYS[l.tabela] || [];
			if (!keys.some(function (k) { return l.fields[k]; })) { l.matches = []; return; }
			api('/pz/match', { method: 'POST', body: { tabela: l.tabela, fields: l.fields } }).then(function (rows) {
				if (st.lines[i] !== l) return;
				syncLines();
				l.matches = rows;
				if (!l.userPicked) l.item_id = rows.length ? rows[0].id : 0;
				if (l.item_id && !rows.some(function (x) { return x.id === +l.item_id; })) l.item_id = 0;
				var focused = document.activeElement && document.activeElement.getAttribute('data-ff');
				renderLines();
				if (focused) { var f = linesBox.querySelector('[data-pl="' + i + '"] [data-ff="' + focused + '"]'); if (f) { f.focus(); var v = f.value; if (f.setSelectionRange && f.type === 'text') f.setSelectionRange(v.length, v.length); } }
			}).catch(function () {});
		}
		m.querySelector('[data-padd]').addEventListener('click', function () {
			syncLines();
			st.lines.push({ tabela: 'stal', fields: {}, ilosc: '', raw: '', item_id: 0, matches: [], touched: true });
			renderLines();
		});
		renderLines();
		renderFiles();

		m.querySelector('[data-psave]').addEventListener('click', function () {
			syncLines();
			var err = m.querySelector('.msm-form-err');
			if (st.files.some(function (f) { return !f.id && !f.err; })) { toast('Poczekaj, aż skany się wgrają.', 'warn'); return; }
			var body2 = {
				header: { data: m.querySelector('[name=data]').value, dostawca: m.querySelector('[name=dostawca]').value, nr_dok: m.querySelector('[name=nr_dok]').value, uwagi: m.querySelector('[name=uwagi]').value },
				lines: st.lines.map(function (l) { return { tabela: l.tabela, item_id: +l.item_id || 0, ilosc: l.ilosc, fields: +l.item_id ? {} : l.fields }; }),
				files: st.files.filter(function (f) { return f.id; }).map(function (f) { return f.id; }),
				ocr: st.ocr,
				zam: Object.keys(zamPick).filter(function (k) { return zamPick[k] && zamPick[k].on && zamCand[k] && zamCand[k].length; }).map(function (k) { return { line: +k, poz: zamPick[k].poz, ilosc: zamPick[k].ilosc }; })
			};
			var btn = this; btn.disabled = true;
			if (ED) {
				body2 = { header: body2.header, files: body2.files,
					lines: st.old.map(function (o) { return { id: o.l.id, ilosc: o.ilosc, usun: o.usun }; }),
					add: body2.lines,
					drop_files: st.oldFiles.filter(function (o) { return o.usun; }).map(function (o) { return o.f.id; }) };
			}
			api(ED ? '/pz/' + doc.id + '/edytuj' : '/pz', { method: 'POST', body: body2 }).then(function (r) {
				toast(r.message); STOCK.forEach(invalidate); refresh('pz');
				renderPZView(r.doc);
			}).catch(function (e) {
				btn.disabled = false;
				err.innerHTML = esc(e.message).replace(/\n/g, '<br>'); err.hidden = false;
				m.querySelector('.msm-modal-body').scrollTop = 0;
			});
		});
	}

	function renderPZView(doc) {
		var canceled = doc.status === 'anulowany';
		var body = '<div class="msm-wz-status"><span class="msm-tag msm-tag-pz-' + esc(doc.status) + '">' + esc(PZ_LABELS[doc.status] || doc.status) + '</span>' +
			'<span class="msm-muted">przyjął: ' + esc(doc.created_name) + ', ' + esc(fmtDate(doc.created_at)) + '</span>' +
			(doc.updated_name ? '<span class="msm-muted">zmienił: ' + esc(doc.updated_name) + ', ' + esc(fmtDate(doc.updated_at)) + '</span>' : '') +
			(doc.canceled_name ? '<span class="msm-muted">anulował: ' + esc(doc.canceled_name) + ', ' + esc(fmtDate(doc.canceled_at)) + '</span>' : '') + '</div>' +
			'<dl class="msm-pz-dl"><div><dt>Data przyjęcia</dt><dd>' + esc(fmtDate(doc.data)) + '</dd></div><div><dt>Dostawca</dt><dd>' + esc(doc.dostawca) + '</dd></div>' +
			'<div><dt>Nr dokumentu dostawcy</dt><dd>' + esc(doc.nr_dok || '—') + '</dd></div>' + (doc.uwagi ? '<div><dt>Uwagi</dt><dd>' + esc(doc.uwagi).replace(/\n/g, '<br>') + '</dd></div>' : '') + '</dl>' +
			'<table class="msm-table msm-pz-vlines"><thead><tr><th class="num">Lp.</th><th>Magazyn</th><th>Pozycja</th><th>Przyjęcie</th><th class="num">Ilość</th><th class="num">Stan teraz</th></tr></thead><tbody>' +
			doc.lines.map(function (l) {
				return '<tr><td class="num" data-label="Lp.">' + l.lp + '.</td><td data-label="Magazyn">' + esc(l.magazyn) + '</td><td data-label="Pozycja"><span class="msm-zt__v">' + esc(l.opis) + '</span></td><td data-label="Przyjęcie"><span class="msm-tag ' + (l.akcja === 'nowa' ? 'msm-tag-ok' : 'msm-tag-pobranie') + '">' + (l.akcja === 'nowa' ? 'nowa pozycja' : 'dodano do stanu') + '</span></td>' +
					'<td class="num" data-label="Ilość"><b>' + fmtNum(l.ilosc) + ' ' + esc(l.jednostka) + '</b></td><td class="num" data-label="Stan teraz">' + (l.stock === null ? '—' : fmtNum(l.stock) + ' ' + esc(l.jednostka)) + '</td></tr>';
			}).join('') + '</tbody></table>' +
			(doc.zam && doc.zam.length ? '<h3 class="msm-wz-h">Zaliczono na zamówienia</h3><ul class="msm-pz-zam">' + doc.zam.map(function (z) { return '<li><a href="#zam-' + z.zam_id + '" data-close>' + esc(z.numer) + '</a> · ' + esc(z.opis) + ' – <b>' + fmtNum(z.ilosc) + '</b></li>'; }).join('') + '</ul>' : '') +
			(doc.files.length ? '<h3 class="msm-wz-h">Skany dokumentu</h3><div class="msm-pz-files">' + doc.files.map(function (f) {
				var img = /^image\//.test(f.mime);
				return '<a class="msm-pz-file" href="' + esc(f.url) + '" target="_blank" rel="noopener" data-view="' + (img ? 'img' : 'file') + '" data-name="' + esc(f.nazwa) + '">' + (img ? '<img src="' + esc(f.url) + '" alt="">' : '<span class="msm-pz-pdf">PDF</span>') + '<div><b>' + esc(f.nazwa) + '</b><small>otwórz</small></div></a>';
			}).join('') + '</div>' : '<p class="msm-muted msm-small">Brak dołączonych skanów.</p>');
		var m = openModal(doc.numer, body,
			'<button type="button" class="msm-btn msm-btn-ghost" data-close>Zamknij</button>' + (!canceled ? '<button type="button" class="msm-btn msm-btn-danger-ghost" data-pcancel>Anuluj PZ</button><button type="button" class="msm-btn msm-btn-primary" data-pedit>Edytuj</button>' : ''), true);
		var eb = m.querySelector('[data-pedit]');
		if (eb) eb.addEventListener('click', function () { loadOptions('pz').then(function (opts) { renderPZForm(opts || {}, doc); }); });
		var cb = m.querySelector('[data-pcancel]');
		if (cb) cb.addEventListener('click', function () {
			var mm = openModal('Anulować ' + doc.numer + '?', '<p>Przyjęte ilości zostaną cofnięte ze stanu (nowo dodane pozycje – usunięte). Dokument zostanie w rejestrze jako „anulowany”.</p><label class="msm-field full"><span>Powód (opcjonalnie)</span><textarea name="note" rows="2"></textarea></label>',
				'<button type="button" class="msm-btn" data-back>Wróć</button><button type="button" class="msm-btn msm-btn-danger" data-ok>Anuluj PZ</button>');
			mm.querySelector('[data-back]').addEventListener('click', function () { renderPZView(doc); });
			mm.querySelector('[data-ok]').addEventListener('click', function () {
				api('/pz/' + doc.id + '/anuluj', { method: 'POST', body: { note: mm.querySelector('[name=note]').value } }).then(function (r) {
					toast(r.message); STOCK.forEach(invalidate); refresh('pz'); renderPZView(r.doc);
				}).catch(function (e) { toast(e.message, 'err'); });
			});
		});
	}

	function itemBox(t, row) {
		var rez = REZ_T.indexOf(t) >= 0 && row._rez > 0 ? row._rez : 0;
		var av = rez ? Math.max(0, row.ilosc - rez) : null;
		return '<div class="msm-item-box"><b>' + esc(rowTitle(t, row)) + '</b><span>Na stanie: <b>' + fmtNum(row.ilosc) + ' ' + U(t) + '</b>' +
			(rez ? ' · <span class="msm-rez-hint">zarezerwowane ' + fmtNum(rez) + ' ' + U(t) + ' · dostępne <b>' + fmtNum(av) + ' ' + U(t) + '</b></span>' : '') +
			(row.uwagi ? ' · ' + esc(row.uwagi) : '') + '</span></div>';
	}

	/* ================================================================
	   ROZPOZNAWANIE DOKUMENTÓW (WZ/PZ/faktury) Z RÓŻNYCH PROGRAMÓW
	   Uniwersalny odczyt tabeli pozycji po POŁOŻENIU tekstu na stronie:
	   – PDF z warstwą tekstową: elementy z pdf.js (x, y, szerokość),
	   – skan / zdjęcie: słowa z OCR (ramki słów z Tesseracta).
	   Wiersz nagłówka tabeli („Lp. | Nazwa | Kod | Ilość | J.m. …”) wyznacza kolumny,
	   więc kolejność i nazwy kolumn mogą się różnić między programami
	   (Subiekt, Optima/XL, WF-Mag, Symfonia, enova, Streamsoft, iFirma, Firmao, wFirma,
	   Fakturownia, inFakt, Saldeo…). Dla nietypowych układów można raz wskazać kolumny –
	   układ zapamiętuje się dla dostawcy (NIP).
	   ================================================================ */

	/* Geometria strony z pdf.js: słowa z położeniem (y liczone od góry strony). */
	function pdfGeoPage(tc, vp) {
		var W = vp.width, H = vp.height, words = [];
		(tc.items || []).forEach(function (it) {
			var s = String(it.str || '');
			if (!s.trim()) return;
			var t = it.transform, h = Math.abs(t[3]) || it.height || 8, x = t[4], w = it.width || s.length * h * 0.5;
			var y = H - t[5] - h * 0.8;
			docSplitWords(s, x, w, y, h, words);
		});
		return { w: W, h: H, words: words };
	}
	/* Słowa z OCR (tesseract.js – blocks → paragraphs → lines → words). */
	function ocrGeoPage(data, w, h) {
		var words = [];
		var ln = 0;
		(data && data.blocks || []).forEach(function (b) {
			(b.paragraphs || []).forEach(function (p) {
				(p.lines || []).forEach(function (l) {
					ln++;
					(l.words || []).forEach(function (wd) {
						var s = String(wd.text || '').trim(), bb = wd.bbox;
						if (!s || !bb || (wd.confidence !== undefined && wd.confidence < 20 && s.length < 2)) return;
						words.push({ x0: bb.x0, x1: bb.x1, y: bb.y0, h: Math.max(4, bb.y1 - bb.y0), s: s, ln: ln });
					});
				});
			});
		});
		return { w: w, h: h, words: words };
	}
	/* Element tekstu PDF może zawierać kilka słów – dzielimy go z proporcjonalnym położeniem. */
	function docSplitWords(s, x, w, y, h, out) {
		var len = s.length, re = /\S+/g, m;
		while ((m = re.exec(s))) {
			out.push({ x0: x + w * m.index / len, x1: x + w * (m.index + m[0].length) / len, y: y, h: h, s: m[0] });
		}
	}

	/* Wiersze dokumentu: słowa grupowane po wysokości (strony jedna pod drugą). */
	function docRows(geo) {
		var rows = [], off = 0;
		(geo.pages || []).forEach(function (pg, pi) {
			var sc = 1000 / (pg.w || 1000); // współrzędne w „tysięcznych” szerokości strony
			var sk = docSkew(pg.words);
			var ws = pg.words.map(function (w) { var yy = w.y - sk * (w.x0 + w.x1) / 2; return { x0: w.x0 * sc, x1: w.x1 * sc, y: yy * sc + off, h: w.h * sc, s: w.s, p: pi }; })
				.sort(function (a, b) { return a.y - b.y || a.x0 - b.x0; });
			var hs = ws.map(function (w) { return w.h; }).sort(function (a, b) { return a - b; });
			var mh = hs.length ? hs[Math.floor(hs.length / 2)] : 10;
			var cur = null;
			ws.forEach(function (w) {
				if (cur && Math.abs(w.y - cur.y) <= Math.max(2, Math.min(w.h, cur.h, mh) * 0.55)) { cur.words.push(w); cur.h = Math.max(cur.h, w.h); }
				else { cur = { y: w.y, h: w.h, words: [w], p: pi }; rows.push(cur); }
			});
			off += (pg.h || 1400) * sc + 50;
		});
		rows.forEach(function (r) {
			r.words.sort(function (a, b) { return a.x0 - b.x0; });
			r.text = r.words.map(function (w) { return w.s; }).join(' ');
			r.f = fold(r.text);
		});
		return rows;
	}
	/* Pochylenie zdjęcia/skanu: mediana nachylenia linii tekstu z OCR (słowa z tej samej linii). */
	function docSkew(words) {
		var L = {}, sl = [];
		words.forEach(function (w) { if (w.ln) (L[w.ln] = L[w.ln] || []).push(w); });
		Object.keys(L).forEach(function (k) {
			var a = L[k]; if (a.length < 3) return;
			a.sort(function (p, q) { return p.x0 - q.x0; });
			var f = a[0], l = a[a.length - 1], dx = (l.x0 + l.x1 - f.x0 - f.x1) / 2;
			if (dx < 150) return;
			var cy = function (w) { return w.y + w.h; }; // dół słowa ≈ linia bazowa (bez ogonków większość słów)
			sl.push((cy(l) - cy(f)) / dx);
		});
		if (sl.length < 3) return 0;
		sl.sort(function (a, b) { return a - b; });
		var s = sl[Math.floor(sl.length / 2)];
		return Math.abs(s) > 0.0015 && Math.abs(s) < 0.15 ? s : 0;
	}
	/* Tekst z geometrii (dla starszych parserów i podglądu). */
	function docText(rows) { return rows.map(function (r) { return r.text; }).join('\n'); }

	/* ---------- kolumny ---------- */
	var DOC_COLS = [
		['lp', /^(l\s*\.?\s*p\.?|lp\.?|nr\.?|poz\.?|#)$/],
		['kod', /^(kod|symbol|indeks|index|nr\s*kat|nr\s*katalogowy|numer\s*katalogowy|katalog|sku|ean|kod\s*towaru|kod\s*produktu|symbol\s*towaru|indeks\s*towaru|nr\s*artykulu|art\.?\s*nr)/],
		['nazwa', /(nazwa|towar|opis|asortyment|produkt|artykul|material|wyszczegolnienie|przedmiot)/],
		['ilosc', /^([il1|]{1,2}los[ce]|il\.|ilo|qty|liczba|wydano|wydana|przyjeto)/],
		['jm', /^(j\s*\.?\s*m\.?|jm\.?|jedn\.?|jednostka|j\.\s*miary|miara|jedn\.\s*miary)$/],
		['jm2', /^(j\s*\.?\s*m\s*\.?\s*p\.?|jm\s*pom\.?|jedn\.\s*pom\.?|j\.\s*m\.\s*pomocn\w*)$/],
		['cena', /^(cena)/],
		['wart', /^(wartosc|kwota|netto|brutto)/],
		['vat', /^(vat|stawka|st\.\s*vat|%\s*vat)/],
		['waga', /^(waga|masa)/],
		['skip', /^(pkwiu|gtu|cn|rabat|upust|magazyn|lokalizacja|partia|seria|uwagi|termin|data|kraj)/]
	];
	var DOC_QUAL = /^(towaru|towar|produktu|uslugi|towaru\/uslugi|lub|katalogowy|katalogowa|netto|brutto|wydana|wydano|jedn\.?|jednostkowa|artykulu|materialu|vat|razem|z|w)$/;
	/* Rodzaj kolumny z tekstu komórki nagłówka (null – to nie jest nazwa kolumny). */
	function docColType(t) {
		var f = fold(t).replace(/[\[\]():]/g, '').replace(/\s+/g, ' ').trim();
		if (!f || f.length > 40) return null;
		for (var i = 0; i < DOC_COLS.length; i++) if (DOC_COLS[i][1].test(f)) return DOC_COLS[i][0];
		return null;
	}
	/* Słowa wiersza → „komórki” (słowa blisko siebie). */
	function docCells(words, gapK) {
		var cells = [], cur = null;
		words.forEach(function (w) {
			var gap = cur ? w.x0 - cur.x1 : 1e9;
			if (cur && gap < Math.max(w.h, cur.h) * (gapK || 0.9)) { cur.x1 = w.x1; cur.s += ' ' + w.s; cur.words.push(w); cur.h = Math.max(cur.h, w.h); }
			else { cur = { x0: w.x0, x1: w.x1, s: w.s, words: [w], h: w.h }; cells.push(cur); }
		});
		return cells;
	}
	/* Nagłówek tabeli: wiersz (lub dwa wiersze) z kolumną nazwy i ilości. */
	function docFindHeader(rows, from) {
		for (var i = from || 0; i < rows.length; i++) {
			var r = rows[i];
			if (!/([il1|]lo|qty|wydano)/.test(r.f) || !/(nazwa|towar|opis|asortyment|produkt|artykul|material|wyszczeg|kod|indeks|symbol)/.test(r.f)) continue;
			var group = [r];
			var nx = rows[i + 1];
			if (nx && nx.p === r.p && nx.y - r.y < r.h * 2.2 && docHeaderish(nx)) group.push(nx);
			var cols = docHeaderCols(group);
			var types = cols.map(function (c) { return c.t; });
			if (types.indexOf('ilosc') < 0 || (types.indexOf('nazwa') < 0 && types.indexOf('kod') < 0)) continue;
			return { i: i, last: i + group.length - 1, cols: cols };
		}
		return null;
	}
	/* Czy wiersz wygląda na dalszą część nagłówka (krótkie słowa bez liczb, np. „lub usługi”, „[kg]”). */
	function docHeaderish(r) {
		return r.words.length <= 12 && !/\d{2,}/.test(r.text) && r.words.every(function (w) { return w.s.length < 18; });
	}
	function docHeaderCols(group) {
		var cells = [];
		group.forEach(function (r, gi) {
			docCells(r.words, 0.75).forEach(function (c) {
				/* „Lp. Nazwa towaru” w jednej komórce → dwie kolumny. */
				var m = c.s.match(/^(L\.?\s?p\.?|Lp\.?|Nr\.?)\s+(.+)$/i);
				if (m && c.words.length > 1 && docColType(c.s) !== 'kod' && docColType(m[2]) === 'nazwa') {
					var w0 = c.words[0];
					cells.push({ x0: w0.x0, x1: w0.x1, s: w0.s, g: gi });
					cells.push({ x0: c.words[1].x0, x1: c.x1, s: c.words.slice(1).map(function (w) { return w.s; }).join(' '), g: gi });
				} else cells.push({ x0: c.x0, x1: c.x1, s: c.s, g: gi });
				/* Kilka nazw kolumn sklejonych odstępem jednej spacji („Ilość J.m.”) – rozdziel, gdy każde słowo to osobna kolumna. */
			});
		});
		var out = [];
		cells.forEach(function (c) {
			var t = docColType(c.s);
			/* „Ilość J.m.”, „Ilość Jm Cena” – kilka kolumn w jednej komórce (gdy drugie słowo nie jest dopowiedzeniem) */
			if (t && c.s.indexOf(' ') > 0) {
				var ps = c.s.split(' '), ts = ps.map(docColType);
				if (ts.filter(Boolean).length >= 2 && !ps.slice(1).some(function (p) { return DOC_QUAL.test(fold(p)); }) && ts[0] !== ts[1]) t = null;
			}
			if (!t && c.s.indexOf(' ') > 0) {
				/* spróbuj słowo po słowie */
				var parts = c.s.split(' '), ok = parts.map(docColType);
				if (ok.filter(Boolean).length >= 2) {
					var x = c.x0, wch = (c.x1 - c.x0) / c.s.length;
					parts.forEach(function (p, k) { var x1 = x + p.length * wch; if (ok[k]) out.push({ x0: x, x1: x1, t: ok[k], s: p, g: c.g }); x = x1 + wch; });
					return;
				}
			}
			if (!t) {
				/* druga linia nagłówka („lub usługi”, „[kg]”) – dopisz do kolumny nad nią */
				var up = out.filter(function (o) { return o.g < c.g && o.x0 < c.x1 && o.x1 > c.x0; })[0];
				if (up) { up.x0 = Math.min(up.x0, c.x0); up.x1 = Math.max(up.x1, c.x1); up.s += ' ' + c.s; if (/\bkg\b/i.test(c.s) && up.t === 'ilosc') up.unit = 'kg'; }
				return;
			}
			/* nazwa z drugiej linii nakłada się na tę z pierwszej („Ilość” / „wydana”) */
			var same = out.filter(function (o) { return o.x0 < c.x1 && o.x1 > c.x0; })[0];
			if (same && c.g !== same.g) { same.x0 = Math.min(same.x0, c.x0); same.x1 = Math.max(same.x1, c.x1); if (same.t === 'skip' || (same.t === 'ilosc' && t === 'jm')) same.t = t; return; }
			out.push({ x0: c.x0, x1: c.x1, t: t, s: c.s, g: c.g });
		});
		out.sort(function (a, b) { return a.x0 - b.x0; });
		/* Druga kolumna ilości / j.m. (np. Optima: J.m. Ilość J.m.p. Ilość) → ilosc2 / jm2. */
		var seen = {};
		out.forEach(function (c) {
			if (c.t === 'jm2') { c.t = 'jm2'; seen.jm2 = 1; return; }
			if ((c.t === 'ilosc' || c.t === 'jm') && seen[c.t]) c.t = c.t + '2';
			seen[c.t] = 1;
		});
		/* granice kolumn: w połowie odstępu między nagłówkami */
		out.forEach(function (c, k) {
			var prev = out[k - 1], next = out[k + 1];
			c.L = prev ? (prev.x1 + c.x0) / 2 : -1e9;
			c.R = next ? (c.x1 + next.x0) / 2 : 1e9;
		});
		return out;
	}
	/* Przypisanie słów wiersza do kolumn (słowo do kolumny, w której leży jego środek). */
	function docAssign(row, cols) {
		var o = {};
		row.words.forEach(function (w) {
			var cx = (w.x0 + w.x1) / 2, best = null;
			for (var k = 0; k < cols.length; k++) { if (cx >= cols[k].L && cx < cols[k].R) { best = cols[k]; break; } }
			if (!best) return;
			o[best.t] = o[best.t] ? o[best.t] + ' ' + w.s : w.s;
		});
		return o;
	}
	var DOC_STOP = /^(razem|suma|ogolem|podsumowanie|lacznie|wartosc (netto )?(razem|ogolem)|do zaplaty|slownie|wystawil|wystawila|wydal|odebral|przyjal|zatwierdzil|podpis|uwagi\s*:|sposob platnosci|termin platnosci|zaplacono|pozostalo|strona \d|str\. \d|wartosc towaru|stawka vat razem|w tym)/;
	function docNum(s) {
		var m = String(s || '').replace(/\s(?=\d{3}\b)/g, '').match(/-?\d+(?:[.,]\d+)?/);
		return m ? pnum(m[0]) : null;
	}
	/* Granice kolumn wg treści tabeli: między środkami sąsiednich nagłówków szukamy pionowego „pasa”
	   bez tekstu we wszystkich wierszach pozycji (długie nazwy wchodzą pod nagłówek liczby itp.). */
	function docRefine(rows, from, cols) {
		var body = [];
		for (var i = from; i < rows.length && body.length < 80; i++) { if (DOC_STOP.test(rows[i].f)) break; if (/\d{2,}|\d[.,x×]\d/.test(rows[i].text)) body.push(rows[i]); } // wiersze bez liczb to zwykle szum ze skanu
		if (!body.length) return cols;
		for (var k = 0; k + 1 < cols.length; k++) {
			var c = cols[k], n = cols[k + 1], lo = (c.x0 + c.x1) / 2, hi = (n.x0 + n.x1) / 2;
			if (hi - lo < 4) continue;
			/* słowa z pasa między nagłówkami; każde „należy” do bliższego nagłówka (odległość odcinków) */
			var ws = [], dist = function (w, h) { return Math.max(0, h.x0 - w.x1, w.x0 - h.x1); };
			/* tekst przed kolumną liczbową: słowo z literami należy do kolumny tekstowej, sama liczba – do liczbowej */
			var numN = /^(ilosc2?|cena|wart|waga|vat)$/.test(n.t) && /^(nazwa|kod)$/.test(c.t);
			body.forEach(function (r) { r.words.forEach(function (w) {
				if (w.x1 <= lo || w.x0 >= hi) return;
				var left = numN ? !/^-?[\d\s.,]+$/.test(w.s) : dist(w, c) <= dist(w, n);
				ws.push({ a: w.x0, b: w.x1, left: left });
			}); });
			ws.sort(function (p, q) { return p.a - q.a; });
			/* kandydaci: pionowe przerwy bez tekstu; wybór – najwięcej słów po „swojej” stronie, potem najszersza */
			var gaps = [], at = lo;
			ws.forEach(function (v) { if (v.a - at >= 2) gaps.push([at, v.a]); at = Math.max(at, v.b); });
			if (hi - at >= 2) gaps.push([at, hi]);
			var best = null, bs = -1;
			gaps.forEach(function (g) {
				var mid = (g[0] + g[1]) / 2, s = 0;
				ws.forEach(function (v) { if ((v.b <= mid) === v.left) s++; });
				if (s > bs || (s === bs && g[1] - g[0] > best[1] - best[0])) { bs = s; best = g; }
			});
			if (best) { var b = (best[0] + best[1]) / 2; c.R = b; n.L = b; }
		}
		return cols;
	}
	/* Pozycje tabeli: { lp, kod, nazwa, ilosc, jm, ilosc2, jm2, raw }. */
	function docTable(rows, hdr) {
		var cols = docRefine(rows, hdr.last + 1, hdr.cols), hasLp = cols.some(function (c) { return c.t === 'lp'; });
		var qtyCol = cols.filter(function (c) { return c.t === 'ilosc'; })[0];
		var recs = [], conts = [], cur = null, lastY = null;
		for (var i = hdr.last + 1; i < rows.length; i++) {
			var r = rows[i];
			var gap = lastY !== null && r.y - lastY > r.h * 6;
			if (gap || DOC_STOP.test(r.f) || /^(razem|suma)\b/.test(fold(r.words[0] ? r.words[0].s : ''))) {
				/* koniec tabeli (podsumowanie, duża przerwa) – ale na kolejnej stronie może być jej ciąg dalszy */
				var again = docFindHeader(rows, i), lastP = recs.length ? recs[recs.length - 1].p : rows[hdr.last >= 0 ? hdr.last : 0].p;
				if (again && (rows[again.i].p > lastP || again.i === i)) { i = again.last; cols = docRefine(rows, again.last + 1, again.cols); lastY = null; continue; }
				break;
			}
			/* powtórzony nagłówek na nowej stronie */
			if (/([il1|]lo|qty)/.test(r.f) && /(nazwa|towar|opis|kod|indeks)/.test(r.f) && !/\d{3,}/.test(r.text)) { var h2 = docFindHeader(rows, i); if (h2 && h2.i === i) { cols = docRefine(rows, h2.last + 1, h2.cols); i = h2.last; continue; } }
			var a = docAssign(r, cols);
			if (!Object.keys(a).length) continue;
			lastY = r.y;
			var lpv = a.lp ? a.lp.match(/^\s*(\d{1,4})\.?\s*$/) : null;
			if (!hasLp && a.nazwa) { var lm = a.nazwa.match(/^(\d{1,3})\.?\s+(.{3,})$/); if (lm) { lpv = [lm[0], lm[1]]; a.nazwa = lm[2]; } }
			var q = a.ilosc !== undefined ? docNum(a.ilosc) : null;
			var named = !!(a.nazwa || a.kod);
			/* nowa pozycja: numer Lp. albo ilość z nazwą (OCR potrafi przekręcić „1” w Lp. na „t”, „Ę”, „-”),
			   chyba że poprzednia pozycja jeszcze nie ma ilości (ilość wyśrodkowana na dwóch wierszach) */
			var start = !!lpv && named;
			if (!start && q !== null && named) start = !(cur && cur.ilosc === null && r.y - cur.y0 < r.h * 3);
			if (start) {
				cur = { lp: lpv ? +lpv[1] : recs.length + 1, kod: a.kod || '', nazwa: '', parts: [{ y: r.y, n: a.nazwa || '' }], ilosc: q, jm: a.jm || '', ilosc2: docNum(a.ilosc2), jm2: a.jm2 || '', y0: r.y, p: r.p, raw: r.text };
				/* jednostka sklejona z ilością w jednej kolumnie („200 kg”) */
				if (!cur.jm && a.ilosc) { var um = a.ilosc.match(/([a-ząćęłńóśźż.]{1,6})\s*$/i); if (um && !/^\d/.test(um[1])) cur.jm = um[1]; }
				recs.push(cur);
			} else conts.push({ y: r.y, h: r.h, a: a, q: q, text: r.text, after: recs.length - 1 });
		}
		/* ciąg dalszy pozycji (dłuższa nazwa, ilość wyśrodkowana pionowo…) – do bliższej pozycji: poprzedniej albo następnej */
		conts.forEach(function (c) {
			var P = recs[c.after], N = recs[c.after + 1], dP = P ? c.y - P.y0 : 1e9, dN = N ? N.y0 - c.y : 1e9;
			var to = N && dN < dP * 0.6 && dN < c.h * 2.5 ? N : (P && dP < c.h * 5 ? P : null);
			if (!to) return;
			var a = c.a;
			if (a.nazwa && !/^(opis|uwagi)\s*:/i.test(a.nazwa)) to.parts.push({ y: c.y, n: a.nazwa });
			if (a.kod) to.kod = to === N ? a.kod + ' ' + to.kod : to.kod + ' ' + a.kod;
			if (to.ilosc === null && c.q !== null) to.ilosc = c.q;
			if (!to.jm && a.jm) to.jm = a.jm;
			if (to.ilosc2 === null && a.ilosc2) to.ilosc2 = docNum(a.ilosc2);
			if (!to.jm2 && a.jm2) to.jm2 = a.jm2;
			to.raw += ' ' + c.text;
		});
		if (qtyCol && qtyCol.unit && recs.length) recs.forEach(function (x) { if (!x.jm) x.jm = qtyCol.unit; });
		recs.forEach(function (x) { x.nazwa = x.parts.sort(function (p, q) { return p.y - q.y; }).map(function (p) { return p.n; }).join(' '); });
		return recs.filter(function (x) { return (x.nazwa || x.kod) && (x.ilosc !== null || x.ilosc2 !== null); })
			.map(function (x) { x.nazwa = x.nazwa.replace(/\s+/g, ' ').trim(); x.kod = x.kod.trim(); x.jm = x.jm.trim(); delete x.y0; delete x.parts; delete x.p; return x; });
	}

	/* ---------- nagłówek dokumentu ---------- */
	var DOC_SUP = /^(sprzedawca|dostawca|wystawca|nadawca|sprzedajacy|dostawca towaru|wydajacy|magazyn wydajacy|firma)\b/;
	var DOC_BUY = /^(nabywca|odbiorca|kupujacy|platnik|zamawiajacy|adres dostawy|miejsce dostawy|dostawa do)\b/;
	var DOC_OWN = /kisielewski/i;
	/* NIP naszej firmy (Ustawienia) – nigdy nie jest NIP-em dostawcy. */
	function docOwnNip(n) { var own = (typeof C !== 'undefined' && C && C.firmaNip) || '7511771802'; return !!n && n === own; }
	/* Blok dostawcy: etykieta „Sprzedawca/Dostawca/Wystawca…”, pod nią nazwa (ta sama kolumna strony). */
	function docParty(rows) {
		var out = { nazwa: '', nip: '' };
		for (var i = 0; i < rows.length && i < 80; i++) {
			var r = rows[i], cells = docCells(r.words, 1.2);
			for (var c = 0; c < cells.length; c++) {
				var cf = fold(cells[c].s);
				if (!DOC_SUP.test(cf)) continue;
				var x0 = cells[c].x0, x1 = cells[c + 1] ? cells[c + 1].x0 : 1000;
				var nextBuy = cells.slice(c + 1).filter(function (z) { return DOC_BUY.test(fold(z.s)); })[0];
				if (nextBuy) x1 = nextBuy.x0;
				var rest = cells[c].s.replace(/^[^:]*:\s*/, '');
				var lines = [];
				if (rest !== cells[c].s && rest.length > 2) lines.push(rest);
				for (var j = i + 1; j < rows.length && j < i + 9; j++) {
					var t = rows[j].words.filter(function (w) { return w.x0 >= x0 - 30 && w.x0 < x1 - 5; }).map(function (w) { return w.s; }).join(' ').trim();
					if (!t) continue;
					if (DOC_BUY.test(fold(t)) || DOC_SUP.test(fold(t))) break;
					lines.push(t);
				}
				if (!lines.length || DOC_OWN.test(lines[0])) continue;
				out.nazwa = lines[0].replace(/^[:\-\s]+/, '');
				/* nazwa w dwóch liniach: „Stal-Hurt Spółka z ograniczoną” / „odpowiedzialnością” */
				if (lines[1] && !/\d{2}-\d{3}|nip|ul\.|tel|regon|krs|\d{3}/i.test(lines[1]) && lines[1].length < 60 && /(sp|spolk|odpowiedz|s\.a|sp\.|k\.|j\.)/i.test(fold(lines[0] + ' ' + lines[1]))) out.nazwa += ' ' + lines[1];
				lines.some(function (l) { var n = docNip(l); if (n) { out.nip = n; return true; } return false; });
				return out;
			}
		}
		return out;
	}
	/* Pierwszy NIP w tekście, który nie jest NIP-em naszej firmy (w jednym wierszu bywają oba – sprzedawca i nabywca). */
	function docNip(s) {
		var re = /NIP\s*(?:UE|PL)?\s*[:.]?\s*(?:PL\s*)?([0-9][0-9\s\-]{8,14}[0-9])/gi, m;
		while ((m = re.exec(String(s || '')))) {
			var d = m[1].replace(/\D/g, '');
			if (d.length > 10) d = d.slice(0, 10); // „NIP 6290009999 REGON…” – sklejone cyfry
			if (d.length === 10 && !docOwnNip(d)) return d;
		}
		return '';
	}
	/* NIP dostawcy z całego tekstu: pierwszy NIP, w którego pobliżu nie ma naszej firmy. */
	function docSupplierNip(rows, party) {
		if (party && party.nip) return party.nip;
		for (var i = 0; i < rows.length; i++) {
			var n = docNip(rows[i].text);
			if (!n) continue;
			var near = rows.slice(Math.max(0, i - 4), i + 1).map(function (r) { return r.text; }).join(' ');
			if (!DOC_OWN.test(near)) return n;
		}
		return '';
	}
	/* Data dokumentu: najpierw data wydania/dostawy, potem wystawienia, na końcu pierwsza data w tekście. */
	function docDate(text) {
		var t = String(text || ''), D = '(\\d{4}[-.\\/]\\d{1,2}[-.\\/]\\d{1,2}|\\d{1,2}[-.\\/]\\d{1,2}[-.\\/]\\d{4})';
		var labels = ['data\\s+(?:wydania|dostawy|przyj[eę]cia|realizacji|dokumentu|wysy[łl]ki)', 'data\\s+(?:wystawienia|sprzeda[żz]y)', 'data'];
		for (var i = 0; i < labels.length; i++) {
			var m = t.match(new RegExp(labels[i] + '[^\\d\\n]{0,25}' + D, 'i'));
			if (m) return docIsoDate(m[1]);
		}
		return findData(t);
	}
	function docIsoDate(s) {
		var p = s.split(/[-.\/]/);
		if (p[0].length === 4) return p[0] + '-' + ('0' + p[1]).slice(-2) + '-' + ('0' + p[2]).slice(-2);
		return p[2] + '-' + ('0' + p[1]).slice(-2) + '-' + ('0' + p[0]).slice(-2);
	}
	/* Numer dokumentu WZ/PZ/FV z różnych programów: „WZ 12/2026”, „WZ/1/11/2026”, „WZ-123/26/MAG”,
	   „WZ 12/MAG/2026”, „WZ/000123/26”, „Wydanie zewnętrzne nr 12/11/2026”. */
	function docNumber(text) {
		/* OCR czyta „/” jako I, l lub | („WZI000123/26”, „26IMAG”) – naprawa tylko w numerach dokumentów */
		var t = String(text || '').replace(/\b(wz|pz|fv|fs)(?=[I|l]\d)/gi, function (m) { return m.toUpperCase(); }).replace(/\b(WZ|PZ|FV|FS)[I|l](?=\d)/g, '$1/')
			.replace(/\b((?:WZ|PZ|FV|FS)[\s\/\-]*[A-Z0-9\/\-]*?\d)[I|l](?=\d|[A-Z]{2,})/g, '$1/').replace(/\bwz(?=[\s\/\-]*\d)/g, 'WZ');
		var m = t.match(/\b((?:WZ|PZ|FV|FS|FA|WZK|WZS)(?:\s*[\/\-]\s*|\s+)(?:[A-Z]{1,6}\s*[\/\-]\s*)?\d{1,8}(?:\s*[\/\-]\s*[A-Z0-9]{1,8}){1,4})\b/);
		if (m) return m[1].replace(/\s*([\/\-])\s*/g, '$1').replace(/\s+/g, ' ').trim();
		m = t.match(/(?:wydanie\s+zewn[eę]trzne|przyj[eę]cie\s+zewn[eę]trzne|dokument\s+wz|dow[oó]d\s+wydania|faktura(?:\s+vat)?)\s*(?:nr|numer)?\.?\s*[:#]?\s*([A-Z]{0,4}[\s\/\-]*\d{1,8}(?:\s*[\/\-]\s*[A-Z0-9]{1,8}){0,4})/i);
		if (m && /\d/.test(m[1])) return m[1].replace(/\s*([\/\-])\s*/g, '$1').trim();
		return findDocNo(t);
	}

	/* ---------- jednostki i zamiana na pozycje magazynu ---------- */
	function docUnit(jm) {
		var f = fold(jm).replace(/[.\s]/g, '');
		if (!f) return '';
		if (/^(szt|sztuk|sztuki|pcs|ark|arkusz|arkusze|arkuszy|kpl|komplet|op|opak|el|elem)/.test(f) || /^s?s[zż2][tłl1]?$/.test(f) || /^[s5]z[t7]/.test(f)) return 'szt';
		if (/^(kg|kilogram)/.test(f)) return 'kg';
		if (/^(t|tona|tony|ton|mg)$/.test(f)) return 't';
		if (/^(m|mb|metr|metry|mbiez|lm)$/.test(f)) return 'm';
		if (/^(m2|mkw)$/.test(f)) return 'm2';
		return f;
	}
	/* Pozycja tabeli → linia PZ (materiał rozpoznany jak w starych parserach, ilość z kolumn). */
	function docRecToPz(rec) {
		var name = (rec.nazwa + (rec.kod && !/\d+x\d+/i.test(rec.nazwa) ? ' ' + rec.kod : '')).trim();
		var u1 = docUnit(rec.jm), u2 = docUnit(rec.jm2);
		var p = parseLine(name + ' ' + (rec.ilosc !== null ? numStr(rec.ilosc) : '') + ' ' + (u1 === 'szt' ? 'szt' : u1 === 'kg' ? 'kg' : ''));
		if (!p) return null;
		var q1 = rec.ilosc, q2 = rec.ilosc2;
		if (u1 === 't' && q1 !== null) { q1 = q1 * 1000; u1 = 'kg'; }
		var szt = u1 === 'szt' ? q1 : (u2 === 'szt' ? q2 : null), kg = u1 === 'kg' ? q1 : (u2 === 'kg' ? q2 : null);
		if (p.tabela === 'kregi') p.ilosc = kg !== null ? numStr(kg) : '';
		else if (szt !== null) p.ilosc = String(Math.round(szt));
		else if (kg !== null) { var s = kgToSzt(p.tabela, p.fields, kg); p.ilosc = s ? String(s) : ''; if (s) p.kgInfo = numStr(kg) + ' kg'; }
		else if (u1 === 'm' && p.tabela === 'stal' && pnum(p.fields.dlugosc)) p.ilosc = String(Math.max(1, Math.round(q1 / pnum(p.fields.dlugosc))));
		else if (u1 !== 'm2' && q1 !== null && q1 === Math.round(q1) && q1 > 0) p.ilosc = String(q1); // nieczytelna j.m. – liczba całkowita to zwykle sztuki
		p.raw = (rec.lp ? rec.lp + '. ' : '') + name + ' – ' + (rec.ilosc !== null ? numStr(rec.ilosc) + ' ' + (rec.jm || '') : '') + (rec.ilosc2 !== null ? ' / ' + numStr(rec.ilosc2) + ' ' + (rec.jm2 || '') : '');
		return p;
	}

	/* ---------- nauczone układy (kolumny wskazane raz dla dostawcy) ---------- */
	var OCR_LEARN = false; // 1.98.0: okno „Wskaż kolumny” jeszcze w przygotowaniu – zapamiętane układy już działają przy odczycie
	var OCR_WZORY = null;
	function ocrWzory() {
		if (OCR_WZORY) return Promise.resolve(OCR_WZORY);
		return api('/ocr-wzory', { query: { _: Date.now() } }).then(function (r) { OCR_WZORY = r.wzory || {}; return OCR_WZORY; }).catch(function () { return {}; });
	}
	function docProfileKey(nip, nazwa) {
		if (nip) return nip;
		var f = fold(nazwa).replace(/(sp\.?\s*z\s*o\.?\s*o\.?|spolka.*|s\.a\.|sp\.\s*[jk]\.?)/g, '').replace(/[^a-z0-9]+/g, ' ').trim();
		return f ? 'n:' + f.slice(0, 60) : '';
	}
	/* Tabela wg zapamiętanych kolumn: { cols: [{x (środek, 0–1000), t}] }. */
	function docTableByProfile(rows, prof) {
		var cols = prof.cols.slice().sort(function (a, b) { return a.x - b.x; }).map(function (c) { return { t: c.t, x0: c.x, x1: c.x }; });
		cols.forEach(function (c, k) { c.L = k ? (cols[k - 1].x + c.x0) / 2 : -1e9; c.R = cols[k + 1] ? (c.x1 + cols[k + 1].x0) / 2 : 1e9; });
		/* od wiersza nagłówka (jeśli jest) – inaczej od pierwszego wiersza wyglądającego na pozycję */
		var h = docFindHeader(rows), from = h ? h.last + 1 : 0;
		var fake = { last: from - 1, cols: cols };
		return docTable(rows, fake);
	}

	/* ---------- główna funkcja: geometria → wynik dla PZ ---------- */
	function docParse(geo) {
		var rows = docRows(geo), text = docText(rows);
		var party = docParty(rows), nip = docSupplierNip(rows, party);
		var res = { rows: rows, text: text, nip: nip, dostawca: party.nazwa, nr_dok: docNumber(text), data: docDate(text), recs: [], how: '' };
		var key = docProfileKey(nip, party.nazwa), prof = key && OCR_WZORY ? OCR_WZORY[key] : null;
		if (prof) { res.recs = docTableByProfile(rows, prof); res.how = 'wzor'; res.prof = prof; }
		if (!res.recs.length) { var h = docFindHeader(rows); if (h) { res.recs = docTable(rows, h); res.how = 'kolumny'; res.hdr = h; } }
		res.key = key;
		return res;
	}

	/* ---------- nauka układu: wskazanie kolumn na przykładowym wierszu ---------- */
	var DOC_ROLES = [['', '— pomiń —'], ['lp', 'Lp.'], ['kod', 'Kod / indeks'], ['nazwa', 'Nazwa'], ['ilosc', 'Ilość'], ['jm', 'J.m.'], ['ilosc2', 'Ilość (2.)'], ['jm2', 'J.m. (2.)']];
	function docLearn(geo, dostawca, done) {
		var rows = docRows(geo), d = docParse(geo), hdr = d.hdr || docFindHeader(rows);
		var key = d.key || docProfileKey('', dostawca);
		var cand = rows.map(function (r, i) { return { r: r, i: i }; }).filter(function (x) { return x.r.words.length >= 2 && /\d/.test(x.r.text) && (!hdr || x.i > hdr.last); });
		if (!cand.length) { toast('W dokumencie nie ma wierszy z danymi do wskazania.', 'err'); return; }
		var pickI = d.recs.length ? cand.filter(function (x) { return x.r.text.indexOf(d.recs[0].raw.split(' ')[0]) === 0; }).map(function (x) { return x.i; })[0] : cand[0].i;
		if (pickI === undefined) pickI = cand[0].i;
		var body = '<div class="msm-doclearn">' +
			'<p class="msm-muted">1. Kliknij wiersz z <b>jedną pozycją</b> dokumentu (np. pierwszą blachę). 2. Pod spodem przypisz każdej części wiersza kolumnę. Układ zapamięta się dla dostawcy' + (d.nip ? ' (NIP ' + esc(d.nip) + ')' : '') + ' i kolejne jego dokumenty odczytają się same.</p>' +
			'<label class="msm-field"><span>Dostawca</span><input type="text" data-dlname value="' + esc(d.dostawca || dostawca || '') + '"' + (d.nip ? '' : ' placeholder="nazwa dostawcy – wymagana, gdy na dokumencie nie ma NIP"') + '></label>' +
			'<div class="msm-doclearn__rows" data-dlrows>' + cand.slice(0, 150).map(function (x) { return '<button type="button" class="msm-doclearn__row" data-dlrow="' + x.i + '">' + esc(x.r.text) + '</button>'; }).join('') + '</div>' +
			'<h4 class="msm-wz-h">Kolumny wybranego wiersza</h4><div class="msm-doclearn__cells" data-dlcells></div>' +
			'<h4 class="msm-wz-h">Podgląd odczytu</h4><div data-dlprev></div></div>';
		var foot = (d.prof ? '<button type="button" class="msm-btn msm-btn-danger-ghost" data-dldel>Usuń zapamiętany układ</button>' : '') +
			'<button type="button" class="msm-btn" data-close>Anuluj</button><button type="button" class="msm-btn msm-btn-primary" data-dlsave disabled>Zapamiętaj układ</button>';
		var m = openModal('Układ dokumentu dostawcy', body, foot, true);
		m.querySelector('.msm-modal').classList.add('msm-doclearn-modal');
		var cellsBox = m.querySelector('[data-dlcells]'), prev = m.querySelector('[data-dlprev]'), saveB = m.querySelector('[data-dlsave]');
		var cells = [];
		function pick(i) {
			m.querySelectorAll('[data-dlrow]').forEach(function (b) { b.classList.toggle('is-on', +b.getAttribute('data-dlrow') === i); });
			var r = rows[i];
			cells = docCells(r.words, 0.9).map(function (c) {
				var cx = (c.x0 + c.x1) / 2, role = '';
				if (d.prof) { var best = null, bd = 1e9; d.prof.cols.forEach(function (pc) { var dd = Math.abs(pc.x - cx); if (dd < bd) { bd = dd; best = pc; } }); if (best && bd < 60) role = best.t; }
				else if (hdr) { hdr.cols.forEach(function (hc) { if (cx >= hc.L && cx < hc.R && DOC_ROLES.some(function (x) { return x[0] === hc.t; })) role = hc.t; }); }
				else if (/^\d{1,3}\.?$/.test(c.s) && c.x0 < 120) role = 'lp';
				return { x: Math.round(cx), s: c.s, t: role };
			});
			cellsBox.innerHTML = cells.map(function (c, k) {
				return '<label class="msm-doclearn__cell"><code>' + esc(c.s) + '</code><select data-dlrole="' + k + '">' + DOC_ROLES.map(function (o) { return '<option value="' + o[0] + '"' + (o[0] === c.t ? ' selected' : '') + '>' + o[1] + '</option>'; }).join('') + '</select></label>';
			}).join('');
			cellsBox.querySelectorAll('[data-dlrole]').forEach(function (s) { s.addEventListener('change', function () { cells[+s.getAttribute('data-dlrole')].t = s.value; preview(); }); });
			preview();
		}
		function prof() { return { cols: cells.filter(function (c) { return c.t; }).map(function (c) { return { x: c.x, t: c.t }; }) }; }
		function preview() {
			var p = prof(), types = p.cols.map(function (c) { return c.t; });
			var ok = types.indexOf('ilosc') >= 0 && (types.indexOf('nazwa') >= 0 || types.indexOf('kod') >= 0);
			saveB.disabled = !ok;
			if (!ok) { prev.innerHTML = '<p class="msm-muted">Wskaż co najmniej kolumny <b>Nazwa</b> (albo Kod) i <b>Ilość</b>.</p>'; return; }
			var recs = docTableByProfile(rows, p), mat = 0;
			prev.innerHTML = recs.length ? '<div class="msm-table-wrap"><table class="msm-table msm-doclearn__prev"><thead><tr><th>Lp.</th><th>Kod</th><th>Nazwa</th><th>Ilość</th><th>J.m.</th><th>Rozpoznano</th></tr></thead><tbody>' + recs.map(function (r) {
				var pz = docRecToPz(r); if (pz) mat++;
				return '<tr><td>' + esc(r.lp) + '</td><td>' + esc(r.kod) + '</td><td>' + esc(r.nazwa) + '</td><td>' + esc(r.ilosc !== null ? fmtNum(r.ilosc) : '') + (r.ilosc2 !== null ? ' / ' + esc(fmtNum(r.ilosc2)) : '') + '</td><td>' + esc(r.jm + (r.jm2 ? ' / ' + r.jm2 : '')) + '</td><td>' + (pz ? '<span class="msm-eltag is-ok">' + esc(S[pz.tabela] ? S[pz.tabela].label : pz.tabela) + (pz.ilosc ? ' · ' + esc(pz.ilosc) + ' ' + (pz.tabela === 'kregi' ? 'kg' : 'szt.') : '') + '</span>' : '<span class="msm-muted">nie materiał</span>') + '</td></tr>';
			}).join('') + '</tbody></table></div><p class="msm-muted msm-small">' + plN(recs.length, 'pozycja', 'pozycje', 'pozycji') + ', w tym ' + mat + ' rozpoznanych jako materiał.</p>' : '<p class="msm-muted">Z takim układem nie odczytano żadnej pozycji – sprawdź przypisanie kolumn.</p>';
		}
		m.querySelectorAll('[data-dlrow]').forEach(function (b) { b.addEventListener('click', function () { pick(+b.getAttribute('data-dlrow')); }); });
		pick(pickI);
		var on = m.querySelector('[data-dlrow].is-on'); if (on) on.scrollIntoView({ block: 'center' });
		saveB.addEventListener('click', function () {
			var name = m.querySelector('[data-dlname]').value.trim(), k = d.nip || docProfileKey('', name);
			if (!k) { toast('Podaj nazwę dostawcy.', 'err'); return; }
			saveB.disabled = true;
			api('/ocr-wzory', { method: 'POST', body: { key: k, nip: d.nip, nazwa: name, cols: prof().cols } }).then(function (r) {
				OCR_WZORY = r.wzory || {}; closeModal(); toast('Zapamiętano układ dokumentów dostawcy' + (name ? ' ' + name : '') + '.'); if (done) done();
			}).catch(function (e) { saveB.disabled = false; toast(e.message, 'err'); });
		});
		var del = m.querySelector('[data-dldel]');
		if (del) del.addEventListener('click', function () {
			api('/ocr-wzory/delete', { method: 'POST', body: { key: key } }).then(function (r) { OCR_WZORY = r.wzory || {}; closeModal(); toast('Usunięto zapamiętany układ.'); if (done) done(); }).catch(function (e) { toast(e.message, 'err'); });
		});
	}
	function msmClGroups(e) {
		var g = e && e.groups;
		if (Array.isArray(g)) return g;
		if (g && typeof g === 'object') return Object.keys(g).map(function (k) { return { type: k, items: Array.isArray(g[k]) ? g[k] : [] }; });
		return [];
	}
	/* ---------------- mój profil ---------------- */

	function renderProfile() {
		var main = document.getElementById('msm-main');
		main.innerHTML = '<section class="msm-panel msm-profile"><div class="msm-loading">Ładowanie profilu…</div></section>';
		api('/profil').then(function (p) {
			var opt = p.options.map(function (o) { return '<option' + (o === p.display_name ? ' selected' : '') + '>' + esc(o) + '</option>'; }).join('');
			main.innerHTML = '<section class="msm-panel msm-profile">' +
				'<div class="msm-profile__head"><span class="msm-avatar msm-avatar--lg">' + esc(initials(p.display_name)) + '</span>' +
				'<div><h2>Mój profil</h2><p class="msm-muted">Login: <b>' + esc(p.login) + '</b> · ' + esc(p.role) + '</p></div></div>' +
				'<form class="msm-form" novalidate><div class="msm-form-err msm-alert msm-alert-err" hidden></div>' +
				'<h3>Dane</h3><div class="msm-grid">' +
				'<label class="msm-field" data-field="first_name"><span>Imię</span><input name="first_name" type="text" autocomplete="given-name" value="' + esc(p.first_name) + '"><em class="msm-ferr"></em></label>' +
				'<label class="msm-field" data-field="last_name"><span>Nazwisko</span><input name="last_name" type="text" autocomplete="family-name" value="' + esc(p.last_name) + '"><em class="msm-ferr"></em></label>' +
				'<label class="msm-field" data-field="display_name"><span>Przedstawiaj mnie jako</span><select name="display_name">' + opt + '</select><em class="msm-ferr"></em><small class="msm-muted">Tak będziesz widoczny w historii, pobraniach i wnioskach.</small></label>' +
				'<label class="msm-field" data-field="email"><span>E-mail</span><input name="email" type="text" inputmode="email" autocomplete="email" value="' + esc(p.email) + '"><em class="msm-ferr"></em><small class="msm-muted">Na ten adres przychodzą powiadomienia.</small></label>' +
				'</div>' +
				'<h3>Zmiana hasła <span class="msm-muted msm-small">(zostaw puste, jeśli nie zmieniasz)</span></h3><div class="msm-grid">' +
				'<label class="msm-field" data-field="pass1"><span>Nowe hasło</span><input name="pass1" type="password" autocomplete="new-password" placeholder="min. 10 znaków"><em class="msm-ferr"></em></label>' +
				'<label class="msm-field" data-field="pass2"><span>Powtórz nowe hasło</span><input name="pass2" type="password" autocomplete="new-password"><em class="msm-ferr"></em></label>' +
				'</div>' +
				'<div class="msm-grid" data-current hidden><label class="msm-field" data-field="current"><span>Aktualne hasło <i class="msm-req">*</i></span><input name="current" type="password" autocomplete="current-password"><em class="msm-ferr"></em><small class="msm-muted">Wymagane przy zmianie e-maila lub hasła.</small></label></div>' +
				'<div class="msm-row"><button type="submit" class="msm-btn msm-btn-primary" data-save>Zapisz zmiany</button><a class="msm-btn msm-btn-ghost" href="#' + esc(store('tab') || 'stal') + '">Wróć do magazynu</a></div>' +
				'</form></section>';
			var form = main.querySelector('form');
			var fn = form.querySelector('[name=first_name]'), ln = form.querySelector('[name=last_name]'), dn = form.querySelector('[name=display_name]');
			var login = p.login, nick = p.nickname;
			function rebuild() {
				var f = fn.value.trim(), l = ln.value.trim(), cur = dn.value;
				var o = [nick, login];
				if (f) o.push(f);
				if (l) o.push(l);
				if (f && l) { o.push(f + ' ' + l); o.push(l + ' ' + f); }
				o.push(p.display_name);
				o = o.filter(function (x, i) { return x && o.indexOf(x) === i; });
				dn.innerHTML = o.map(function (x) { return '<option' + (x === cur ? ' selected' : '') + '>' + esc(x) + '</option>'; }).join('');
			}
			fn.addEventListener('input', rebuild);
			ln.addEventListener('input', rebuild);
			function needCurrent() {
				var need = form.querySelector('[name=email]').value.trim().toLowerCase() !== String(p.email).toLowerCase() ||
					form.querySelector('[name=pass1]').value !== '' || form.querySelector('[name=pass2]').value !== '';
				form.querySelector('[data-current]').hidden = !need;
			}
			form.querySelectorAll('[name=email],[name=pass1],[name=pass2]').forEach(function (el) { el.addEventListener('input', needCurrent); });
			form.addEventListener('submit', function (e) {
				e.preventDefault();
				var btn = form.querySelector('[data-save]');
				btn.disabled = true;
				api('/profil', { method: 'POST', body: readForm(form) }).then(function (res) {
					try { sessionStorage.setItem('msm_toast', res.message); } catch (er) {}
					location.reload();
				}).catch(function (er) { btn.disabled = false; showErrors(form, er); });
			});
		}).catch(function (e) { main.innerHTML = '<div class="msm-alert msm-alert-err">' + esc(e.message) + '</div>'; });
	}

	function initials(name) {
		return String(name || '?').split(/\s+/).filter(Boolean).slice(0, 2).map(function (w) { return w.charAt(0).toUpperCase(); }).join('');
	}

	/* ---------------- import ---------------- */

	/* ---------------- słowniki WZ (odbiorcy, przeznaczenie, transport) ---------------- */

	var ICON_STAR = '<svg class="msm-ico" width="16" height="16" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round" aria-hidden="true"><path d="m12 3 2.8 5.7 6.2.9-4.5 4.4 1.1 6.2L12 17.3 6.4 20.2l1.1-6.2L3 9.6l6.2-.9z"/></svg>';

	function renderSlownik(typ) {
		var info = SL_INFO[typ];
		var main = document.getElementById('msm-main');
		var rows = [], q = '';
		main.innerHTML =
			'<div class="msm-cat msm-sl">' +
			'<div class="msm-pagehead"><div><h1>' + esc(info.title) + '</h1><p class="msm-muted" data-count>&nbsp;</p></div>' +
			'<div class="msm-pagehead__tools"><button type="button" class="msm-btn msm-btn-primary" data-wznew>+ Nowa WZ</button></div></div>' +
			'<form class="msm-card msm-sl-add" data-add autocomplete="off">' +
			'<label class="msm-field msm-sl-add__name"><span>Dodaj ' + esc(info.one) + '</span><input name="nazwa" type="text" maxlength="255" placeholder="' + esc(info.ph) + '"></label>' +
			'<label class="msm-check"><input type="checkbox" name="domyslny"><span>Ustaw jako domyślny na nowej WZ</span></label>' +
			'<button type="submit" class="msm-btn msm-btn-primary">+ Dodaj</button></form>' +
			'<div class="msm-sl-def" data-def></div>' +
			'<div class="msm-sl-tools"><label class="msm-field msm-sl-search"><span>Szukaj na liście</span><input type="search" data-q placeholder="Wpisz fragment nazwy…"></label></div>' +
			'<div class="msm-table-wrap" data-list><div class="msm-loading">Ładowanie…</div></div>' +
			'</div>';
		main.querySelector('[data-wznew]').addEventListener('click', function () { openWZ(null); });
		var form = main.querySelector('[data-add]');
		form.addEventListener('submit', function (e) {
			e.preventDefault();
			var name = form.nazwa.value.trim();
			if (!name) { form.nazwa.focus(); toast('Wpisz nazwę.', 'err'); return; }
			api('/slowniki', { method: 'POST', body: { typ: typ, nazwa: name, domyslny: form.domyslny.checked } }).then(function (r) {
				form.reset(); toast('Dodano: „' + name + '”.'); show(r.all); form.nazwa.focus();
			}).catch(function (e2) { toast(e2.message, 'err'); });
		});
		main.querySelector('[data-q]').addEventListener('input', function (e) { q = e.target.value.trim().toLowerCase(); draw(); });

		function show(all) { rows = (all && all[typ]) || []; draw(); }
		function load() { api('/slowniki').then(function (r) { show(r.all); }).catch(function (e) { toast(e.message, 'err'); }); }

		function draw() {
			if (current !== Object.keys(SL_TYPES).filter(function (k) { return SL_TYPES[k] === typ; })[0]) return;
			var def = rows.filter(function (r) { return r.domyslny; })[0];
			main.querySelector('[data-count]').textContent = rows.length + ' ' + plural(rows.length, 'pozycja', 'pozycje', 'pozycji') + ' na liście';
			main.querySelector('[data-def]').innerHTML = def
				? '<span class="msm-sl-def__star">' + ICON_STAR + '</span><span>Domyślnie na nowej WZ: <b>' + esc(def.nazwa) + '</b></span><button type="button" class="msm-btn msm-btn-ghost msm-btn-sm" data-undef="' + def.id + '">Wyłącz domyślną</button>'
				: '<span class="msm-muted">Brak pozycji domyślnej – pole w nowej WZ będzie puste. Kliknij gwiazdkę przy pozycji, aby ją ustawić.</span>';
			var list = rows.filter(function (r) { return !q || r.nazwa.toLowerCase().indexOf(q) >= 0; });
			var wrap = main.querySelector('[data-list]');
			if (!list.length) {
				wrap.innerHTML = '<div class="msm-empty">' + (rows.length ? 'Brak pozycji pasujących do wyszukiwania.' : 'Lista jest pusta – dodaj pierwszą pozycję powyżej.') + '</div>';
			} else {
				wrap.innerHTML = '<table class="msm-table msm-sl-table"><thead><tr><th class="msm-sl-c-def">Domyślna</th><th>Nazwa</th><th class="num msm-sl-c-use">Użyto na WZ</th><th class="msm-sl-c-act"></th></tr></thead><tbody>' +
					list.map(function (r) {
						return '<tr data-id="' + r.id + '"' + (r.domyslny ? ' class="is-default"' : '') + '>' +
							'<td class="msm-sl-c-def" data-label="Domyślna"><button type="button" class="msm-star' + (r.domyslny ? ' on' : '') + '" data-star aria-pressed="' + (r.domyslny ? 'true' : 'false') + '" title="' + (r.domyslny ? 'Pozycja domyślna – kliknij, aby wyłączyć' : 'Ustaw jako domyślną na nowej WZ') + '">' + ICON_STAR + '</button></td>' +
							'<td data-label="Nazwa" class="msm-sl-name">' + esc(r.nazwa) + (r.domyslny ? ' <span class="msm-tag msm-tag-ok">domyślna</span>' : '') + '</td>' +
							'<td class="num msm-sl-c-use" data-label="Użyto na WZ">' + (r.uzyto || '–') + '</td>' +
							'<td class="msm-act msm-sl-c-act">' +
							'<button type="button" class="msm-iconbtn" data-edit title="Edytuj">' + ICON_EDIT + '</button>' +
							'<button type="button" class="msm-iconbtn msm-iconbtn-danger" data-del title="Usuń">' + ICON_DEL + '</button></td></tr>';
					}).join('') + '</tbody></table>';
			}
			var ud = main.querySelector('[data-undef]');
			if (ud) ud.addEventListener('click', function () { setDef(+ud.getAttribute('data-undef'), false); });
			wrap.querySelectorAll('tr[data-id]').forEach(function (tr) {
				var id = +tr.getAttribute('data-id');
				var r = rows.filter(function (x) { return x.id === id; })[0];
				tr.querySelector('[data-star]').addEventListener('click', function () { setDef(id, !r.domyslny); });
				tr.querySelector('[data-edit]').addEventListener('click', function () { edit(r); });
				tr.querySelector('[data-del]').addEventListener('click', function () {
					confirmBox('Usunąć pozycję?', 'Pozycja „' + esc(r.nazwa) + '” zniknie z listy podpowiedzi. Wystawione WZ pozostaną bez zmian.', 'Usuń', true).then(function (ok) {
						if (!ok) return;
						api('/slowniki/' + id, { method: 'DELETE' }).then(function (res) { toast('Usunięto.'); show(res.all); }).catch(function (e) { toast(e.message, 'err'); });
					});
				});
			});
		}

		function setDef(id, on) {
			api('/slowniki/' + id, { method: 'POST', body: { domyslny: on } }).then(function (r) {
				toast(on ? 'Ustawiono pozycję domyślną dla nowej WZ.' : 'Wyłączono pozycję domyślną.'); show(r.all);
			}).catch(function (e) { toast(e.message, 'err'); });
		}

		function edit(r) {
			var m = openModal('Edytuj: ' + info.title,
				'<form data-f autocomplete="off"><label class="msm-field"><span>Nazwa</span><input name="nazwa" type="text" maxlength="255" value="' + esc(r.nazwa) + '"></label>' +
				'<label class="msm-check"><input type="checkbox" name="domyslny"' + (r.domyslny ? ' checked' : '') + '><span>Domyślna na nowej WZ</span></label>' +
				(r.uzyto ? '<p class="msm-muted msm-small">Zmiana nazwy nie zmienia już zapisanych WZ (' + r.uzyto + ').</p>' : '') + '</form>',
				'<button type="button" class="msm-btn" data-close>Anuluj</button><button type="button" class="msm-btn msm-btn-primary" data-save>Zapisz</button>');
			var f = m.querySelector('[data-f]');
			function save() {
				api('/slowniki/' + r.id, { method: 'POST', body: { nazwa: f.nazwa.value, domyslny: f.domyslny.checked } }).then(function (res) {
					closeModal(); toast('Zapisano.'); show(res.all);
				}).catch(function (e) { toast(e.message, 'err'); });
			}
			m.querySelector('[data-save]').addEventListener('click', save);
			f.addEventListener('submit', function (e) { e.preventDefault(); save(); });
		}

		load();
	}

	/* Import z Excela – osobna strona (#import, gdy brak dostępu do Kopii danych) albo sekcja w „Kopia danych”. */
	function renderImport() {
		if (mOn('kopia') && C.canEdit) { try { sessionStorage.setItem('msm_goimp', 'import'); } catch (e) {} location.hash = '#kopia'; return; }
		var main = document.getElementById('msm-main');
		main.innerHTML = '<div class="msm-cat"><div data-imp></div></div>';
		importPanel(main.querySelector('[data-imp]'));
	}
	function importPanel(main) {
		main.innerHTML = '<section class="msm-card msm-kopia-imp" id="msm-import">' +
			'<h3 class="msm-wz-h">Import z Excela</h3>' +
			'<p class="msm-muted">Wgraj plik .xlsx z zestawieniem. Arkusze są rozpoznawane po nagłówkach kolumn (Stal: „Opis… Długość mb”, Blachy pełne: „Gatunek, Grubość, Wymiar, Materiał”, Blachy niepełne: „Wymiar A, Wymiar B”, Kręgi: „Oznaczenie blachy”). ' +
			'Pasują też pliki wyeksportowane z tej aplikacji. Nazwy są automatycznie ujednolicane, a kg/m i sumy przeliczane.</p>' +
			'<form class="msm-form msm-import" novalidate>' +
			'<label class="msm-file"><input type="file" name="file" accept=".xlsx"><span>Wybierz plik .xlsx…</span></label>' +
			'<div class="msm-seg"><label><input type="radio" name="mode" value="append" checked> Dopisz do istniejących</label>' +
			'<label><input type="radio" name="mode" value="replace"> Zastąp (usuń dotychczasowe pozycje w rozpoznanych magazynach)</label></div>' +
			'<div class="msm-row"><button type="button" class="msm-btn" data-dry>Sprawdź plik</button><button type="button" class="msm-btn msm-btn-primary" data-run disabled>Importuj</button></div>' +
			'</form><div data-report></div></section>';
		var form = main.querySelector('form');
		var file = form.querySelector('[name=file]');
		var runBtn = form.querySelector('[data-run]');
		file.addEventListener('change', function () {
			form.querySelector('.msm-file span').textContent = file.files[0] ? file.files[0].name : 'Wybierz plik .xlsx…';
			runBtn.disabled = true;
			main.querySelector('[data-report]').innerHTML = '';
		});
		function send(dry) {
			if (!file.files[0]) { toast('Wybierz plik.', 'warn'); return; }
			var mode = form.querySelector('[name=mode]:checked').value;
			var go = function () {
				var fd = new FormData();
				fd.append('file', file.files[0]);
				fd.append('mode', mode);
				if (dry) fd.append('dry', '1');
				var rep = main.querySelector('[data-report]');
				rep.innerHTML = '<div class="msm-loading">' + (dry ? 'Analizuję plik…' : 'Importuję…') + '</div>';
				api('/import', { method: 'POST', form: fd }).then(function (res) {
					rep.innerHTML = reportHtml(res);
					if (dry) runBtn.disabled = !res.sheets.some(function (s) { return s.count > 0; });
					else {
						runBtn.disabled = true;
						toast('Import zakończony.');
						STOCK.forEach(invalidate);
					}
				}).catch(function (e) { rep.innerHTML = '<div class="msm-alert msm-alert-err">' + esc(e.message) + '</div>'; });
			};
			if (!dry && mode === 'replace') {
				confirmBox('Zastąpić dane?', 'Dotychczasowe pozycje w magazynach rozpoznanych w pliku zostaną <b>usunięte</b> i zastąpione danymi z pliku. Historia pobrań zostanie zachowana.', 'Zastąp', true).then(function (ok) { if (ok) go(); });
			} else go();
		}
		form.querySelector('[data-dry]').addEventListener('click', function () { send(true); });
		runBtn.addEventListener('click', function () { send(false); });
	}

	function reportHtml(res) {
		var html = '<h3>' + (res.dry ? 'Wynik sprawdzenia' : 'Wynik importu') + '</h3><table class="msm-table"><thead><tr><th>Arkusz</th><th>Magazyn</th><th class="num">Wierszy do importu</th><th class="num">Pominięte</th><th>Uwagi</th></tr></thead><tbody>';
		res.sheets.forEach(function (s) {
			html += '<tr><td>' + esc(s.sheet) + '</td><td>' + esc(s.label || '—') + '</td><td class="num">' + (s.table ? s.count : '') + '</td><td class="num">' + (s.skipped || '') + '</td><td>' + esc(s.note || '') +
				(s.errors && s.errors.length ? '<details><summary>Błędy (' + s.errors.length + ')</summary><ul>' + s.errors.map(function (e) { return '<li>' + esc(e) + '</li>'; }).join('') + '</ul></details>' : '') + '</td></tr>';
		});
		html += '</tbody></table>';
		if (!res.dry && res.summary) {
			html += '<ul class="msm-summary">' + Object.keys(res.summary).map(function (k) {
				var x = res.summary[k];
				return '<li><b>' + esc(S[k].label) + '</b>: dodano ' + x.added + (x.removed ? ', usunięto ' + x.removed : '') + ' – <a href="#' + k + '">pokaż</a></li>';
			}).join('') + '</ul>';
		} else if (res.dry) {
			html += '<p class="msm-muted">Nic jeszcze nie zapisano. Kliknij „Importuj”, aby zapisać dane.</p>';
		}
		return html;
	}

	function renderLogowania() {
		var main = document.getElementById('msm-main');
		main.innerHTML = '<div class="msm-cat"><div class="msm-pagehead"><div><h1>Dziennik logowań</h1><p class="msm-muted">Kto i kiedy logował się do magazynu</p></div></div>' +
			'<div class="msm-table-wrap" data-log><div class="msm-loading">Ładowanie…</div></div></div>';
		var box = main.querySelector('[data-log]');
		api('/logins').then(function (rows) {
			if (!rows.length) { box.innerHTML = '<div class="msm-card msm-empty"><p class="msm-muted">Brak wpisów.</p></div>'; return; }
			box.innerHTML = '<table class="msm-table"><thead><tr><th>Kiedy</th><th>Użytkownik</th><th>Login</th><th>IP</th><th>Wynik</th></tr></thead><tbody>' +
				rows.map(function (r) {
					var ok = r.wynik === 'ok';
					return '<tr><td data-label="Kiedy">' + esc(fmtDateTime(r.czas)) + '</td><td data-label="Użytkownik">' + esc(r.display_name || '') + '</td><td data-label="Login">' + esc(r.user_login || '') + '</td><td data-label="IP">' + esc(r.ip || '') + '</td>' +
						'<td data-label="Wynik"><span class="msm-tag ' + (ok ? 'msm-tag-ok' : 'msm-tag-no') + '">' + (ok ? 'zalogowano' : 'błędne hasło') + '</span></td></tr>';
				}).join('') + '</tbody></table>';
		}).catch(function (e) { box.innerHTML = '<p class="msm-alert msm-alert-err">' + esc(e.message) + '</p>'; });
	}
	function fmtDateTime(v) {
		if (!v) return '';
		var s = String(v).replace(' ', 'T'), d = new Date(s);
		return isNaN(d) ? v : d.toLocaleString('pl-PL', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });
	}

	/* ---------- Zarządzanie użytkownikami ---------- */
	function renderUsers() {
		var main = document.getElementById('msm-main');
		main.innerHTML = '<div class="msm-cat"><div class="msm-pagehead"><div><h1>Użytkownicy</h1><p class="msm-muted">Konta magazynu, hasła i uprawnienia (bez wchodzenia do WordPressa)</p></div>' +
			'<div class="msm-pagehead__tools"><button type="button" class="msm-btn msm-btn-primary" data-newuser>+ Dodaj użytkownika</button></div></div>' +
			'<div data-users><div class="msm-loading">Ładowanie…</div></div></div>';
		var box = main.querySelector('[data-users]');
		function load() {
			api('/users').then(function (d) {
				USR = d;
				box.innerHTML = d.users.map(function (u) {
					return '<div class="msm-user-card"><div class="msm-user-card__i"><b>' + esc(u.display_name) + '</b>' +
						'<span class="msm-tag ' + (u.role === 'msm_admin' ? 'msm-tag-ok' : 'msm-tag-no') + '">' + esc(d.roles[u.role]) + '</span>' +
						(u.self ? '<span class="msm-muted msm-small">(to Ty)</span>' : '') +
						'<small class="msm-muted">login: ' + esc(u.login) + (u.email ? ' · ' + esc(u.email) : '') + '</small></div>' +
						'<div class="msm-user-card__a">' +
						(u.manage === false ? '<span class="msm-muted msm-small" title="To konto ma uprawnienia, których Ty nie masz">tylko administrator WP</span>' :
						'<button type="button" class="msm-btn msm-btn-sm" data-uperm="' + u.id + '">' + (u.self && !d.wp_admin ? 'Dane konta' : 'Uprawnienia') + '</button>' +
						'<button type="button" class="msm-btn msm-btn-sm" data-upass="' + u.id + '">Reset hasła</button>' +
						(u.self ? '' : '<button type="button" class="msm-btn msm-btn-sm msm-btn-danger-ghost" data-udel="' + u.id + '">Usuń</button>')) +
						'</div></div>';
				}).join('');
				box.querySelectorAll('[data-uperm]').forEach(function (b) { b.addEventListener('click', function () { editUser(find(+b.getAttribute('data-uperm'))); }); });
				box.querySelectorAll('[data-upass]').forEach(function (b) { b.addEventListener('click', function () { resetPass(find(+b.getAttribute('data-upass'))); }); });
				box.querySelectorAll('[data-udel]').forEach(function (b) { b.addEventListener('click', function () { delUser(find(+b.getAttribute('data-udel'))); }); });
			}).catch(function (e) { box.innerHTML = '<p class="msm-alert msm-alert-err">' + esc(e.message) + '</p>'; });
		}
		var USR = null;
		function find(id) { return USR.users.filter(function (u) { return u.id === id; })[0]; }
		main.querySelector('[data-newuser]').addEventListener('click', function () { newUser(); });

		function permsFields(u, locked) {
			var p = u ? u.perms : { menu: {}, caps: {} };
			var dis = locked ? ' disabled' : '';
			function on(k) { return !u || p.menu[k] !== false; }
			function cb(k, l, child) {
				return '<label class="msm-check' + (child ? ' msm-perm-child' : '') + '"><input type="checkbox" data-mk="' + k + '"' + (on(k) ? ' checked' : '') + dis + '> ' + esc(l) + '</label>';
			}
			/* Menu jak w aplikacji: grupy, pozycje i ich podpozycje (wyłączenie sekcji ukrywa jej podpozycje). */
			var menu = (USR.menu_tree || []).map(function (g) {
				return '<div class="msm-perm-grp"><div class="msm-perm-grp__t">' + esc(g.group) + '</div>' + g.items.map(function (it) {
					return '<div class="msm-perm-item" data-mparent="' + it.k + '">' + cb(it.k, it.l, false) +
						(it.children.length ? '<div class="msm-perm-children">' + it.children.map(function (c) { return cb(c.k, c.l, true); }).join('') + '</div>' : '') + '</div>';
				}).join('') + '</div>';
			}).join('');
			var caps = Object.keys(USR.cap_keys).map(function (k) {
				var onc = u ? p.caps[k] !== false : false;
				return '<label class="msm-check"><input type="checkbox" data-ck="' + k + '"' + (onc ? ' checked' : '') + dis + '> ' + esc(USR.cap_keys[k]) + '</label>';
			}).join('');
			return (locked ? '<p class="msm-alert msm-small">Własnej roli i uprawnień nie zmieniasz sam – poproś innego administratora.</p>' : '') +
				'<div class="msm-perm-cols"><div><h4>Widoczne w menu <span class="msm-perm-all"><button type="button" class="msm-link" data-mall="1"' + dis + '>zaznacz wszystko</button> · <button type="button" class="msm-link" data-mall="0"' + dis + '>odznacz</button></span></h4>' + menu + '</div>' +
				'<div><h4>Dozwolone akcje</h4>' + caps + '</div></div>';
		}
		/* Podpozycje wyszarzone, gdy sekcja nadrzędna jest wyłączona. */
		function bindPerms(form) {
			function sync() {
				form.querySelectorAll('[data-mparent]').forEach(function (it) {
					var parent = it.querySelector(':scope > label input[data-mk]');
					it.querySelectorAll('.msm-perm-children input').forEach(function (c) { c.closest('label').classList.toggle('is-off', !parent.checked); });
				});
			}
			form.addEventListener('change', function (e) { if (e.target.matches('[data-mk]')) sync(); });
			form.querySelectorAll('[data-mall]').forEach(function (b) {
				b.addEventListener('click', function () { var v = b.getAttribute('data-mall') === '1'; form.querySelectorAll('[data-mk]').forEach(function (c) { if (!c.disabled) c.checked = v; }); sync(); });
			});
			sync();
		}
		function collectPerms(form) {
			var out = { menu: {}, caps: {} };
			form.querySelectorAll('[data-mk]').forEach(function (c) { out.menu[c.getAttribute('data-mk')] = c.checked; });
			form.querySelectorAll('[data-ck]').forEach(function (c) { out.caps[c.getAttribute('data-ck')] = c.checked; });
			return out;
		}
		function minPass() { return (USR && USR.min_pass) || 10; }
		function passField(label, full) {
			return '<label class="msm-field' + (full ? ' full' : '') + '" data-field="password"><span>' + label + ' <i class="msm-req">*</i></span>' +
				'<span class="msm-pass"><input name="password" type="text" autocomplete="new-password" spellcheck="false" placeholder="min. ' + minPass() + ' znaków">' +
				'<button type="button" class="msm-btn msm-btn-sm" data-genpass title="Wygeneruj bezpieczne hasło">Wygeneruj</button></span><em class="msm-ferr"></em></label>';
		}
		/* Hasło łatwe do przepisania z kartki: bez znaków mylących (0/O, 1/l/I). */
		function genPass() {
			var a = 'abcdefghjkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789', n = 12, out = '', buf = new Uint32Array(n);
			(window.crypto || window.msCrypto).getRandomValues(buf);
			for (var i = 0; i < n; i++) out += a[buf[i] % a.length];
			return out.slice(0, 4) + '-' + out.slice(4, 8) + '-' + out.slice(8);
		}
		function bindGen(form) {
			var b = form.querySelector('[data-genpass]');
			if (b) b.addEventListener('click', function () { form.password.value = genPass(); form.password.focus(); form.password.select(); });
		}
		function roleSel(val, locked) {
			return '<label class="msm-field"><span>Rola</span><select name="role"' + (locked ? ' disabled' : '') + '>' + Object.keys(USR.roles).map(function (r) { return '<option value="' + r + '"' + (r === val ? ' selected' : '') + '>' + esc(USR.roles[r]) + '</option>'; }).join('') + '</select></label>';
		}

		function editUser(u) {
			var locked = u.self && !USR.wp_admin;
			var body = '<form class="msm-form" novalidate><div class="msm-form-err msm-alert msm-alert-err" hidden></div>' +
				'<div class="msm-grid"><label class="msm-field"><span>Nazwa wyświetlana</span><input type="text" name="display_name" value="' + esc(u.display_name) + '"></label>' +
				'<label class="msm-field"><span>E-mail</span><input name="email" type="email" value="' + esc(u.email) + '"><em class="msm-ferr"></em></label>' +
				roleSel(u.role, locked) + '</div>' +
				'<p class="msm-muted msm-small">Rola ustawia zestaw domyślny; poniżej możesz indywidualnie włączać/wyłączać. Nie dasz nikomu uprawnień, których sam nie masz.</p>' +
				permsFields(u, locked) + '</form>';
			var m = openModal('Uprawnienia – ' + esc(u.display_name), body, '<button type="button" class="msm-btn" data-close>Anuluj</button><button type="button" class="msm-btn msm-btn-primary" data-save>Zapisz</button>', true);
			var form = m.querySelector('form'); bindPerms(form);
			m.querySelector('[data-save]').addEventListener('click', function () {
				var btn = this; btn.disabled = true;
				var payload = { display_name: form.display_name.value, email: form.email.value };
				if (!locked) { payload.role = form.role.value; payload.perms = collectPerms(form); }
				api('/users/' + u.id, { method: 'POST', body: payload })
					.then(function (r) { closeModal(); toast(r.message); load(); }).catch(function (e) { btn.disabled = false; showErrors(form, e); });
			});
		}
		function newUser() {
			var body = '<form class="msm-form" novalidate><div class="msm-form-err msm-alert msm-alert-err" hidden></div>' +
				'<div class="msm-grid"><label class="msm-field" data-field="login"><span>Login <i class="msm-req">*</i></span><input type="text" name="login" autocomplete="off"><em class="msm-ferr"></em></label>' +
				'<label class="msm-field"><span>Nazwa wyświetlana</span><input type="text" name="display_name" autocomplete="off"></label>' +
				'<label class="msm-field" data-field="email"><span>E-mail</span><input name="email" type="email" autocomplete="off"><em class="msm-ferr"></em></label>' +
				passField('Hasło', false) +
				roleSel('msm_viewer') + '</div>' + permsFields(null) + '</form>';
			var m = openModal('Nowy użytkownik', body, '<button type="button" class="msm-btn" data-close>Anuluj</button><button type="button" class="msm-btn msm-btn-primary" data-save>Dodaj konto</button>', true);
			var form = m.querySelector('form'); bindPerms(form); bindGen(form);
			m.querySelector('[data-save]').addEventListener('click', function () {
				var btn = this; btn.disabled = true;
				api('/users', { method: 'POST', body: { login: form.login.value, display_name: form.display_name.value, email: form.email.value, password: form.password.value, role: form.role.value, perms: collectPerms(form) } })
					.then(function (r) { closeModal(); toast(r.message); load(); }).catch(function (e) { btn.disabled = false; showErrors(form, e); });
			});
		}
		function resetPass(u) {
			var body = '<form class="msm-form" novalidate><div class="msm-form-err msm-alert msm-alert-err" hidden></div>' +
				'<p class="msm-muted">Nowe hasło dla konta <b>' + esc(u.login) + '</b>.</p>' +
				'<div class="msm-grid">' + passField('Nowe hasło', true) + '</div></form>';
			var m = openModal('Reset hasła', body, '<button type="button" class="msm-btn" data-close>Anuluj</button><button type="button" class="msm-btn msm-btn-primary" data-save>Zmień hasło</button>', false);
			var form = m.querySelector('form'); bindGen(form);
			m.querySelector('[data-save]').addEventListener('click', function () {
				var btn = this; btn.disabled = true;
				api('/users/' + u.id + '/password', { method: 'POST', body: { password: form.password.value } })
					.then(function (r) { closeModal(); toast(r.message); if (r.relogin) setTimeout(function () { location.reload(); }, 1800); }).catch(function (e) { btn.disabled = false; showErrors(form, e); });
			});
		}
		function delUser(u) {
			confirmBox('Usunąć konto „' + u.login + '”?', 'Konto zostanie trwale usunięte z WordPressa. Tej operacji nie można cofnąć.', 'Usuń konto').then(function (ok) {
				if (!ok) return;
				api('/users/' + u.id + '/delete', { method: 'POST' }).then(function (r) { toast(r.message); load(); }).catch(function (e) { toast(e.message, 'err'); });
			});
		}
		load();
	}

	/* ---------- Historia wersji (zmiany obu wtyczek) ---------- */
	var CL_TYPES = { nowe: 'Nowe', zmiany: 'Zmiany', poprawki: 'Poprawki', bezpieczenstwo: 'Bezpieczeństwo' };
	var CL_PLUGINS = { magazyn: 'System K-ERP', ocr: 'Magazyn OCR', grafik: 'Magazyn grafik' };
	function renderZmiany() {
		var main = document.getElementById('msm-main');
		main.innerHTML = '<div class="msm-cat"><div class="msm-pagehead"><div><h1>Historia wersji</h1><p class="msm-muted">Co zmieniało się w systemie – od pierwszej wersji do obecnej</p></div></div>' +
			'<div data-cl><div class="msm-loading">Ładowanie…</div></div></div>';
		var box = main.querySelector('[data-cl]');
		try { localStorage.setItem('msm_seen_ver', C.version); } catch (e) {}
		root.querySelectorAll('[data-newver]').forEach(function (el) { el.hidden = true; });

		/* Data z godziną, gdy jest znana (np. 2026-11-20 16:32:05 → 20.11.2026, 16:32). */
		function fmtD(d) {
			if (!d) return '';
			var p = String(d).slice(0, 10).split('-'), t = String(d).slice(11, 16);
			return (p.length === 3 ? p[2] + '.' + p[1] + '.' + p[0] : d) + (/^\d\d:\d\d$/.test(t) ? ', ' + t : '');
		}
		api('/changelog').then(function (d) {
			/* Data instalacji wersji na tym serwerze (z automatycznego rejestru). */
			var inst = {};
			d.installs.forEach(function (r) { var k = r.plugin + '@' + r.version; if (!inst[k]) inst[k] = r.at; });
			var state = { plugin: '', q: '', page: 1, pp: 20 };
			try { var spp = +localStorage.getItem('msm_cl_pp'); if ([10, 20, 50, 0].indexOf(spp) >= 0 && localStorage.getItem('msm_cl_pp') !== null) state.pp = spp; } catch (e) {}

			var stats = '<div class="msm-cl-stats">' +
				'<div class="msm-cl-stat"><span>System K-ERP</span><b>' + esc(d.installed.magazyn) + '</b></div>' +
				'<div class="msm-cl-stat"><span>Magazyn OCR</span><b>' + (d.installed.ocr ? esc(d.installed.ocr) : '<em>nie zainstalowano</em>') + '</b></div>' +
				'<div class="msm-cl-stat"><span>Magazyn grafik</span><b>' + (d.installed.grafik ? esc(d.installed.grafik) : '<em>nie zainstalowano</em>') + '</b></div>' +
				(d.tech ? '<div class="msm-cl-stat"><span>Baza danych</span><b>' + esc(d.tech.db) + '</b></div>' +
					'<div class="msm-cl-stat"><span>WordPress · PHP</span><b>' + esc(d.tech.wordpress) + ' · ' + esc(d.tech.php) + '</b></div>' : '') +
				'</div>';
			var bar = '<div class="msm-cl-bar"><div class="msm-cl-chips" role="tablist">' +
				[['', 'Wszystko'], ['magazyn', 'System K-ERP'], ['ocr', 'OCR'], ['grafik', 'Grafik']].map(function (c, i) {
					return '<button type="button" class="msm-cl-chip' + (i ? '' : ' is-on') + '" data-clp="' + c[0] + '">' + c[1] + '</button>';
				}).join('') + '</div>' +
				'<input type="search" class="msm-cl-q" data-clq placeholder="Szukaj w zmianach, np. WZ, OCR, hasło"></div>';
			var installs = d.installs.length ? '<details class="msm-card msm-cl-inst"><summary>Instalacje na tym serwerze <span class="msm-count">' + d.installs.length + '</span></summary><ul>' +
				d.installs.map(function (r) {
					return '<li><b>' + esc(CL_PLUGINS[r.plugin] || r.plugin) + ' ' + esc(r.version) + '</b><span class="msm-muted">' + (r.from ? 'z ' + esc(r.from) + ' · ' : 'pierwsza rejestracja · ') + esc(fmtDateTime(r.at)) + '</span></li>';
				}).join('') + '</ul><p class="msm-muted msm-small">Rejestr prowadzony automatycznie od wersji 1.65.4.</p></details>' : '';
			box.innerHTML = stats + bar + '<ol class="msm-cl-list" data-cllist></ol><div class="msm-cl-foot" data-clfoot></div>' + installs;
			var list = box.querySelector('[data-cllist]'), foot = box.querySelector('[data-clfoot]');
			/* Stronicowanie: liczba wersji na stronie (zapamiętana), ‹ strona / stron ›. */
			function pager(total) {
				var pages = state.pp ? Math.max(1, Math.ceil(total / state.pp)) : 1;
				state.page = Math.min(Math.max(1, state.page), pages);
				var from = state.pp ? (state.page - 1) * state.pp : 0, to = state.pp ? Math.min(total, from + state.pp) : total;
				foot.innerHTML = total ? '<span class="msm-muted">Wersje <b>' + (from + 1) + '–' + to + '</b> z ' + total + '</span>' +
					'<div class="msm-pager"><select data-clpp aria-label="Wersji na stronie">' + [10, 20, 50, 0].map(function (n) {
						return '<option value="' + n + '"' + (state.pp === n ? ' selected' : '') + '>' + (n ? n + ' / str.' : 'wszystkie') + '</option>';
					}).join('') + '</select>' +
					(pages > 1 ? '<button type="button" class="msm-btn msm-btn-sm" data-clpg="first"' + (state.page <= 1 ? ' disabled' : '') + ' aria-label="Pierwsza strona">«</button>' +
						'<button type="button" class="msm-btn msm-btn-sm" data-clpg="-1"' + (state.page <= 1 ? ' disabled' : '') + ' aria-label="Poprzednia strona">‹</button>' +
						'<span>' + state.page + ' / ' + pages + '</span>' +
						'<button type="button" class="msm-btn msm-btn-sm" data-clpg="1"' + (state.page >= pages ? ' disabled' : '') + ' aria-label="Następna strona">›</button>' +
						'<button type="button" class="msm-btn msm-btn-sm" data-clpg="last"' + (state.page >= pages ? ' disabled' : '') + ' aria-label="Ostatnia strona">»</button>' : '') +
					'</div>' : '';
				var sel = foot.querySelector('[data-clpp]');
				if (sel) sel.addEventListener('change', function () { state.pp = +sel.value; state.page = 1; try { localStorage.setItem('msm_cl_pp', String(state.pp)); } catch (e) {} draw(); });
				foot.querySelectorAll('[data-clpg]').forEach(function (b) {
					b.addEventListener('click', function () {
						var v = b.getAttribute('data-clpg');
						state.page = v === 'first' ? 1 : v === 'last' ? pages : state.page + (+v);
						draw();
						list.scrollIntoView({ behavior: 'smooth', block: 'start' });
					});
				});
				return [from, to];
			}

			function draw() {
				var q = state.q.toLowerCase();
				var rows = d.entries.filter(function (e) {
					if (state.plugin && e.plugin !== state.plugin) return false;
					if (!q) return true;
					var txt = [e.version, e.title, e.note || ''].concat(msmClGroups(e).reduce(function (a, g) { return a.concat(g.items); }, [])).join(' ').toLowerCase();
					return txt.indexOf(q) >= 0;
				});
				if (!rows.length) { list.innerHTML = '<li class="msm-cl-empty msm-muted">Brak zmian pasujących do wyszukiwania.</li>'; pager(0); return; }
				var rg = pager(rows.length);
				list.innerHTML = rows.slice(rg[0], rg[1]).map(function (e) {
					var cur = d.installed[e.plugin] === e.version;
					var at = inst[e.plugin + '@' + e.version];
					var date = at ? 'zainstalowano ' + fmtD(at) : (e.date ? fmtD(e.date) : '');
					var groups = msmClGroups(e).map(function (g) {
						var items = g.items.filter(function (it) { return !q || it.toLowerCase().indexOf(q) >= 0 || (e.title + e.version).toLowerCase().indexOf(q) >= 0; });
						if (!items.length) return '';
						return '<div class="msm-cl-g"><span class="msm-cl-type is-' + esc(g.type) + '">' + esc(CL_TYPES[g.type] || g.type) + '</span><ul>' +
							items.map(function (it) { return '<li>' + esc(it) + '</li>'; }).join('') + '</ul></div>';
					}).join('');
					return '<li class="msm-cl-item' + (e.gap ? ' is-gap' : '') + (cur ? ' is-current' : '') + '">' +
						'<div class="msm-cl-head"><span class="msm-cl-ver">' + esc(e.version) + '</span>' +
						(state.plugin ? '' : '<span class="msm-cl-plugin">' + esc(CL_PLUGINS[e.plugin] || e.plugin) + '</span>') +
						(cur ? '<span class="msm-tag msm-tag-ok">zainstalowana</span>' : '') +
						(date ? '<span class="msm-cl-date">' + esc(date) + '</span>' : '') + '</div>' +
						'<h3 class="msm-cl-title">' + esc(e.title) + '</h3>' +
						(e.note ? '<p class="msm-cl-note">' + esc(e.note) + '</p>' : '') + groups + '</li>';
				}).join('');
			}
			box.querySelectorAll('[data-clp]').forEach(function (b) {
				b.addEventListener('click', function () {
					state.plugin = b.getAttribute('data-clp'); state.page = 1;
					box.querySelectorAll('[data-clp]').forEach(function (x) { x.classList.toggle('is-on', x === b); });
					draw();
				});
			});
			var qi = box.querySelector('[data-clq]'), qt;
			qi.addEventListener('input', function () { clearTimeout(qt); qt = setTimeout(function () { state.q = qi.value.trim(); state.page = 1; draw(); }, 150); });
			draw();
		}).catch(function (e) { box.innerHTML = '<p class="msm-alert msm-alert-err">' + esc(e.message) + '</p>'; });
	}

	/* Po aktualizacji: jednorazowy komunikat + kropka „nowe” przy „Historia wersji”. */
	function clAnnounce() {
		var seen = null;
		try { seen = localStorage.getItem('msm_seen_ver'); } catch (e) { return; }
		if (!C.version || seen === C.version) return;
		if (!seen) { try { localStorage.setItem('msm_seen_ver', C.version); } catch (e) {} return; } /* pierwsze uruchomienie – bez komunikatu */
		root.querySelectorAll('a[href="#zmiany"]').forEach(function (a) {
			if (!a.querySelector('[data-newver]')) a.insertAdjacentHTML('beforeend', '<span class="msm-count is-hot" data-newver>nowe</span>');
		});
		setTimeout(function () { toast('System zaktualizowany do wersji ' + C.version + ' – zobacz „Techniczne → Historia wersji”.'); }, 1200);
	}

	/* ---------- Ustawienia systemu (dane firmy, super administratorzy, powiadomienia) ---------- */
	/*
	 * Edytor listy „po jednym”: pozycje jako plakietki z ×, pole + „Dodaj” (Enter dodaje; wklejenie kilku linii / po przecinku dodaje wszystkie).
	 * o: { items, placeholder, suggest: [{v, label}], label(v), locked: [v], sort, sep (RegExp do wklejania), check(v) → błąd|'' , onChange }
	 */
	function chipEditor(el, o) {
		var items = (o.items || []).slice(), lid = 'ce' + Math.random().toString(36).slice(2, 8);
		el.classList.add('msm-ce');
		el.innerHTML = '<ul class="msm-ce__list" data-celist></ul>' +
			'<div class="msm-ce__add"><input type="text" data-cein placeholder="' + esc(o.placeholder || 'Dodaj…') + '"' + (o.suggest ? ' list="' + lid + '"' : '') + ' autocomplete="off">' +
			(o.suggest ? '<datalist id="' + lid + '">' + o.suggest.map(function (x) { return '<option value="' + esc(x.v) + '">' + esc(x.label || '') + '</option>'; }).join('') + '</datalist>' : '') +
			'<button type="button" class="msm-btn msm-btn-sm" data-ceadd>+ Dodaj</button></div><em class="msm-ce__err" data-ceerr hidden></em>';
		var ul = el.querySelector('[data-celist]'), inp = el.querySelector('[data-cein]'), er = el.querySelector('[data-ceerr]');
		var key = function (v) { return String(v).toLowerCase(); };
		function draw() {
			ul.innerHTML = items.length ? items.map(function (v, i) {
				var lock = (o.locked || []).map(key).indexOf(key(v)) >= 0;
				return '<li class="msm-ce__chip' + (lock ? ' is-locked' : '') + '"><span>' + (o.label ? o.label(v) : esc(v)) + '</span>' +
					(lock ? '<i class="msm-ce__lock" title="Nie można usunąć">' + ICON_LOCK + '</i>' : '<button type="button" data-cedel="' + i + '" aria-label="Usuń ' + esc(v) + '" title="Usuń">×</button>') + '</li>';
			}).join('') : '<li class="msm-ce__empty">Lista jest pusta.</li>';
			ul.querySelectorAll('[data-cedel]').forEach(function (b) {
				b.addEventListener('click', function () { items.splice(+b.getAttribute('data-cedel'), 1); draw(); if (o.onChange) o.onChange(); });
			});
		}
		function add() {
			var parts = inp.value.split(o.sep || /\r?\n|[,;]/).map(function (x) { return x.trim(); }).filter(Boolean), bad = [];
			parts.forEach(function (v) {
				var e = o.check ? o.check(v) : '';
				if (e) { bad.push(e); return; }
				if (items.map(key).indexOf(key(v)) >= 0) { bad.push('„' + v + '” już jest na liście.'); return; }
				items.push(v);
			});
			if (o.sort) items.sort(function (a, b) { return a.localeCompare(b, 'pl'); });
			er.hidden = !bad.length; er.textContent = bad.join(' ');
			if (parts.length > bad.length) { inp.value = ''; draw(); if (o.onChange) o.onChange(); }
			inp.focus();
		}
		inp.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); add(); } });
		inp.addEventListener('input', function () { er.hidden = true; });
		el.querySelector('[data-ceadd]').addEventListener('click', add);
		draw();
		return { get: function () { return items.slice(); } };
	}
	var ICON_LOCK = '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/></svg>';

	/* ---------- Ustawienia: sekcje w kartach, menu sekcji z boku, listy „po jednym”, zapis z paska na dole ---------- */
	function renderUstawienia() {
		var main = document.getElementById('msm-main');
		main.innerHTML = '<div class="msm-cat"><div class="msm-pagehead"><div><h1>Ustawienia</h1><p class="msm-muted">Dane firmy, progi ostrzeżeń, listy wyboru, powiadomienia i uprawnienia specjalne</p></div></div>' +
			'<div data-ust><div class="msm-loading">Ładowanie…</div></div></div>';
		var box = main.querySelector('[data-ust]');
		var SI = function (p) { return '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + p + '</svg>'; };
		var SECS = [
			['firma', 'Firma', 'Dane na wydrukach, w dokumentach i stopkach e-maili', SI('<path d="M3 21h18M5 21V7l7-4 7 4v14M9 9h1M14 9h1M9 13h1M14 13h1M9 17h1M14 17h1"/>')],
			['progi', 'Progi ostrzeżeń', 'Ile dni wcześniej system ostrzega o terminach', SI('<path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/>')],
			['listy', 'Listy wyboru', 'Lokalizacje i pracownicy do wyboru w formularzach', SI('<path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/>')],
			['powiad', 'Powiadomienia', 'Kto dostaje e-maile o zdarzeniach w magazynie', SI('<rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-10 5L2 7"/>')],
			['super', 'Uprawnienia specjalne', 'Super administratorzy systemu', SI('<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>')]
		];
		function split(lbl) { var m = /^(.*?)\s*\((.*)\)\s*$/.exec(lbl); return m ? [m[1], m[2]] : [lbl, '']; }
		/* Brak konta widać na plakietce – tu tylko konta do ponownego potwierdzenia. */
		function warn(list) { list = (list || []).filter(function (x) { return / \(/.test(x); }); return list.length ? '<em class="msm-field-hint msm-hint-warn">' + esc(list.join('; ')) + '</em>' : ''; }
		function draw(s) {
			var v = s.values, miss = s.missing || {}, users = s.users || [], dirty = false;
			var byLogin = {}; users.forEach(function (u) { byLogin[u.login.toLowerCase()] = u; });
			var person = function (x) {
				var u = byLogin[String(x).toLowerCase()];
				return u ? '<b>' + esc(u.name || u.login) + '</b><small>' + esc(u.login) + '</small>' : (/@/.test(x) ? '<b>' + esc(x) + '</b><small>e-mail</small>' : '<b>' + esc(x) + '</b><small class="msm-ce__bad">brak takiego konta</small>');
			};
			var sugg = users.map(function (u) { return { v: u.login, label: u.name + (u.email ? ' · ' + u.email : '') }; });
			var sec = function (k, body) {
				var d = SECS.filter(function (x) { return x[0] === k; })[0];
				return '<section class="msm-card msm-ust__sec" id="ust-' + k + '"><header class="msm-ust__h"><i>' + d[3] + '</i><div><h2>' + esc(d[1]) + '</h2><p class="msm-muted">' + esc(d[2]) + '</p></div></header>' + body + '</section>';
			};
			var listField = function (k, lbl, hint, extra) {
				return '<div class="msm-field full msm-ust__list" data-field="' + k + '"><span>' + lbl + ' <em class="msm-count" data-cecount="' + k + '"></em></span><div data-ce="' + k + '"></div>' +
					(hint ? '<em class="msm-field-hint">' + hint + '</em>' : '') + (extra || '') + '<em class="msm-ferr"></em></div>';
			};
			box.innerHTML = '<div class="msm-ust">' +
				'<nav class="msm-ust__nav" aria-label="Sekcje ustawień">' + SECS.map(function (x, i) {
					return '<a href="#ust-' + x[0] + '" data-ustnav="' + x[0] + '"' + (i ? '' : ' class="is-on"') + '>' + x[3] + '<span>' + esc(x[1]) + '</span></a>';
				}).join('') + '</nav>' +
				'<form class="msm-form msm-ust__body" novalidate><div class="msm-form-err msm-alert msm-alert-err" hidden></div>' +
				sec('firma', '<div class="msm-grid msm-ust__grid">' + ['firma_nazwa', 'firma_skrot', 'firma_nip', 'firma_adres', 'magazyn_nazwa', 'pal_kontakt'].filter(function (k) { return s.labels[k]; })
					.concat(Object.keys(s.labels).filter(function (k) { return ['firma_nazwa', 'firma_skrot', 'firma_nip', 'firma_adres', 'magazyn_nazwa', 'pal_kontakt'].indexOf(k) < 0; })).map(function (k) {
					var l = split(s.labels[k]), wide = k === 'firma_nazwa' || k === 'firma_adres';
					return '<label class="msm-field' + (wide ? ' full' : '') + '" data-field="' + k + '"><span>' + esc(l[0]) + '</span><input type="text" name="' + k + '" value="' + esc(v[k]) + '" maxlength="200">' +
						(l[1] ? '<em class="msm-field-hint">' + esc(l[1].charAt(0).toUpperCase() + l[1].slice(1)) + '</em>' : '') + '<em class="msm-ferr"></em></label>';
				}).join('') + '</div>') +
				sec('progi', '<div class="msm-ust__nums">' + Object.keys(s.nums || {}).map(function (k) {
					return '<label class="msm-field" data-field="' + k + '"><span>' + esc(s.nums[k]) + '</span><span class="msm-ust-num"><input type="number" name="' + k + '" value="' + esc(v[k]) + '" min="1" max="365" inputmode="numeric"><b>dni</b></span><em class="msm-ferr"></em></label>';
				}).join('') + '</div><p class="msm-field-hint">Zmiana działa od razu po zapisaniu (u innych osób po odświeżeniu strony).</p>') +
				sec('listy', listField('lokalizacje', 'Lokalizacje przyrządów pomiarowych i elektronarzędzi', 'Do wyboru w kartach przyrządów i elektronarzędzi oraz jako filtr na listach. Usunięcie z listy nie zmienia już zapisanych pozycji.') +
					listField('pracownicy_zmian', 'Pracownicy w kartach zmian', 'Listy Wypełnił / Operator / Pomocnik oraz lista wyboru w eksportowanym arkuszu Excela. Dostęp do zakładki włączasz w Użytkownicy → Produkcja → Karty zmian.')) +
				sec('powiad', listField('blachy_notify', 'Odbiorcy e-maila o pobraniu blachy pełnej', 'Wybierz konto z podpowiedzi (e-mail z profilu tej osoby) albo wpisz adres e-mail.', warn(miss.blachy_notify))) +
				sec('super', listField('super_logins', 'Super administratorzy', 'Mogą trwale usuwać dane bez śladu i zmieniać te ustawienia. ' + (s.wp_admin ? 'Jako administrator WordPressa możesz dowolnie zmieniać tę listę.' : 'Własnego konta (' + esc(s.me) + ') nie możesz usunąć.'), warn(miss.super_logins))) +
				'<div class="msm-ust__bar"><span class="msm-muted" data-ustdirty>Wszystkie zmiany zapisane.</span><button type="submit" class="msm-btn msm-btn-primary">Zapisz ustawienia</button></div>' +
				'</form></div>';
			var form = box.querySelector('form');
			function touch() { dirty = true; var d = box.querySelector('[data-ustdirty]'); d.textContent = 'Masz niezapisane zmiany.'; d.classList.add('is-dirty'); counts(); }
			var CE = {
				lokalizacje: chipEditor(box.querySelector('[data-ce=lokalizacje]'), { items: v.lokalizacje || [], placeholder: 'Nowa lokalizacja, np. Opole', onChange: touch }),
				pracownicy_zmian: chipEditor(box.querySelector('[data-ce=pracownicy_zmian]'), { items: v.pracownicy_zmian || [], placeholder: 'Nazwisko i imię, np. Dróbka Michał', sort: true, onChange: touch }),
				blachy_notify: chipEditor(box.querySelector('[data-ce=blachy_notify]'), { items: v.blachy_notify || [], placeholder: 'Login albo adres e-mail', suggest: sugg, label: person, sep: /[\s,;]+/, onChange: touch }),
				super_logins: chipEditor(box.querySelector('[data-ce=super_logins]'), { items: v.super_logins || [], placeholder: 'Login konta', suggest: sugg, label: person, sep: /[\s,;]+/, locked: s.wp_admin ? [] : [s.me],
					check: function (x) { return /@/.test(x) ? 'Super administratora podaj loginem, nie adresem e-mail.' : ''; }, onChange: touch })
			};
			function counts() { Object.keys(CE).forEach(function (k) { var c = box.querySelector('[data-cecount="' + k + '"]'); if (c) c.textContent = CE[k].get().length; }); }
			counts();
			form.addEventListener('input', function (e) { if (!e.target.closest('.msm-ce')) touch(); });
			/* Menu sekcji: podświetla sekcję widoczną na ekranie. */
			var navA = box.querySelectorAll('[data-ustnav]');
			navA.forEach(function (a) { a.addEventListener('click', function (e) { e.preventDefault(); box.querySelector(a.getAttribute('href')).scrollIntoView({ behavior: 'smooth', block: 'start' }); }); });
			if ('IntersectionObserver' in window) {
				var io = new IntersectionObserver(function (en) {
					en.forEach(function (x) { if (x.isIntersecting) navA.forEach(function (a) { a.classList.toggle('is-on', a.getAttribute('href') === '#' + x.target.id); }); });
				}, { rootMargin: '-35% 0px -60% 0px' });
				box.querySelectorAll('.msm-ust__sec').forEach(function (x) { io.observe(x); });
			}
			form.addEventListener('submit', function (ev) {
				ev.preventDefault();
				var btn = form.querySelector('[type=submit]'), body = {};
				Object.keys(s.labels).forEach(function (k) { body[k] = form[k].value; });
				Object.keys(s.nums || {}).forEach(function (k) { body[k] = form[k].value; });
				Object.keys(CE).forEach(function (k) { body[k] = CE[k].get(); });
				btn.disabled = true;
				api('/ustawienia', { method: 'POST', body: body })
					.then(function (r) { toast(r.message); var y = window.scrollY; draw(r); window.scrollTo(0, y); })
					.catch(function (e) { btn.disabled = false; showErrors(form, e); });
			});
		}
		api('/ustawienia').then(draw).catch(function (e) { box.innerHTML = '<p class="msm-alert msm-alert-err">' + esc(e.message) + '</p>'; });
	}

	/* ---------- Kopia danych (nocna + ręczna) ---------- */
	function renderKopia() {
		var main = document.getElementById('msm-main');
		main.innerHTML = '<div class="msm-cat"><div class="msm-pagehead"><div><h1>Kopia danych</h1><p class="msm-muted">Kopia całego systemu do Excela – co noc automatycznie albo ręcznie, e-mailem i na serwerze. Niżej: import stanów z Excela.</p></div></div>' +
			'<div data-kopia><div class="msm-loading">Ładowanie…</div></div></div>';
		var box = main.querySelector('[data-kopia]');
		function dt(ts) { return ts ? esc(fmtDateTime(new Date(ts * 1000).toISOString())) : null; }
		function load() {
			api('/backup').then(function (s) {
				var icoFile = '<svg class="msm-ico" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/><path d="M9 13h6M9 17h6"/></svg>';
				var files = s.files.length ? '<ul class="msm-kopia-files">' + s.files.map(function (f) {
					return '<li class="msm-kopia-file"><a href="' + esc(f.url) + '" class="msm-kopia-file__name">' + icoFile + '<span>' + esc(f.name) + '</span></a>' +
						'<span class="msm-kopia-file__date">' + fmtDateTime(new Date(f.time * 1000).toISOString()) + '</span>' +
						'<a href="' + esc(f.url) + '" class="msm-btn msm-btn-sm" download>Pobierz</a></li>';
				}).join('') + '</ul>' : '<div class="msm-kopia-empty"><p class="msm-muted">Brak kopii na serwerze.</p><p class="msm-small msm-muted">Kliknij „Wyślij kopię teraz”, aby utworzyć pierwszą.</p></div>';

				box.innerHTML =
					'<form class="msm-card msm-kopia-card" data-bf>' +
					'<div class="msm-kopia-auto"><label class="msm-switch"><input type="checkbox" name="enabled"' + (s.enabled ? ' checked' : '') + '><span class="msm-switch__slider"></span></label>' +
					'<div><b>Automatyczna kopia co noc</b><span class="msm-muted msm-small">Codziennie ok. 02:00 system tworzy kopię i wysyła ją na podane adresy.</span></div></div>' +
					'<div class="msm-kopia-grid">' +
					'<label class="msm-field"><span>Główny e-mail do wysyłki</span><input name="email" type="email" placeholder="np. biuro@firma.pl" value="' + esc(s.email) + '"></label>' +
					'<label class="msm-field"><span>Ile kopii trzymać na serwerze</span><input name="keep" type="number" min="1" max="365" value="' + (s.keep || 30) + '"></label>' +
					'<label class="msm-field full"><span>Dodatkowe adresy e-mail</span><input name="emails_extra" type="text" placeholder="np. szef@firma.pl, ksiegowosc@firma.pl" value="' + esc(s.emails_extra || '') + '"><em class="msm-field-hint">Kilka adresów oddziel przecinkiem – kopia trafi na wszystkie.</em></label>' +
					'</div>' +
					'<div class="msm-kopia-status">' +
					'<div class="msm-kopia-stat"><span class="msm-kopia-stat__lbl">Ostatnia kopia</span><b>' + (dt(s.last) || 'nigdy') + '</b></div>' +
					'<div class="msm-kopia-stat"><span class="msm-kopia-stat__lbl">Następna (automat)</span><b>' + (s.enabled ? (dt(s.next) || '—') : 'wyłączona') + '</b></div>' +
					'</div>' +
					(s.error ? '<p class="msm-alert msm-alert-err">Ostatnia kopia nie powiodła się: ' + esc(s.error) + '</p>' : '') +
					'<details class="msm-kopia-zakres"><summary>Co jest w kopii? <span class="msm-muted">' + (s.sheets || []).length + ' arkuszy + arkusz „Informacje”</span></summary>' +
					'<p class="msm-muted msm-small">Każda tabela systemu w osobnym arkuszu, ze wszystkimi kolumnami. Każda nowa tabela trafia do kopii automatycznie. Skany PZ i obrazy podpisów zostają na serwerze (w kopii jest ich lista); hasła nie są zapisywane.</p>' +
					'<ul>' + (s.sheets || []).map(function (n) { return '<li>' + esc(n) + '</li>'; }).join('') + '</ul></details>' +
					'<div class="msm-kopia-actions"><button type="button" class="msm-btn" data-bsave>Zapisz ustawienia</button><button type="button" class="msm-btn msm-btn-primary" data-brun>Wyślij kopię teraz</button></div>' +
					'</form>' +
					'<div class="msm-card msm-kopia-list"><h3 class="msm-wz-h">Kopie na serwerze <span class="msm-count">' + s.files.length + '</span></h3>' + files + '</div>' +
					(mOn('import') ? '<div data-imp></div>' : '');
				if (mOn('import')) {
					importPanel(box.querySelector('[data-imp]'));
					if (/import/.test(location.search + sessionStorage.getItem('msm_goimp'))) { try { sessionStorage.removeItem('msm_goimp'); } catch (e) {} box.querySelector('#msm-import').scrollIntoView({ block: 'start' }); }
				}

				var form = box.querySelector('[data-bf]');
				box.querySelector('[data-bsave]').addEventListener('click', function () {
					var b = this; b.disabled = true;
					api('/backup', { method: 'POST', body: { enabled: form.enabled.checked, email: form.email.value, emails_extra: form.emails_extra.value, keep: +form.keep.value } })
						.then(function () { b.disabled = false; toast('Zapisano ustawienia.'); load(); }).catch(function (e) { b.disabled = false; toast(e.message, 'err'); });
				});
				box.querySelector('[data-brun]').addEventListener('click', function () {
					var b = this; b.disabled = true; b.textContent = 'Generowanie…';
					api('/backup/run', { method: 'POST' }).then(function (r) {
						toast(r.sent ? 'Kopia wysłana (' + (r.email || 'e-mail') + ') i zapisana.' : 'Kopia zapisana na serwerze' + (r.email ? ' (wysyłka e-mail nieudana)' : ' (brak adresu e-mail)') + '.');
						load();
					}).catch(function (e) { b.disabled = false; b.textContent = 'Wyślij kopię teraz'; toast(e.message, 'err'); });
				});
			}).catch(function (e) { box.innerHTML = '<p class="msm-alert msm-alert-err">' + esc(e.message) + '</p>'; });
		}
		load();
	}

	function renderMailTemplates() {
		var main = document.getElementById('msm-main');
		main.innerHTML = '<div class="msm-cat"><div class="msm-pagehead"><div><h1>Szablony e-maili</h1><p class="msm-muted">Treści wiadomości wysyłanych przez system. Kliknij szablon, aby go rozwinąć. Pola w nawiasach, np. {material}, są podmieniane na dane.</p></div></div>' +
			'<div data-mt><div class="msm-loading">Ładowanie…</div></div></div>';
		var box = main.querySelector('[data-mt]');
		var chev = '<svg class="msm-acc__chev" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m6 9 6 6 6-6"/></svg>';
		var tbBtn = function (cmd, label, title) { return '<button type="button" class="msm-rte-b" data-cmd="' + cmd + '" title="' + title + '">' + label + '</button>'; };
		function load() {
			api('/mail-templates').then(function (list) {
				box.innerHTML = '<div class="msm-acc-list">' + list.map(function (t) {
					var vars = Object.keys(t.vars).map(function (k) {
						return '<button type="button" class="msm-chip msm-tpl-var" data-var="{' + k + '}" title="' + esc(t.vars[k]) + '">{' + k + '}</button>';
					}).join('');
					var toolbar = '<div class="msm-rte-tb">' +
						tbBtn('bold', '<b>B</b>', 'Pogrubienie') + tbBtn('italic', '<i>I</i>', 'Kursywa') + tbBtn('underline', '<u>U</u>', 'Podkreślenie') +
						'<span class="msm-rte-sep"></span>' + tbBtn('insertUnorderedList', '•', 'Lista punktowana') + tbBtn('insertOrderedList', '1.', 'Lista numerowana') +
						'<span class="msm-rte-sep"></span>' + tbBtn('removeFormat', '⌫', 'Wyczyść formatowanie') + '</div>';
					return '<div class="msm-acc" data-key="' + esc(t.key) + '">' +
						'<button type="button" class="msm-acc__head" data-acc><span class="msm-acc__title">' + esc(t.label) + '</span>' +
						(t.customized ? '<span class="msm-tag msm-tag-ok">zmieniony</span>' : '<span class="msm-tag">domyślny</span>') + chev + '</button>' +
						'<div class="msm-acc__body" hidden>' +
						'<p class="msm-muted msm-small msm-tpl__desc">' + esc(t.desc) + '</p>' +
						'<label class="msm-field full"><span>Temat wiadomości</span><input name="subject" type="text" value="' + esc(t.subject) + '"></label>' +
						'<div class="msm-field full"><span>Treść wiadomości</span>' + toolbar +
						'<div class="msm-rte" contenteditable="true" data-body="' + esc(t.body) + '"></div></div>' +
						'<div class="msm-tpl__vars"><span class="msm-muted msm-small">Pola do wstawienia (kliknij, aby dodać w miejscu kursora):</span><div class="msm-tpl__chips">' + vars + '</div></div>' +
						'<div class="msm-tpl__act"><button type="button" class="msm-btn msm-btn-ghost" data-reset>Przywróć domyślny</button><button type="button" class="msm-btn msm-btn-primary" data-save>Zapisz szablon</button></div>' +
						'</div></div>';
				}).join('') + '</div>';

				box.querySelectorAll('.msm-acc').forEach(function (acc) {
					var head = acc.querySelector('[data-acc]');
					var bodyWrap = acc.querySelector('.msm-acc__body');
					var subj = acc.querySelector('[name=subject]');
					var editor = acc.querySelector('.msm-rte');
					editor.innerHTML = editor.getAttribute('data-body') || '';
					var lastField = editor;
					subj.addEventListener('focus', function () { lastField = subj; });
					editor.addEventListener('focus', function () { lastField = editor; });

					head.addEventListener('click', function () {
						var open = !bodyWrap.hidden;
						bodyWrap.hidden = open;
						acc.classList.toggle('is-open', !open);
					});
					// Pasek formatowania – zachowujemy zaznaczenie (mousedown preventDefault).
					acc.querySelectorAll('.msm-rte-b').forEach(function (b) {
						b.addEventListener('mousedown', function (e) { e.preventDefault(); editor.focus(); document.execCommand(b.getAttribute('data-cmd'), false, null); });
					});
					// Wstawianie pól {…} w miejscu kursora.
					acc.querySelectorAll('.msm-tpl-var').forEach(function (b) {
						b.addEventListener('mousedown', function (e) {
							e.preventDefault();
							var txt = b.getAttribute('data-var');
							if (lastField === subj) {
								var s = subj.selectionStart || 0, en = subj.selectionEnd || 0;
								subj.value = subj.value.slice(0, s) + txt + subj.value.slice(en);
								subj.selectionStart = subj.selectionEnd = s + txt.length; subj.focus();
							} else {
								editor.focus(); document.execCommand('insertText', false, txt);
							}
						});
					});
					acc.querySelector('[data-save]').addEventListener('click', function () {
						var btn = this; btn.disabled = true;
						api('/mail-templates', { method: 'POST', body: { key: acc.getAttribute('data-key'), subject: subj.value, body: editor.innerHTML } })
							.then(function () { btn.disabled = false; toast('Zapisano szablon.'); load(); })
							.catch(function (e) { btn.disabled = false; toast(e.message, 'err'); });
					});
					acc.querySelector('[data-reset]').addEventListener('click', function () {
						confirmBox('Przywrócić domyślny szablon?', 'Twoje zmiany w tym szablonie zostaną usunięte.', 'Przywróć domyślny', true).then(function (ok) {
							if (!ok) return;
							api('/mail-templates', { method: 'POST', body: { key: acc.getAttribute('data-key'), subject: '', body: '' } })
								.then(function () { toast('Przywrócono domyślny szablon.'); load(); })
								.catch(function (e) { toast(e.message, 'err'); });
						});
					});
				});
			}).catch(function (e) { box.innerHTML = '<p class="msm-alert msm-alert-err">' + esc(e.message) + '</p>'; });
		}
		load();
	}

	function pollZam() {
		if (!C.canEdit || !mOn('zamowienia')) return;
		/* Licznik = blachy poniżej minimum + braki dla zleceń, które trzeba jeszcze zamówić. */
		Promise.all([api('/do-zamowienia'), api('/zam/braki').catch(function () { return { braki: [] }; })]).then(function (r) {
			var a = (r[0] || []).length, b = ((r[1] && r[1].braki) || []).filter(function (g) { return g.do_zam > 0; }).length, n = a + b;
			root.querySelectorAll('[data-zamcount]').forEach(function (el) { el.textContent = n; el.hidden = !n; el.title = [b ? b + ' braków dla zleceń do zamówienia' : '', a ? a + ' poniżej stanu minimalnego' : ''].filter(Boolean).join(' · '); });
		}).catch(function () {});
	}

	/* ===================== Magazyn BHP – wydania na osoby ===================== */
	function renderWydaniaBhp() {
		var main = document.getElementById('msm-main');
		main.innerHTML = '<div class="msm-cat">' +
			'<div class="msm-pagehead"><div><h1>Wydania BHP</h1><p class="msm-muted">Wydania środków ochrony i odzieży roboczej na konkretne osoby</p></div>' +
			'<div class="msm-pagehead__tools">' +
			(cEdit() ? '<button type="button" class="msm-btn msm-btn-primary" data-bhpnew>+ Nowe wydanie</button>' : '') +
			(cEdit() ? '<button type="button" class="msm-btn" data-bhparch title="Uzupełnij historię z poprzednich lat – bez zmiany stanu i bez numeru">+ Wpis archiwalny</button>' : '') +
			'</div></div>' +
			'<div class="msm-table-wrap" data-bhpwyd><div class="msm-loading">Ładowanie…</div></div></div>';
		var nb = main.querySelector('[data-bhpnew]');
		if (nb) nb.addEventListener('click', function () { openWydanieBhp(); });
		var ab = main.querySelector('[data-bhparch]');
		if (ab) ab.addEventListener('click', function () { openWydanieBhp(null, true); });
		loadWydaniaBhp();
	}
	function loadWydaniaBhp() {
		var box = document.querySelector('[data-bhpwyd]');
		if (!box) return;
		api('/bhp/wydania').then(function (rows) {
			if (!rows.length) { box.innerHTML = '<div class="msm-card msm-empty"><p class="msm-muted">Brak wydań. Kliknij „Nowe wydanie”, aby wydać odzież lub środki BHP na osobę.</p></div>'; return; }
			box.innerHTML = '<table class="msm-table"><thead><tr><th>Numer</th><th>Data</th><th>Osoba</th><th>Dział</th><th>Poz.</th><th>Szt.</th><th>Status</th><th>Wydał</th><th></th></tr></thead><tbody>' +
				rows.map(function (r) {
					var stg = r.status === 'anulowane' ? '<span class="msm-tag msm-tag-no">anulowane</span>' : (r.status === 'archiwalne' ? '<span class="msm-tag">archiwalne</span>' : '<span class="msm-tag msm-tag-ok">wydane</span>');
					return '<tr><td data-label="Numer">' + (r.numer ? '<b>' + esc(r.numer) + '</b>' : '<span class="msm-muted">—</span>') + '</td><td data-label="Data">' + esc(fmtDate(r.data).slice(0, 10)) + '</td><td data-label="Osoba">' + esc(r.osoba_name) + '</td><td data-label="Dział">' + esc(r.dzial || '—') + '</td><td data-label="Poz.">' + (r.poz || 0) + '</td><td data-label="Szt.">' + (r.szt || 0) + '</td><td data-label="Status">' + stg + '</td><td data-label="Wydał">' + esc(r.wydal_name || '') + '</td>' +
						'<td class="msm-act"><button type="button" class="msm-iconbtn" data-bhpprint="' + r.id + '" title="Drukuj / PDF" aria-label="Drukuj">' + ICON_PRINT + '</button>' +
						(cEdit() && r.status !== 'anulowane' ? '<button type="button" class="msm-btn msm-btn-sm msm-btn-danger-ghost" data-bhpcancel="' + r.id + '">Anuluj</button>' : '') +
						(C.canPurge ? '<button type="button" class="msm-iconbtn msm-iconbtn-danger" data-bhpdel="' + r.id + '" title="Usuń trwale' + (r.numer ? ' – numer zostanie zwolniony' : '') + '" aria-label="Usuń">' + ICON_DEL + '</button>' : '') + '</td></tr>';
				}).join('') + '</tbody></table>';
			box.querySelectorAll('[data-bhpprint]').forEach(function (b) {
				b.addEventListener('click', function () { window.open(printUrl({ msm_print: 'bhp_wyd', id: b.getAttribute('data-bhpprint') }), '_blank'); });
			});
			box.querySelectorAll('[data-bhpdel]').forEach(function (b) {
				b.addEventListener('click', function () {
					var id = +b.getAttribute('data-bhpdel');
					var row = (rows || []).filter(function (x) { return x.id === id; })[0] || {};
					var arch = !row.numer;
					var msg = arch
						? 'Wpis archiwalny zostanie trwale usunięty. Nie zmienia stanu magazynu – można bezpiecznie usuwać.'
						: 'Wydanie <b>' + esc(row.numer) + '</b> zostanie trwale usunięte, a jego <b>numer zwolniony</b> (będzie można nadać go ponownie). ' + (row.status === 'anulowane' ? 'Wydanie było anulowane – stan już wcześniej wrócił.' : 'Pobrany stan wróci na magazyn BHP.');
					confirmBox('Usunąć ' + (arch ? 'wpis archiwalny' : 'wydanie ' + (row.numer || '')) + '?', msg, 'Usuń trwale', true).then(function (ok) {
						if (!ok) return;
						api('/bhp/wydania/' + id + '/usun', { method: 'POST' }).then(function (res) {
							toast(res.message || 'Usunięto.'); invalidate('bhp'); loadWydaniaBhp();
						}).catch(function (e) { toast(e.message, 'err'); });
					});
				});
			});
			box.querySelectorAll('[data-bhpcancel]').forEach(function (b) {
				b.addEventListener('click', function () {
					var id = +b.getAttribute('data-bhpcancel');
					var mm = openModal('Anulować wydanie BHP?', '<p>Stan pozycji pobranych z magazynu wróci na stan BHP. Pozycje wpisane ręcznie nie zmieniają stanu.</p><label class="msm-field full"><span>Powód (opcjonalnie)</span><textarea name="note" rows="2"></textarea></label>',
						'<button type="button" class="msm-btn" data-close>Wróć</button><button type="button" class="msm-btn msm-btn-danger" data-ok>Anuluj wydanie</button>');
					mm.querySelector('[data-ok]').addEventListener('click', function () {
						api('/bhp/wydania/' + id + '/anuluj', { method: 'POST', body: { note: mm.querySelector('[name=note]').value } }).then(function (res) {
							closeModal(); toast(res.message || 'Anulowano.'); invalidate('bhp'); loadWydaniaBhp();
						}).catch(function (e) { toast(e.message, 'err'); });
					});
				});
			});
		}).catch(function (e) { box.innerHTML = '<p class="msm-alert msm-alert-err">' + esc(e.message) + '</p>'; });
	}

	function openOsobaKarta(o) {
		if (!o) return;
		var yNow = new Date().getFullYear();
		var years = [];
		for (var y = yNow; y >= yNow - 3; y--) years.push(y);
		var body = '<p>Karta wyposażenia BHP dla: <b>' + esc(o.imie_nazwisko) + '</b>' + (o.dzial ? ' · ' + esc(o.dzial) : '') + '.</p>' +
			'<div class="msm-ut-hd">Na wyposażeniu teraz</div><div data-nawyp><div class="msm-loading">Ładowanie…</div></div>' +
			'<label class="msm-field"><span>Wydruk – zakres</span><select name="rok"><option value="0">Wszystkie wydania</option>' +
			years.map(function (y) { return '<option value="' + y + '"' + (y === yNow ? ' selected' : '') + '>Rok ' + y + '</option>'; }).join('') + '</select></label>' +
			'<p class="msm-muted msm-small">Wydruk zawiera „Na wyposażeniu teraz” oraz pełną historię wydań. Pozycje z anulowanych wydań są pomijane.</p>';
		var m = openModal('Karta wyposażenia – ' + o.imie_nazwisko, body,
			'<button type="button" class="msm-btn" data-close>Zamknij</button><button type="button" class="msm-btn msm-btn-primary" data-pr>Drukuj / PDF</button>', true);
		var nw = m.querySelector('[data-nawyp]');
		api('/bhp/held/' + o.id).then(function (res) {
			var lines = res.lines || [];
			if (!lines.length) { nw.innerHTML = '<p class="msm-muted msm-small">Nic na wyposażeniu.</p>'; return; }
			nw.innerHTML = '<table class="msm-table msm-ut-tab"><thead><tr><th>Asortyment / nazwa</th><th>Rozm.</th><th>Ilość</th><th>Norma</th><th>Wydano</th></tr></thead><tbody>' +
				lines.map(function (l) { return '<tr><td data-label="Asortyment">' + esc((l.kategoria ? l.kategoria + ' · ' : '') + l.nazwa) + '</td><td data-label="Rozm.">' + esc(l.rozmiar || '—') + '</td><td data-label="Ilość"><b>' + l.held + '</b></td><td data-label="Norma">' + esc(l.norma || '—') + '</td><td data-label="Wydano">' + esc(fmtDate(l.last_data).slice(0, 10)) + '</td></tr>'; }).join('') + '</tbody></table>';
		}).catch(function (e) { nw.innerHTML = '<p class="msm-err">' + esc(e.message) + '</p>'; });
		m.querySelector('[data-pr]').addEventListener('click', function () {
			window.open(printUrl({ msm_print: 'bhp_osoba', id: o.id, rok: m.querySelector('[name=rok]').value }), '_blank');
		});
	}

	function bhpLocs(r) {
		return {
			magazyn: (Number(r.st_mag_nowy) || 0) + (Number(r.st_mag_uzywany) || 0),
			szafa: (Number(r.st_szafa_nowy) || 0) + (Number(r.st_szafa_uzywany) || 0)
		};
	}

	function openWydanieBhp(prefill, arch) {
		var blines = [];
		if (prefill) blines.push({ bhp_id: prefill.id, nazwa: rowTitle('bhp', prefill), rozmiar: prefill.rozmiar || '', kategoria: prefill.kategoria || '', ilosc: 1, zrodlo: 'magazyn', stock: prefill.ilosc, lokacja: 'magazyn', locs: bhpLocs(prefill) });
		var body = '<form class="msm-form" novalidate><div class="msm-form-err msm-alert msm-alert-err" hidden></div>' +
			(arch ? '<div class="msm-alert msm-wn-info"><p><b>Wpis archiwalny</b> – uzupełnienie historii z poprzednich lat. <b>Nie zmienia stanu magazynu</b> i <b>nie dostaje numeru</b>. Podaj datę, kiedy faktycznie wydano, oraz pozycje.</p></div>' : '') +
			'<div class="msm-grid">' +
			'<label class="msm-field" data-field="osoba_sel"><span>Osoba <i class="msm-req">*</i></span><select name="osoba_sel"><option value="">— wczytywanie… —</option></select><em class="msm-ferr"></em></label>' +
			'<label class="msm-field" data-field="osoba_name" hidden><span>Imię i nazwisko <i class="msm-req">*</i></span><input type="text" name="osoba_name" placeholder="np. Jan Kowalski"><em class="msm-ferr"></em></label>' +
			'<label class="msm-field" data-field="dzial"><span>Dział / brygada</span><input type="text" name="dzial" placeholder="np. Produkcja"></label>' +
			'<label class="msm-field" data-field="data"><span>Data wydania' + (arch ? ' <i class="msm-req">*</i>' : '') + '</span><input type="date" name="data"' + (arch ? '' : ' value="' + new Date().toISOString().slice(0, 10) + '"') + '><em class="msm-ferr"></em></label>' +
			'</div>' +
			'<div class="msm-bhp-pick"><div class="msm-bhp-pick__col"><h4>' + (arch ? 'Podpowiedz z katalogu BHP (bez zmiany stanu)' : 'Z magazynu BHP') + '</h4>' +
			'<input type="text" class="msm-input" data-bhpq placeholder="Szukaj: asortyment, nazwa, rozmiar…"><div class="msm-bhp-res" data-bhpres><p class="msm-muted">Wpisz, czego szukasz.</p></div></div>' +
			'<div class="msm-bhp-pick__col"><h4>Pozycja spoza magazynu (ręczna)</h4>' +
			'<div class="msm-grid"><label class="msm-field"><span>Asortyment</span><input type="text" data-mkat placeholder="np. Rękawice"></label>' +
			'<label class="msm-field"><span>Nazwa / producent</span><input type="text" data-mnaz placeholder="np. Rękawice robocze"></label>' +
			'<label class="msm-field"><span>Rozmiar</span><input type="text" data-mroz placeholder="np. 10"></label>' +
			'<label class="msm-field"><span>Ilość</span><input type="text" inputmode="numeric" data-milo value="1"></label></div>' +
			'<button type="button" class="msm-btn msm-btn-sm" data-maddr>+ Dodaj pozycję ręczną</button></div></div>' +
			'<div class="msm-bhp-lines" data-bhplines></div>' +
			'<label class="msm-field full" data-field="uwagi"><span>Uwagi</span><textarea name="uwagi" rows="2" placeholder="np. wymiana zużytej odzieży"></textarea></label>' +
			'</form>';
		var m = openModal(arch ? 'Wpis archiwalny – poprzednie wydanie' : 'Nowe wydanie BHP', body,
			'<button type="button" class="msm-btn" data-close>Anuluj</button><button type="button" class="msm-btn msm-btn-primary" data-save>' + (arch ? 'Zapisz wpis archiwalny' : 'Zapisz wydanie') + '</button>', true);
		var form = m.querySelector('form');
		var sel = form.querySelector('[name=osoba_sel]');
		var nameField = form.querySelector('[data-field=osoba_name]');
		var dzialInp = form.querySelector('[name=dzial]');
		var osoby = [];
		api('/t/bhp_osoby', { query: { per_page: 500, orderby: 'imie_nazwisko', order: 'asc' } }).then(function (d) {
			osoby = d.rows || [];
			sel.innerHTML = '<option value="">— wybierz osobę —</option>' +
				osoby.map(function (o) { return '<option value="' + o.id + '">' + esc(o.imie_nazwisko) + (o.dzial ? ' · ' + esc(o.dzial) : '') + '</option>'; }).join('') +
				'<option value="__manual">— wpisz ręcznie —</option>';
		}).catch(function () { sel.innerHTML = '<option value="">— wybierz osobę —</option><option value="__manual">— wpisz ręcznie —</option>'; });
		sel.addEventListener('change', function () {
			var manual = sel.value === '__manual';
			nameField.hidden = !manual;
			if (!manual) {
				var o = osoby.filter(function (x) { return x.id === +sel.value; })[0];
				if (o && o.dzial && !dzialInp.value) dzialInp.value = o.dzial;
			}
		});
		function syncLines() {
			var box = form.querySelector('[data-bhplines]');
			if (!blines.length) { box.innerHTML = '<p class="msm-muted msm-small">Brak pozycji. Dodaj z magazynu BHP lub ręcznie.</p>'; return; }
			box.innerHTML = '<table class="msm-table msm-bhp-ltab"><thead><tr><th>Asortyment</th><th>Nazwa / rozmiar</th><th>Źródło</th><th>Lokalizacja</th><th>Ilość</th><th></th></tr></thead><tbody>' +
				blines.map(function (l, i) {
					var zr = l.zrodlo === 'magazyn' ? '<span class="msm-tag msm-tag-ok">magazyn</span>' : (l.zrodlo === 'archiwum' ? '<span class="msm-tag">archiwum</span>' : '<span class="msm-tag">ręczna</span>');
					var locCell = '<span class="msm-muted">—</span>';
					if (l.zrodlo === 'magazyn') {
						var lm = (l.locs && l.locs.magazyn) || 0, ls = (l.locs && l.locs.szafa) || 0;
						locCell = '<select class="msm-bhp-loc" data-lloc="' + i + '">' +
							'<option value="magazyn"' + (l.lokacja !== 'szafa' ? ' selected' : '') + '>Magazyn (' + lm + ')</option>' +
							'<option value="szafa"' + (l.lokacja === 'szafa' ? ' selected' : '') + '>Szafa BHP (' + ls + ')</option></select>';
					}
					return '<tr><td data-label="Asortyment">' + esc(l.kategoria || '—') + '</td><td data-label="Nazwa / rozmiar">' + esc(l.nazwa) + (l.rozmiar ? ' · <b>' + esc(l.rozmiar) + '</b>' : '') + '</td><td data-label="Źródło">' + zr + '</td><td data-label="Lokalizacja">' + locCell + '</td>' +
						'<td data-label="Ilość"><input type="text" inputmode="numeric" class="msm-bhp-q" data-li="' + i + '" value="' + esc(String(l.ilosc)) + '"></td>' +
						'<td><button type="button" class="msm-iconbtn msm-iconbtn-danger" data-lrem="' + i + '" aria-label="Usuń">' + ICON_DEL + '</button></td></tr>';
				}).join('') + '</tbody></table>';
			box.querySelectorAll('[data-li]').forEach(function (inp) {
				inp.addEventListener('input', function () { blines[+inp.getAttribute('data-li')].ilosc = inp.value; });
			});
			box.querySelectorAll('[data-lloc]').forEach(function (s) {
				s.addEventListener('change', function () { blines[+s.getAttribute('data-lloc')].lokacja = s.value; syncLines(); });
			});
			box.querySelectorAll('[data-lrem]').forEach(function (b) {
				b.addEventListener('click', function () { blines.splice(+b.getAttribute('data-lrem'), 1); syncLines(); });
			});
		}
		syncLines();
		var bq = form.querySelector('[data-bhpq]'), bres = form.querySelector('[data-bhpres]');
		var searchBhp = debounce(function () {
			var q = bq.value.trim();
			if (!q) { bres.innerHTML = '<p class="msm-muted">Wpisz, czego szukasz.</p>'; return; }
			api('/t/bhp', { query: { q: q, per_page: 20 } }).then(function (d) {
				if (!d.rows.length) { bres.innerHTML = '<p class="msm-muted">Brak pozycji.</p>'; return; }
				bres.innerHTML = d.rows.map(function (r) {
					var zero = Number(r.ilosc) <= 0;
					var lc = bhpLocs(r);
					return '<div class="msm-wz-hit"><span><b>' + esc(rowTitle('bhp', r)) + '</b><small>' + (arch ? 'z katalogu' : 'na stanie ' + (r.ilosc || 0) + ' szt (mag ' + lc.magazyn + ' · szafa ' + lc.szafa + ')') + '</small></span>' +
						'<button type="button" class="msm-btn msm-btn-sm' + ((!arch && zero) ? '' : ' msm-btn-primary') + '" data-bpick="' + r.id + '"' + ((!arch && zero) ? ' disabled title="Brak na stanie"' : '') + '>Dodaj</button></div>';
				}).join('');
				bres.querySelectorAll('[data-bpick]').forEach(function (b) {
					b.addEventListener('click', function () {
						var r = d.rows.filter(function (x) { return x.id === +b.getAttribute('data-bpick'); })[0];
						var ex = blines.filter(function (l) { return l.bhp_id === r.id; })[0];
						if (ex) { ex.ilosc = (parseInt(ex.ilosc, 10) || 0) + 1; } else if (arch) {
							blines.push({ bhp_id: null, nazwa: rowTitle('bhp', r), rozmiar: r.rozmiar || '', kategoria: r.kategoria || '', ilosc: 1, zrodlo: 'archiwum' });
						} else {
							blines.push({ bhp_id: r.id, nazwa: rowTitle('bhp', r), rozmiar: r.rozmiar || '', kategoria: r.kategoria || '', ilosc: 1, zrodlo: 'magazyn', stock: r.ilosc, lokacja: 'magazyn', locs: bhpLocs(r) });
						}
						syncLines(); toast('Dodano: ' + rowTitle('bhp', r));
					});
				});
			}).catch(function (e) { bres.innerHTML = '<p class="msm-err">' + esc(e.message) + '</p>'; });
		}, 300);
		bq.addEventListener('input', searchBhp);
		form.querySelector('[data-maddr]').addEventListener('click', function () {
			var naz = form.querySelector('[data-mnaz]').value.trim();
			if (!naz) { toast('Podaj nazwę pozycji ręcznej.', 'err'); return; }
			blines.push({ bhp_id: null, nazwa: naz, kategoria: form.querySelector('[data-mkat]').value.trim(), rozmiar: form.querySelector('[data-mroz]').value.trim(), ilosc: form.querySelector('[data-milo]').value || 1, zrodlo: arch ? 'archiwum' : 'reczne' });
			form.querySelector('[data-mkat]').value = ''; form.querySelector('[data-mnaz]').value = ''; form.querySelector('[data-mroz]').value = ''; form.querySelector('[data-milo]').value = '1';
			syncLines();
		});
		m.querySelector('[data-save]').addEventListener('click', function () {
			if (!blines.length) { toast('Dodaj przynajmniej jedną pozycję.', 'err'); return; }
			var manual = sel.value === '__manual';
			var payload = {
				osoba_id: manual ? 0 : (+sel.value || 0),
				osoba_name: manual ? form.querySelector('[name=osoba_name]').value.trim() : '',
				dzial: dzialInp.value.trim(),
				data: form.querySelector('[name=data]').value,
				uwagi: form.querySelector('[name=uwagi]').value.trim(),
				lines: blines.map(function (l) { return { bhp_id: l.bhp_id, nazwa: l.nazwa, kategoria: l.kategoria, rozmiar: l.rozmiar, ilosc: l.ilosc, lokacja: l.lokacja || 'magazyn' }; })
			};
			if (!payload.osoba_id && !payload.osoba_name) { toast('Wybierz lub wpisz osobę.', 'err'); return; }
			if (arch && !payload.data) { toast('Podaj datę wydania (archiwalnego).', 'err'); return; }
			var saveBtn = this;
			function finish(seq) {
				if (seq) payload.nr_seq = seq;
				saveBtn.disabled = true;
				api('/bhp/wydania', { method: 'POST', body: payload }).then(function (res) {
					closeModal(); invalidate('bhp');
					if (current === 'bhp') refresh('bhp');
					if (current === 'bhp_wyd') loadWydaniaBhp();
					var doc = res.doc || {};
					var mm = openModal('Zapisano', '<p>' + esc(res.message || 'Zapisano.') + '</p><p class="msm-muted msm-small">Możesz wydrukować kartę wydania (A4) z podpisem odbierającego.</p>',
						'<button type="button" class="msm-btn" data-close>Zamknij</button>' + (doc.id ? '<button type="button" class="msm-btn msm-btn-primary" data-pr>Drukuj kartę wydania</button>' : ''));
					var pr = mm.querySelector('[data-pr]');
					if (pr) pr.addEventListener('click', function () { window.open(printUrl({ msm_print: 'bhp_wyd', id: doc.id }), '_blank'); });
				}).catch(function (e) {
					saveBtn.disabled = false;
					if (e.status === 409 && e.data && e.data.norm && cEdit()) { askOverrideNorm(e.data.norm, payload, finish); return; }
					if (document.body.contains(form)) { showErrors(form, e); } else { toast(e.message || 'Błąd zapisu.', 'err'); }
				});
			}
			if (arch) { payload.archiwalne = 1; finish(); return; }
			// Numeracja: jeśli są wolne numery (po usuniętych wydaniach) – zapytaj, który nadać.
			api('/bhp/next-number').then(function (info) {
				if (info.auto || !info.free || !info.free.length) { finish(); return; }
				var opts = info.free.map(function (f) { return '<option value="' + f.seq + '">' + esc(f.numer) + ' — wolny</option>'; }).join('') +
					'<option value="' + info.next + '">' + esc(info.next_numer) + ' — kolejny</option>';
				var mm = openModal('Jaki numer nadać?',
					'<p>W tym roku są <b>wolne numery</b> po usuniętych wydaniach. Wybierz numer dla nowego wydania:</p>' +
					'<label class="msm-field"><span>Numer wydania</span><select name="nr">' + opts + '</select></label>',
					'<button type="button" class="msm-btn" data-close>Anuluj</button><button type="button" class="msm-btn msm-btn-primary" data-ok>Nadaj i zapisz</button>');
				mm.querySelector('[data-ok]').addEventListener('click', function () { finish(+mm.querySelector('[name=nr]').value); });
			}).catch(function () { finish(); });
		});
	}



	/* ===================== Utylizacja / rozliczenie wyposażenia ===================== */
	function askOverrideNorm(norm, payload, finish) {
		var rowsH = norm.map(function (x) { return '<tr><td>' + esc(x.kategoria) + '</td><td>' + x.posiada + '</td><td>' + x.wydawane + '</td><td><b>' + x.po + '</b></td><td>' + x.limit + '</td></tr>'; }).join('');
		var mm = openModal('Przekroczono normę przydziału',
			'<p>To wydanie przekroczy <b>maksymalny stan posiadania</b> dla:</p>' +
			'<table class="msm-table"><thead><tr><th>Asortyment</th><th>Ma</th><th>Wydaje</th><th>Razem</th><th>Norma</th></tr></thead><tbody>' + rowsH + '</tbody></table>' +
			'<label class="msm-field full"><span>Uzasadnienie (zapisze się w uwagach wydania)</span><input type="text" name="onote" placeholder="np. zniszczenie w pracy, wymiana awaryjna"></label>',
			'<button type="button" class="msm-btn" data-close>Anuluj</button><button type="button" class="msm-btn msm-btn-danger" data-ok>Wydaj mimo to</button>');
		mm.querySelector('[data-ok]').addEventListener('click', function () { payload.override = 1; payload.override_note = mm.querySelector('[name=onote]').value; closeModal(); finish(); });
	}

	function bindSigPad(canvas) {
		var ctx = canvas.getContext('2d'); ctx.lineWidth = 2.2; ctx.lineCap = 'round'; ctx.strokeStyle = '#0b1020';
		var drawing = false, dirty = false, last = null;
		function pos(e) { var r = canvas.getBoundingClientRect(); var t = e.touches ? e.touches[0] : e; return { x: (t.clientX - r.left) * (canvas.width / r.width), y: (t.clientY - r.top) * (canvas.height / r.height) }; }
		function start(e) { drawing = true; last = pos(e); e.preventDefault(); }
		function move(e) { if (!drawing) return; var p = pos(e); ctx.beginPath(); ctx.moveTo(last.x, last.y); ctx.lineTo(p.x, p.y); ctx.stroke(); last = p; dirty = true; e.preventDefault(); }
		function end() { drawing = false; }
		canvas.addEventListener('mousedown', start); canvas.addEventListener('mousemove', move); window.addEventListener('mouseup', end);
		canvas.addEventListener('touchstart', start, { passive: false }); canvas.addEventListener('touchmove', move, { passive: false }); canvas.addEventListener('touchend', end);
		return { data: function () { return dirty ? canvas.toDataURL('image/png') : ''; }, clear: function () { ctx.clearRect(0, 0, canvas.width, canvas.height); dirty = false; } };
	}

	function renderUtylizacje() {
		var main = document.getElementById('msm-main');
		var yNow = new Date().getFullYear();
		main.innerHTML = '<div class="msm-cat"><div class="msm-pagehead"><div><h1>Utylizacje / rozliczenia BHP</h1><p class="msm-muted">Zdejmowanie zużytych rzeczy ze stanu posiadania osoby oraz zwrot używalnego na magazyn</p></div>' +
			'<div class="msm-pagehead__tools">' +
			(cEdit() ? '<button type="button" class="msm-btn msm-btn-primary" data-utnew>+ Nowa utylizacja</button>' : '') +
			'<a class="msm-btn" href="' + esc(printUrl({ msm_print: 'bhp_util_rok', rok: yNow })) + '" target="_blank" rel="noopener">Raport roczny ' + yNow + '</a>' +
			'</div></div><div class="msm-table-wrap" data-utlist><div class="msm-loading">Ładowanie…</div></div></div>';
		var nb = main.querySelector('[data-utnew]');
		if (nb) nb.addEventListener('click', function () { openUtylizacja(); });
		loadUtylizacje();
	}
	function loadUtylizacje() {
		var box = document.querySelector('[data-utlist]');
		if (!box) return;
		api('/bhp/util').then(function (rows) {
			if (!rows.length) { box.innerHTML = '<div class="msm-card msm-empty"><p class="msm-muted">Brak protokołów. Kliknij „Nowa utylizacja”, aby rozliczyć wyposażenie pracownika.</p></div>'; return; }
			box.innerHTML = '<table class="msm-table"><thead><tr><th>Numer</th><th>Data</th><th>Pracownik</th><th>Dział</th><th>Utylizacja</th><th>Zwrot</th><th>Powód</th><th></th></tr></thead><tbody>' +
				rows.map(function (r) {
					return '<tr><td data-label="Numer"><b>' + esc(r.numer) + '</b></td><td data-label="Data">' + esc(fmtDate(r.data).slice(0, 10)) + '</td><td data-label="Pracownik">' + esc(r.osoba_name) + '</td><td data-label="Dział">' + esc(r.dzial || '—') + '</td><td data-label="Utylizacja">' + (r.uty || 0) + ' szt</td><td data-label="Zwrot">' + (r.zwr ? r.zwr + ' szt.' : '—') + '</td><td data-label="Powód">' + esc(r.powod || '—') + '</td>' +
						'<td class="msm-act"><button type="button" class="msm-iconbtn" data-utprint="' + r.id + '" title="Drukuj protokół" aria-label="Drukuj">' + ICON_PRINT + '</button></td></tr>';
				}).join('') + '</tbody></table>';
			box.querySelectorAll('[data-utprint]').forEach(function (b) { b.addEventListener('click', function () { window.open(printUrl({ msm_print: 'bhp_util', id: b.getAttribute('data-utprint') }), '_blank'); }); });
		}).catch(function (e) { box.innerHTML = '<p class="msm-alert msm-alert-err">' + esc(e.message) + '</p>'; });
	}

	function openUtylizacja(prefillOsoba) {
		var heldRows = [];
		var body = '<form class="msm-form" novalidate><div class="msm-form-err msm-alert msm-alert-err" hidden></div>' +
			'<div class="msm-grid">' +
			'<label class="msm-field" data-field="osoba"><span>Pracownik <i class="msm-req">*</i></span><select name="osoba"><option value="">— wczytywanie… —</option></select><em class="msm-ferr"></em></label>' +
			'<label class="msm-field"><span>Data</span><input type="date" name="data" value="' + new Date().toISOString().slice(0, 10) + '"></label>' +
			'<label class="msm-field"><span>Powód domyślny</span><select name="powod"><option value="">—</option>' + ['Zużycie', 'Zniszczenie', 'Koniec ważności', 'Utrata', 'Inny'].map(function (p) { return '<option>' + p + '</option>'; }).join('') + '</select></label>' +
			'</div>' +
			'<div class="msm-ut-held" data-held><p class="msm-muted msm-small">Wybierz pracownika, aby zobaczyć jego stan posiadania.</p></div>' +
			'<label class="msm-field full"><span>Uwagi</span><textarea name="uwagi" rows="2"></textarea></label>' +
			'<div class="msm-ut-sig"><span class="msm-small msm-muted">Podpis pracownika (opcjonalnie):</span><div class="msm-sigbox"><canvas data-sig width="520" height="150"></canvas></div><button type="button" class="msm-btn msm-btn-sm" data-sigclear>Wyczyść podpis</button></div>' +
			'</form>';
		var m = openModal('Nowa utylizacja / rozliczenie', body, '<button type="button" class="msm-btn" data-close>Anuluj</button><button type="button" class="msm-btn msm-btn-primary" data-save>Zapisz protokół</button>', true);
		var form = m.querySelector('form');
		var sel = form.querySelector('[name=osoba]');
		var sig = bindSigPad(form.querySelector('[data-sig]'));
		form.querySelector('[data-sigclear]').addEventListener('click', function () { sig.clear(); });
		api('/t/bhp_osoby', { query: { per_page: 500, orderby: 'imie_nazwisko', order: 'asc' } }).then(function (d) {
			var os = d.rows || [];
			sel.innerHTML = '<option value="">— wybierz —</option>' + os.map(function (o) { return '<option value="' + o.id + '" data-dzial="' + esc(o.dzial || '') + '">' + esc(o.imie_nazwisko) + (o.dzial ? ' · ' + esc(o.dzial) : '') + '</option>'; }).join('');
			if (prefillOsoba) { sel.value = prefillOsoba.id; loadHeld(); }
		});
		sel.addEventListener('change', loadHeld);
		function loadHeld() {
			var box = form.querySelector('[data-held]'); var id = +sel.value;
			if (!id) { box.innerHTML = '<p class="msm-muted msm-small">Wybierz pracownika…</p>'; return; }
			box.innerHTML = '<div class="msm-loading">Ładowanie stanu posiadania…</div>';
			api('/bhp/held/' + id).then(function (res) {
				heldRows = res.lines || [];
				if (!heldRows.length) { box.innerHTML = '<p class="msm-muted msm-small">Ten pracownik nie ma nic na wyposażeniu.</p>'; return; }
				box.innerHTML = '<div class="msm-ut-hd">Na wyposażeniu teraz – zaznacz, co zutylizować lub zwrócić na magazyn:</div>' +
					'<table class="msm-table msm-ut-tab"><thead><tr><th></th><th>Asortyment / nazwa</th><th>Rozm.</th><th>Ma</th><th>Operacja</th><th>Ilość</th><th>Powód</th></tr></thead><tbody>' +
					heldRows.map(function (l, i) {
						return '<tr><td class="msm-sel"><input type="checkbox" data-uchk="' + i + '"></td>' +
							'<td data-label="Asortyment">' + esc((l.kategoria ? l.kategoria + ' · ' : '') + l.nazwa) + '</td><td data-label="Rozm.">' + esc(l.rozmiar || '—') + '</td><td data-label="Ma"><b>' + l.held + '</b></td>' +
							'<td data-label="Operacja"><select data-utyp="' + i + '"><option value="utylizacja">Utylizacja</option><option value="zwrot">Zwrot na magazyn</option></select></td>' +
							'<td data-label="Ilość"><input type="text" inputmode="numeric" data-uqty="' + i + '" value="' + l.held + '"></td>' +
							'<td data-label="Powód"><input type="text" data-upow="' + i + '" placeholder="np. zużycie"></td></tr>';
					}).join('') + '</tbody></table>';
			}).catch(function (e) { box.innerHTML = '<p class="msm-err">' + esc(e.message) + '</p>'; });
		}
		m.querySelector('[data-save]').addEventListener('click', function () {
			var id = +sel.value; if (!id) { toast('Wybierz pracownika.', 'err'); return; }
			var lines = [];
			heldRows.forEach(function (l, i) {
				var chk = form.querySelector('[data-uchk="' + i + '"]'); if (!chk || !chk.checked) return;
				var q = parseInt(form.querySelector('[data-uqty="' + i + '"]').value, 10) || 0; if (q < 1) return;
				lines.push({ typ: form.querySelector('[data-utyp="' + i + '"]').value, kategoria: l.kategoria, nazwa: l.nazwa, rozmiar: l.rozmiar, ilosc: q, powod: form.querySelector('[data-upow="' + i + '"]').value });
			});
			if (!lines.length) { toast('Zaznacz przynajmniej jedną pozycję.', 'err'); return; }
			var payload = { osoba_id: id, dzial: sel.options[sel.selectedIndex].getAttribute('data-dzial') || '', data: form.querySelector('[name=data]').value, powod: form.querySelector('[name=powod]').value, uwagi: form.querySelector('[name=uwagi]').value, podpis: sig.data(), lines: lines };
			var btn = this; btn.disabled = true;
			api('/bhp/util', { method: 'POST', body: payload }).then(function (res) {
				closeModal(); invalidate('bhp'); if (current === 'bhp') refresh('bhp'); if (current === 'bhp_util') loadUtylizacje();
				var doc = res.doc || {};
				var mm = openModal('Protokół zapisany', '<p>' + esc(res.message || 'Zapisano.') + '</p><p class="msm-muted msm-small">Zutylizowane rzeczy zeszły ze stanu posiadania. Zwrócone wróciły na magazyn BHP.</p>',
					'<button type="button" class="msm-btn" data-close>Zamknij</button>' + (doc.id ? '<button type="button" class="msm-btn msm-btn-primary" data-pr>Drukuj protokół</button>' : ''));
				var pr = mm.querySelector('[data-pr]');
				if (pr) pr.addEventListener('click', function () { window.open(printUrl({ msm_print: 'bhp_util', id: doc.id }), '_blank'); });
			}).catch(function (e) { btn.disabled = false; if (document.body.contains(form)) { showErrors(form, e); } else { toast(e.message || 'Błąd.', 'err'); } });
		});
	}

	function renderDoWymiany() {
		var main = document.getElementById('msm-main');
		main.innerHTML = '<div class="msm-cat"><div class="msm-pagehead"><div><h1>Do wymiany</h1><p class="msm-muted">Wyposażenie, którego termin wymiany (wg norm) już minął</p></div></div><div class="msm-table-wrap" data-wym><div class="msm-loading">Ładowanie…</div></div></div>';
		var box = main.querySelector('[data-wym]');
		api('/bhp/do-wymiany').then(function (rows) {
			if (!rows.length) { box.innerHTML = '<div class="msm-card msm-empty"><p class="msm-muted">Nic nie wymaga wymiany. 👍</p><p class="msm-small msm-muted">Terminy ustawisz w zakładce „Normy” (pole „Wymiana co [mies.]”).</p></div>'; return; }
			box.innerHTML = '<table class="msm-table"><thead><tr><th>Pracownik</th><th>Dział</th><th>Asortyment / nazwa</th><th>Rozm.</th><th>Ma</th><th>Wydano</th><th>Termin minął</th></tr></thead><tbody>' +
				rows.map(function (r) { return '<tr><td data-label="Pracownik">' + esc(r.osoba) + '</td><td data-label="Dział">' + esc(r.dzial || '—') + '</td><td data-label="Asortyment">' + esc((r.kategoria ? r.kategoria + ' · ' : '') + r.nazwa) + '</td><td data-label="Rozm.">' + esc(r.rozmiar || '—') + '</td><td data-label="Ma">' + r.held + '</td><td data-label="Wydano">' + esc(fmtDate(r.wydano).slice(0, 10)) + '</td><td data-label="Termin minął"><b class="msm-brak">' + esc(fmtDate(r.termin).slice(0, 10)) + '</b></td></tr>'; }).join('') + '</tbody></table>';
		}).catch(function (e) { box.innerHTML = '<p class="msm-alert msm-alert-err">' + esc(e.message) + '</p>'; });
	}
	/* ---------------- aplikacja na telefon (PWA) + powiadomienia ---------------- */

	var PWA = { reg: null, prompt: null };
	var NOTIF_KEY = 'msm_notif';

	function pwaNotifSupported() { return 'Notification' in window && 'serviceWorker' in navigator; }
	/* Włączone = zgoda przeglądarki + wybór użytkownika (można wyłączyć w aplikacji bez grzebania w ustawieniach). */
	function pwaNotifOn() {
		if (!pwaNotifSupported() || Notification.permission !== 'granted') return false;
		try { return localStorage.getItem(NOTIF_KEY) !== 'off'; } catch (e) { return true; }
	}

	function pwaNotify(title, body, tab) {
		if (!pwaNotifOn() || !PWA.reg) return;
		/* Gdy ktoś właśnie patrzy na aplikację, wystarczy komunikat w środku (toast). */
		if (!document.hidden && document.hasFocus()) return;
		var url = (C.appUrl || location.pathname) + '#' + tab;
		try {
			PWA.reg.showNotification(title, {
				body: body,
				tag: 'msm-' + tab, /* kolejne powiadomienie tego typu zastępuje poprzednie zamiast się mnożyć */
				renotify: true,
				icon: C.pwaIcon,
				badge: C.pwaIcon,
				data: { url: url }
			});
		} catch (e) { /* starsze przeglądarki */ }
	}

	function pwaSyncUi() {
		var sup = pwaNotifSupported(), on = pwaNotifOn(), denied = sup && Notification.permission === 'denied';
		root.querySelectorAll('[data-notif]').forEach(function (b) {
			b.hidden = !sup || !PWA.reg;
			var label = on ? 'Powiadomienia: włączone' : (denied ? 'Powiadomienia: zablokowane' : 'Włącz powiadomienia');
			var span = b.querySelector('span');
			(span || b).textContent = label;
			b.classList.toggle('is-on', on);
		});
		root.querySelectorAll('[data-install]').forEach(function (b) { b.hidden = !PWA.prompt; });
		/* Instrukcja: tam, gdzie przeglądarka nie daje przycisku (Firefox, iPhone), i gdy aplikacja nie jest już zainstalowana. */
		root.querySelectorAll('[data-howto]').forEach(function (b) { b.hidden = !!PWA.prompt || pwaStandalone(); });
	}

	function pwaToggleNotif() {
		if (!pwaNotifSupported()) return;
		if (pwaNotifOn()) {
			try { localStorage.setItem(NOTIF_KEY, 'off'); } catch (e) {}
			toast('Powiadomienia wyłączone.');
			return pwaSyncUi();
		}
		if (Notification.permission === 'denied') {
			toast('Powiadomienia są zablokowane w przeglądarce – odblokuj je w ustawieniach witryny (ikona kłódki przy adresie).', 'warn');
			return;
		}
		Notification.requestPermission().then(function (p) {
			if (p === 'granted') {
				try { localStorage.removeItem(NOTIF_KEY); } catch (e) {}
				toast('Powiadomienia włączone – dostaniesz informację o nowych wnioskach, także gdy aplikacja jest w tle.');
			}
			pwaSyncUi();
		});
	}

	function pwaStandalone() {
		return (window.matchMedia && matchMedia('(display-mode: standalone)').matches) || window.navigator.standalone === true;
	}

	function pwaBrowser() {
		var ua = navigator.userAgent;
		var ios = /iPhone|iPad|iPod/.test(ua) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
		if (ios) return 'ios';
		var android = /Android/.test(ua);
		if (/Firefox\//.test(ua)) return android ? 'ff-android' : 'ff-desktop';
		if (/SamsungBrowser/.test(ua)) return 'samsung';
		return android ? 'chrome-android' : 'chrome-desktop';
	}

	var HOWTO = {
		'ff-android': ['Dotknij <b>⋮</b> (trzy kropki) – w nowszym Firefoxie na dole ekranu, w starszym obok paska adresu.', 'Wybierz <b>„Zainstaluj”</b> albo <b>„Dodaj aplikację do ekranu głównego”</b>.', 'Potwierdź – ikona „Magazyn” pojawi się na ekranie głównym. Uruchamiaj magazyn z tej ikony.', 'Jeśli w menu jest tylko <b>„Dodaj do ekranu głównego”</b> (skrót), zamknij kartę, otwórz magazyn ponownie i odczekaj kilka sekund – Firefox musi najpierw wczytać opis aplikacji.'],
		'ios': ['Otwórz magazyn w <b>Safari</b> (od iOS 16.4 także Chrome/Firefox).', 'Dotknij <b>Udostępnij</b> (kwadrat ze strzałką).', 'Wybierz <b>„Do ekranu początkowego”</b> → <b>Dodaj</b>.', 'Powiadomienia na iPhonie działają tylko po uruchomieniu z tej ikony.'],
		'samsung': ['Dotknij <b>☰</b> na dole ekranu.', 'Wybierz <b>„Dodaj stronę do”</b> → <b>„Ekran startowy”</b>.'],
		'chrome-android': ['Dotknij <b>⋮</b> obok paska adresu.', 'Wybierz <b>„Zainstaluj aplikację”</b> (albo „Dodaj do ekranu głównego” → Zainstaluj).'],
		'ff-desktop': ['Firefox na komputerze nie instaluje aplikacji internetowych (na Windowsie tylko jako funkcja testowa w Ustawienia → Labs).', 'Na komputerze użyj Chrome lub Edge – w menu z inicjałami pojawi się „Zainstaluj aplikację”.'],
		'chrome-desktop': ['Kliknij ikonę instalacji po prawej stronie paska adresu albo menu <b>⋮</b> → <b>„Zapisz i udostępnij” / „Zainstaluj”</b>.']
	};

	/* Sprawdzenie warunków instalacji – wynik do pokazania na ekranie (i zrzutu dla administratora). */
	function pwaCheck() {
		var link = document.querySelector('link[rel="manifest"]');
		var checks = [
			{ ok: window.isSecureContext, t: 'Połączenie HTTPS' },
			{ ok: !!link, t: 'Strona wskazuje opis aplikacji (manifest)' }
		];
		var man = link ? fetch(link.href, { credentials: 'include' }).then(function (r) {
			var ct = r.headers.get('content-type') || '';
			return r.text().then(function (txt) {
				var j = null; try { j = JSON.parse(txt); } catch (e) {}
				return { ok: !!(r.ok && j && j.start_url && j.icons && j.icons.length), t: 'Manifest się wczytuje', d: j ? '' : ('serwer zwrócił ' + r.status + ', ' + (ct.split(';')[0] || 'brak typu') + ' zamiast JSON – sprawdź wtyczki cache/zabezpieczeń') };
			});
		}).catch(function (e) { return { ok: false, t: 'Manifest się wczytuje', d: e.message }; }) : Promise.resolve(null);
		var icon = fetch(C.pwaIcon, { method: 'HEAD' }).then(function (r) { return { ok: r.ok, t: 'Ikona aplikacji', d: r.ok ? '' : 'błąd ' + r.status }; }).catch(function () { return { ok: false, t: 'Ikona aplikacji' }; });
		var sw = ('serviceWorker' in navigator) ? navigator.serviceWorker.getRegistration(C.swScope).then(function (reg) {
			return { ok: !!(reg && (reg.active || reg.waiting || reg.installing)), t: 'Service worker (tryb offline, powiadomienia)', d: reg ? '' : 'nie zarejestrowany – zablokowany adres ' + C.sw };
		}) : Promise.resolve({ ok: false, t: 'Service worker', d: 'przeglądarka nie obsługuje' });
		return Promise.all([man, icon, sw]).then(function (r) {
			return checks.concat(r.filter(Boolean)).concat([
				{ ok: pwaStandalone(), t: 'Uruchomiona jako aplikacja', d: pwaStandalone() ? '' : 'teraz: zwykła karta przeglądarki', info: true },
				{ ok: pwaNotifOn(), t: 'Powiadomienia', d: pwaNotifSupported() ? (Notification.permission === 'denied' ? 'zablokowane w ustawieniach witryny' : (pwaNotifOn() ? '' : 'wyłączone')) : 'nieobsługiwane', info: true }
			]);
		});
	}

	function pwaHowto() {
		var br = pwaBrowser(), steps = HOWTO[br] || HOWTO['chrome-android'];
		var body = '<div class="msm-howto"><ol class="msm-howto__steps">' + steps.map(function (s) { return '<li>' + s + '</li>'; }).join('') + '</ol>' +
			'<h4 class="msm-howto__h">Sprawdzenie tego urządzenia</h4><ul class="msm-howto__checks" data-checks><li class="msm-muted">Sprawdzam…</li></ul>' +
			'<p class="msm-muted msm-small">Gdy coś jest na czerwono, zrób zrzut ekranu tego okna i wyślij administratorowi.</p></div>';
		openModal('Aplikacja na telefonie', body, '<button type="button" class="msm-btn msm-btn-primary" data-close>Zamknij</button>', false);
		pwaCheck().then(function (list) {
			var ul = document.querySelector('[data-checks]');
			if (!ul) return;
			ul.innerHTML = list.map(function (c) {
				var cls = c.ok ? 'is-ok' : (c.info ? 'is-info' : 'is-bad');
				return '<li class="' + cls + '"><i aria-hidden="true">' + (c.ok ? '✓' : (c.info ? '•' : '✕')) + '</i><span><b>' + esc(c.t) + '</b>' + (c.d ? '<small>' + esc(c.d) + '</small>' : '') + '</span></li>';
			}).join('') + '<li class="is-info"><i aria-hidden="true">•</i><span><b>Przeglądarka</b><small>' + esc(navigator.userAgent) + '</small></span></li>';
		});
	}

	function pwaInit() {
		/* Przycisk „Zainstaluj” (Chrome/Edge/Android). Na iPhonie: Udostępnij → „Do ekranu początkowego”. */
		window.addEventListener('beforeinstallprompt', function (e) { e.preventDefault(); PWA.prompt = e; pwaSyncUi(); });
		window.addEventListener('appinstalled', function () { PWA.prompt = null; pwaSyncUi(); toast('Aplikacja zainstalowana.'); });

		root.addEventListener('click', function (e) {
			var n = e.target.closest('[data-notif]'), i = e.target.closest('[data-install]'), h = e.target.closest('[data-howto]');
			if (h) { e.preventDefault(); pwaHowto(); return; }
			if (n) { e.preventDefault(); pwaToggleNotif(); }
			if (i && PWA.prompt) {
				e.preventDefault();
				PWA.prompt.prompt();
				PWA.prompt.userChoice.then(function () { PWA.prompt = null; pwaSyncUi(); });
			}
		});

		if (!('serviceWorker' in navigator) || !C.sw || !window.isSecureContext) return pwaSyncUi();
		navigator.serviceWorker.register(C.sw, { scope: C.swScope }).then(function (reg) {
			PWA.reg = reg;
			pwaSyncUi();
		}).catch(function () { pwaSyncUi(); });
		/* Kliknięcie w powiadomienie przy otwartej aplikacji → przejście do zakładki bez przeładowania. */
		navigator.serviceWorker.addEventListener('message', function (e) {
			if (e.data && e.data.type === 'msm-goto') {
				var h = new URL(e.data.url, location.href).hash;
				if (h && h !== location.hash) location.hash = h;
			}
		});
	}
	/* ================================================================
	   PRODUKCJA – arkusz zleceń edytowany jak w Excelu (kolumny A–O, arkusz 2026)
	   Bez sortowania: kolejność stała, nowe zlecenia na końcu.
	   ================================================================ */

	/* k: z = pole zlecenia (scalone nad detalami), d = pole detalu, c = wyliczane */
	var PCOLS = [
		{ f: 'uwagi', k: 'd', l: 'Uwagi', w: 70, rich: true },
		{ f: 'nr_zlec', k: 'z', l: 'Nr zlec.', w: 92 },
		{ f: 'start_zlec', k: 'z', l: 'Start zlec.', w: 100 },
		{ f: 'koniec_zlec', k: 'z', l: 'Zakoń\u00ADczenie zlec.', w: 100 },
		{ f: 'dostepnosc', k: 'd', l: 'Dostęp\u00ADność przyrzą\u00ADdów / spraw\u00ADdzianów', w: 160 },
		{ f: 'wersja', k: 'd', l: 'Wer\u00ADsja', w: 52 },
		{ f: 'laser', k: 'd', l: 'La\u00ADser', w: 42, laser: true },
		{ f: 'material', k: 'd', l: 'Materiał', w: 112 },
		{ f: 'mat_klienta', k: 'd', l: 'Mat. klien\u00ADta', w: 50, bool: true },
		{ f: 'czas_ciecia', k: 'd', l: 'Czas cię\u00ADcia [s]', w: 58, sec: true },
		{ f: 'klient', k: 'z', l: 'Nazwa klien\u00ADta', w: 118 },
		{ f: 'nr_zlec_klienta', k: 'z', l: 'Nr zlec. klien\u00ADta', w: 112 },
		{ f: 'nazwa_detalu', k: 'd', l: 'Nazwa detali', w: 138 },
		{ f: 'nr_rysunku', k: 'd', l: 'Nr rysunku', w: 150 },
		{ f: 'ilosc_zam', k: 'd', l: 'Ilość zam.', w: 68, num: true },
		{ f: 'wykonano', k: 'd', l: 'Wy\u00ADkon.', w: 66, num: true },
		{ f: 'proc', k: 'c', l: '% wy\u00ADkon.', w: 58, num: true },
		{ f: 'zostalo', k: 'c', l: 'Zo\u00ADstało', w: 64, num: true }
	];

	function pgProc(d) {
		if (!(d.ilosc_zam > 0)) return 0;
		var v = 100 * d.wykonano / d.ilosc_zam;
		return Math.round(v * 10) / 10;
	}
	function pgVal(o, d, col) {
		if (col.f === 'proc') return pgProc(d);
		if (col.f === 'zostalo') return d.ilosc_zam - d.wykonano;
		if (col.bool) return d[col.f] ? 'tak' : '';
		return col.k === 'z' ? o[col.f] : d[col.f];
	}
	function toBool(v) { return /^(1|tak|t|x|true|yes|y|✓)$/i.test(String(v == null ? '' : v).trim()) ? 1 : 0; }
	/* Wpis z siatki → wartość do zapisu; null = niepoprawny (komunikat już pokazany). */
	function pgIn(col, v) {
		v = v == null ? '' : String(v);
		if (col.num) {
			if (v.trim() !== '' && isNaN(parseFloat(v.replace(/\s/g, '').replace(',', '.')))) { toast('„' + pgLbl(col) + '”: „' + v + '” nie jest liczbą.', 'err'); return null; }
			return String(toIntG(v));
		}
		if (col.bool) return toBool(v) ? 'tak' : '';
		if (col.rich) return textToHtml(v);
		if (col.sec) {
			var sv = parseSec(v);
			if (sv === null) { toast('„Czas cięcia [s]”: wpisz liczbę sekund, np. 54 albo 12,5.', 'err'); return null; }
			return sv;
		}
		if (col.laser) {
			v = v.trim().toUpperCase();
			if (v !== '' && v !== 'L1' && v !== 'L2') { toast('„Laser” może mieć tylko wartość L1 albo L2.', 'err'); return null; }
		}
		return v;
	}
	/* „54 s.”, „12,56 sek.”, „5min 24 sek” → „54”, „12,56”, „324”; '' gdy puste; null gdy nieczytelne (jak MSM_Prod::parse_sec). */
	function parseSec(v) {
		v = String(v == null ? '' : v).replace(/\u00a0/g, ' ').trim().toLowerCase();
		if (v === '' || v === 'brak' || v === '-' || v === '–' || v === '—') return '';
		var num = '(\\d+(?:[.,]\\d+)?)', sfx = '(?:\\s*(?:s|sek|sekund[ay]?)\\.?)?', m, sec;
		if ((m = v.match(new RegExp('^(\\d+)\\s*min\\.?(?:\\s*' + num + sfx + ')?$')))) sec = 60 * +m[1] + (m[2] ? parseFloat(m[2].replace(',', '.')) : 0);
		else if ((m = v.match(new RegExp('^' + num + sfx + '$')))) sec = parseFloat(m[1].replace(',', '.'));
		else return null;
		return String(Math.round(sec * 100) / 100).replace('.', ',');
	}
	function toIntG(v) { var n = parseFloat(String(v == null ? '' : v).replace(/\s/g, '').replace(',', '.')); return isNaN(n) ? 0 : Math.round(n); }
	/* Jednostka w nagłówku („[s]”) zawsze małą literą, mimo wersalików nagłówków. */
	function unitLbl(t) { return esc(t).replace(/\[(\w+)\]/g, '<span class="msm-unit">[$1]</span>'); }
	function pgLbl(col) { return col.l.replace(/\u00AD/g, ''); }
	function pgShow(v, col) {
		if (col.num) return v === '' || v == null ? '' : fmtNum(v);
		if (col.rich) return rteText(v);
		return v == null ? '' : String(v);
	}

	/* ================================================================
	   Prosty edytor tekstu (pogrubienie, pochylenie, podkreślenie, listy)
	   Wartość: HTML z b/i/u/ol/ul/li/br albo zwykły tekst (stare wpisy).
	   ================================================================ */
	var RTE_RX = /<(b|strong|i|em|u|ol|ul|li|br|p|div)\b/i;
	function rteIsHtml(v) { return RTE_RX.test(String(v || '')); }
	function textToHtml(s) { return esc(String(s == null ? '' : s)).replace(/\r?\n/g, '<br>'); }
	function rteIn(v) { v = v == null ? '' : String(v); return rteIsHtml(v) ? rteClean(v) : textToHtml(v); }
	/* Czyszczenie HTML (także wklejonego z Worda/Excela): zostają tylko b, i, u, listy i nowe linie. */
	function rteClean(html) {
		var t = document.createElement('template'); t.innerHTML = String(html || '');
		function block(out) { return out && !/(<br>|<\/ol>|<\/ul>)$/.test(out); }
		function walk(node) {
			var out = '';
			node.childNodes.forEach(function (n) {
				if (n.nodeType === 3) { out += esc(n.nodeValue.replace(/[\r\n]+/g, ' ')); return; }
				if (n.nodeType !== 1) return;
				var tag = n.tagName.toLowerCase(), inner;
				if (tag === 'strong') tag = 'b';
				if (tag === 'em') tag = 'i';
				if (tag === 'span' && n.style) { // np. wklejone z Worda: <span style="font-weight:bold">
					inner = walk(n);
					if (/^(bold|[6-9]00)$/.test(n.style.fontWeight)) inner = '<b>' + inner + '</b>';
					if (n.style.fontStyle === 'italic') inner = '<i>' + inner + '</i>';
					if (/underline/.test(n.style.textDecoration || n.style.textDecorationLine || '')) inner = '<u>' + inner + '</u>';
					out += inner; return;
				}
				if (tag === 'br') { out += '<br>'; return; }
				if (tag === 'b' || tag === 'i' || tag === 'u') { inner = walk(n); if (inner.replace(/<br>/g, '').trim()) out += '<' + tag + '>' + inner + '</' + tag + '>'; return; }
				if (tag === 'ol' || tag === 'ul') {
					var li = '';
					n.childNodes.forEach(function (c) { if (c.nodeType === 1 && c.tagName.toLowerCase() === 'li') li += '<li>' + walk(c).replace(/(<br>)+$/, '') + '</li>'; });
					if (li) out += '<' + tag + '>' + li + '</' + tag + '>';
					return;
				}
				if (tag === 'li') { out += '<li>' + walk(n) + '</li>'; return; }
				if (tag === 'div' || tag === 'p' || /^h[1-6]$/.test(tag)) {
					inner = walk(n);
					if (block(out)) out += '<br>';
					out += inner === '' ? '<br>' : inner;
					return;
				}
				if (tag === 'style' || tag === 'script' || tag === 'meta' || tag === 'title') return;
				out += walk(n);
			});
			return out;
		}
		var r = walk(t.content).replace(/<br>(<(?:ol|ul)>)/g, '$1').replace(/(<br>\s*)+$/, '').replace(/^\s+|\s+$/g, '');
		var tmp = document.createElement('div'); tmp.innerHTML = r;
		return ((tmp.textContent || '').trim() || /<li>/.test(r)) ? r : '';
	}
	/* Zwykły tekst (siatka, kopiowanie): listy jako „1.” i „•”. */
	function rteText(v) {
		v = v == null ? '' : String(v);
		if (!rteIsHtml(v)) return v;
		var t = document.createElement('template'); t.innerHTML = v;
		function walk(node) {
			var out = '';
			node.childNodes.forEach(function (n) {
				if (n.nodeType === 3) { out += n.nodeValue; return; }
				if (n.nodeType !== 1) return;
				var tag = n.tagName.toLowerCase();
				if (tag === 'br') { out += '\n'; return; }
				if (tag === 'ol' || tag === 'ul') {
					var k = 0;
					if (out && !/\n$/.test(out)) out += '\n';
					n.childNodes.forEach(function (c) { if (c.nodeType === 1) out += (tag === 'ol' ? (++k) + '. ' : '• ') + walk(c).trim() + '\n'; });
					return;
				}
				if ((tag === 'div' || tag === 'p') && out && !/\n$/.test(out)) out += '\n';
				out += walk(n);
			});
			return out;
		}
		return walk(t.content).replace(/\n{3,}/g, '\n\n').trim();
	}
	var RTE_BTN = [
		['bold', 'Pogrubienie (Ctrl+B)', '<path d="M7 5h6a3.5 3.5 0 0 1 0 7H7zM7 12h7a3.5 3.5 0 0 1 0 7H7z"/>'],
		['italic', 'Pochylenie (Ctrl+I)', '<path d="M14 5h-4M14 19h-4M15 5l-6 14"/>'],
		['underline', 'Podkreślenie (Ctrl+U)', '<path d="M7 4v7a5 5 0 0 0 10 0V4M5 20h14"/>'],
		'|',
		['insertOrderedList', 'Lista numerowana', '<path d="M10 6h10M10 12h10M10 18h10"/><path d="M4 5h1v4M4 9h2M4 14.5a1 1 0 0 1 2 .3c0 .6-2 1.7-2 2.7h2" stroke-width="1.6"/>'],
		['insertUnorderedList', 'Lista punktowana', '<path d="M10 6h10M10 12h10M10 18h10"/><circle cx="5" cy="6" r="1.2" fill="currentColor"/><circle cx="5" cy="12" r="1.2" fill="currentColor"/><circle cx="5" cy="18" r="1.2" fill="currentColor"/>'],
		'|',
		['removeFormat', 'Wyczyść formatowanie', '<path d="M6 5h12M12 5l-3 14M15 15l5 5M20 15l-5 5"/>']
	];
	/* attrs – atrybuty pola (data-f / data-kk …), value – HTML albo tekst. */
	function rteHtml(attrs, value, ph) {
		return '<div class="msm-rte"><div class="msm-rte__bar" role="toolbar" aria-label="Formatowanie">' +
			RTE_BTN.map(function (b) {
				return b === '|' ? '<i class="msm-rte__sep" aria-hidden="true"></i>' :
					'<button type="button" tabindex="-1" data-rte="' + b[0] + '" title="' + b[1] + '" aria-label="' + b[1] + '"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + b[2] + '</svg></button>';
			}).join('') + '</div>' +
			'<div class="msm-rte__area" contenteditable="true" role="textbox" aria-multiline="true" spellcheck="false"' + attrs + (ph ? ' data-ph="' + esc(ph) + '"' : '') + '>' + rteIn(value) + '</div></div>';
	}
	function rteBind(scope) {
		scope.querySelectorAll('.msm-rte').forEach(function (box) {
			if (box._rte) return; box._rte = true;
			var area = box.querySelector('.msm-rte__area');
			function state() {
				box.querySelectorAll('[data-rte]').forEach(function (b) {
					var c = b.getAttribute('data-rte'), on = false;
					try { on = c !== 'removeFormat' && document.queryCommandState(c); } catch (e) {}
					b.classList.toggle('is-on', !!on && document.activeElement === area);
				});
			}
			box.querySelectorAll('[data-rte]').forEach(function (b) {
				b.addEventListener('mousedown', function (e) { e.preventDefault(); }); // zaznaczenie zostaje w polu
				b.addEventListener('click', function () {
					if (document.activeElement !== area) area.focus();
					var c = b.getAttribute('data-rte');
					document.execCommand(c, false, null);
					if (c === 'removeFormat') { // listy też zamieniamy na zwykłe linie
						['insertOrderedList', 'insertUnorderedList'].forEach(function (x) { try { if (document.queryCommandState(x)) document.execCommand(x, false, null); } catch (e) {} });
					}
					state();
				});
			});
			area.addEventListener('paste', function (e) {
				var cd = e.clipboardData; if (!cd) return;
				e.preventDefault();
				var h = cd.getData('text/html'), tx = cd.getData('text/plain');
				document.execCommand('insertHTML', false, h ? rteClean(h) : textToHtml(tx));
			});
			area.addEventListener('keyup', state); area.addEventListener('mouseup', state);
			area.addEventListener('focus', function () { box.classList.add('is-focus'); state(); });
			area.addEventListener('blur', function () { box.classList.remove('is-focus'); state(); });
		});
	}
	function rteValue(area) { return rteClean(area.innerHTML); }
	function rteSame(a, b) { return rteClean(rteIn(a)) === rteClean(rteIn(b)); }

	/* Odmiana: 1 zlecenie, 2 zlecenia, 5 zleceń. */
	/* ================================================================
	   Menu podręczne (⋯)
	   ================================================================ */
	var POP = null;
	function popMenu(anchor, title, items) {
		closePop();
		POP = document.createElement('div');
		POP.className = 'msm-pg-menu';
		POP.innerHTML = (title ? '<div class="msm-pg-menu__t">' + esc(title) + '</div>' : '') + items.map(function (it, i) {
			return it === '-' ? '<hr>' : '<button type="button" data-i="' + i + '"' + (it.disabled ? ' disabled' : '') + (it.danger ? ' class="is-danger"' : '') + '>' + esc(it.label) + '</button>';
		}).join('');
		root.appendChild(POP);
		var b = anchor.getBoundingClientRect();
		POP.style.left = Math.max(8, Math.min(b.right - POP.offsetWidth, window.innerWidth - POP.offsetWidth - 8)) + 'px';
		POP.style.top = Math.min(b.bottom + 6, window.innerHeight - POP.offsetHeight - 8) + 'px';
		POP.addEventListener('click', function (e) {
			var btn = e.target.closest('button[data-i]'); if (!btn || btn.disabled) return;
			var it = items[+btn.getAttribute('data-i')]; closePop(); it.run();
		});
		setTimeout(function () { document.addEventListener('mousedown', outsidePop); }, 0);
	}
	function outsidePop(e) { if (POP && !POP.contains(e.target)) closePop(); }
	function closePop() { if (POP && POP.parentNode) POP.parentNode.removeChild(POP); POP = null; document.removeEventListener('mousedown', outsidePop); }
	var ICO_DOTS = '<svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><circle cx="5" cy="12" r="1.8"/><circle cx="12" cy="12" r="1.8"/><circle cx="19" cy="12" r="1.8"/></svg>';
	function plN(n, one, few, many) { var m10 = n % 10, m100 = n % 100; return n + ' ' + (n === 1 ? one : (m10 >= 2 && m10 <= 4 && (m100 < 12 || m100 > 14)) ? few : many); }
	/* ---- wyszukiwanie: bez wielkości liter i polskich znaków, „29,93” = „29.93” ---- */
	function srchNorm(s) {
		return String(s == null ? '' : s).toLowerCase().replace(/ł/g, 'l').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/,/g, '.').replace(/\s+/g, ' ');
	}
	/* Cały tekst zlecenia: wszystkie pola zlecenia, karty projektu (z tabelami), pozycji, rezerwacji i numery palet. */
	var HAY_SKIP = { palety_n: 1, notatki_n: 1, karty_n: 1, pobrania_n: 1, id: 1, zlec_id: 1, poz: 1, updated_by: 1, updated_at: 1, arkusz: 1, table: 1, det_id: 1, status: 1, jedn: 1 };
	var HAY_RICH = { uwagi: 1, uwagi_ogolne: 1, nabywca: 1, odbiorca: 1, pal_nadawca: 1, pal_odbiorca: 1 };
	function hayOf(v, key, out) {
		if (v == null || HAY_SKIP[key]) return out;
		if (Array.isArray(v)) { v.forEach(function (x) { hayOf(x, '', out); }); return out; }
		if (typeof v === 'object') { Object.keys(v).forEach(function (k) { hayOf(v[k], k, out); }); return out; }
		if (key === 'mat_klienta') { if (+v) out.push('material klienta'); return out; }
		out.push(HAY_RICH[key] ? rteText(v) : String(v));
		return out;
	}
	function orderHay(o) {
		var t = hayOf(o, '', []);
		var s = orderSums(o);
		t.push(fmtNum(s.proc, 1) + '%');
		return srchNorm(t.join(' | '));
	}
	function orderSums(o) {
		var z = 0, w = 0;
		o.det.forEach(function (d) { z += d.ilosc_zam || 0; w += d.wykonano || 0; });
		return { zam: z, wyk: w, proc: z > 0 ? Math.round(1000 * w / z) / 10 : 0, zost: z - w };
	}

	/* Trasa: #produkcja (lista zleceń) albo #prod-<id> (strona zlecenia). */
	function renderProdukcja(zid, tab, noteId) {
		var main = document.getElementById('msm-main');
		var DETAIL = !!zid;
		var TAB = tab || 'karta';
		var narrow = window.matchMedia('(max-width: 1180px)').matches;
		var view = (function () { try { return localStorage.getItem('msm_pg_view') || 'cards'; } catch (e) { return 'cards'; } })();
		if (narrow) view = 'cards'; // tabela 15 kolumn tylko na szerszych ekranach
		var DATA = null, ORDER = null;
		function ORDERS() { return DETAIL ? (ORDER ? [ORDER] : []) : DATA.orders; }

		if (DETAIL) {
			main.innerHTML = '<div class="msm-cat msm-pg-page" data-pgdetail><div class="msm-loading">Ładowanie zlecenia…</div></div>';
		} else {
			main.innerHTML = '<div class="msm-cat msm-pg-page"><div class="msm-pagehead"><div><h1 class="msm-pg-h1">Zlecenia <label class="msm-pgrok"><span class="msm-sr">Rok</span><select data-pgrok aria-label="Rok listy zleceń"></select></label></h1><p class="msm-muted" data-pgcount>&nbsp;</p></div>' +
				'<div class="msm-pagehead__tools"><button type="button" class="msm-btn msm-btn-primary" data-pgkarta title="Wczytaj kartę projektu (.xlsx) i utwórz z niej zlecenie">+ Zlecenie z karty projektu</button><button type="button" class="msm-btn" data-pgadd>+ Puste zlecenie</button>' +
				'<button type="button" class="msm-btn" data-pgimp title="Dopisz nowe zlecenia z arkusza Produkcji (.xlsx) – istniejących nie zmienia">Import z Excela</button>' + xbtn('xlsx', 'data-pgexp="xlsx"') + xbtn('csv', 'data-pgexp="csv"') + '</div></div>' +
				'<div class="msm-filters" aria-label="Filtry" data-pgfwrap hidden><div class="msm-filters__body msm-pgf" data-pgflt></div></div>' +
				'<div data-pg><div class="msm-table-wrap"><div class="msm-loading">Ładowanie…</div></div></div></div>';
			main.querySelectorAll('[data-pgexp]').forEach(function (b) {
				b.addEventListener('click', function () { window.location.href = buildUrl('/prod/export', { format: b.getAttribute('data-pgexp'), rok: DATA ? DATA.sheet : '', _wpnonce: C.nonce }); });
			});
			main.querySelector('[data-pgadd]').addEventListener('click', addOrder);
			main.querySelector('[data-pgimp]').addEventListener('click', importPick);
			main.querySelector('[data-pgkarta]').addEventListener('click', function () { pickKarta(function (res) { kartaPreview(res, null); }); });
		}
		var host = main.querySelector(DETAIL ? '[data-pgdetail]' : '[data-pg]');
		/* Rok listy zleceń: zapamiętany w karcie przeglądarki; domyślnie bieżący rok. */
		var ROK = (function () { try { return sessionStorage.getItem('msm_pg_rok') || ''; } catch (e) { return ''; } })();
		function drawYears() {
			var sel = main.querySelector('[data-pgrok]'); if (!sel) return;
			sel.innerHTML = (DATA.lata || [DATA.sheet]).map(function (y) { return '<option value="' + y + '"' + (y === DATA.sheet ? ' selected' : '') + '>' + y + (y === DATA.biezacy ? '' : '') + '</option>'; }).join('');
			if (!sel._b) {
				sel._b = true;
				sel.addEventListener('change', function () {
					ROK = sel.value;
					try { sessionStorage.setItem('msm_pg_rok', ROK === DATA.biezacy ? '' : ROK); } catch (e) {}
					FLT.klient = {}; fSave(); // klienci są inni w każdym roku
					var f = main.querySelector('[data-pgflt]'); if (f) f.innerHTML = '';
					host.innerHTML = '<div class="msm-table-wrap"><div class="msm-loading">Ładowanie…</div></div>';
					load();
				});
			}
		}
		/* Strona zlecenia zawsze od góry; lista wraca do miejsca, z którego otwarto zlecenie. */
		if (DETAIL) window.scrollTo(0, 0);
		function rememberListPos() { try { sessionStorage.setItem('msm_pg_y', String(window.scrollY)); } catch (e) {} }
		var gridHost = null; // kontener tabeli (widok „Tabela” na stronie zlecenia)

		function load() {
			return api('/prod', { query: DETAIL ? { zlec: zid } : (ROK ? { rok: ROK } : {}) }).then(function (d) {
				DATA = d;
				if (!DETAIL) drawYears();
				if (!DETAIL) return renderList();
				ORDER = null;
				d.orders.forEach(function (o) { if (o.id === zid) ORDER = o; });
				if (!ORDER) { host.innerHTML = '<div class="msm-card msm-empty"><p class="msm-muted">To zlecenie nie istnieje (mogło zostać usunięte).</p><p><a class="msm-btn" href="#produkcja">‹ Wróć do Produkcji</a></p></div>'; return; }
				renderDetail();
			}).catch(function (e) { host.innerHTML = '<p class="msm-alert msm-alert-err">' + esc(e.message) + '</p>'; });
		}
		function rerender() { if (!DETAIL) return renderList(); renderDetail(); }

		/* ---------------- zapis ---------------- */
		function applyServer(res) {
			(res.z || []).forEach(function (z) {
				DATA.orders.forEach(function (o) { if (o.id === z.id) Object.keys(z).forEach(function (k) { if (k !== 'det') o[k] = z[k]; }); });
			});
			(res.d || []).forEach(function (nd) {
				DATA.orders.forEach(function (o) { o.det.forEach(function (d) { if (d.id === nd.id) Object.keys(nd).forEach(function (k) { d[k] = nd[k]; }); }); }); // w miejscu – widoki trzymają odwołania
			});
		}
		/* changes: [{k, id, f, v, old}] – zapis optymistyczny, przy błędzie przywrócenie */
		function save(changes, opts) {
			changes = changes.filter(function (c) { return String(c.old == null ? '' : c.old) !== String(c.v == null ? '' : c.v); });
			if (!changes.length) return Promise.resolve();
			setLocal(changes, 'v');
			if (!(opts && opts.noUndo)) { UNDO.push(changes); REDO.length = 0; }
			afterLocal(changes, true);
			return api('/prod/cells', { method: 'POST', body: { changes: changes.map(function (c) { return { k: c.k, id: c.id, f: c.f, v: c.v }; }) } })
				.then(function (res) { applyServer(res); afterLocal(changes, false); })
				.catch(function (e) {
					setLocal(changes, 'old');
					if (!(opts && opts.noUndo)) UNDO.pop();
					afterLocal(changes, false, true);
					toast(e.message, 'err');
				});
		}
		/* Odświeżenie tego, co widać: tabela albo karty zlecenia. */
		function afterLocal(changes, saving, reverted) {
			if (GRID.ready) GRID.refresh(changes, saving);
			if (DETAIL && view === 'cards' && host.querySelector('[data-pgcards]')) syncCards(changes, saving, reverted);
			if (DETAIL) syncHead();
		}
		function setLocal(changes, which) {
			changes.forEach(function (c) {
				DATA.orders.forEach(function (o) {
					if (c.k === 'z' && o.id === c.id) o[c.f] = c[which];
					if (c.k === 'd') o.det.forEach(function (d) { if (d.id === c.id) d[c.f] = numCol(c.f) ? toInt(c[which]) : (c.f === 'mat_klienta' ? toBool(c[which]) : c[which]); });
				});
			});
		}
		function numCol(f) { return f === 'ilosc_zam' || f === 'wykonano'; }
		function toInt(v) { var n = parseFloat(String(v == null ? '' : v).replace(/\s/g, '').replace(',', '.')); return isNaN(n) ? 0 : Math.round(n); }
		var UNDO = [], REDO = [];
		function undo(redo) {
			var st = redo ? REDO : UNDO, other = redo ? UNDO : REDO;
			var b = st.pop();
			if (!b) return;
			var rev = b.map(function (c) { return { k: c.k, id: c.id, f: c.f, v: redo ? c.v : c.old, old: redo ? c.old : c.v }; });
			other.push(b);
			save(rev, { noUndo: true });
			toast(redo ? 'Ponowiono zmianę.' : 'Cofnięto zmianę.');
		}

		/* ---------------- akcje na zleceniach / detalach ---------------- */
		function addOrder() {
			api('/prod/order', { method: 'POST', body: { rok: DATA ? DATA.sheet : '' } }).then(function (r) {
				sessionStorage.setItem('msm_pg_new', '1');
				location.hash = '#prod-' + r.order.id;
			}).catch(function (e) { toast(e.message, 'err'); });
		}
		function replaceOrder(order) {
			DATA.orders.forEach(function (o, i) { if (o.id === order.id) DATA.orders[i] = order; });
			if (ORDER && ORDER.id === order.id) ORDER = order;
		}
		function addDetail(o, afterId) {
			api('/prod/det', { method: 'POST', body: { zlec_id: o.id, after_id: afterId || 0 } }).then(function (r) {
				replaceOrder(r.order);
				rerender();
				if (view === 'table' && GRID.ready) { var idx = GRID.rowOfDetail(r.id); GRID.select(idx >= 0 ? idx : 0, 9); GRID.scrollToActive(); }
				else { var f = host.querySelector('[data-det="' + r.id + '"] [data-f="nazwa_detalu"]'); if (f) { f.scrollIntoView({ block: 'center' }); f.focus(); } }
			}).catch(function (e) { toast(e.message, 'err'); });
		}
		function delDetail(o, d) {
			if (o.det.length <= 1) { toast('To jedyny detal zlecenia – usuń całe zlecenie.', 'warn'); return; }
			confirmBox('Usunąć detal?', '„' + esc(d.nazwa_detalu || 'detal bez nazwy') + '” ze zlecenia ' + esc(o.nr_zlec || '') + '. Zapis trafi do Historii zmian.', 'Usuń detal').then(function (ok) {
				if (!ok) return;
				api('/prod/det/' + d.id + '/delete', { method: 'POST' }).then(function (r) { replaceOrder(r.order); rerender(); toast('Usunięto detal.'); }).catch(function (e) { toast(e.message, 'err'); });
			});
		}
		function delOrder(o) {
			confirmBox('Usunąć zlecenie ' + (o.nr_zlec || '') + '?', 'Zlecenie z ' + o.det.length + ' detalami zniknie z listy razem ze swoimi paletówkami (ich numery wrócą do puli). Zapis trafi do Historii zmian.', 'Usuń zlecenie').then(function (ok) {
				if (!ok) return;
				api('/prod/order/' + o.id + '/delete', { method: 'POST' }).then(function () {
					toast('Usunięto zlecenie.');
					if (DETAIL) { location.hash = '#produkcja'; return; }
					DATA.orders = DATA.orders.filter(function (x) { return x.id !== o.id; });
					rerender();
				}).catch(function (e) { toast(e.message, 'err'); });
			});
		}
		function moveOrder(o, dir) {
			var i = DATA.orders.indexOf(o), j = i + dir;
			if (j < 0 || j >= DATA.orders.length) return;
			api('/prod/order/' + o.id + '/move', { method: 'POST', body: { dir: dir } }).then(function () {
				DATA.orders[i] = DATA.orders[j]; DATA.orders[j] = o;
				toast(dir > 0 ? 'Przesunięto zlecenie w górę.' : 'Przesunięto zlecenie w dół.');
				rerender();
			}).catch(function (e) { toast(e.message, 'err'); });
		}

		/* Po powrocie do karty przeglądarki: świeże dane (inni mogli coś zmienić), jeśli nikt nie edytuje. */
		var lastLoad = Date.now();
		function onVis() {
			if (!document.body.contains(host)) { document.removeEventListener('visibilitychange', onVis); return; }
			var typing = document.activeElement && host.contains(document.activeElement) && /^(INPUT|TEXTAREA)$/.test(document.activeElement.tagName);
			if (!document.hidden && Date.now() - lastLoad > 60000 && !(GRID.ready && GRID.isEditing()) && !typing) { lastLoad = Date.now(); load(); }
		}
		document.addEventListener('visibilitychange', onVis);

		/* ================================================================
		   SIATKA (komputer)
		   ================================================================ */
		var GRID = (function () {
			var rows = [], wrap = null, table = null, editor = null, menu = null;
			var sel = { r: 0, c: 1, r2: 0, c2: 1 }, editing = null, dragging = false;
			var TOTAL_W = PCOLS.reduce(function (a, c) { return a + c.w; }, 0);

			function flatten() {
				rows = [];
				ORDERS().forEach(function (o, oi) {
					var start = rows.length;
					o.det.forEach(function (d, di) { rows.push({ o: o, d: d, oi: oi, di: di, start: start, end: start + o.det.length - 1 }); });
				});
			}
			function cellHtml(r, c) {
				var row = rows[r], col = PCOLS[c], v = pgVal(row.o, row.d, col);
				var cls = 'msm-pg-c' + (col.num || col.sec ? ' is-num' : '') + (col.k === 'c' ? ' is-calc' : '') + (col.k === 'z' ? ' is-z' : '');
				if (col.f === 'start_zlec' || col.f === 'koniec_zlec') cls += ' is-date';
				if (col.f === 'zostalo' && v < 0) cls += ' is-neg';
				if (col.f === 'proc' && v >= 100) cls += ' is-done';
				var span = col.k === 'z' && row.o.det.length > 1 ? ' rowspan="' + row.o.det.length + '"' : '';
				return '<td class="' + cls + '"' + span + ' data-r="' + r + '" data-c="' + c + '">' + esc(pgShow(v, col)) + '</td>';
			}
			function build(keepSel) {
				flatten();
				var y = window.scrollY;
				/* Szerokości proporcjonalne – tabela mieści się na ekranie bez przewijania w bok (jak pozostałe listy). */
				var cols = PCOLS.map(function (c) { return '<col style="width:' + (100 * c.w / TOTAL_W * 0.97).toFixed(2) + '%">'; }).join('') + '<col style="width:3%">';
				var head = '<tr>' + PCOLS.map(function (c, i) {
					return '<th class="' + (c.num ? 'num' : '') + (c.k === 'c' ? ' is-calc' : '') + '" data-c="' + i + '">' + unitLbl(c.l) + '</th>';
				}).join('') + '<th class="msm-pg-acth" aria-label="Akcje"></th></tr>';
				var body = rows.map(function (row, r) {
					var first = row.di === 0, last = row.di === row.o.det.length - 1;
					var h = '<tr class="' + (first ? 'is-first' : '') + (last ? ' is-last' : '') + '" data-r="' + r + '">';
					for (var c = 0; c < PCOLS.length; c++) {
						if (PCOLS[c].k === 'z' && !first) continue;
						h += cellHtml(r, c);
					}
					return h + '<td class="msm-pg-act"><button type="button" class="msm-iconbtn" data-gm="' + r + '" title="Wiersz i zlecenie: wstaw, usuń, przesuń" aria-label="Akcje" tabindex="-1">' +
						'<svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><circle cx="5" cy="12" r="1.8"/><circle cx="12" cy="12" r="1.8"/><circle cx="19" cy="12" r="1.8"/></svg></button></td></tr>';
				}).join('');
				gridHost.innerHTML = '<div class="msm-table-wrap msm-pg-wrap" tabindex="0"><div class="msm-pg-inner"><table class="msm-pg"><colgroup>' + cols + '</colgroup><thead>' + head + '</thead><tbody>' + body + '</tbody></table></div></div>' +
					'<p class="msm-pg-foot msm-muted">Kliknij komórkę i pisz – zmiana zapisuje się od razu. Enter / Tab – dalej, F2 – edycja, Alt+Enter – nowa linia, Ctrl+C / Ctrl+V – kopiuj i wklej (także z Excela), Ctrl+Z – cofnij, prawy przycisk – wstaw / usuń detal.</p>';
				wrap = gridHost.querySelector('.msm-pg-wrap'); table = wrap.querySelector('table');
				if (keepSel) window.scrollTo(0, y);
				editing = null; editor = null;
				GRID.ready = true;
				bind();
				if (!keepSel) sel = { r: 0, c: 1, r2: 0, c2: 1 };
				clampSel(); paint();
			}
			function clampSel() {
				var n = rows.length;
				if (!n) return;
				['r', 'r2'].forEach(function (k) { sel[k] = Math.max(0, Math.min(n - 1, sel[k])); });
				['c', 'c2'].forEach(function (k) { sel[k] = Math.max(0, Math.min(PCOLS.length - 1, sel[k])); });
			}
			function el(r, c) {
				if (!rows[r]) return null;
				if (PCOLS[c].k === 'z') r = rows[r].start;
				return table.querySelector('td[data-r="' + r + '"][data-c="' + c + '"]');
			}
			function rect() {
				var r1 = Math.min(sel.r, sel.r2), r2 = Math.max(sel.r, sel.r2), c1 = Math.min(sel.c, sel.c2), c2 = Math.max(sel.c, sel.c2);
				return { r1: r1, r2: r2, c1: c1, c2: c2 };
			}
			function paint() {
				if (!table) return;
				table.querySelectorAll('.is-sel,.is-active').forEach(function (x) { x.classList.remove('is-sel', 'is-active'); });
				if (!rows.length) return;
				var R = rect(), multi = R.r1 !== R.r2 || R.c1 !== R.c2;
				if (multi) for (var r = R.r1; r <= R.r2; r++) for (var c = R.c1; c <= R.c2; c++) { var e = el(r, c); if (e) e.classList.add('is-sel'); }
				var a = el(sel.r, sel.c);
				if (a) a.classList.add('is-active');
			}
			function select(r, c, extend) {
				if (extend) { sel.r2 = r; sel.c2 = c; } else { sel = { r: r, c: c, r2: r, c2: c }; }
				clampSel(); paint();
			}
			/* Przewija stronę tak, by aktywna komórka była widoczna pod przyklejonym nagłówkiem. */
			function scrollToActive() {
				var e = el(sel.r2, sel.c2) || el(sel.r, sel.c);
				if (!e) return;
				var top = table.querySelector('thead').getBoundingClientRect().bottom;
				var b = e.getBoundingClientRect();
				if (b.top < top) window.scrollBy(0, b.top - top - 6);
				else if (b.bottom > window.innerHeight) window.scrollBy(0, b.bottom - window.innerHeight + 12);
			}
			/* Ruch kursora: przez scalone komórki zlecenia skacze na sąsiednie zlecenie (jak w Excelu). */
			function move(dr, dc, extend) {
				var r = extend ? sel.r2 : sel.r, c = extend ? sel.c2 : sel.c;
				if (dc) c = Math.max(0, Math.min(PCOLS.length - 1, c + dc));
				if (dr) {
					if (PCOLS[c].k === 'z' && rows[r]) r = dr > 0 ? rows[r].end + 1 : rows[r].start - 1;
					else r = r + dr;
					r = Math.max(0, Math.min(rows.length - 1, r));
				}
				select(r, c, extend);
				scrollToActive();
			}

			/* ---- edycja ---- */
			function startEdit(initial, mode) {
				var col = PCOLS[sel.c];
				if (!rows[sel.r]) return;
				if (col.k === 'c') { toast('„' + pgLbl(col) + '” liczy się samo (jak formuła w Excelu).', 'warn'); return; }
				var e = el(sel.r, sel.c);
				if (!e) return;
				var row = rows[sel.r], cur = pgVal(row.o, row.d, col);
				sel.r2 = sel.r; sel.c2 = sel.c; paint();
				editor = document.createElement('textarea');
				editor.className = 'msm-pg-ed' + (col.num ? ' is-num' : '');
				editor.spellcheck = false;
				editor.value = initial != null ? initial : (cur == null ? '' : (col.rich ? rteText(cur) : String(cur)));
				var inner = wrap.querySelector('.msm-pg-inner');
				/* Edytor nad komórką; wąskie kolumny dostają szersze pole, ale nie wychodzi poza tabelę. */
				var w = Math.min(Math.max(e.offsetWidth, col.num ? 100 : 220), inner.offsetWidth);
				var left = Math.min(e.offsetLeft, inner.offsetWidth - w);
				editor.style.left = Math.max(0, left) + 'px';
				editor.style.top = e.offsetTop + 'px';
				editor.style.width = w + 'px';
				editor.style.minHeight = e.offsetHeight + 'px';
				inner.appendChild(editor);
				editing = { r: sel.r, c: sel.c, mode: mode || (initial != null ? 'enter' : 'edit'), orig: cur };
				editor.focus();
				var L = editor.value.length; editor.setSelectionRange(L, L);
				autoGrow();
				editor.addEventListener('input', autoGrow);
				editor.addEventListener('keydown', edKey);
				editor.addEventListener('blur', function () { if (editing) commit(); });
			}
			function autoGrow() { if (!editor) return; editor.style.height = 'auto'; editor.style.height = editor.scrollHeight + 2 + 'px'; }
			function commit(cancel) {
				if (!editing) return;
				var ed = editing, val = editor.value;
				editing = null;
				var e = editor; editor = null;
				if (e && e.parentNode) e.parentNode.removeChild(e);
				wrap.focus({ preventScroll: true });
				if (cancel) return;
				var col = PCOLS[ed.c], row = rows[ed.r];
				if (col.rich && val === rteText(ed.orig)) return; // bez zmian – formatowanie zostaje
				var v = pgIn(col, val); if (v === null) return;
				save([{ k: col.k, id: col.k === 'z' ? row.o.id : row.d.id, f: col.f, v: v, old: ed.orig == null ? '' : String(ed.orig) }]);
			}
			function edKey(ev) {
				ev.stopPropagation(); // klawisze edytora nie trafiają do obsługi siatki
				var k = ev.key;
				if (k === 'Enter' && (ev.altKey || ev.ctrlKey)) { // nowa linia w komórce (jak w Excelu)
					ev.preventDefault();
					var s = editor.selectionStart, t = editor.value;
					editor.value = t.slice(0, s) + '\n' + t.slice(editor.selectionEnd);
					editor.selectionStart = editor.selectionEnd = s + 1; autoGrow();
					return;
				}
				if (k === 'Enter') { ev.preventDefault(); commit(); move(ev.shiftKey ? -1 : 1, 0); return; }
				if (k === 'Tab') { ev.preventDefault(); commit(); move(0, ev.shiftKey ? -1 : 1); return; }
				if (k === 'Escape') { ev.preventDefault(); commit(true); return; }
				if (editing && editing.mode === 'enter' && /^Arrow/.test(k)) {
					ev.preventDefault(); commit();
					move(k === 'ArrowDown' ? 1 : k === 'ArrowUp' ? -1 : 0, k === 'ArrowRight' ? 1 : k === 'ArrowLeft' ? -1 : 0);
				}
			}

			/* ---- schowek ---- */
			function tsvCell(v) { v = v == null ? '' : String(v); return /[\t\n"]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v; }
			function copyText() {
				var R = rect(), out = [];
				for (var r = R.r1; r <= R.r2; r++) {
					var line = [];
					for (var c = R.c1; c <= R.c2; c++) { var row = rows[r], pv = pgVal(row.o, row.d, PCOLS[c]); line.push(tsvCell(PCOLS[c].rich ? rteText(pv) : pv)); }
					out.push(line.join('\t'));
				}
				return out.join('\r\n');
			}
			/* Parser TSV z Excela (komórki w cudzysłowach mogą mieć tabulatory i nowe linie). */
			function parseTsv(text) {
				var res = [], row = [], cur = '', i = 0, q = false;
				text = text.replace(/\r\n?/g, '\n');
				if (text.slice(-1) === '\n') text = text.slice(0, -1);
				while (i < text.length) {
					var ch = text[i];
					if (q) {
						if (ch === '"' && text[i + 1] === '"') { cur += '"'; i += 2; continue; }
						if (ch === '"') { q = false; i++; continue; }
						cur += ch; i++; continue;
					}
					if (ch === '"' && cur === '') { q = true; i++; continue; }
					if (ch === '\t') { row.push(cur); cur = ''; i++; continue; }
					if (ch === '\n') { row.push(cur); res.push(row); row = []; cur = ''; i++; continue; }
					cur += ch; i++;
				}
				row.push(cur); res.push(row);
				return res;
			}
			function paste(text) {
				var data = parseTsv(text), R = rect(), changes = [], seen = {};
				if (!data.length) return;
				var single = data.length === 1 && data[0].length === 1;
				var h = single ? R.r2 - R.r1 + 1 : data.length, w = single ? R.c2 - R.c1 + 1 : Math.max.apply(null, data.map(function (x) { return x.length; }));
				for (var i = 0; i < h; i++) {
					var r = R.r1 + i; if (!rows[r]) break;
					for (var j = 0; j < w; j++) {
						var c = R.c1 + j; if (c >= PCOLS.length) break;
						var col = PCOLS[c]; if (col.k === 'c') continue;
						var v = single ? data[0][0] : (data[i] && data[i][j] != null ? data[i][j] : '');
						var row = rows[r], id = col.k === 'z' ? row.o.id : row.d.id, key = col.k + id + col.f;
						if (seen[key]) continue; // scalona komórka zlecenia – bierze pierwszą wartość
						seen[key] = 1;
						v = pgIn(col, v); if (v === null) continue;
						var cur = pgVal(row.o, row.d, col);
						changes.push({ k: col.k, id: id, f: col.f, v: v, old: cur == null ? '' : String(cur) });
					}
				}
				if (!single) select(Math.min(R.r1 + h - 1, rows.length - 1), Math.min(R.c1 + w - 1, PCOLS.length - 1), true);
				var n = changes.filter(function (c) { return String(c.old) !== String(c.v); }).length;
				save(changes).then(function () { if (n > 1) toast('Wklejono ' + n + ' komórek.'); });
			}
			function clearSel() {
				var R = rect(), changes = [], seen = {};
				for (var r = R.r1; r <= R.r2; r++) for (var c = R.c1; c <= R.c2; c++) {
					var col = PCOLS[c]; if (col.k === 'c') continue;
					var row = rows[r], id = col.k === 'z' ? row.o.id : row.d.id, key = col.k + id + col.f;
					if (seen[key]) continue; seen[key] = 1;
					var cur = pgVal(row.o, row.d, col);
					changes.push({ k: col.k, id: id, f: col.f, v: col.num ? '0' : '', old: cur == null ? '' : String(cur) });
				}
				save(changes);
			}

			/* Odświeżenie zmienionych komórek bez przebudowy całej tabeli. */
			function refresh(changes, saving) {
				if (!table) return;
				var touched = {};
				changes.forEach(function (ch) {
					rows.forEach(function (row, r) {
						if ((ch.k === 'z' && row.o.id === ch.id && row.di === 0) || (ch.k === 'd' && row.d.id === ch.id)) touched[r] = ch.k;
					});
				});
				Object.keys(touched).forEach(function (r) {
					r = +r;
					PCOLS.forEach(function (col, c) {
						if (touched[r] === 'z' && col.k !== 'z') return;
						if (touched[r] === 'd' && col.k === 'z') return;
						var e = el(r, c); if (!e) return;
						var v = pgVal(rows[r].o, rows[r].d, col);
						e.textContent = pgShow(v, col);
						e.classList.toggle('is-neg', col.f === 'zostalo' && v < 0);
						e.classList.toggle('is-done', col.f === 'proc' && v >= 100);
						e.classList.toggle('is-saving', !!saving && col.k !== 'c');
					});
				});
			}

			/* ---- menu kontekstowe ---- */
			function openMenu(x, y, r) {
				closeMenu();
				var row = rows[r]; if (!row) return;
				var o = row.o, d = row.d;
				menu = document.createElement('div');
				menu.className = 'msm-pg-menu';
				menu.innerHTML =
					'<div class="msm-pg-menu__t">Zlecenie ' + esc(o.nr_zlec || '(bez numeru)') + '</div>' +
					'<button data-a="detadd">Wstaw detal poniżej</button>' +
					'<button data-a="detdel"' + (o.det.length <= 1 ? ' disabled' : '') + '>Usuń detal</button>' +
					'<hr><button data-a="del" class="is-danger">Usuń zlecenie</button>';
				root.appendChild(menu); // w obrębie aplikacji – jej czcionka i kolory
				var mw = menu.offsetWidth, mh = menu.offsetHeight;
				menu.style.left = Math.min(x, window.innerWidth - mw - 8) + 'px';
				menu.style.top = Math.min(y, window.innerHeight - mh - 8) + 'px';
				menu.addEventListener('click', function (ev) {
					var b = ev.target.closest('button[data-a]'); if (!b || b.disabled) return;
					var a = b.getAttribute('data-a'); closeMenu();
					if (a === 'detadd') addDetail(o, d.id);
					if (a === 'detdel') delDetail(o, d);
					if (a === 'up') moveOrder(o, -1);
					if (a === 'down') moveOrder(o, 1);
					if (a === 'add') addOrder();
					if (a === 'del') delOrder(o);
				});
			}
			function closeMenu() { if (menu && menu.parentNode) menu.parentNode.removeChild(menu); menu = null; }

			/* ---- zdarzenia ---- */
			function cellFrom(t) { var td = t.closest && t.closest('td[data-c]'); return td && table.contains(td) ? { r: +td.getAttribute('data-r'), c: +td.getAttribute('data-c') } : null; }
			function bind() {
				wrap.addEventListener('mousedown', function (ev) {
					if (ev.target.closest('.msm-pg-ed')) return;
					var gm = ev.target.closest('[data-gm]');
					if (gm) { ev.preventDefault(); var r0 = +gm.getAttribute('data-gm'); select(r0, sel.c); var b = gm.getBoundingClientRect(); openMenu(b.left, b.bottom + 4, r0); return; }
					if (ev.target.closest('thead')) { ev.preventDefault(); return; } // nagłówki nie sortują
					var p = cellFrom(ev.target);
					if (!p || ev.button !== 0) return;
					if (editing) commit();
					ev.preventDefault();
					select(p.r, p.c, ev.shiftKey);
					dragging = true;
					wrap.focus({ preventScroll: true });
				});
				wrap.addEventListener('mouseover', function (ev) {
					if (!dragging) return;
					var p = cellFrom(ev.target); if (p) select(p.r, p.c, true);
				});
				document.addEventListener('mouseup', function () { dragging = false; });
				wrap.addEventListener('dblclick', function (ev) { var p = cellFrom(ev.target); if (p) { select(p.r, p.c); startEdit(null, 'edit'); } });
				wrap.addEventListener('contextmenu', function (ev) {
					var p = cellFrom(ev.target) || (ev.target.closest('[data-gm]') ? { r: +ev.target.closest('[data-gm]').getAttribute('data-gm'), c: sel.c } : null);
					if (!p) return;
					ev.preventDefault();
					var R = rect();
					if (!(p.r >= R.r1 && p.r <= R.r2 && p.c >= R.c1 && p.c <= R.c2)) select(p.r, p.c);
					openMenu(ev.clientX, ev.clientY, p.r);
				});
				wrap.addEventListener('keydown', function (ev) {
					if (editing) return;
					var k = ev.key, mod = ev.ctrlKey || ev.metaKey;
					if (mod && (k === 'z' || k === 'Z')) { ev.preventDefault(); undo(ev.shiftKey); return; }
					if (mod && (k === 'y' || k === 'Y')) { ev.preventDefault(); undo(true); return; }
					if (mod && (k === 'a' || k === 'A')) { ev.preventDefault(); sel = { r: 0, c: 0, r2: rows.length - 1, c2: PCOLS.length - 1 }; paint(); return; }
					if (mod) return; // kopiuj / wklej obsługują zdarzenia copy / paste
					var nav = { ArrowDown: [1, 0], ArrowUp: [-1, 0], ArrowRight: [0, 1], ArrowLeft: [0, -1] };
					if (nav[k]) { ev.preventDefault(); move(nav[k][0], nav[k][1], ev.shiftKey); return; }
					if (k === 'Tab') { ev.preventDefault(); move(0, ev.shiftKey ? -1 : 1); return; }
					if (k === 'Enter') { ev.preventDefault(); if (ev.shiftKey) move(-1, 0); else startEdit(null, 'edit'); return; }
					if (k === 'F2') { ev.preventDefault(); startEdit(null, 'edit'); return; }
					if (k === 'Delete' || k === 'Backspace') { ev.preventDefault(); clearSel(); return; }
					if (k === 'Escape') { closeMenu(); select(sel.r, sel.c); return; }
					if (k === 'PageDown' || k === 'PageUp') { ev.preventDefault(); move(k === 'PageDown' ? 15 : -15, 0, ev.shiftKey); return; }
					if (k.length === 1 && !ev.altKey) { ev.preventDefault(); startEdit(k, 'enter'); }
				});
				wrap.addEventListener('copy', function (ev) { if (editing) return; ev.preventDefault(); ev.clipboardData.setData('text/plain', copyText()); toast('Skopiowano.'); });
				wrap.addEventListener('cut', function (ev) { if (editing) return; ev.preventDefault(); ev.clipboardData.setData('text/plain', copyText()); clearSel(); });
				wrap.addEventListener('paste', function (ev) { if (editing) return; ev.preventDefault(); paste(ev.clipboardData.getData('text/plain') || ''); });
				document.addEventListener('mousedown', function docDown(ev) {
					if (!document.body.contains(wrap)) { document.removeEventListener('mousedown', docDown); return; }
					if (menu && !menu.contains(ev.target)) closeMenu();
				});
				wrap.focus({ preventScroll: true });
			}
			return {
				ready: false, build: build, refresh: refresh, select: select, scrollToActive: scrollToActive, startEdit: startEdit,
				rowsCount: function () { return rows.length; },
				isEditing: function () { return !!editing; },
				active: function () { return { r: sel.r, c: sel.c }; },
				rowOfDetail: function (id) { for (var i = 0; i < rows.length; i++) if (rows[i].d.id === id) return i; return -1; }
			};
		})();


		/* ================================================================
		   LISTA ZLECEŃ
		   ================================================================ */
		/* ---- termin: postęp czasu od startu do zakończenia vs. realizacja ---- */
		function pgDate(s) {
			var m = String(s || '').trim().match(/^(\d{1,2})[.\-\/](\d{1,2})[.\-\/](\d{4})$/);
			if (!m) return null;
			var d = new Date(+m[3], +m[2] - 1, +m[1]);
			return d.getMonth() === +m[2] - 1 ? d : null;
		}
		function dni(n) { return n + ' ' + (n === 1 ? 'dzień' : 'dni'); }
		/* state: none | done | late | risk (≤ 7 dni do terminu) | slow (postęp poniżej planu) | ok | wait */
		function termin(o, t) {
			t = t || orderSums(o);
			var end = pgDate(o.koniec_zlec), start = pgDate(o.start_zlec);
			if (!end) return { state: 'none', pct: 0, txt: 'brak daty zakończenia' };
			var now = new Date(); now.setHours(0, 0, 0, 0);
			var DAY = 864e5, left = Math.round((end - now) / DAY);
			var pct = start && end > start ? Math.max(0, Math.min(100, Math.round(100 * (now - start) / (end - start)))) : (left < 0 ? 100 : 0);
			if (t.zam > 0 && t.proc >= 100) return { state: 'done', pct: 100, txt: 'zrealizowane' };
			if (left < 0) return { state: 'late', pct: 100, txt: 'po terminie ' + dni(-left) };
			if (start && now < start) return { state: 'wait', pct: 0, txt: 'start za ' + dni(Math.round((start - now) / DAY)) };
			var txt = left === 0 ? 'termin dziś' : 'zostało ' + dni(left);
			/* zagrożone: do 7 dni do terminu; dalej – „postęp poniżej planu”, gdy czas ucieka szybciej niż postęp prac */
			if (left <= PROG.zlecenia) return { state: 'risk', pct: pct, txt: txt };
			if (pct - t.proc > 15) return { state: 'slow', pct: pct, txt: txt };
			return { state: 'ok', pct: pct, txt: txt };
		}
		var T_TITLE = { done: 'Zlecenie zrealizowane', late: 'Termin minął, a zlecenie nie jest zrealizowane', risk: 'Termin zagrożony – do ' + PROG.zlecenia + ' dni do zakończenia, a zlecenie nie jest zrealizowane', slow: 'Postęp poniżej planu – czas mija szybciej niż postęp prac, ale do terminu zostało ponad 7 dni', ok: 'W terminie', wait: 'Zlecenie jeszcze się nie zaczęło', none: 'Uzupełnij datę zakończenia' };
		function terminHtml(tm) {
			return '<div class="msm-tm is-' + tm.state + '" title="' + T_TITLE[tm.state] + '"><div class="msm-pbar"><i style="width:' + tm.pct + '%"></i></div><small>' + esc(tm.txt) + '</small></div>';
		}

		/* ---- filtry listy (zapamiętane w karcie przeglądarki) ---- */
		var FLT = (function () { try { return JSON.parse(sessionStorage.getItem('msm_pg_flt')) || null; } catch (e) { return null; } })() || { q: '', klient: {}, termin: {}, wyk: {} };
		var F_TERMIN = [['late', 'Po terminie'], ['risk', 'Zagrożone (do ' + PROG.zlecenia + ' dni)'], ['slow', 'Postęp poniżej planu'], ['ok', 'W terminie'], ['wait', 'Przed startem'], ['done', 'Zrealizowane'], ['none', 'Bez daty zakończenia']];
		var F_WYK = [['zero', 'Nierozpoczęte (0%)'], ['open', 'W realizacji'], ['done', 'Zrealizowane (100%)']];
		function fSave() { try { sessionStorage.setItem('msm_pg_flt', JSON.stringify(FLT)); } catch (e) {} }
		function fOn(k) { return Object.keys(FLT[k]).filter(function (x) { return FLT[k][x]; }); }
		function fCount() { return (FLT.q.trim() ? 1 : 0) + fOn('klient').length + fOn('termin').length + fOn('wyk').length; }
		function wykState(t) { return t.zam > 0 && t.proc >= 100 ? 'done' : (t.wyk > 0 ? 'open' : 'zero'); }
		function fMatch(o) {
			var t = orderSums(o);
			if (fOn('klient').length && !FLT.klient[o.klient || '(bez klienta)']) return false;
			if (fOn('termin').length && !FLT.termin[termin(o, t).state]) return false;
			if (fOn('wyk').length && !FLT.wyk[wykState(t)]) return false;
			var q = srchNorm(FLT.q.trim());
			if (q) {
				var hay = orderHay(o);
				if (q.split(/\s+/).some(function (w) { return hay.indexOf(w) < 0; })) return false;
			}
			return true;
		}
		function buildFilters() {
			var wrap = main.querySelector('[data-pgfwrap]'), box = main.querySelector('[data-pgflt]');
			var kl = [];
			DATA.orders.forEach(function (o) { var k = o.klient || '(bez klienta)'; if (kl.indexOf(k) < 0) kl.push(k); });
			kl.sort(function (a, b) { return a.localeCompare(b, 'pl'); });
			function ms(label, key, opts) {
				return '<div class="msm-f msm-ms" data-ms="' + key + '"><span>' + label + '</span>' +
					'<button type="button" class="msm-ms__btn" data-msbtn aria-haspopup="listbox" aria-expanded="false"><span data-mstxt>Wszystkie</span></button>' +
					'<div class="msm-ms__pop" data-mspop hidden role="listbox" aria-multiselectable="true">' +
					opts.map(function (v) { return '<label class="msm-ms__opt"><input type="checkbox" data-fk="' + key + '" value="' + esc(v[0]) + '"><span>' + esc(v[1]) + '</span></label>'; }).join('') +
					'<button type="button" class="msm-ms__clr" data-msclr>Wyczyść</button></div></div>';
			}
			box.innerHTML =
				'<label class="msm-f msm-pgf__q"><span>Szukaj</span><input type="search" data-fq value="' + esc(FLT.q) + '" placeholder="szukaj we wszystkich polach zlecenia, karty, pozycji i palet…" autocomplete="off"></label>' +
				ms('Klient', 'klient', kl.map(function (k) { return [k, k]; })) + ms('Termin', 'termin', F_TERMIN) + ms('Wykonanie', 'wyk', F_WYK) +
				'<div class="msm-f msm-zam-fclear"><button type="button" class="msm-link" data-fclr>Wyczyść filtry <span class="msm-badge" data-fcount hidden></span></button></div>';
			wrap.hidden = false;
			var LBL = { termin: {}, wyk: {} };
			F_TERMIN.forEach(function (x) { LBL.termin[x[0]] = x[1]; }); F_WYK.forEach(function (x) { LBL.wyk[x[0]] = x[1]; });
			function refresh(f) {
				var k = f.getAttribute('data-ms'), c = fOn(k);
				f.querySelector('[data-mstxt]').textContent = !c.length ? 'Wszystkie' : c.length === 1 ? ((LBL[k] && LBL[k][c[0]]) || c[0]) : c.length + ' wybrane';
				f.classList.toggle('is-on', c.length > 0);
				f.querySelectorAll('input[data-fk]').forEach(function (cb) { cb.checked = !!FLT[k][cb.value]; });
			}
			function closeAll(except) {
				box.querySelectorAll('.msm-ms.is-open').forEach(function (f) { if (f === except) return; f.classList.remove('is-open'); f.querySelector('[data-mspop]').hidden = true; f.querySelector('[data-msbtn]').setAttribute('aria-expanded', 'false'); });
			}
			function changed() { fSave(); syncFCount(); renderRows(); }
			box.querySelectorAll('.msm-ms').forEach(function (f) {
				var pop = f.querySelector('[data-mspop]'), btn = f.querySelector('[data-msbtn]');
				refresh(f);
				btn.addEventListener('click', function (e) { e.stopPropagation(); var open = pop.hidden; closeAll(f); pop.hidden = !open; f.classList.toggle('is-open', open); btn.setAttribute('aria-expanded', open ? 'true' : 'false'); });
				pop.addEventListener('click', function (e) { e.stopPropagation(); });
				f.querySelectorAll('input[data-fk]').forEach(function (cb) { cb.addEventListener('change', function () { FLT[cb.getAttribute('data-fk')][cb.value] = cb.checked; refresh(f); changed(); }); });
				f.querySelector('[data-msclr]').addEventListener('click', function () { FLT[f.getAttribute('data-ms')] = {}; refresh(f); changed(); });
			});
			var qt = null, qi = box.querySelector('[data-fq]');
			qi.addEventListener('input', function () { clearTimeout(qt); qt = setTimeout(function () { FLT.q = qi.value; changed(); }, 150); });
			box.querySelector('[data-fclr]').addEventListener('click', function () {
				FLT = { q: '', klient: {}, termin: {}, wyk: {} }; qi.value = '';
				box.querySelectorAll('.msm-ms').forEach(refresh); changed();
			});
			function outside() { if (!document.body.contains(box)) { document.removeEventListener('click', outside); document.removeEventListener('keydown', escK); return; } closeAll(null); }
			function escK(e) { if (e.key === 'Escape') outside(); }
			if (!box._doc) { box._doc = true; document.addEventListener('click', outside); document.addEventListener('keydown', escK); }
			syncFCount();
		}
		function syncFCount() {
			var n = fCount();
			main.querySelectorAll('[data-fcount]').forEach(function (el) { el.textContent = n; el.hidden = !n; });
		}

		function renderList() {
			GRID.ready = false;
			if (!DATA.orders.length) {
				main.querySelector('[data-pgcount]').textContent = 'Rok ' + DATA.sheet;
				var fw = main.querySelector('[data-pgfwrap]'); if (fw) fw.hidden = true;
				var other = (DATA.lata || []).filter(function (y) { return y !== DATA.sheet; });
				host.innerHTML = '<div class="msm-card msm-empty"><p><b>Brak zleceń w ' + esc(DATA.sheet) + ' roku.</b></p><p class="msm-muted">Dodaj pierwsze przyciskiem „+ Zlecenie z karty projektu” albo „+ Puste zlecenie”.' +
					(other.length ? ' Zlecenia z innych lat wybierzesz obok tytułu (' + other.map(esc).join(', ') + ').' : '') + '</p></div>';
				return;
			}
			if (!main.querySelector('[data-pgflt] [data-fq]')) buildFilters();
			renderRows();
		}
		function renderRows() {
			var nd = DATA.orders.reduce(function (a, o) { return a + o.det.length; }, 0);
			/* Najnowsze na górze – odwrotnie niż w arkuszu Excela (kolejność zapisu się nie zmienia). */
			var ALL = DATA.orders.slice().reverse(), L = ALL.filter(fMatch);
			main.querySelector('[data-pgcount]').textContent = (L.length === ALL.length ? plN(ALL.length, 'zlecenie', 'zlecenia', 'zleceń') + ' · ' + plN(nd, 'pozycja', 'pozycje', 'pozycji') : 'Pokazano ' + L.length + ' z ' + plN(ALL.length, 'zlecenia', 'zleceń', 'zleceń')) + ' · rok ' + DATA.sheet;
			if (!L.length) {
				host.innerHTML = '<div class="msm-card msm-empty"><p><b>Brak zleceń dla wybranych filtrów.</b></p><p><button type="button" class="msm-btn msm-btn-sm" data-fclr2>Wyczyść filtry</button></p></div>';
				host.querySelector('[data-fclr2]').addEventListener('click', function () { var b = main.querySelector('[data-fclr]'); if (b) b.click(); });
				return;
			}
			host.innerHTML = '<div class="msm-table-wrap"><table class="msm-table msm-pgl"><thead><tr>' +
				'<th>Nr zlec.</th><th>Nazwa klienta</th><th>Nr zlec. klienta</th><th>Start zlec.</th><th>Zakończenie zlec.</th><th class="msm-pgl-p">Wykonanie</th><th class="msm-pgl-t">Termin</th><th class="msm-pgl-act"></th></tr></thead><tbody>' +
				L.map(function (o) {
					var i = ALL.indexOf(o);
					return '<tr data-zid="' + o.id + '">' +
						'<td data-label="Nr zlec."><a class="msm-pgl-nr" href="#prod-' + o.id + '">' + (o.nr_zlec ? esc(o.nr_zlec) : '<i>(bez numeru)</i>') + '</a><small class="msm-pgl-n">' + o.det.length + ' ' + (o.det.length === 1 ? 'pozycja' : (o.det.length < 5 ? 'pozycje' : 'pozycji')) + (o.karta && o.karta.nazwa_projektu ? ' · ' + esc(o.karta.nazwa_projektu) : '') + '</small></td>' +
						'<td data-label="Nazwa klienta">' + esc(o.klient) + '</td>' +
						'<td data-label="Nr zlec. klienta">' + esc(o.nr_zlec_klienta) + '</td>' +
						'<td data-label="Start zlec." class="msm-pgl-d">' + esc(o.start_zlec) + '</td>' +
						'<td data-label="Zakończenie zlec." class="msm-pgl-d">' + esc(o.koniec_zlec) + '</td>' +
						(function (t) {
							return '<td data-label="Wykonanie" class="msm-pgl-p" title="Wykonano ' + fmtNum(t.wyk) + ' z ' + fmtNum(t.zam) + '"><div class="msm-pgl-pv"><b' + (t.proc >= 100 ? ' class="is-done"' : '') + '>' + fmtNum(t.proc, 1) + '%</b>' + progress(t.proc) + '</div></td>';
						})(orderSums(o)) +
						'<td data-label="Termin" class="msm-pgl-t">' + terminHtml(termin(o)) + '</td>' +
						'<td class="msm-pgl-act"><button type="button" class="msm-iconbtn" data-om="' + i + '" title="Przesuń / usuń" aria-label="Akcje">' + ICO_DOTS + '</button></td></tr>';
				}).join('') + '</tbody></table></div>';
			var y = +(sessionStorage.getItem('msm_pg_y') || 0);
			if (y) { sessionStorage.removeItem('msm_pg_y'); window.scrollTo(0, y); }
			host.querySelectorAll('a.msm-pgl-nr').forEach(function (l) { l.addEventListener('click', rememberListPos); });
			host.querySelectorAll('tr[data-zid]').forEach(function (tr) {
				tr.addEventListener('click', function (e) {
					if (e.target.closest('[data-om]') || e.target.closest('a')) return;
					rememberListPos();
					location.hash = '#prod-' + tr.getAttribute('data-zid');
				});
			});
			host.querySelectorAll('[data-om]').forEach(function (b) {
				b.addEventListener('click', function (e) {
					e.stopPropagation();
					var i = +b.getAttribute('data-om'), o = ALL[i];
					popMenu(b, 'Zlecenie ' + (o.nr_zlec || ''), [
						{ label: 'Otwórz', run: function () { location.hash = '#prod-' + o.id; } }, '-',
						{ label: 'Przesuń w górę', disabled: i === 0, run: function () { moveOrder(o, 1); } },
						{ label: 'Przesuń w dół', disabled: i === ALL.length - 1, run: function () { moveOrder(o, -1); } }, '-',
						{ label: 'Usuń zlecenie', danger: true, run: function () { delOrder(o); } }
					]);
				});
			});
		}

		/* ================================================================
		   STRONA ZLECENIA
		   ================================================================ */
		function fld(k, id, f, label, val, span, opt) {
			opt = opt || {};
			var v = val == null ? '' : String(val);
			var attrs = ' data-k="' + k + '" data-id="' + id + '" data-f="' + f + '"';
			var ctrl = opt.rich
				? rteHtml(attrs, v, opt.ph)
				: opt.select
				? '<select' + attrs + '>' + opt.select.map(function (x) { return '<option value="' + esc(x[0]) + '"' + (x[0] === v ? ' selected' : '') + '>' + esc(x[1]) + '</option>'; }).join('') + '</select>'
				: opt.check
				? '<span class="msm-pf__chk"><input type="checkbox"' + attrs + (+v ? ' checked' : '') + '><i aria-hidden="true"></i><em>' + esc(opt.check) + '</em></span>'
				: opt.area
				? '<textarea rows="' + (opt.rows || 2) + '"' + attrs + ' spellcheck="false">' + esc(v) + '</textarea>'
				: '<input type="text"' + attrs + (opt.num ? ' inputmode="numeric" class="is-num"' : '') + (opt.sec ? ' inputmode="decimal" class="is-num"' : '') + ' value="' + esc(v) + '" spellcheck="false"' + (opt.list ? ' list="' + opt.list + '" autocomplete="off"' : '') + (opt.ph ? ' placeholder="' + esc(opt.ph) + '"' : '') + '>';
			var tg = opt.rich ? 'div' : 'label'; // edytor w <div>: kliknięcie w pasek nie przenosi kursora
			return '<' + tg + ' class="msm-pf msm-pf--' + span + (opt.big ? ' is-big' : '') + '"><span>' + unitLbl(label) + '</span>' + ctrl + '</' + tg + '>';
		}
		function progress(p) {
			var w = Math.max(0, Math.min(100, p));
			return '<div class="msm-pbar' + (p >= 100 ? ' is-done' : '') + '"><i style="width:' + w + '%"></i></div>';
		}
		function headHtml(o) {
			var t = orderSums(o);
			return '<section class="msm-card msm-pgo" data-pghead>' +
				'<div class="msm-pgo__grid">' +
				fld('z', o.id, 'nr_zlec', 'Nr zlecenia', o.nr_zlec, 3, { big: true, ph: 'np. B02335' }) +
				fld('z', o.id, 'klient', 'Nazwa klienta', o.klient, 5) +
				fld('z', o.id, 'nr_zlec_klienta', 'Nr zlecenia klienta', o.nr_zlec_klienta, 4) +
				fld('z', o.id, 'start_zlec', 'Start zlecenia', o.start_zlec, 3, { ph: 'dd.mm.rrrr' }) +
				fld('z', o.id, 'koniec_zlec', 'Zakończenie zlecenia', o.koniec_zlec, 3, { ph: 'dd.mm.rrrr' }) +
				'<div class="msm-pgo__kpi msm-pf--6" data-kpi>' + kpiHtml(o, t) + '</div>' +
				fld('z', o.id, 'uwagi_ogolne', 'Uwagi ogólne do zlecenia', o.uwagi_ogolne, 12, { rich: true, ph: 'Informacje dotyczące całego zlecenia (np. pakowanie, transport, kontakt u klienta)…' }) +
				'</div></section>';
		}
		function kpiHtml(o, t) {
			return '<div class="msm-pk"><span>Pozycje</span><b>' + o.det.length + '</b></div>' +
				'<div class="msm-pk"><span>Zamówiono</span><b>' + fmtNum(t.zam) + '</b></div>' +
				'<div class="msm-pk"><span>Wykonano</span><b>' + fmtNum(t.wyk) + '</b></div>' +
				'<div class="msm-pk msm-pk--wide"><span>Realizacja <em>' + fmtNum(t.proc, 1) + '%</em>' + (t.zost !== 0 ? ' · zostało ' + fmtNum(t.zost) : '') + '</span>' + progress(t.proc) + '</div>' +
				(function (tm) { return '<div class="msm-pk msm-pk--full"><span>Termin <em>' + esc(tm.txt) + '</em></span>' + terminHtml(tm) + '</div>'; })(termin(o, t));
		}
		function detHtml(o, d, i) {
			var p = pgProc(d), z = d.ilosc_zam - d.wykonano;
			return '<article class="msm-card msm-pgd" data-det="' + d.id + '">' +
				'<header class="msm-pgd__h"><span class="msm-pgd__no">Pozycja ' + (i + 1) + '</span>' +
				'<span class="msm-pgd__name" data-dname>' + esc(d.nazwa_detalu || '') + '</span>' +
				'<span class="msm-pgd__pal" data-palsum="' + d.id + '" hidden></span>' +
				'<button type="button" class="msm-iconbtn" data-dm="' + d.id + '" title="Wstaw / usuń pozycję" aria-label="Akcje pozycji">' + ICO_DOTS + '</button></header>' +
				'<div class="msm-pgd__grid">' +
				fld('d', d.id, 'nazwa_detalu', 'Nazwa detali', d.nazwa_detalu, 6, { area: true, rows: 1 }) +
				fld('d', d.id, 'nr_rysunku', 'Nr rysunku', d.nr_rysunku, 6, { area: true, rows: 1 }) +
				fld('d', d.id, 'ilosc_zam', 'Ilość zam.', d.ilosc_zam, 2, { num: true }) +
				fld('d', d.id, 'wykonano', 'Wykonano', d.wykonano, 2, { num: true }) +
				'<div class="msm-pf msm-pf--8 msm-pgd__prog" data-prog><span>Realizacja</span>' + progHtml(p, z) + '</div>' +
				fld('d', d.id, 'dostepnosc', 'Dostępność przyrządów / sprawdzianów', d.dostepnosc, 12, { area: true, rows: 1 }) +
				'<div class="msm-pf--12 msm-nzrow" data-narz="' + d.id + '"></div>' +
				fld('d', d.id, 'wersja', 'Wersja', d.wersja, 2, { list: 'msm-pg-dl-wersja', ph: 'np. V1' }) +
				fld('d', d.id, 'czas_ciecia', 'Czas cięcia [s]', d.czas_ciecia, 2, { sec: true, ph: 'np. 54' }) +
				fld('d', d.id, 'laser', 'Laser', d.laser, 2, { select: [['', '—'], ['L1', 'L1'], ['L2', 'L2']] }) +
				fld('d', d.id, 'material', 'Materiał', d.material, 4, { list: 'msm-pg-dl-material', ph: 'np. M400-50A C5' }) +
				fld('d', d.id, 'mat_klienta', 'Materiał klienta', d.mat_klienta, 2, { check: 'od klienta' }) +
				'<div class="msm-pf msm-pf--12 msm-pgd__mag" data-mag="' + d.id + '">' + magHtml(d) + '</div>' +
				fld('d', d.id, 'uwagi', 'Uwagi', d.uwagi, 12, { rich: true }) +
				'</div></article>';
		}
		/* Materiał z magazynu: rezerwacje pozycji + przycisk wyszukiwania. */
		var REZ_ST = { nowa: 'czeka na akceptację', aktywna: 'zarezerwowano', wydana: 'wydano' };
		function magHtml(d) {
			var rz = d.rez || [];
			var zp = d.zap || [];
			return '<span>Materiał z magazynu</span><div class="msm-pgd__magrow">' +
				(rz.length ? rz.map(function (r) {
					return '<span class="msm-rzchip is-' + r.status + '" title="' + esc(r.material) + '"><b>' + fmtNum(r.ilosc) + ' ' + r.jedn + '</b> ' + esc(r.material) + ' <em>' + (REZ_ST[r.status] || r.status) + '</em></span>';
				}).join('') : (zp.length ? '' : (d.mat_klienta ? '<span class="msm-muted">Materiał dostarcza klient.</span>' : '<span class="msm-muted">Brak rezerwacji.</span>'))) +
				zapChips(d, true) +
				'<span class="msm-pgd__magbtns"><button type="button" class="msm-btn msm-btn-sm" data-zapbtn="' + d.id + '" title="Zgłoś, ile materiału potrzeba – wolny materiał zarezerwuje się od razu, brak trafi do „Do zamówienia”">+ Zapotrzebowanie</button>' +
				'<button type="button" class="msm-btn msm-btn-sm" data-magbtn="' + d.id + '">' +
				'<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg> Sprawdź na magazynie</button></span></div>';
		}
		function bindMag(scope) {
			scope.querySelectorAll('[data-magbtn]').forEach(function (b) {
				b.addEventListener('click', function () { openMag(+b.getAttribute('data-magbtn')); });
			});
			scope.querySelectorAll('[data-zapbtn]').forEach(function (b) {
				b.addEventListener('click', function () { openZap(+b.getAttribute('data-zapbtn')); });
			});
			scope.querySelectorAll('[data-zapdel]').forEach(function (b) {
				b.addEventListener('click', function () {
					var d = findDet(+b.closest('[data-mag]').getAttribute('data-mag'));
					var z = (d.zap || []).filter(function (x) { return x.id === +b.getAttribute('data-zapdel'); })[0] || {};
					var m = openModal('Usunąć zapotrzebowanie?', '<p>' + esc(z.opis || '') + ' – <b>' + fmtNum(z.ilosc || 0) + ' ' + (z.jm === 'kg' ? 'kg' : 'szt.') + '</b>. Brak zniknie z „Do zamówienia”.</p>' +
						(z.zarezerw > 0 ? '<label class="msm-check"><input type="checkbox" data-zrel checked> Zwolnij też zarezerwowany materiał (' + fmtNum(z.zarezerw) + ' ' + (z.jm === 'kg' ? 'kg' : 'szt.') + ')</label>' : ''),
						'<button type="button" class="msm-btn" data-close>Anuluj</button><button type="button" class="msm-btn msm-btn-danger" data-ok>Usuń</button>');
					m.querySelector('[data-ok]').addEventListener('click', function () {
						var rel = m.querySelector('[data-zrel]'), ok = this; ok.disabled = true;
						api('/zap/' + z.id + '/delete', { method: 'POST', body: { zwolnij: rel ? rel.checked : false } }).then(function (r) { closeModal(); d.zap = r.zap; d.rez = r.rez; redrawMag(d); toast(r.message); }).catch(function (e) { ok.disabled = false; toast(e.message, 'err'); });
					});
				});
			});
		}
		function openZap(detId) {
			var d = findDet(detId); if (!d) return;
			var o = DATA.orders.filter(function (x) { return x.id === d.zlec_id; })[0];
			zapForm(d, o ? o.nr_zlec : '', function (r) { d.zap = r.zap; d.rez = r.rez; redrawMag(d); });
		}
		function findDet(id) { var d = null; DATA.orders.forEach(function (o) { o.det.forEach(function (x) { if (x.id === id) d = x; }); }); return d; }
		function redrawMag(d) {
			var box = host.querySelector('[data-mag="' + d.id + '"]');
			if (box) { box.innerHTML = magHtml(d); bindMag(box); }
		}
		function openMag(detId, q) {
			var d = findDet(detId); if (!d) return;
			var m = openModal('Materiał na magazynie', '<div class="msm-loading">Szukam…</div>', '<button type="button" class="msm-btn" data-close>Zamknij</button>', true);
			m.querySelector('.msm-modal').classList.add('msm-magm');
			api('/prod/det/' + detId + '/magazyn', { query: q ? { q: q } : {} }).then(function (r) {
				d.rez = r.rez; redrawMag(d);
				var sz = r.szukane, crit = [];
				if (sz.grades.length) crit.push('gatunek <b>' + esc(sz.grades.join(' / ')) + '</b>');
				if (sz.grubosc !== null) crit.push('grubość <b>' + fmtNum(sz.grubosc) + ' mm</b>');
				if (sz.izolacja) crit.push('izolacja <b>' + esc(sz.izolacja) + '</b> (kręgi wyżej)');
				var body = '<p class="msm-muted msm-magm__for">' + esc(d.nazwa_detalu || 'Pozycja') + (r.zlecenie ? ' · zlecenie ' + esc(r.zlecenie) : '') + (d.ilosc_zam ? ' · zamówiono ' + fmtNum(d.ilosc_zam) + ' szt.' : '') + '</p>' +
					'<form class="msm-magm__q" data-magq><input type="text" name="q" value="' + esc(q || r.material) + '" placeholder="np. M400-50A C5 albo DC01 2mm" autocomplete="off"><button type="submit" class="msm-btn msm-btn-sm">Szukaj</button></form>' +
					(crit.length ? '<p class="msm-small msm-muted">Szukam: ' + crit.join(', ') + '.</p>' : '<p class="msm-alert msm-alert-warn">Wpisz materiał (gatunek i grubość), aby wyszukać.</p>') +
					(r.rez.length ? '<div class="msm-magm__rez"><b>Rezerwacje tej pozycji</b>' + r.rez.map(function (x) { return '<span class="msm-rzchip is-' + x.status + '"><b>' + fmtNum(x.ilosc) + ' ' + x.jedn + '</b> ' + esc(x.material) + ' <em>' + (REZ_ST[x.status] || x.status) + '</em></span>'; }).join('') + '</div>' : '') +
					(r.wyniki.length ? '<div class="msm-table-wrap"><table class="msm-table msm-magm__t"><thead><tr><th>Magazyn</th><th>Materiał</th><th class="num">Stan</th><th class="num">Dostępne</th><th></th></tr></thead><tbody>' +
						r.wyniki.map(function (x, i) {
							return '<tr><td data-label="Magazyn"><span class="msm-chip msm-chip-sm">' + esc(x.tlabel) + '</span></td><td data-label="Materiał">' + esc(x.opis) + (x.uwagi ? '<small class="msm-muted"> · ' + esc(x.uwagi) + '</small>' : '') + '</td>' +
								'<td data-label="Stan" class="num">' + fmtNum(x.stan) + ' ' + esc(x.jedn) + (x.zarez ? '<small class="msm-rez-cell">rez. ' + fmtNum(x.zarez) + '</small>' : '') + '</td>' +
								'<td data-label="Dostępne" class="num"><b class="' + (x.dostepne > 0 ? 'is-ok' : 'is-none') + '">' + fmtNum(x.dostepne) + ' ' + esc(x.jedn) + '</b></td>' +
								'<td class="msm-magm__act">' + (x.dostepne > 0 ? '<button type="button" class="msm-btn msm-btn-sm msm-btn-primary" data-rzi="' + i + '">' + (r.can_edit ? 'Zarezerwuj' : 'Poproś o rezerwację') + '</button>' : '<span class="msm-muted msm-small">zajęte</span>') + '</td></tr>';
						}).join('') + '</tbody></table></div>'
						: (crit.length ? '<div class="msm-empty msm-magm__none"><p><b>Nie ma tego materiału na magazynie.</b></p><p class="msm-muted">Sprawdź pisownię albo poszukaj innego gatunku. Brakujący materiał zgłoś do zamówienia.</p></div>' : ''));
				m.querySelector('.msm-modal-body').innerHTML = body;
				m.querySelector('[data-magq]').addEventListener('submit', function (e) { e.preventDefault(); openMag(detId, this.q.value.trim()); });
				m.querySelectorAll('[data-rzi]').forEach(function (b) {
					b.addEventListener('click', function () {
						var x = r.wyniki[+b.getAttribute('data-rzi')];
						var row = Object.assign({}, x.row || {}, { id: x.id, ilosc: x.stan, _rez: x.zarez });
						openRezerwacja(row, x.table, {
							zlecenie: r.zlecenie, prod_det_id: detId,
							uwagi: 'Produkcja: ' + (d.nazwa_detalu || 'pozycja') + (d.nr_rysunku ? ' (' + d.nr_rysunku + ')' : ''),
							onDone: function () { openMag(detId, q); }
						});
					});
				});
			}).catch(function (e) { m.querySelector('.msm-modal-body').innerHTML = '<p class="msm-alert msm-alert-err">' + esc(e.message) + '</p>'; });
		}

		/* ================================================================
		   Dostępność przyrządów → odnośniki do Sprawdzianów i przyrządów
		   ================================================================ */
		var NARZ = {}, NARZ_AUTO = false, nzTimer = null;
		var NZ_ST = { jest: 'jest', hala: 'wypożyczony', czesciowo: '', brak: 'brak' };
		var NZ_T = { prz_okr: 'Przyrządy okrągłe', spr_okr: 'Sprawdziany okrągłe', prz_prost: 'Przyrządy prostokątne', spr_prost: 'Sprawdziany prostokątne' };
		function nzLabel(t) { return t.state === 'czesciowo' ? 'częściowo ' + t.avail + ' z ' + t.need : NZ_ST[t.state]; }
		function loadNarz(o) {
			return api('/prod/order/' + o.id + '/narzedzia').then(function (r) {
				NARZ = r.det || {}; NARZ_AUTO = !!r.auto;
				o.det.forEach(function (d) { drawNarz(d.id); });
			}).catch(function () {});
		}
		function drawNarz(detId) {
			var box = host.querySelector('[data-narz="' + detId + '"]'); if (!box) return;
			var toks = NARZ[detId] || [];
			box.innerHTML = toks.map(function (t, i) {
				var nums = t.items.map(function (x) { return x.numer + (x.hala ? ' (HALA)' : ''); }).join(', ');
				return '<button type="button" class="msm-nzchip is-' + t.state + '" data-nz="' + detId + ':' + i + '" title="' + esc(nums ? NZ_T[t.table] + ': ' + nums : 'Nie ma w ewidencji ' + NZ_T[t.table].toLowerCase()) + '">' +
					'<i aria-hidden="true"></i><span>' + esc(t.text) + '</span><em>' + esc(nzLabel(t)) + '</em></button>';
			}).join('');
			box.hidden = !toks.length;
			box.querySelectorAll('[data-nz]').forEach(function (b) {
				b.addEventListener('click', function () { var p = b.getAttribute('data-nz').split(':'); openNarz(+p[0], +p[1]); });
			});
		}
		function narzLater(o) { clearTimeout(nzTimer); nzTimer = setTimeout(function () { loadNarz(o); }, 400); }
		function openNarz(detId, i) {
			var t = (NARZ[detId] || [])[i]; if (!t) return;
			var canHala = C.canEdit || capOn('inwentarz');
			var unit = t.table.indexOf('okr') > 0 ? 'Ø' : 'T';
			var body = '<p class="msm-nzm__head"><span class="msm-nzchip is-' + t.state + ' is-static"><i></i><span>' + esc(t.text) + '</span><em>' + esc(nzLabel(t)) + '</em></span></p>' +
				'<p class="msm-muted msm-small">' + esc(NZ_T[t.table]) + ' · ' + unit + ' ' + fmtNum(t.dim, 2) + ' mm ±0,02 · potrzeba ' + t.need + ' szt.' + (t.nr ? ' · wskazany nr ' + esc(t.prefix + t.nr) : '') + '</p>' +
				(t.items.length ? '<div class="msm-table-wrap"><table class="msm-table msm-nzm__t"><thead><tr><th>Numer</th><th class="num">' + unit + ' [mm]</th><th>Miejsce</th><th>Zlecenia</th><th></th></tr></thead><tbody>' +
					t.items.map(function (x, k) {
						return '<tr><td data-label="Numer"><b>' + esc(x.numer) + '</b>' + (x.wskazany ? ' <small class="msm-chip msm-chip-sm">wpisany</small>' : '') + '</td><td data-label="' + unit + '" class="num">' + (x.wym === null ? '—' : fmtNum(x.wym, 2)) + '</td>' +
							'<td data-label="Miejsce">' + (x.hala ? '<span class="msm-nzhala">HALA – wypożyczony</span>' : 'regał ' + esc(x.regal || '—')) + '</td>' +
							'<td data-label="Zlecenia"><small>' + esc(x.zlec) + '</small></td>' +
							'<td class="msm-nzm__act">' + (canHala ? (x.hala ? '<button type="button" class="msm-btn msm-btn-sm" data-nzret="' + k + '">Zwróć na regał</button>' : '<button type="button" class="msm-btn msm-btn-sm" data-nzhala="' + k + '">Wydaj na halę</button>') : '') + '</td></tr>';
					}).join('') + '</tbody></table></div>'
					: '<div class="msm-empty msm-magm__none"><p><b>Brak w ewidencji.</b></p><p class="msm-muted">Nie ma ' + esc(NZ_T[t.table].toLowerCase()) + ' o wymiarze ' + fmtNum(t.dim, 2) + ' mm (±0,02).</p></div>') +
				'<div data-nzret-box></div>';
			var m = openModal('Przyrządy i sprawdziany', body, '<a class="msm-btn" href="#' + t.table + '">Otwórz ' + esc(NZ_T[t.table]) + '</a><button type="button" class="msm-btn msm-btn-primary" data-close>Zamknij</button>', true);
			m.querySelector('.msm-modal-foot a').addEventListener('click', closeModal);
			var o = ORDER;
			function after(msg) { toast(msg); loadNarz(o).then(function () { openNarz(detId, i); }); }
			m.querySelectorAll('[data-nzhala]').forEach(function (b) {
				b.addEventListener('click', function () {
					var x = t.items[+b.getAttribute('data-nzhala')]; b.disabled = true;
					api('/t/' + t.table + '/' + x.id + '/hala', { method: 'POST', body: { action: 'hala' } }).then(function () { after(x.numer + ' wydano na halę.'); }).catch(function (e) { b.disabled = false; toast(e.message, 'err'); });
				});
			});
			m.querySelectorAll('[data-nzret]').forEach(function (b) {
				b.addEventListener('click', function () {
					var x = t.items[+b.getAttribute('data-nzret')], box = m.querySelector('[data-nzret-box]');
					box.innerHTML = '<form class="msm-magm__q msm-nzm__ret"><input type="text" name="regal" placeholder="Na jaki regał odkładasz ' + esc(x.numer) + '? np. 6" autocomplete="off"><button type="submit" class="msm-btn msm-btn-sm msm-btn-primary">Zwróć</button></form>';
					var f = box.querySelector('form'); f.regal.focus();
					f.addEventListener('submit', function (e) {
						e.preventDefault(); var rg = f.regal.value.trim(); if (!rg) { f.regal.focus(); return; }
						api('/t/' + t.table + '/' + x.id + '/hala', { method: 'POST', body: { action: 'zwrot', regal: rg } }).then(function () { after(x.numer + ' zwrócono na regał ' + rg + '.'); }).catch(function (er) { toast(er.message, 'err'); });
					});
				});
			});
		}

		/* ================================================================
		   PALETÓWKI PROJEKTU
		   ================================================================ */
		var PCOL = [['nazwa', 'Nazwa detalu', 22], ['rysunek', 'Numer części', 20], ['ilosc', 'Ilość [szt]', 10, 1], ['waga', 'Waga brutto [kg]', 11, 1], ['stosy', 'Ilość stosów', 9, 1], ['wysokosc', 'Wysokość stosu [mm]', 11, 1], ['material', 'Materiał', 13]];
		var PAL = null, palPrev = 0, wymOverKeys = [];
		function palUrl(o, ids, extra) { return printUrl(Object.assign({ msm_print: 'prod_pal', id: o.id }, ids ? { pal: ids } : {}, extra || {})); }
		function renderPalety(tb, o) {
			tb.innerHTML = '<div class="msm-loading">Ładowanie paletówek…</div>';
			api('/prod/order/' + o.id + '/palety').then(function (r) { PAL = r; drawPalety(tb, o); }).catch(function (e) { tb.innerHTML = '<p class="msm-alert msm-alert-err">' + esc(e.message) + '</p>'; });
		}
		function palCell(c, v) { return v === null || v === undefined ? '' : String(v).replace('.', ','); }
		function palRowHtml(p, r, ri, o) {
			return '<tr>' + PCOL.map(function (c) {
				var a = ' data-pr="' + p.id + ':' + ri + ':' + c[0] + '" aria-label="' + esc(c[1]) + '"';
				/* Nazwa i numer części mogą być długie (np. „BMZS008926-B_Poz1.01.03_Stator-core-sheet.”) – pole rośnie w pionie. */
				if (c[0] === 'nazwa') {
					return '<td data-label="' + esc(c[1]) + '"><div class="msm-palname"><textarea rows="1" class="msm-palta"' + a + ' autocomplete="off" spellcheck="false">' + esc(r.nazwa || '') + '</textarea></div></td>';
				}
				if (c[0] === 'rysunek') {
					return '<td data-label="' + esc(c[1]) + '"><textarea rows="1" class="msm-palta"' + a + ' autocomplete="off" spellcheck="false">' + esc(r.rysunek || '') + '</textarea></td>';
				}
				return '<td data-label="' + esc(c[1]) + '"><input type="text"' + a + (c[3] ? ' inputmode="decimal" class="is-num"' : '') + ' value="' + esc(palCell(c, r[c[0]])) + '" autocomplete="off" spellcheck="false"></td>';
			}).join('') + '<td class="msm-kt__x"><button type="button" class="msm-iconbtn" data-prdel="' + p.id + ':' + ri + '" title="Usuń wiersz" aria-label="Usuń wiersz">×</button></td></tr>';
		}
		function palCardHtml(p, o) {
			var sum = p.poz.reduce(function (a, r) { return a + (r.ilosc || 0); }, 0);
			return '<article class="msm-card msm-palc' + (p.id === palPrev ? ' is-prev' : '') + '" data-pal="' + p.id + '">' +
				'<header class="msm-palc__h"><button type="button" class="msm-palc__nr" data-palnr="' + p.id + '" title="Zmień numer palety">' + esc(p.numer) +
				'<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"/></svg></button><span class="msm-muted msm-small">' + esc(p.data) + ' · ' + fmtNum(sum) + ' szt.</span><span class="msm-kc__st" data-kst></span>' +
				'<button type="button" class="msm-btn msm-btn-sm msm-btn-ghost" data-palprev="' + p.id + '">Podgląd</button>' +
				'<button type="button" class="msm-iconbtn" data-palm="' + p.id + '" aria-label="Akcje palety">' + ICO_DOTS + '</button></header>' +
				'<div class="msm-palwarn" data-palwarn hidden></div>' +
				'<div class="msm-kt-wrap"><table class="msm-kt msm-palt"><colgroup>' + PCOL.map(function (c) { return '<col style="width:' + c[2] + '%">'; }).join('') + '<col style="width:44px"></colgroup>' +
				'<thead><tr>' + PCOL.map(function (c) { return '<th' + (c[3] ? ' class="num"' : '') + '>' + unitLbl(c[1]) + '</th>'; }).join('') + '<th></th></tr></thead><tbody>' +
				(p.poz.length ? p.poz.map(function (r, ri) { return palRowHtml(p, r, ri, o); }).join('') : '<tr class="msm-kt__empty"><td colspan="' + (PCOL.length + 1) + '">Brak pozycji.</td></tr>') +
				'</tbody></table></div><button type="button" class="msm-kt-add" data-praddrow="' + p.id + '">+ Dodaj pozycję na palecie</button></article>';
		}
		function drawPalety(tb, o) {
			var R = PAL, ps = R.palety, last = ps[ps.length - 1];
			o.palety_n = ps.length; // licznik na zakładce – aktualny po dodaniu / usunięciu palety
			var pbn = document.querySelector('[data-paln]'); if (pbn) { pbn.textContent = ps.length; pbn.hidden = !ps.length; }
			/* Kopia poprzedniej (ostatniej) palety: te same pozycje, ilości, wagi i stosy – nowy wolny numer. */
			var copyBtn = last ? '<button type="button" class="msm-btn" data-palcopy="' + last.id + '" title="Nowa paleta ' + esc(R.nastepny) + ' z pozycjami skopiowanymi z ' + esc(last.numer) + '"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15H4a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v1"/></svg> Skopiuj poprzednią (' + esc(last.numer) + ')</button>' : '';
			if (!palPrev || !ps.some(function (p) { return p.id === palPrev; })) palPrev = ps.length ? ps[ps.length - 1].id : 0;
			var dl = '<datalist id="msm-paldet-' + o.id + '">' + o.det.map(function (d) { return '<option value="' + esc(d.nazwa_detalu || '') + '">' + esc([d.nr_rysunku, d.material].filter(Boolean).join(' · ')) + '</option>'; }).join('') + '</datalist>';
			tb.innerHTML =
				'<div class="msm-ptool"><span class="msm-muted">' + (ps.length ? ps.length + ' ' + (ps.length === 1 ? 'paleta' : ps.length < 5 ? 'palety' : 'palet') + ' · ' + esc(ps[0].numer) + (ps.length > 1 ? ' – ' + esc(ps[ps.length - 1].numer) : '') : 'Brak palet') + ' · następny wolny numer: <b>' + esc(R.nastepny) + '</b></span>' +
				'<span class="msm-ptool__btns">' + (ps.length ? '<a class="msm-btn" href="' + esc(palUrl(o, '', { auto: 1 })) + '" target="_blank" rel="noopener">Pobierz PDF (' + ps.length + ')</a>' : '') +
				copyBtn + '<button type="button" class="msm-btn msm-btn-primary" data-paladd>+ Nowa paleta</button></span></div>' +
				'<section class="msm-card msm-kc"><header class="msm-kc__h"><h2>Nadawca i odbiorca</h2><span class="msm-kc__st" data-kst></span></header><div class="msm-pgo__grid">' +
				palAddr('nad', 'Nadawca / Sender', R.nadawca, R.nadawca_wlasny, 'Z Ustawień', 'Przywróć z Ustawień', 'Dane domyślne zmienisz w Techniczne → Ustawienia.') +
				palAddr('odb', 'Odbiorca / Recipient', R.odbiorca, R.odbiorca_wlasny, 'Z karty projektu', 'Przywróć z karty projektu', 'Zmiana tutaj dotyczy tylko paletówek.') +
				'</div></section>' +
				(ps.length ? '<div class="msm-pal-list">' + ps.map(function (p) { return palCardHtml(p, o); }).join('') + '</div>' +
					'<div class="msm-pal-next"><span class="msm-muted">Następna paleta: <b>' + esc(R.nastepny) + '</b></span>' + copyBtn + '<button type="button" class="msm-btn" data-paladd>+ Nowa paleta</button></div>'
					: '<div class="msm-card msm-empty msm-pal-empty"><svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 17h18M3 21h18M5 17v4M12 17v4M19 17v4M6 7h12v10H6z"/></svg><h3>Brak paletówek</h3><p class="msm-muted">Dodaj pierwszą paletę – dostanie numer ' + esc(R.nastepny) + ' i pozycję z tego zlecenia.</p></div>') +
				(ps.length ? '<section class="msm-palpv"><header><h2>Podgląd paletówki <span data-pvnr>' + esc((ps.filter(function (p) { return p.id === palPrev; })[0] || {}).numer || '') + '</span></h2>' +
					'<a class="msm-btn msm-btn-sm" data-pvpdf href="' + esc(palUrl(o, palPrev, { auto: 1 })) + '" target="_blank" rel="noopener">Pobierz PDF tej palety</a></header>' +
					'<div class="msm-palpv__box"><iframe title="Podgląd paletówki" data-pvframe src="' + esc(palUrl(o, palPrev, { embed: 1 })) + '"></iframe></div></section>' : '') + dl;
			bindPalTop(tb, o);
			bindPalety(tb, o);
			wymCheck(tb, o, false);
			fitPreview(tb);
			palGrowAll(tb);
			if (document.fonts && document.fonts.ready) document.fonts.ready.then(function () { palGrowAll(tb); });
			if (!tb._fit) { tb._fit = true; window.addEventListener('resize', function () { if (document.body.contains(tb)) { fitPreview(tb); palGrowAll(tb); } }); }
		}
		function fitPreview(tb) {
			var box = tb.querySelector('.msm-palpv__box'), fr = tb.querySelector('[data-pvframe]'); if (!box || !fr) return;
			var W = 794, H = 1123, sc = Math.min(1, box.clientWidth / W); // A4 przy 96 dpi
			fr.style.width = W + 'px'; fr.style.height = H + 'px'; fr.style.transform = 'scale(' + sc + ')';
			box.style.height = Math.ceil(H * sc) + 'px';
		}
		function reloadPreview(tb, o) {
			var fr = tb.querySelector('[data-pvframe]'); if (!fr) return;
			fr.src = palUrl(o, palPrev, { embed: 1, _: Date.now() });
			var p = PAL.palety.filter(function (x) { return x.id === palPrev; })[0];
			tb.querySelector('[data-pvnr]').textContent = p ? p.numer : '';
			tb.querySelector('[data-pvpdf]').href = palUrl(o, palPrev, { auto: 1 });
			tb.querySelectorAll('[data-pal]').forEach(function (c) { c.classList.toggle('is-prev', +c.getAttribute('data-pal') === palPrev); });
		}
		function findPal(id) { return PAL.palety.filter(function (p) { return p.id === id; })[0]; }
		var palTimers = {};
		/* ---- Kontrola ilości z Karty projektu → Wymagania techniczne ----
		   Pozycja palety jest przypisana do wiersza wymagań po numerze części (rysunku), a gdy go brak – po nazwie.
		   Liczy się suma ze wszystkich palet zlecenia. */
		function wNorm(v) { return srchNorm(v).replace(/[\s.,;:_\-\/]+/g, ''); }
		function wymList(o) {
			return ((o.karta && o.karta.wymagania) || []).map(function (w, i) {
				var q = palNum(String(w.ilosc || '').replace(/[^\d\s,.]/g, '').trim());
				return { i: i, lp: w.lp || String(i + 1), nazwa: w.nazwa || '', rys: wNorm(w.rysunek), naz: wNorm(w.nazwa), ilosc: q };
			}).filter(function (w) { return w.ilosc > 0 && (w.rys || w.naz); });
		}
		function wymFor(W, r, o) {
			var d = r.det_id ? o.det.filter(function (x) { return x.id === r.det_id; })[0] : null;
			var rys = [wNorm(r.rysunek), d ? wNorm(d.nr_rysunku) : ''].filter(Boolean), naz = [wNorm(r.nazwa), d ? wNorm(d.nazwa_detalu) : ''].filter(Boolean);
			return W.filter(function (w) { return w.rys && rys.indexOf(w.rys) >= 0; })[0] ||
				W.filter(function (w) { return w.naz && naz.indexOf(w.naz) >= 0; })[0] || null;
		}
		/* { indeks wymagania: { w, suma, palety: [numery] } } – tylko przekroczone. */
		function wymOver(o) {
			var W = wymList(o), S = {};
			if (!W.length || !PAL) return {};
			PAL.palety.forEach(function (p) {
				p.poz.forEach(function (r) {
					var w = wymFor(W, r, o); if (!w || !r.ilosc) return;
					var e = S[w.i] || (S[w.i] = { w: w, suma: 0, palety: [] });
					e.suma += r.ilosc; if (e.palety.indexOf(p.numer) < 0) e.palety.push(p.numer);
				});
			});
			Object.keys(S).forEach(function (k) { if (S[k].suma <= S[k].w.ilosc) delete S[k]; });
			return S;
		}
		function wymMsg(e) {
			return 'Przekroczono ilość z Karty projektu (Wymagania techniczne, poz. ' + e.w.lp + (e.w.nazwa ? ' „' + e.w.nazwa + '”' : '') + '): zamówiono ' + fmtNum(e.w.ilosc) + ' szt., na paletach ' + fmtNum(e.suma) + ' szt. (+' + fmtNum(e.suma - e.w.ilosc) + ').';
		}
		/* Ostrzeżenia na kartach palet i oznaczenie pól ilości. Zwraca przekroczenia. */
		function wymMark(tb, o) {
			var S = wymOver(o), W = wymList(o);
			(PAL ? PAL.palety : []).forEach(function (p) {
				var card = tb.querySelector('[data-pal="' + p.id + '"]'); if (!card) return;
				var hit = [];
				p.poz.forEach(function (r, ri) {
					var w = W.length ? wymFor(W, r, o) : null, e = w && S[w.i];
					var inp = card.querySelector('[data-pr="' + p.id + ':' + ri + ':ilosc"]');
					if (inp) { inp.classList.toggle('is-over', !!e); inp.title = e ? wymMsg(e) : (w ? 'Karta projektu: ' + fmtNum(w.ilosc) + ' szt. (poz. ' + w.lp + ')' : ''); }
					if (e && hit.indexOf(e) < 0) hit.push(e);
				});
				var box = card.querySelector('[data-palwarn]'); if (!box) return;
				box.hidden = !hit.length;
				box.innerHTML = hit.map(function (e) { return '<p><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/><path d="M12 9v4M12 17h.01"/></svg><span>' + esc(wymMsg(e)) + (e.palety.length > 1 ? ' <small>Palety: ' + esc(e.palety.join(', ')) + '.</small>' : '') + '</span></p>'; }).join('');
			});
			return S;
		}
		/* Odświeża ostrzeżenia; notify – komunikat, gdy przekroczenie jest nowe albo większe niż wcześniej. */
		function wymCheck(tb, o, notify) {
			var S = wymMark(tb, o), before = wymOverKeys;
			wymOverKeys = Object.keys(S).map(function (k) { return k + ':' + S[k].suma; });
			if (notify) Object.keys(S).forEach(function (k) { if (before.indexOf(k + ':' + S[k].suma) < 0) toast(wymMsg(S[k]), 'warn'); });
		}
		function savePal(tb, o, p) {
			var card = tb.querySelector('[data-pal="' + p.id + '"]');
			kState(card, 'saving');
			clearTimeout(palTimers[p.id]);
			palTimers[p.id] = setTimeout(function () {
				api('/prod/pal/' + p.id, { method: 'POST', body: { poz: p.poz } }).then(function () {
					kState(card, 'saved');
					var sum = p.poz.reduce(function (a, r) { return a + (r.ilosc || 0); }, 0), sm = card && card.querySelector('.msm-palc__h .msm-small');
					if (sm) sm.textContent = p.data + ' · ' + fmtNum(sum) + ' szt.';
					if (p.id === palPrev) reloadPreview(tb, o);
				}).catch(function (e) { kState(card, ''); toast(e.message, 'err'); });
			}, 300);
		}
		function palNum(v) { v = String(v || '').replace(/\s/g, '').replace(',', '.').replace(/mm$/i, ''); return v === '' || isNaN(+v) ? null : +v; }
		/* Nadawca / odbiorca: edytor; pusty albo równy domyślnemu = dane domyślne (Ustawienia / karta projektu). */
		function palAddr(key, label, val, own, srcLbl, resetLbl, note) {
			return '<div class="msm-pf--6 msm-palodb"><div class="msm-pf"><span>' + esc(label) + '</span>' + rteHtml(' data-paladdr="' + key + '"', val) + '</div>' +
				'<div class="msm-palodb-info">' + (own
					? '<span class="msm-palsrc is-own">Własne dane dla paletówek</span><button type="button" class="msm-btn msm-btn-sm msm-btn-ghost" data-paladdrreset="' + key + '"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/></svg> ' + esc(resetLbl) + '</button>'
					: '<span class="msm-palsrc">' + esc(srcLbl) + '</span><span class="msm-muted msm-small">' + esc(note) + '</span>') + '</div></div>';
		}
		function bindPalTop(tb, o) {
			tb.querySelectorAll('[data-paladd]').forEach(function (b) { b.addEventListener('click', function () { palAdd(tb, o, 1, 0); }); });
			tb.querySelectorAll('[data-palcopy]').forEach(function (b) {
				b.addEventListener('click', function () { b.disabled = true; palAdd(tb, o, 1, +b.getAttribute('data-palcopy'), true); });
			});
			var F = { nad: ['nadawca', 'nadawca_def'], odb: ['odbiorca', 'odbiorca_karta'] };
			function saveAddr(key, v) {
				var sec = tb.querySelector('.msm-kc'), body = {}; kState(sec, 'saving');
				body[F[key][0]] = v;
				api('/prod/order/' + o.id + '/pal-odbiorca', { method: 'POST', body: body }).then(function (r) { PAL = r; kState(sec, 'saved'); drawPalety(tb, o); }).catch(function (e) { kState(sec, ''); toast(e.message, 'err'); });
			}
			rteBind(tb);
			tb.querySelectorAll('[data-paladdr]').forEach(function (el) {
				var key = el.getAttribute('data-paladdr');
				el.addEventListener('blur', function () {
					var v = rteValue(el);
					if (rteSame(v, PAL[F[key][0]] || '')) return;
					saveAddr(key, rteSame(v, PAL[F[key][1]] || '') ? '' : v);
				});
			});
			tb.querySelectorAll('[data-paladdrreset]').forEach(function (b) {
				b.addEventListener('click', function () { saveAddr(b.getAttribute('data-paladdrreset'), ''); });
			});
		}
		/* Wysokość pola tekstowego dopasowana do treści (zawijanie długich nazw i numerów). */
		function palGrow(el) {
			if (!el.offsetParent) { requestAnimationFrame(function () { if (el.offsetParent) palGrow(el); }); return; }
			el.style.height = 'auto'; el.style.height = (el.scrollHeight + el.offsetHeight - el.clientHeight) + 'px'; // + obramowanie
		}
		function palGrowAll(scope) {
			requestAnimationFrame(function () { scope.querySelectorAll('textarea.msm-palta').forEach(palGrow); });
		}
		/* Podpowiedzi nazw pozycji ze zlecenia (zamiast <datalist>, który nie działa z polem wielowierszowym). */
		function palSuggest(el, o) {
			var names = o.det.map(function (d) { return d.nazwa_detalu || ''; }).filter(function (x, i, a) { return x && a.indexOf(x) === i; });
			if (!names.length) return;
			var box = document.createElement('div'); box.className = 'msm-palsug'; box._el = el; box.hidden = true; box.setAttribute('role', 'listbox');
			(el.closest('.msm-app') || document.body).appendChild(box); // poza przewijaną tabelą (nie jest ucinana), w stylu aplikacji
			var cur = -1, L = [];
			function show(e) {
				var q = e && e.type === 'input' ? srchNorm(el.value.trim()) : ''; // po wejściu w pole – wszystkie pozycje zlecenia
				L = names.filter(function (n) { return !q || srchNorm(n).indexOf(q) >= 0; });
				if (L.length === 1 && L[0] === el.value.trim()) L = [];
				cur = -1;
				box.innerHTML = L.map(function (n, i) {
					var d = o.det.filter(function (x) { return x.nazwa_detalu === n; })[0] || {};
					return '<button type="button" role="option" data-i="' + i + '"><b>' + esc(n) + '</b>' + (d.nr_rysunku || d.material ? '<small>' + esc([d.nr_rysunku, d.material].filter(Boolean).join(' · ')) + '</small>' : '') + '</button>';
				}).join('');
				box.hidden = !L.length;
				if (!box.hidden) {
					var rc = el.getBoundingClientRect();
					box.style.top = (rc.bottom + 4) + 'px'; box.style.left = rc.left + 'px'; box.style.minWidth = rc.width + 'px';
				}
			}
			function onScroll() { if (!document.body.contains(el)) { box.remove(); window.removeEventListener('scroll', onScroll, true); return; } box.hidden = true; }
			window.addEventListener('scroll', onScroll, true);
			function pick(i) {
				el.value = L[i]; box.hidden = true; palGrow(el);
				el.dispatchEvent(new Event('change'));
			}
			function mark() { box.querySelectorAll('button').forEach(function (b, i) { b.classList.toggle('is-on', i === cur); }); }
			box.addEventListener('mousedown', function (e) { e.preventDefault(); var b = e.target.closest('[data-i]'); if (b) pick(+b.getAttribute('data-i')); });
			el.addEventListener('focus', show);
			el.addEventListener('input', show);
			el.addEventListener('blur', function () { box.hidden = true; if (!document.body.contains(el)) box.remove(); });
			el.addEventListener('keydown', function (e) {
				if (box.hidden) return;
				if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { e.preventDefault(); cur = (cur + (e.key === 'ArrowDown' ? 1 : -1) + L.length) % L.length; mark(); }
				else if (e.key === 'Enter' && cur >= 0) { e.preventDefault(); e.stopImmediatePropagation(); pick(cur); el.blur(); }
				else if (e.key === 'Escape') { e.stopPropagation(); box.hidden = true; }
			});
		}
		/* Obsługa kart palet – tylko w podanym zakresie (cała lista albo jedna przerysowana karta). */
		function bindPalety(tb, o, scope) {
			scope = scope || tb;
			document.querySelectorAll('.msm-palsug').forEach(function (b) { if (b._el && !document.body.contains(b._el)) b.remove(); });
			scope.querySelectorAll('textarea.msm-palta').forEach(function (el) {
				el.addEventListener('input', function () {
					if (/[\r\n]/.test(el.value)) el.value = el.value.replace(/\s*[\r\n]+\s*/g, ' '); // jedna linia (wklejone z Excela)
					palGrow(el);
				});
				palGrow(el);
				if (/:nazwa$/.test(el.getAttribute('data-pr'))) palSuggest(el, o);
			});
			scope.querySelectorAll('[data-pr]').forEach(function (el) {
				el.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); el.blur(); } });
				el.addEventListener('change', function () {
					var k = el.getAttribute('data-pr').split(':'), p = findPal(+k[0]), r = p && p.poz[+k[1]], f = k[2]; if (!r) return;
					var col = PCOL.filter(function (c) { return c[0] === f; })[0];
					if (col[3]) {
						var n = palNum(el.value);
						if (el.value.trim() !== '' && n === null) { toast('„' + col[1] + '” musi być liczbą.', 'err'); el.value = palCell(col, r[f]); return; }
						r[f] = f === 'ilosc' || f === 'stosy' ? (n === null ? (f === 'ilosc' ? 0 : null) : Math.round(n)) : n;
						el.value = palCell(col, r[f]);
					} else r[f] = el.value.trim();
					/* Wybór nazwy pozycji ze zlecenia uzupełnia numer części i materiał. */
					if (f === 'nazwa') {
						var d = o.det.filter(function (x) { return (x.nazwa_detalu || '') === r.nazwa; })[0];
						if (d) {
							r.det_id = d.id;
							var tr = el.closest('tr');
							if (!r.rysunek) { r.rysunek = d.nr_rysunku || ''; tr.querySelector('[data-pr$=":rysunek"]').value = r.rysunek; }
							if (!r.material) { r.material = d.material || ''; tr.querySelector('[data-pr$=":material"]').value = r.material; }
						}
					}
					wymCheck(tb, o, f === 'ilosc' || f === 'nazwa' || f === 'rysunek');
					savePal(tb, o, p);
				});
			});
			scope.querySelectorAll('[data-prdel]').forEach(function (b) {
				b.addEventListener('click', function () {
					var k = b.getAttribute('data-prdel').split(':'), p = findPal(+k[0]);
					p.poz.splice(+k[1], 1); redrawPal(tb, o, p); savePal(tb, o, p);
				});
			});
			scope.querySelectorAll('[data-praddrow]').forEach(function (b) {
				b.addEventListener('click', function () {
					var p = findPal(+b.getAttribute('data-praddrow'));
					p.poz.push({ det_id: null, nazwa: '', rysunek: '', ilosc: 0, waga: null, stosy: null, wysokosc: null, material: '' });
					redrawPal(tb, o, p);
					var f = tb.querySelector('[data-pal="' + p.id + '"] tbody tr:last-child [data-pr]'); if (f) f.focus();
					savePal(tb, o, p);
				});
			});
			scope.querySelectorAll('[data-palprev]').forEach(function (b) {
				b.addEventListener('click', function () { palPrev = +b.getAttribute('data-palprev'); reloadPreview(tb, o); tb.querySelector('.msm-palpv').scrollIntoView({ behavior: 'smooth', block: 'start' }); });
			});
			scope.querySelectorAll('[data-palnr]').forEach(function (b) {
				b.addEventListener('click', function () { palNr(tb, o, findPal(+b.getAttribute('data-palnr'))); });
			});
			scope.querySelectorAll('[data-palm]').forEach(function (b) {
				b.addEventListener('click', function () {
					var p = findPal(+b.getAttribute('data-palm'));
					popMenu(b, 'Paleta ' + p.numer, [
						{ label: 'Zmień numer palety…', run: function () { palNr(tb, o, p); } },
						{ label: 'Powiel paletę (kolejne numery)…', run: function () { palDup(tb, o, p); } },
						{ label: 'Pobierz PDF tej palety', run: function () { window.open(palUrl(o, p.id, { auto: 1 }), '_blank'); } }, '-',
						{ label: 'Usuń paletę', danger: true, run: function () { palDel(tb, o, p); } }
					]);
				});
			});
		}
		function redrawPal(tb, o, p) {
			var card = tb.querySelector('[data-pal="' + p.id + '"]'); if (!card) return;
			var tmp = document.createElement('div'); tmp.innerHTML = palCardHtml(p, o);
			var nc = tmp.firstChild; card.parentNode.replaceChild(nc, card);
			bindPalety(tb, o, nc);
			wymCheck(tb, o, false);
		}
		function palAdd(tb, o, ile, wzor, copy) {
			var src = copy ? findPal(wzor) : null;
			api('/prod/order/' + o.id + '/palety', { method: 'POST', body: { ile: ile, wzor: wzor } }).then(function (r) {
				PAL = r; palPrev = r.palety.length ? r.palety[r.palety.length - 1].id : 0;
				toast(src ? 'Dodano paletę ' + r.dodane[0] + ' – kopia ' + src.numer + '.' : r.dodane.length === 1 ? 'Dodano paletę ' + r.dodane[0] + '.' : 'Dodano palety ' + r.dodane[0] + ' – ' + r.dodane[r.dodane.length - 1] + '.');
				var prev = wymOverKeys;
				drawPalety(tb, o);
				var S = wymOver(o);
				Object.keys(S).forEach(function (k) { if (prev.indexOf(k + ':' + S[k].suma) < 0) toast(wymMsg(S[k]), 'warn'); });
				var last = tb.querySelector('[data-pal="' + palPrev + '"]'); if (last) last.scrollIntoView({ behavior: 'smooth', block: 'center' });
			}).catch(function (e) { tb.querySelectorAll('[data-palcopy]').forEach(function (b) { b.disabled = false; }); toast(e.message, 'err'); });
		}
		/* Zmiana numeru palety – na bieżąco sprawdza, czy numer nie jest już użyty (w dowolnym zleceniu). */
		function palNr(tb, o, p) {
			var m = openModal('Numer palety ' + p.numer, '<form class="msm-form" data-nrf novalidate><div class="msm-form-err msm-alert msm-alert-err" hidden></div>' +
				'<div class="msm-grid"><label class="msm-field full" data-field="numer"><span>Nowy numer</span><input type="text" name="numer" value="' + esc(p.numer) + '" autocomplete="off" spellcheck="false" placeholder="np. P00127/26">' +
				'<em class="msm-field-hint" data-nrinfo>Format P00127/26 – możesz wpisać też samo „127” (rok ' + p.rok + ').</em><em class="msm-ferr"></em></label></div></form>',
				'<button type="button" class="msm-btn" data-close>Anuluj</button><button type="button" class="msm-btn msm-btn-primary" data-nrok>Zapisz numer</button>', false);
			var f = m.querySelector('[data-nrf]'), inp = f.numer, info = m.querySelector('[data-nrinfo]'), okb = m.querySelector('[data-nrok]'), t = null, seq = 0;
			inp.focus(); inp.select();
			function check() {
				var my = ++seq, v = inp.value.trim();
				if (!v) { info.textContent = 'Wpisz numer.'; info.className = 'msm-field-hint msm-hint-warn'; okb.disabled = true; return; }
				api('/prod/pal/sprawdz', { query: { numer: v, rok: p.rok, except: p.id } }).then(function (r) {
					if (my !== seq) return;
					var same = r.numer === p.numer;
					info.textContent = same ? 'To obecny numer tej palety.' : r.msg;
					info.className = 'msm-field-hint' + (r.ok ? (same ? '' : ' msm-hint-ok') : ' msm-hint-warn');
					okb.disabled = !r.ok || same;
				}).catch(function () {});
			}
			inp.addEventListener('input', function () { clearTimeout(t); okb.disabled = true; t = setTimeout(check, 250); });
			check();
			function save() {
				if (okb.disabled) return;
				okb.disabled = true;
				api('/prod/pal/' + p.id + '/numer', { method: 'POST', body: { numer: inp.value.trim() } }).then(function (r) {
					closeModal(); PAL = r;
					var np = findPal(p.id); toast('Zmieniono numer palety ' + p.numer + ' → ' + (np ? np.numer : '') + '.');
					drawPalety(tb, o);
				}).catch(function (e) { okb.disabled = false; showErrors(f, e); });
			}
			okb.addEventListener('click', save);
			f.addEventListener('submit', function (e) { e.preventDefault(); save(); });
			inp.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); save(); } });
		}
		function palDup(tb, o, p) {
			var m = openModal('Powiel paletę ' + p.numer, '<form class="msm-form" data-dupf><p class="msm-muted">Nowe palety dostaną kolejne wolne numery (od ' + esc(PAL.nastepny) + ') i te same pozycje co ' + esc(p.numer) + '.</p>' +
				'<div class="msm-grid"><label class="msm-field"><span>Ile kopii?</span><input type="number" name="ile" min="1" max="50" value="1" inputmode="numeric"></label></div></form>',
				'<button type="button" class="msm-btn" data-close>Anuluj</button><button type="button" class="msm-btn msm-btn-primary" data-dupok>Powiel</button>', false);
			var f = m.querySelector('[data-dupf]'); f.ile.focus(); f.ile.select();
			function go() { var n = Math.max(1, Math.min(50, parseInt(f.ile.value, 10) || 1)); closeModal(); palAdd(tb, o, n, p.id); }
			m.querySelector('[data-dupok]').addEventListener('click', go);
			f.addEventListener('submit', function (e) { e.preventDefault(); go(); });
		}
		function palDel(tb, o, p) {
			confirmBox('Usunąć paletę ' + p.numer + '?', 'Paleta zniknie z systemu, a numer ' + esc(p.numer) + ' wróci do puli – dostanie go następna nowa paleta. Zapis trafi do Historii zmian.', 'Usuń paletę').then(function (ok) {
				if (!ok) return;
				api('/prod/pal/' + p.id + '/delete', { method: 'POST' }).then(function (r) { PAL = r; toast('Usunięto paletę ' + p.numer + '.'); drawPalety(tb, o); }).catch(function (e) { toast(e.message, 'err'); });
			});
		}

		function progHtml(p, z) {
			return '<div class="msm-pgd__pv"><b' + (p >= 100 ? ' class="is-done"' : '') + '>' + fmtNum(p, 1) + '%</b>' + progress(p) +
				'<em class="' + (z < 0 ? 'is-neg' : '') + '">zostało ' + fmtNum(z) + '</em></div>';
		}

		/* Podpowiedzi z dotychczasowych wpisów (najczęstsze najpierw). */
		function datalists() {
			function uniq(f, base) {
				var cnt = {};
				(base || []).forEach(function (v) { cnt[v] = 1e6; });
				DATA.orders.forEach(function (o) { o.det.forEach(function (d) { var v = String(d[f] || '').trim(); if (v) cnt[v] = (cnt[v] || 0) + 1; }); });
				return Object.keys(cnt).sort(function (a, b) { return cnt[b] - cnt[a] || a.localeCompare(b, 'pl', { numeric: true }); });
			}
			function dl(id, vals) { return '<datalist id="' + id + '">' + vals.map(function (v) { return '<option value="' + esc(v) + '">'; }).join('') + '</datalist>'; }
			return dl('msm-pg-dl-wersja', uniq('wersja', ['V1', 'V2', 'V3', 'V4', 'V5'])) + dl('msm-pg-dl-material', uniq('material'));
		}

		var TABS_P = [['karta', 'Karta projektu'], ['szczegoly', 'Szczegóły projektu'], ['paletowki', 'Paletówki projektu'], ['notatki', 'Notatki']].concat(PRZES ? [['przesylki', 'Przesyłki']] : []).concat(C.menu && C.menu.prod_karty ? [['karty', 'Karty zmian']] : []).concat(mOn('zlecenie') ? [['pobrania', 'Pobrania']] : []);
		function tabHash(id, t) { return '#prod-' + id + (t && t !== 'karta' ? '-' + t : ''); }

		function renderDetail() {
			GRID.ready = false;
			var o = ORDER, idx = DATA.orders.indexOf(o), prev = DATA.orders[idx + 1], next = DATA.orders[idx - 1]; // jak na liście: wyżej = nowsze
			host.innerHTML =
				'<div class="msm-pgo-top"><a class="msm-link msm-pgo-back" href="#produkcja">‹ Produkcja</a>' +
				'<span class="msm-pgo-nav">' + (prev ? '<a class="msm-btn msm-btn-sm" href="' + tabHash(prev.id, TAB) + '" title="Zlecenie wyżej na liście (nowsze)">‹ ' + esc(prev.nr_zlec || 'poprzednie') + '</a>' : '') +
				(next ? '<a class="msm-btn msm-btn-sm" href="' + tabHash(next.id, TAB) + '" title="Zlecenie niżej na liście (starsze)">' + esc(next.nr_zlec || 'następne') + ' ›</a>' : '') + '</span></div>' +
				'<div class="msm-pagehead"><div><h1 data-ptitle>Zlecenie ' + esc(o.nr_zlec || '(bez numeru)') + '</h1><p class="msm-muted" data-psub>' + esc(subTitle(o)) + '</p></div>' +
				'<div class="msm-pagehead__tools"><button type="button" class="msm-btn msm-iconbtn-txt" data-pom aria-label="Więcej">' + ICO_DOTS + '</button></div></div>' +
				'<nav class="msm-ptabs" role="tablist">' + TABS_P.map(function (t) {
					return '<button type="button" role="tab" data-ptab="' + t[0] + '" aria-selected="' + (TAB === t[0]) + '" class="' + (TAB === t[0] ? 'is-on' : '') + '">' + t[1] +
						(t[0] === 'szczegoly' ? ' <span class="msm-ptabs__n">' + o.det.length + '</span>' : '') +
						(t[0] === 'notatki' ? ' <span class="msm-ptabs__n" data-notn' + (o.notatki_n ? '' : ' hidden') + '>' + (o.notatki_n || 0) + '</span>' : '') +
						(t[0] === 'paletowki' ? ' <span class="msm-ptabs__n" data-paln' + (o.palety_n ? '' : ' hidden') + '>' + (o.palety_n || 0) + '</span>' : '') +
						(t[0] === 'karty' ? ' <span class="msm-ptabs__n" data-kztn' + (o.karty_n ? '' : ' hidden') + '>' + (o.karty_n || 0) + '</span>' : '') +
						(t[0] === 'pobrania' ? ' <span class="msm-ptabs__n" data-pbtn' + (o.pobrania_n ? '' : ' hidden') + '>' + (o.pobrania_n || 0) + '</span>' : '') + '</button>';
				}).join('') + '</nav>' +
				'<div data-ptabbody></div>' + datalists();
			host.querySelector('[data-pom]').addEventListener('click', function (e) {
				popMenu(e.currentTarget, 'Zlecenie ' + (o.nr_zlec || ''), [
					{ label: 'Przesuń wyżej na liście', disabled: idx === DATA.orders.length - 1, run: function () { moveOrder(o, 1); } },
					{ label: 'Przesuń niżej na liście', disabled: idx === 0, run: function () { moveOrder(o, -1); } }, '-',
					{ label: 'Usuń zlecenie', danger: true, run: function () { delOrder(o); } }
				]);
			});
			host.querySelectorAll('[data-ptab]').forEach(function (b) {
				b.addEventListener('click', function () {
					var t = b.getAttribute('data-ptab'); if (t === TAB) return;
					TAB = t;
					history.replaceState(null, '', tabHash(o.id, TAB));
					renderDetail();
				});
			});
			var tb = host.querySelector('[data-ptabbody]');
			if (TAB === 'karta') return renderKarta(tb, o);
			if (TAB === 'paletowki') return renderPalety(tb, o);
			if (TAB === 'notatki') return renderNotatki(tb, o);
			if (TAB === 'przesylki' && PRZES) return renderPrzesylkiZlec(tb, o);
			if (TAB === 'karty' && C.menu && C.menu.prod_karty) return renderKartyZlec(tb, o);
			if (TAB === 'pobrania' && mOn('zlecenie')) return renderPobraniaZlec(tb, o);
			tb.innerHTML = (narrow ? '' : '<div class="msm-ptool"><span class="msm-muted">Widok pozycji</span><div class="msm-seg" role="tablist"><button type="button" data-view="cards" class="' + (view === 'cards' ? 'is-on' : '') + '">Karty</button><button type="button" data-view="table" class="' + (view === 'table' ? 'is-on' : '') + '">Tabela</button></div></div>') +
				headHtml(o) +
				'<div data-pgbody></div>' +
				'<button type="button" class="msm-pgd-add" data-padd><span aria-hidden="true">+</span> Dodaj pozycję</button>';
			tb.querySelector('[data-padd]').addEventListener('click', function () { addDetail(o, o.det[o.det.length - 1] && o.det[o.det.length - 1].id); });
			tb.querySelectorAll('[data-view]').forEach(function (b) {
				b.addEventListener('click', function () {
					view = b.getAttribute('data-view');
					try { localStorage.setItem('msm_pg_view', view); } catch (e) {}
					renderDetail();
				});
			});
			bindFields(tb.querySelector('[data-pghead]'));
			var body = tb.querySelector('[data-pgbody]');
			if (view === 'table') {
				gridHost = body;
				GRID.build();
			} else {
				body.innerHTML = '<div class="msm-pgd-list" data-pgcards>' + o.det.map(function (d, i) { return detHtml(o, d, i); }).join('') + '</div>';
				bindFields(body);
				bindMag(body);
				loadNarz(o);
				/* Podpowiedź: ile sztuk tej pozycji jest już na paletach (Wykonano zostaje ręczne). */
				api('/prod/order/' + o.id + '/palety').then(function (r) {
					var sum = {};
					r.palety.forEach(function (p) { p.poz.forEach(function (x) { if (x.det_id) sum[x.det_id] = (sum[x.det_id] || 0) + (x.ilosc || 0); }); });
					o.det.forEach(function (d) {
						var el = host.querySelector('[data-palsum="' + d.id + '"]'); if (!el || !sum[d.id]) return;
						el.hidden = false; el.textContent = 'na paletach: ' + fmtNum(sum[d.id]) + (d.ilosc_zam ? ' z ' + fmtNum(d.ilosc_zam) : '') + ' szt.';
					});
				}).catch(function () {});
				body.querySelectorAll('[data-dm]').forEach(function (b) {
					b.addEventListener('click', function () {
						var d = null; o.det.forEach(function (x) { if (x.id === +b.getAttribute('data-dm')) d = x; });
						popMenu(b, 'Pozycja', [
							{ label: 'Wstaw pozycję poniżej', run: function () { addDetail(o, d.id); } },
							{ label: 'Usuń pozycję', danger: true, disabled: o.det.length <= 1, run: function () { delDetail(o, d); } }
						]);
					});
				});
			}
			if (sessionStorage.getItem('msm_pg_new')) {
				sessionStorage.removeItem('msm_pg_new');
				var nr = host.querySelector('[data-f="nr_zlec"]'); if (nr) nr.focus();
			}
		}
		function subTitle(o) {
			var n = o.karta && o.karta.nazwa_projektu;
			return [o.klient, n].filter(function (x) { return x; }).join(' · ') || ' ';
		}


		/* Pola na stronie zlecenia: zapis po wyjściu z pola (Enter w polu jednowierszowym, Esc – cofnięcie). */
		function curVal(k, id, f) {
			var v = '';
			DATA.orders.forEach(function (o) {
				if (k === 'z' && o.id === id) v = o[f];
				if (k === 'd') o.det.forEach(function (d) { if (d.id === id) v = d[f]; });
			});
			return v == null ? '' : String(v);
		}
		function grow(t) { if (t.tagName !== 'TEXTAREA') return; t.style.height = 'auto'; t.style.height = (t.scrollHeight + 2) + 'px'; }
		function bindFields(scope) {
			rteBind(scope);
			scope.querySelectorAll('[data-f]').forEach(function (el) {
				if (el.classList.contains('msm-rte__area')) {
					el.addEventListener('blur', function () {
						var k = el.getAttribute('data-k'), id = +el.getAttribute('data-id'), f = el.getAttribute('data-f');
						var old = curVal(k, id, f), v = rteValue(el);
						if (rteSame(v, old)) return;
						save([{ k: k, id: id, f: f, v: v, old: old }]);
					});
					return;
				}
				if (el.tagName === 'SELECT' || el.type === 'checkbox') {
					el.addEventListener('change', function () {
						var k = el.getAttribute('data-k'), id = +el.getAttribute('data-id'), f = el.getAttribute('data-f');
						var v = el.type === 'checkbox' ? (el.checked ? '1' : '0') : el.value;
						save([{ k: k, id: id, f: f, v: v, old: curVal(k, id, f) }]);
					});
					return;
				}
				grow(el);
				el.addEventListener('input', function () { grow(el); });
				el.addEventListener('keydown', function (e) {
					if (e.key === 'Escape') { el.value = curVal(el.getAttribute('data-k'), +el.getAttribute('data-id'), el.getAttribute('data-f')); grow(el); el.blur(); }
					if (e.key === 'Enter' && el.tagName === 'INPUT') { e.preventDefault(); el.blur(); }
				});
				el.addEventListener('blur', function () {
					var k = el.getAttribute('data-k'), id = +el.getAttribute('data-id'), f = el.getAttribute('data-f');
					var old = curVal(k, id, f), v = el.value;
					if (f === 'czas_ciecia') {
						var sv = parseSec(v);
						if (sv === null) { toast('„Czas cięcia [s]”: wpisz liczbę sekund, np. 54 albo 12,5.', 'err'); el.value = old; return; }
						v = sv; el.value = v;
					}
					if (numCol(f)) {
						if (v.trim() !== '' && isNaN(parseFloat(v.replace(/\s/g, '').replace(',', '.')))) { toast('To pole musi być liczbą.', 'err'); el.value = old; return; }
						v = String(toInt(v)); el.value = v;
					}
					if (v !== old) save([{ k: k, id: id, f: f, v: v, old: old }]);
				});
			});
		}
		/* Po zapisie: znacznik przy polu + przeliczenie realizacji pozycji. */
		function syncCards(changes, saving, reverted) {
			changes.forEach(function (c) {
				var el = host.querySelector('[data-k="' + c.k + '"][data-id="' + c.id + '"][data-f="' + c.f + '"]');
				if (el) {
					if (el.type === 'checkbox') el.checked = !!+curVal(c.k, c.id, c.f);
					else if (el.classList.contains('msm-rte__area')) { if (reverted || document.activeElement !== el) el.innerHTML = rteIn(curVal(c.k, c.id, c.f)); }
					else if (reverted || document.activeElement !== el) { el.value = curVal(c.k, c.id, c.f); grow(el); }
					var lab = el.closest('.msm-pf');
					lab.classList.toggle('is-saving', !!saving);
					if (!saving && !reverted) { lab.classList.add('is-saved'); setTimeout(function () { lab.classList.remove('is-saved'); }, 1200); }
				}
				if (c.k === 'd') {
					var card = host.querySelector('[data-det="' + c.id + '"]'); if (!card) return;
					var d = null; ORDER.det.forEach(function (x) { if (x.id === c.id) d = x; });
					if (!d) return;
					card.querySelector('[data-prog]').innerHTML = '<span>Realizacja</span>' + progHtml(pgProc(d), d.ilosc_zam - d.wykonano);
					card.querySelector('[data-dname]').textContent = d.nazwa_detalu || '';
					if (c.f === 'mat_klienta') redrawMag(d);
					if (c.f === 'dostepnosc' && !saving) narzLater(ORDER);
				}
			});
		}
		function syncHead() {
			if (!ORDER) return;
			var k = host.querySelector('[data-kpi]'); if (k) k.innerHTML = kpiHtml(ORDER, orderSums(ORDER));
			var t = host.querySelector('[data-ptitle]'); if (t) t.textContent = 'Zlecenie ' + (ORDER.nr_zlec || '(bez numeru)');
			var s = host.querySelector('[data-psub]'); if (s) s.textContent = subTitle(ORDER);
		}


		/* ================================================================
		   KARTA PROJEKTU
		   ================================================================ */
		var KT = {
			wymagania: { t: 'Wymagania techniczne', cols: [['lp', 'Lp.', 5], ['nazwa', 'Nazwa', 20, 1], ['rysunek', 'Rysunek', 15, 1], ['ilosc', 'Ilość', 7], ['material', 'Materiał / wstawka', 13], ['grubosc', 'Grubość [mm]', 8], ['masa', 'Masa [kg]', 8], ['pkwiu', 'PKWiU 2015 / CN 2023', 13], ['cad', 'Rysunek CAD', 11]] },
			dodatkowe: { t: 'Wymagania dodatkowe', cols: [['lp', 'Lp.', 6], ['kto', 'Kto dostarcza materiał', 30], ['wymagania', 'Wymagania', 64, 1]] },
			zmiany: { t: 'Historia zmian karty', cols: [['nr', 'Zmiana', 7], ['data', 'Data', 11], ['powod', 'Powód zmiany', 18, 1], ['opis', 'Opis zmiany', 40, 1], ['wprowadzil', 'Wprowadził', 12], ['zatwierdzil', 'Zatwierdził', 12]] }
		};
		var INCOTERMS = ['EXW', 'FCA', 'CPT', 'CIP', 'DPU', 'DAP', 'DDP', 'FAS', 'FOB', 'CFR', 'CIF'];

		function kf(key, label, span, opt) {
			opt = opt || {};
			var v = String((ORDER.karta || {})[key] || ''), a = ' data-kk="' + key + '"';
			if (opt.rich) return '<div class="msm-pf msm-pf--' + span + '"><span>' + unitLbl(label) + '</span>' + rteHtml(a, v, opt.ph) + '</div>';
			var ctrl = opt.select
				? '<select' + a + '>' + opt.select.map(function (x) { return '<option value="' + esc(x[0]) + '"' + (x[0] === v ? ' selected' : '') + '>' + esc(x[1]) + '</option>'; }).join('') + '</select>'
				: opt.area ? '<textarea rows="' + (opt.rows || 2) + '"' + a + ' spellcheck="false"' + (opt.ph ? ' placeholder="' + esc(opt.ph) + '"' : '') + '>' + esc(v) + '</textarea>'
				: '<input type="text"' + a + ' value="' + esc(v) + '" spellcheck="false"' + (opt.ph ? ' placeholder="' + esc(opt.ph) + '"' : '') + '>';
			return '<label class="msm-pf msm-pf--' + span + '"><span>' + unitLbl(label) + '</span>' + ctrl + '</label>';
		}
		function ksec(id, title, inner, extra) {
			return '<section class="msm-card msm-kc" data-ksec="' + id + '"><header class="msm-kc__h"><h2>' + esc(title) + '</h2>' + (extra || '') + '<span class="msm-kc__st" data-kst></span></header>' + inner + '</section>';
		}
		function ktable(key) {
			var def = KT[key], rows = ORDER.karta[key] || [];
			return '<div class="msm-kt-wrap"><table class="msm-kt"><colgroup>' + def.cols.map(function (c) { return '<col style="width:' + c[2] + '%">'; }).join('') + '<col style="width:44px"></colgroup>' +
				'<thead><tr>' + def.cols.map(function (c) { return '<th>' + unitLbl(c[1]) + '</th>'; }).join('') + '<th></th></tr></thead><tbody>' +
				(rows.length ? rows.map(function (r, ri) {
					return '<tr>' + def.cols.map(function (c) {
						var a = ' data-kt="' + key + '" data-ri="' + ri + '" data-kc="' + c[0] + '" aria-label="' + esc(c[1]) + '"';
						return '<td data-label="' + esc(c[1]) + '">' + (c[3] ? '<textarea rows="1"' + a + ' spellcheck="false">' + esc(r[c[0]] || '') + '</textarea>' : '<input type="text"' + a + ' value="' + esc(r[c[0]] || '') + '" spellcheck="false">') + '</td>';
					}).join('') + '<td class="msm-kt__x"><button type="button" class="msm-iconbtn" data-ktdel="' + key + '" data-ri="' + ri + '" title="Usuń wiersz" aria-label="Usuń wiersz">×</button></td></tr>';
				}).join('') : '<tr class="msm-kt__empty"><td colspan="' + (def.cols.length + 1) + '">Brak wierszy.</td></tr>') +
				'</tbody></table></div><button type="button" class="msm-kt-add" data-ktadd="' + key + '">+ Dodaj wiersz</button>';
		}
		function renderKarta(tb, o) {
			var K = o.karta;
			tb.innerHTML =
				'<div class="msm-ptool"><span class="msm-muted">' + (K.teczka ? esc(K.teczka) + (K.data_karty ? ' · karta z dnia ' + esc(K.data_karty) : '') : 'Karta informacyjna projektu') + '</span>' +
				'<button type="button" class="msm-btn" data-kxls><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3v12m0 0-4-4m4 4 4-4M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"/></svg> Wczytaj z Excela</button></div>' +
				ksec('dane', 'Dane projektu', '<div class="msm-pgo__grid">' +
					fld('z', o.id, 'nr_zlec', 'Nr zlecenia', o.nr_zlec, 3, { big: true, ph: 'np. B02516' }) +
					kf('nazwa_projektu', 'Nazwa projektu', 5) +
					fld('z', o.id, 'nr_zlec_klienta', 'Nr zlecenia klienta', o.nr_zlec_klienta, 4) +
					fld('z', o.id, 'klient', 'Klient', o.klient, 6) +
					fld('z', o.id, 'start_zlec', 'Początek projektu', o.start_zlec, 3, { ph: 'dd.mm.rrrr' }) +
					fld('z', o.id, 'koniec_zlec', 'Koniec projektu', o.koniec_zlec, 3, { ph: 'dd.mm.rrrr' }) +
					kf('handlowy', 'Dział handlowy', 4) + kf('kierownik', 'Kierownik projektu', 4) + kf('inzynier', 'Inżynier projektu', 4) +
					kf('teczka', 'Teczka projektu', 6) + kf('data_karty', 'Data karty', 3, { ph: 'dd.mm.rrrr' }) +
					kf('uwagi_kr', 'Uwagi do projektu', 12, { area: true, rows: 1 }) + '</div>') +
				ksec('handel', 'Warunki handlowe', '<div class="msm-pgo__grid">' +
					kf('platnosc', 'Warunki płatności', 3, { ph: 'np. 30 dni' }) +
					kf('dostawa', 'Warunki dostawy (Incoterms 2020)', 3, { select: [['', '—']].concat(INCOTERMS.map(function (x) { return [x, x]; })) }) +
					kf('poza_ue', 'Wysyłka poza UE', 3, { select: [['', '—'], ['T', 'Tak'], ['N', 'Nie']] }) +
					kf('eur1', 'EUR1', 3, { select: [['', '—'], ['T', 'Tak'], ['N', 'Nie']] }) +
					kf('nabywca', 'Nabywca – dane do faktury', 6, { rich: true }) +
					kf('odbiorca', 'Odbiorca – adres dostawy, kontakt', 6, { rich: true }) +
					kf('windykacja', 'Dane do windykacji', 12, { area: true, rows: 1 }) + '</div>') +
				ksec('wymagania', KT.wymagania.t, ktable('wymagania'), '<small class="msm-muted">z tej tabeli powstają pozycje przy zakładaniu zlecenia z karty</small>') +
				ksec('dodatkowe', KT.dodatkowe.t, ktable('dodatkowe')) +
				ksec('uwagi', 'Uwagi', '<div class="msm-pgo__grid">' + fld('z', o.id, 'uwagi_ogolne', 'Uwagi ogólne do zlecenia', o.uwagi_ogolne, 12, { rich: true }) + '</div>') +
				ksec('zmiany', KT.zmiany.t, ktable('zmiany'));
			bindFields(tb);
			bindKarta(tb, o);
			tb.querySelector('[data-kxls]').addEventListener('click', function () { pickKarta(function (res) { kartaPreview(res, o); }); });
			if (sessionStorage.getItem('msm_pg_new')) {
				sessionStorage.removeItem('msm_pg_new');
				var nr = tb.querySelector('[data-f="nr_zlec"]'); if (nr) nr.focus();
			}
		}
		function bindKarta(tb, o) {
			rteBind(tb);
			tb.querySelectorAll('[data-kk], [data-kt]').forEach(function (el) {
				if (el.classList.contains('msm-rte__area')) {
					el.addEventListener('blur', function () {
						var k = el.getAttribute('data-kk'), v = rteValue(el);
						if (rteSame(v, o.karta[k] || '')) return;
						o.karta[k] = v;
						saveKarta(o, el.closest('[data-ksec]'));
					});
					return;
				}
				grow(el);
				el.addEventListener('input', function () { grow(el); });
				if (el.tagName === 'INPUT') el.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); el.blur(); } });
				el.addEventListener(el.tagName === 'SELECT' ? 'change' : 'blur', function () {
					var K = o.karta, v = el.value, sec = el.closest('[data-ksec]');
					if (el.hasAttribute('data-kk')) {
						var k = el.getAttribute('data-kk');
						if ((K[k] || '') === v) return;
						K[k] = v;
					} else {
						var t = el.getAttribute('data-kt'), ri = +el.getAttribute('data-ri'), c = el.getAttribute('data-kc');
						if (!K[t][ri] || (K[t][ri][c] || '') === v) return;
						K[t][ri][c] = v;
					}
					if (el.getAttribute('data-kk') === 'nazwa_projektu') syncHead();
					saveKarta(o, sec);
				});
			});
			tb.querySelectorAll('[data-ktadd]').forEach(function (b) {
				b.addEventListener('click', function () {
					var t = b.getAttribute('data-ktadd'), row = {};
					KT[t].cols.forEach(function (c) { row[c[0]] = ''; });
					if (row.hasOwnProperty('lp')) row.lp = String(o.karta[t].length + 1);
					if (t === 'zmiany') { row.nr = ('0' + (o.karta[t].length + 1)).slice(-2); row.data = new Date().toLocaleDateString('pl-PL', { day: '2-digit', month: '2-digit', year: 'numeric' }); }
					o.karta[t].push(row);
					var sec = b.closest('[data-ksec]');
					redrawTable(sec, o, t, true);
					saveKarta(o, sec);
				});
			});
			tb.querySelectorAll('[data-ktdel]').forEach(function (b) {
				b.addEventListener('click', function () {
					var t = b.getAttribute('data-ktdel'), ri = +b.getAttribute('data-ri');
					o.karta[t].splice(ri, 1);
					var sec = b.closest('[data-ksec]');
					redrawTable(sec, o, t);
					saveKarta(o, sec);
				});
			});
		}
		function redrawTable(sec, o, t, focusLast) {
			var h = sec.querySelector('.msm-kc__h');
			while (h.nextSibling) sec.removeChild(h.nextSibling);
			h.insertAdjacentHTML('afterend', ktable(t));
			bindKarta(sec, o);
			if (focusLast) { var ins = sec.querySelectorAll('tbody tr:last-child [data-kc]'); var f = ins[1] || ins[0]; if (f) f.focus(); }
		}
		var kTimer = null, kSecs = [];
		function saveKarta(o, sec) {
			if (sec && kSecs.indexOf(sec) < 0) kSecs.push(sec);
			kSecs.forEach(function (x) { kState(x, 'saving'); });
			clearTimeout(kTimer);
			kTimer = setTimeout(function () {
				var secs = kSecs; kSecs = [];
				api('/prod/order/' + o.id + '/karta', { method: 'POST', body: { karta: o.karta } })
					.then(function () { secs.forEach(function (x) { kState(x, 'saved'); }); })
					.catch(function (e) { secs.forEach(function (x) { kState(x, ''); }); toast(e.message, 'err'); });
			}, 250);
		}
		function kState(sec, st) {
			var el = sec && sec.querySelector('[data-kst]'); if (!el) return;
			el.className = 'msm-kc__st' + (st ? ' is-' + st : '');
			el.textContent = st === 'saving' ? 'zapis…' : st === 'saved' ? '✓ zapisano' : '';
			if (st === 'saved') setTimeout(function () { if (el.classList.contains('is-saved')) { el.className = 'msm-kc__st'; el.textContent = ''; } }, 1600);
		}

		/* ---- Notatki zlecenia jako zadania: na górze do wykonania, niżej wykonane (wyszarzone, zostają w historii) ---- */
		function renderNotatki(tb, o) {
			var NOTES = null, EDIT = 0, HL = noteId || 0, ALLDONE = false, FOLD = false;
			try { FOLD = localStorage.getItem('msm_nt_fold') === '1'; } catch (e) {}
			noteId = 0; // podświetlenie tylko przy wejściu z listy Notatek
			/* Układ: kafelki (do wykonania / wykonane / wszystkie) + jedna karta: pole nowej notatki i lista zadań. */
			tb.innerHTML = '<div class="msm-nt msm-nt2"><div data-ntstat></div><div class="msm-nt2__card">' +
				'<form class="msm-nt-new" data-ntnew>' + rteHtml(' data-ntin', '', 'Napisz notatkę lub zadanie do zlecenia…') +
				'<div class="msm-nt-new__foot"><span class="msm-muted">Ctrl+Enter – dodaj · gotowe zadanie zaznacz kółkiem</span><button type="submit" class="msm-btn msm-btn-primary" data-ntadd>Dodaj notatkę</button></div></form>' +
				'<div data-ntlist><div class="msm-loading">Ładowanie notatek…</div></div></div></div>';
			rteBind(tb);
			var form = tb.querySelector('[data-ntnew]'), inp = form.querySelector('[data-ntin]'), list = tb.querySelector('[data-ntlist]');
			function when(n) {
				var s = fmtDate(n.created_at);
				if (n.updated_at) s += ' · zmieniono ' + fmtDate(n.updated_at) + (n.zmienil && n.zmienil !== n.autor ? ' (' + n.zmienil + ')' : '');
				return s;
			}
			function setCount() {
				o.notatki_n = NOTES.filter(function (n) { return !n.wykonano; }).length; // licznik: tylko do wykonania
				o.notatki_t = NOTES.map(function (n) { return rteText(n.tresc); }).join(' ');
				var b = host.querySelector('[data-notn]'); if (b) { b.textContent = o.notatki_n; b.hidden = !o.notatki_n; }
			}
			var ICK = '<svg class="msm-ico" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>';
			var IED = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 20h9M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/></svg>';
			var IDL = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6"/></svg>';
			var IUN = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/></svg>';
			function item(n) {
				var ed = EDIT === n.id, done = !!n.wykonano;
				var chk = done
					? '<button type="button" class="msm-nt2__ck is-on" data-ntundo title="Wykonane – kliknij, aby przywrócić do wykonania" aria-label="Przywróć do wykonania">' + ICK + '</button>'
					: '<button type="button" class="msm-nt2__ck" data-ntdone title="Oznacz jako wykonane" aria-label="Oznacz jako wykonane">' + ICK + '</button>';
				var acts = ed ? '' : (done ? '<button type="button" class="msm-nt2__ib" data-ntundo title="Przywróć do wykonania" aria-label="Przywróć do wykonania">' + IUN + '</button>' : '') +
					(done || n.moje === false ? '' : '<button type="button" class="msm-nt2__ib" data-nted title="Edytuj" aria-label="Edytuj">' + IED + '</button>') +
					(n.moje === false ? '' : '<button type="button" class="msm-nt2__ib is-del" data-ntdel title="Usuń" aria-label="Usuń">' + IDL + '</button>');
				return '<article class="msm-nt-item msm-nt2__r' + (done ? ' is-done' : '') + (HL === n.id ? ' is-hl' : '') + (ed ? ' is-edit' : '') + '" data-nt="' + n.id + '" id="msm-nt-' + n.id + '">' +
					(ed ? '' : chk) + '<div class="msm-nt2__b">' +
					(ed ? rteHtml(' data-ntedin', n.tresc, '') + '<div class="msm-nt-new__foot"><span class="msm-muted">Ctrl+Enter – zapisz · Esc – anuluj</span><span><button type="button" class="msm-btn" data-ntcancel>Anuluj</button> <button type="button" class="msm-btn msm-btn-primary" data-ntsave>Zapisz</button></span></div>'
						: '<div class="msm-nt-body">' + rteIn(n.tresc) + '</div>') +
					'<div class="msm-nt2__meta">' + esc(n.autor) + ' · ' + esc(when(n)) +
					(done ? ' · <b class="msm-nt2__wyk">wykonano ' + esc(fmtDate(n.wykonano_at)) + (n.wykonal ? ' · ' + esc(n.wykonal) : '') + '</b>' : '') + '</div></div>' +
					(acts ? '<span class="msm-nt2__act">' + acts + '</span>' : '') + '</article>';
			}
			function stats() {
				var box = tb.querySelector('[data-ntstat]'); if (!box) return;
				if (!NOTES.length) { box.innerHTML = ''; return; }
				var todo = NOTES.filter(function (n) { return !n.wykonano; }), done = NOTES.filter(function (n) { return n.wykonano; });
				var old = todo.map(function (n) { return n.created_at; }).sort()[0], last = done.slice().sort(function (a, b) { return a.wykonano_at < b.wykonano_at ? 1 : -1; })[0];
				var who = {}; NOTES.forEach(function (n) { who[n.autor] = 1; });
				var t = function (cls, lbl, val, sub) { return '<div class="msm-kzst__t' + cls + '"><span>' + lbl + '</span><b>' + val + '</b><small>' + sub + '</small></div>'; };
				box.innerHTML = '<div class="msm-kzst msm-nt2__st">' +
					t(todo.length ? ' is-todo' : ' is-main', 'Do wykonania', todo.length, todo.length ? 'najstarsze od ' + esc(fmtDate(old).slice(0, 5)) : 'wszystko wykonane') +
					t('', 'Wykonane', done.length, last ? 'ostatnio ' + esc(fmtDate(last.wykonano_at).slice(0, 5)) + (last.wykonal ? ' · ' + esc(last.wykonal) : '') : '—') +
					t('', 'Wszystkie notatki', NOTES.length, esc(plN(Object.keys(who).length, 'osoba', 'osoby', 'osób'))) + '</div>';
			}
			function draw() {
				stats();
				if (!NOTES.length) { list.innerHTML = '<p class="msm-muted msm-nt2__none">Brak notatek do tego zlecenia – dodaj pierwszą powyżej.</p>'; return; }
				var todo = NOTES.filter(function (n) { return !n.wykonano; }), done = NOTES.filter(function (n) { return n.wykonano; });
				var LIM = 5, shown = ALLDONE || done.some(function (n) { return n.id === HL; }) ? done : done.slice(0, LIM);
				var fold = FOLD && !done.some(function (n) { return n.id === HL; });
				list.innerHTML = '<h3 class="msm-nt2__h">Do wykonania <span class="msm-count">' + todo.length + '</span></h3>' +
					(todo.length ? todo.map(item).join('') : '<p class="msm-muted msm-nt2__none">Wszystko wykonane – brak otwartych notatek.</p>') +
					(done.length ? '<h3 class="msm-nt2__h is-done">Wykonane <span class="msm-count">' + done.length + '</span><button type="button" class="msm-link" data-ntfold>' + (fold ? 'Rozwiń ▾' : 'Zwiń ▴') + '</button></h3>' +
						(fold ? '' : '<div class="msm-nt-donelist">' + shown.map(item).join('') + '</div>' +
						(shown.length < done.length ? '<button type="button" class="msm-link msm-nt-more" data-ntall>Pokaż wszystkie wykonane (' + done.length + ')</button>' : '')) : '');
				rteBind(list);
				var fb = list.querySelector('[data-ntfold]'); if (fb) fb.addEventListener('click', function () { FOLD = !fold; try { localStorage.setItem('msm_nt_fold', FOLD ? '1' : '0'); } catch (e) {} draw(); });
				var all = list.querySelector('[data-ntall]'); if (all) all.addEventListener('click', function () { ALLDONE = true; draw(); });
				list.querySelectorAll('[data-nt]').forEach(function (el) {
					var id = +el.getAttribute('data-nt'), n = NOTES.filter(function (x) { return x.id === id; })[0];
					function mark(v, b) {
						b.disabled = true;
						api('/prod/notatka/' + id + '/wykonano', { method: 'POST', body: { wykonano: v ? 1 : 0 } }).then(function (r) { NOTES = r.notatki; HL = 0; setCount(); draw(); toast(v ? 'Oznaczono jako wykonane – notatka jest niżej, w „Wykonane”.' : 'Przywrócono do wykonania.'); }).catch(function (e) { b.disabled = false; toast(e.message, 'err'); });
					}
					var dn = el.querySelector('[data-ntdone]'); if (dn) dn.addEventListener('click', function () { mark(true, dn); });
					el.querySelectorAll('[data-ntundo]').forEach(function (un) { un.addEventListener('click', function () { mark(false, un); }); });
					var e1 = el.querySelector('[data-nted]'); if (e1) e1.addEventListener('click', function () { EDIT = id; HL = 0; draw(); var a = list.querySelector('[data-ntedin]'); if (a) { a.focus(); caretEnd(a); } });
					var d1 = el.querySelector('[data-ntdel]'); if (d1) d1.addEventListener('click', function () {
						confirmBox('Usunąć notatkę?', 'Notatka autorstwa <b>' + esc(n.autor) + '</b> z ' + esc(fmtDate(n.created_at)) + ' zostanie usunięta.', 'Usuń', true).then(function (ok) {
							if (!ok) return;
							api('/prod/notatka/' + id + '/delete', { method: 'POST', body: {} }).then(function (r) { NOTES = r.notatki; setCount(); draw(); toast('Usunięto notatkę.'); }).catch(function (e) { toast(e.message, 'err'); });
						});
					});
					var area = el.querySelector('[data-ntedin]');
					if (!area) return;
					function save() {
						var v = rteValue(area);
						if (!v) { toast('Notatka jest pusta – aby ją usunąć, użyj „Usuń”.', 'err'); return; }
						if (rteSame(v, n.tresc)) { EDIT = 0; draw(); return; }
						var b = el.querySelector('[data-ntsave]'); b.disabled = true;
						api('/prod/notatka/' + id, { method: 'POST', body: { tresc: v } }).then(function (r) { NOTES = r.notatki; EDIT = 0; setCount(); draw(); toast('Zapisano notatkę.'); }).catch(function (e) { b.disabled = false; toast(e.message, 'err'); });
					}
					el.querySelector('[data-ntsave]').addEventListener('click', save);
					el.querySelector('[data-ntcancel]').addEventListener('click', function () { EDIT = 0; draw(); });
					area.addEventListener('keydown', function (e) {
						if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) { e.preventDefault(); save(); }
						if (e.key === 'Escape') { e.stopPropagation(); EDIT = 0; draw(); }
					});
				});
			}
			function caretEnd(a) { try { var r = document.createRange(); r.selectNodeContents(a); r.collapse(false); var s = window.getSelection(); s.removeAllRanges(); s.addRange(r); } catch (e) {} }
			function add(e) {
				if (e) e.preventDefault();
				var v = rteValue(inp);
				if (!v) { inp.focus(); return; }
				var b = form.querySelector('[data-ntadd]'); b.disabled = true;
				api('/prod/order/' + o.id + '/notatki', { method: 'POST', body: { tresc: v } }).then(function (r) {
					b.disabled = false; inp.innerHTML = ''; NOTES = r.notatki; HL = r.id; setCount(); draw(); toast('Dodano notatkę.');
				}).catch(function (er) { b.disabled = false; toast(er.message, 'err'); });
			}
			form.addEventListener('submit', add);
			inp.addEventListener('keydown', function (e) { if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) add(e); });
			api('/prod/order/' + o.id + '/notatki', { query: { _: Date.now() } }).then(function (r) {
				NOTES = r.notatki; setCount(); draw();
				if (HL) {
					var el = list.querySelector('#msm-nt-' + HL);
					if (el) setTimeout(function () { el.scrollIntoView({ block: 'center', behavior: 'smooth' }); }, 60);
					history.replaceState(null, '', tabHash(o.id, 'notatki'));
				}
			}).catch(function (e) { list.innerHTML = '<p class="msm-alert msm-alert-err">' + esc(e.message) + '</p>'; });
		}

		/* ---- import zleceń z arkusza Produkcji: tylko nowe, istniejące bez zmian ---- */
		function importPick() {
			var inp = document.createElement('input');
			inp.type = 'file'; inp.accept = '.xlsx,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
			inp.addEventListener('change', function () { if (inp.files.length) importParse(inp.files[0], ''); });
			inp.click();
		}
		function importParse(file, arkusz) {
			var fd = new FormData(); fd.append('file', file); fd.append('rok', DATA ? DATA.sheet : ''); if (arkusz) fd.append('arkusz', arkusz);
			toast('Czytam arkusz…');
			api('/prod/import/parse', { method: 'POST', form: fd }).then(function (res) { importPreview(res, file); }).catch(function (e) { toast(e.message, 'err'); });
		}
		function importPreview(res, file) {
			var sheets = '<label class="msm-imp-sheet"><span>Arkusz w pliku</span><select data-impsh>' + (res.arkusz ? '' : '<option value="" selected disabled>— wybierz —</option>') + res.arkusze.map(function (a) { return '<option' + (a === res.arkusz ? ' selected' : '') + '>' + esc(a) + '</option>'; }).join('') + '</select></label>';
			var body, foot = '<button type="button" class="msm-btn" data-close>Anuluj</button>';
			if (!res.arkusz) {
				body = '<p class="msm-alert msm-alert-warn">' + esc(res.brak) + '</p>' + sheets;
			} else {
				var n = res.nowe.length;
				body = '<p class="msm-muted msm-kp-file">' + esc(res.plik || '') + '</p>' + sheets +
					'<p class="msm-imp-sum">W arkuszu: <b>' + plN(res.w_pliku, 'zlecenie', 'zlecenia', 'zleceń') + '</b> · już na liście ' + esc(res.rok) + ': <b>' + res.pominiete + '</b> (bez zmian) · nowe: <b>' + n + '</b></p>' +
					(n ? '<div class="msm-table-wrap msm-imp-t"><table class="msm-table"><thead><tr><th class="msm-imp-nw">Nr zlecenia</th><th>Klient</th><th>Termin</th><th class="num">Poz.</th><th>Detale</th></tr></thead><tbody>' +
						res.nowe.map(function (o) { return '<tr><td><b>' + esc(o.nr_zlec || '(bez numeru)') + '</b></td><td>' + esc(o.klient) + '</td><td class="msm-imp-nw">' + esc([o.start, o.koniec].filter(Boolean).join(' – ')) + '</td><td class="num">' + o.pozycji + '</td><td class="msm-muted">' + esc(o.detale) + '</td></tr>'; }).join('') +
						'</tbody></table></div><p class="msm-muted msm-kp-note">Nowe zlecenia trafią na listę ' + esc(res.rok) + ' (na górę). Zlecenia już istniejące – rozpoznane po numerze – nie zostaną zmienione.</p>'
						: '<p class="msm-alert msm-alert-info">Wszystkie zlecenia z tego arkusza już są na liście – nie ma czego dodać.</p>');
				if (n) foot += '<button type="button" class="msm-btn msm-btn-primary" data-impok>Dodaj ' + plN(n, 'zlecenie', 'zlecenia', 'zleceń') + '</button>';
			}
			var m = openModal('Import zleceń z Excela', body, foot, true);
			m.querySelector('[data-impsh]').addEventListener('change', function (e) { closeModal(); importParse(file, e.target.value); });
			var ok = m.querySelector('[data-impok]');
			if (ok) ok.addEventListener('click', function () {
				ok.disabled = true;
				api('/prod/import/commit', { method: 'POST', body: {} }).then(function (r) {
					closeModal(); toast('Dodano ' + plN(r.dodane, 'zlecenie', 'zlecenia', 'zleceń') + ' do listy ' + r.rok + '.');
					if (DATA && r.rok !== DATA.sheet) { ROK = r.rok; try { sessionStorage.setItem('msm_pg_rok', ROK); } catch (e) {} }
					load();
				}).catch(function (e) { ok.disabled = false; toast(e.message, 'err'); });
			});
		}

		/* ---- wczytanie karty z Excela ---- */
		function pickKarta(cb) {
			var inp = document.createElement('input');
			inp.type = 'file'; inp.accept = '.xlsx,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
			inp.addEventListener('change', function () {
				if (!inp.files.length) return;
				var fd = new FormData(); fd.append('file', inp.files[0]);
				toast('Czytam kartę projektu…');
				api('/prod/karta/parse', { method: 'POST', form: fd }).then(cb).catch(function (e) { toast(e.message, 'err'); });
			});
			inp.click();
		}
		function kartaPreview(res, target) {
			var z = res.z, K = res.karta;
			var rows = [['Nr zlecenia', z.nr_zlec], ['Nazwa projektu', K.nazwa_projektu], ['Klient', z.klient], ['Nr zlecenia klienta', z.nr_zlec_klienta], ['Początek – koniec', [z.start_zlec, z.koniec_zlec].filter(Boolean).join(' – ')], ['Kierownik projektu', K.kierownik], ['Warunki', [K.platnosc, K.dostawa].filter(Boolean).join(' · ')]];
			var warn = (res.warnings || []).slice();
			if (target && z.nr_zlec && z.nr_zlec !== target.nr_zlec) warn.unshift('Karta jest dla zlecenia ' + z.nr_zlec + ', a otwarte jest zlecenie ' + (target.nr_zlec || '(bez numeru)') + '.');
			var body = '<p class="msm-muted msm-kp-file">' + esc(res.file || '') + '</p>' +
				(!target && res.exists ? '<p class="msm-alert msm-alert-warn">Zlecenie <b>' + esc(res.exists.nr_zlec) + '</b> już jest w Produkcji. Możesz otworzyć je albo zaktualizować jego kartę danymi z pliku.</p>' : '') +
				warn.map(function (w) { return '<p class="msm-alert msm-alert-warn">' + esc(w) + '</p>'; }).join('') +
				'<dl class="msm-kp-dl">' + rows.filter(function (r) { return r[1]; }).map(function (r) { return '<dt>' + esc(r[0]) + '</dt><dd>' + esc(r[1]) + '</dd>'; }).join('') + '</dl>' +
				(target ? '' : '<h3 class="msm-kp-h">Pozycje zlecenia (' + res.det.length + ')</h3>' +
					(res.det.length ? '<div class="msm-table-wrap"><table class="msm-table msm-kp-t"><thead><tr><th>Nazwa detali</th><th>Nr rysunku</th><th class="num">Ilość</th><th>Materiał</th></tr></thead><tbody>' +
						res.det.map(function (d) { return '<tr><td>' + esc(d.nazwa_detalu) + '</td><td>' + esc(d.nr_rysunku) + '</td><td class="num">' + fmtNum(d.ilosc_zam) + '</td><td>' + esc(d.material) + (d.mat_klienta ? ' <small class="msm-muted">(klienta)</small>' : '') + '</td></tr>'; }).join('') +
						'</tbody></table></div>' : '<p class="msm-muted">Brak – zlecenie dostanie jedną pustą pozycję.</p>') +
					'<p class="msm-muted msm-kp-note">Dostępność przyrządów, wersję, laser, czas cięcia i ilość wykonaną uzupełnisz w „Szczegółach projektu”.</p>') +
				(target ? '<label class="msm-check msm-kp-z"><input type="checkbox" data-kpz checked> Zaktualizuj też dane zlecenia: klient, nr zlecenia klienta, daty i uwagi ogólne</label><p class="msm-muted msm-kp-note">Pozycje w „Szczegółach projektu” nie zmienią się.</p>' : '');
			var foot = '<button type="button" class="msm-btn" data-close>Anuluj</button>' +
				(target ? '<button type="button" class="msm-btn msm-btn-primary" data-kpok="upd">Zastąp kartę</button>'
					: res.exists ? '<button type="button" class="msm-btn" data-kpok="open">Otwórz ' + esc(res.exists.nr_zlec) + '</button><button type="button" class="msm-btn msm-btn-primary" data-kpok="upd">Zaktualizuj jego kartę</button>'
					: '<button type="button" class="msm-btn msm-btn-primary" data-kpok="new">Utwórz zlecenie ' + esc(z.nr_zlec || '') + '</button>');
			var m = openModal(target ? 'Wczytać kartę projektu z pliku?' : 'Nowe zlecenie z karty projektu', body, foot, true);
			m.querySelectorAll('[data-kpok]').forEach(function (b) {
				b.addEventListener('click', function () {
					var act = b.getAttribute('data-kpok');
					if (act === 'open') { closeModal(); location.hash = '#prod-' + res.exists.id; return; }
					b.disabled = true;
					if (act === 'new') {
						api('/prod/order', { method: 'POST', body: { rok: DATA ? DATA.sheet : '', nr_zlec: z.nr_zlec, karta: { z: z, karta: K, det: res.det } } }).then(function (r) {
							closeModal(); toast('Utworzono zlecenie ' + (r.order.nr_zlec || '') + ' z karty projektu.');
							location.hash = '#prod-' + r.order.id;
						}).catch(function (e) { b.disabled = false; toast(e.message, 'err'); });
						return;
					}
					var id = target ? target.id : res.exists.id, zc = m.querySelector('[data-kpz]');
					var zz = !zc || zc.checked ? { nr_zlec_klienta: z.nr_zlec_klienta, klient: z.klient, start_zlec: z.start_zlec, koniec_zlec: z.koniec_zlec, uwagi_ogolne: z.uwagi_ogolne } : null;
					api('/prod/order/' + id + '/karta', { method: 'POST', body: zz ? { karta: K, z: zz } : { karta: K } }).then(function () {
						closeModal(); toast('Zaktualizowano kartę projektu.');
						if (target) { load(); return; }
						location.hash = '#prod-' + id;
					}).catch(function (e) { b.disabled = false; toast(e.message, 'err'); });
				});
			});
		}

		load();
	}

	/* ================================================================
	   PRODUKCJA → PALETÓWKI: wszystkie palety ze wszystkich zleceń
	   ================================================================ */
	function renderPaletyAll() {
		var main = document.getElementById('msm-main');
		main.innerHTML = '<div class="msm-cat msm-pall"><div class="msm-pagehead"><div><h1>Paletówki</h1><p class="msm-muted" data-plcount>&nbsp;</p></div>' +
			'<div class="msm-pagehead__tools"><button type="button" class="msm-btn" data-plpdf disabled>Pobierz PDF zaznaczonych</button></div></div>' +
			'<div class="msm-filters" aria-label="Filtry"><div class="msm-filters__body msm-plf">' +
			'<label class="msm-f msm-pgf__q"><span>Szukaj</span><input type="search" data-plq placeholder="numer palety, zlecenie, klient, detal, rysunek, materiał…" autocomplete="off"></label>' +
			'<label class="msm-f"><span>Rok</span><select data-plrok><option value="">Wszystkie</option></select></label>' +
			'<label class="msm-f"><span>Klient</span><select data-plkl><option value="">Wszyscy</option></select></label>' +
			'<div class="msm-f msm-zam-fclear"><button type="button" class="msm-link" data-plclr>Wyczyść filtry</button></div></div></div>' +
			'<div data-pl><div class="msm-table-wrap"><div class="msm-loading">Ładowanie…</div></div></div></div>';
		var box = main.querySelector('[data-pl]'), q = main.querySelector('[data-plq]'), rok = main.querySelector('[data-plrok]'), kl = main.querySelector('[data-plkl]');
		var ALL = [], SEL = {}, F = (function () { try { return JSON.parse(sessionStorage.getItem('msm_pl_flt')) || {}; } catch (e) { return {}; } })();
		q.value = F.q || '';

		function uniq(a) { return a.filter(function (x, i) { return x && a.indexOf(x) === i; }); }
		function list(a, n) { a = a || []; return a.length > n ? a.slice(0, n).map(esc).join(', ') + ' <span class="msm-muted">+' + (a.length - n) + '</span>' : a.map(esc).join(', '); }
		function save() { F = { q: q.value, rok: rok.value, kl: kl.value }; try { sessionStorage.setItem('msm_pl_flt', JSON.stringify(F)); } catch (e) {} }
		function match(p) {
			if (rok.value && String(p.rok) !== rok.value) return false;
			if (kl.value && (p.klient || '(bez klienta)') !== kl.value) return false;
			var s = srchNorm(q.value.trim());
			if (!s) return true;
			var hay = srchNorm([p.numer, p.numer.replace(/^P0*/, ''), p.nr_zlec, p.klient, p.zam, p.data, p.ilosc, fmtNum(p.waga, 2), p.waga, p.stosy].concat(p.nazwy, p.rysunki, p.material).join(' | '));
			return s.split(/\s+/).every(function (w) { return hay.indexOf(w) >= 0; });
		}
		function syncPdf() {
			var n = Object.keys(SEL).filter(function (k) { return SEL[k]; }).length, b = main.querySelector('[data-plpdf]');
			b.disabled = !n; b.textContent = n ? 'Pobierz PDF zaznaczonych (' + n + ')' : 'Pobierz PDF zaznaczonych';
		}
		function draw() {
			var L = ALL.filter(match);
			var sz = L.reduce(function (a, p) { return a + p.ilosc; }, 0), wg = L.reduce(function (a, p) { return a + p.waga; }, 0);
			main.querySelector('[data-plcount]').textContent = (L.length === ALL.length ? ALL.length + ' palet' : 'Pokazano ' + L.length + ' z ' + ALL.length + ' palet') + (L.length ? ' · ' + fmtNum(sz) + ' szt. · ' + fmtNum(wg, 2) + ' kg' : '');
			if (!ALL.length) { box.innerHTML = '<div class="msm-card msm-empty msm-pal-empty"><h3>Brak paletówek</h3><p class="msm-muted">Palety dodaje się w zleceniu, w zakładce „Paletówki projektu”.</p></div>'; return; }
			if (!L.length) { box.innerHTML = '<div class="msm-card msm-empty"><p><b>Brak palet dla wybranych filtrów.</b></p></div>'; return; }
			var allOn = L.every(function (p) { return SEL[p.id]; });
			box.innerHTML = '<div class="msm-table-wrap"><table class="msm-table msm-plt"><thead><tr>' +
				'<th class="msm-plt__ck"><input type="checkbox" data-plall aria-label="Zaznacz wszystkie"' + (allOn ? ' checked' : '') + '></th>' +
				'<th>Numer palety</th><th>Zlecenie</th><th>Klient</th><th>Detal</th><th>Numer części</th><th class="num">Ilość [szt]</th><th class="num">Waga brutto [kg]</th><th>Materiał</th><th>Data</th><th></th></tr></thead><tbody>' +
				L.map(function (p) {
					return '<tr><td class="msm-plt__ck"><input type="checkbox" data-plck="' + p.id + '"' + (SEL[p.id] ? ' checked' : '') + ' aria-label="Zaznacz ' + esc(p.numer) + '"></td>' +
						'<td data-label="Numer palety"><b class="msm-plt__nr">' + esc(p.numer) + '</b></td>' +
						'<td data-label="Zlecenie"><a class="msm-pgl-nr" href="#prod-' + p.zlec_id + '-paletowki">' + esc(p.nr_zlec || '(bez numeru)') + '</a>' + (p.zam ? '<small class="msm-pgl-n">zam. ' + esc(p.zam) + '</small>' : '') + '</td>' +
						'<td data-label="Klient">' + esc(p.klient) + '</td>' +
						'<td data-label="Detal">' + list(p.nazwy, 2) + '</td>' +
						'<td data-label="Numer części"><small>' + list(p.rysunki, 2) + '</small></td>' +
						'<td data-label="Ilość [szt]" class="num">' + fmtNum(p.ilosc) + '</td>' +
						'<td data-label="Waga brutto [kg]" class="num">' + (p.waga ? fmtNum(p.waga, 2) : '—') + '</td>' +
						'<td data-label="Materiał" class="msm-plt__mat">' + list(p.material, 2) + '</td>' +
						'<td data-label="Data" class="msm-pgl-d">' + esc(p.data) + '</td>' +
						'<td class="msm-pgl-act"><a class="msm-btn msm-btn-sm msm-btn-ghost" href="' + esc(printUrl({ msm_print: 'prod_pal', pal: p.id, auto: 1 })) + '" target="_blank" rel="noopener" title="Pobierz PDF palety ' + esc(p.numer) + '">PDF</a></td></tr>';
				}).join('') + '</tbody></table></div>';
			box.querySelectorAll('[data-plck]').forEach(function (c) { c.addEventListener('change', function () { SEL[c.getAttribute('data-plck')] = c.checked; syncPdf(); }); });
			var all = box.querySelector('[data-plall]');
			if (all) all.addEventListener('change', function () { L.forEach(function (p) { SEL[p.id] = all.checked; }); draw(); syncPdf(); });
		}
		var t = null;
		q.addEventListener('input', function () { clearTimeout(t); t = setTimeout(function () { save(); draw(); }, 150); });
		rok.addEventListener('change', function () { save(); draw(); });
		kl.addEventListener('change', function () { save(); draw(); });
		main.querySelector('[data-plclr]').addEventListener('click', function () { q.value = ''; rok.value = ''; kl.value = ''; save(); draw(); });
		main.querySelector('[data-plpdf]').addEventListener('click', function () {
			var ids = Object.keys(SEL).filter(function (k) { return SEL[k]; });
			if (ids.length) window.open(printUrl({ msm_print: 'prod_pal', pal: ids.join(','), auto: 1 }), '_blank');
		});
		var first = true;
		function fetchList() {
			return api('/prod/palety', { query: { _: Date.now() } }).then(function (r) {
				ALL = r.palety;
				Object.keys(SEL).forEach(function (k) { if (!ALL.some(function (p) { return String(p.id) === k; })) delete SEL[k]; });
				if (!first) { syncPdf(); draw(); return; }
				first = false;
			uniq(ALL.map(function (p) { return String(p.rok); })).forEach(function (y) { rok.insertAdjacentHTML('beforeend', '<option value="' + y + '">' + y + '</option>'); });
			uniq(ALL.map(function (p) { return p.klient || '(bez klienta)'; })).sort(function (a, b) { return a.localeCompare(b, 'pl'); })
				.forEach(function (k) { kl.insertAdjacentHTML('beforeend', '<option value="' + esc(k) + '">' + esc(k) + '</option>'); });
			rok.value = F.rok || ''; kl.value = F.kl || '';
			if (rok.value !== (F.rok || '')) rok.value = '';
			main.querySelector('[data-plcount]').insertAdjacentHTML('beforeend', '');
				draw();
			}).catch(function (e) { box.innerHTML = '<p class="msm-alert msm-alert-err">' + esc(e.message) + '</p>'; });
		}
		fetchList();
		/* Po powrocie do karty (np. po usunięciu palety w zleceniu) – świeża lista. */
		function onVis() {
			if (!document.body.contains(box)) { document.removeEventListener('visibilitychange', onVis); return; }
			if (!document.hidden) fetchList();
		}
		document.addEventListener('visibilitychange', onVis);
	}
	/* ================================================================
	   PRODUKCJA → NOTATKI: zlecenia z notatkami (ostatnia notatka, skrót 200 znaków)
	   ================================================================ */
	function renderNotatkiAll() {
		var LIM = 200;
		var main = document.getElementById('msm-main');
		main.innerHTML = '<div class="msm-cat msm-ntall"><div class="msm-pagehead"><div><h1>Notatki</h1><p class="msm-muted" data-ntcount>&nbsp;</p></div></div>' +
			'<div class="msm-filters" aria-label="Filtry"><div class="msm-filters__body msm-plf">' +
			'<label class="msm-f msm-pgf__q"><span>Szukaj</span><input type="search" data-ntq placeholder="zlecenie, klient, autor, treść notatki…" autocomplete="off"></label>' +
			'<label class="msm-f"><span>Rok</span><select data-ntrok><option value="">Wszystkie</option></select></label>' +
			'<label class="msm-f"><span>Klient</span><select data-ntkl><option value="">Wszyscy</option></select></label>' +
			'<div class="msm-f msm-zam-fclear"><button type="button" class="msm-link" data-ntclr>Wyczyść filtry</button></div></div></div>' +
			'<div data-ntl><div class="msm-loading">Ładowanie…</div></div></div>';
		var box = main.querySelector('[data-ntl]'), q = main.querySelector('[data-ntq]'), rok = main.querySelector('[data-ntrok]'), kl = main.querySelector('[data-ntkl]');
		var ALL = [], OPEN = {}, F = (function () { try { return JSON.parse(sessionStorage.getItem('msm_nt_flt')) || {}; } catch (e) { return {}; } })();
		q.value = F.q || '';

		function uniq(a) { return a.filter(function (x, i) { return x && a.indexOf(x) === i; }); }
		function save() { F = { q: q.value, rok: rok.value, kl: kl.value }; try { sessionStorage.setItem('msm_nt_flt', JSON.stringify(F)); } catch (e) {} }
		function match(z) {
			if (rok.value && z.rok !== rok.value) return false;
			if (kl.value && (z.klient || '(bez klienta)') !== kl.value) return false;
			var s = srchNorm(q.value.trim());
			if (!s) return true;
			var n = z.ostatnia, hay = srchNorm([z.nr_zlec, z.klient, z.nr_zlec_klienta, z.rok, n.autor, n.zmienil, fmtDate(n.created_at), n.tekst].join(' | '));
			return s.split(/\s+/).every(function (w) { return hay.indexOf(w) >= 0; });
		}
		/* Skrót do 200 znaków – ucięty na granicy słowa. */
		function short(t) {
			t = String(t || '').replace(/\s+/g, ' ').trim();
			if (t.length <= LIM) return { s: t, more: false };
			var c = t.slice(0, LIM), sp = c.lastIndexOf(' ');
			return { s: (sp > LIM * 0.6 ? c.slice(0, sp) : c).replace(/[\s.,;:–-]+$/, '') + '…', more: true };
		}
		function draw() {
			var L = ALL.filter(match);
			var sum = L.reduce(function (a, z) { return a + z.ile; }, 0);
			main.querySelector('[data-ntcount]').textContent = (L.length === ALL.length ? plN(ALL.length, 'zlecenie', 'zlecenia', 'zleceń') + ' z notatkami' : 'Pokazano ' + L.length + ' z ' + ALL.length + ' zleceń') + (L.length ? ' · ' + plN(sum, 'notatka', 'notatki', 'notatek') : '');
			if (!ALL.length) { box.innerHTML = '<div class="msm-card msm-empty"><h3>Brak notatek</h3><p class="msm-muted">Notatki dodaje się w zleceniu, w zakładce „Notatki”.</p></div>'; return; }
			if (!L.length) { box.innerHTML = '<div class="msm-card msm-empty"><p><b>Brak notatek dla wybranych filtrów.</b></p></div>'; return; }
			box.innerHTML = '<div class="msm-ntl">' + L.map(function (z) {
				var n = z.ostatnia, sh = short(n.tekst), open = OPEN[z.zlec_id], href = '#prod-' + z.zlec_id + '-notatki-' + n.id;
				var todo = z.ile - (z.wyk || 0);
				return '<article class="msm-card msm-ntl-item' + (n.wykonano ? ' is-done' : '') + '" data-ntz="' + z.zlec_id + '">' +
					'<header class="msm-ntl-item__h"><a class="msm-ntl-nr" href="' + href + '">' + esc(z.nr_zlec || '(bez numeru)') + '</a>' +
					'<span class="msm-ntl-kl">' + esc(z.klient) + '</span>' +
					'<span class="msm-ntl-meta"><span class="msm-ntl-st' + (todo ? '' : ' is-done') + '">' + (todo ? esc(todo) + ' do wykonania' : 'wszystko wykonane') + '</span><span class="msm-ntl-rok">' + esc(z.rok) + '</span> <a class="msm-ntl-cnt" href="#prod-' + z.zlec_id + '-notatki" title="Wszystkie notatki zlecenia">' + plN(z.ile, 'notatka', 'notatki', 'notatek') + '</a></span></header>' +
					'<div class="msm-ntl-who"><b>' + esc(n.autor) + '</b> · ' + esc(fmtDate(n.created_at)) + (n.updated_at ? ' <span class="msm-muted">(zmieniono ' + esc(fmtDate(n.updated_at)) + ')</span>' : '') + '</div>' +
					(open ? '<div class="msm-ntl-txt msm-nt-body">' + rteIn(n.tresc) + '</div>' : '<p class="msm-ntl-txt">' + esc(sh.s) + '</p>') +
					'<footer class="msm-ntl-f">' + (sh.more ? '<button type="button" class="msm-link" data-ntmore aria-expanded="' + !!open + '">' + (open ? 'Zwiń' : 'Czytaj więcej') + '</button>' : '<span></span>') +
					'<a class="msm-btn msm-btn-sm" href="' + href + '">Przejdź do zlecenia ›</a></footer></article>';
			}).join('') + '</div>';
			box.querySelectorAll('[data-ntmore]').forEach(function (b) {
				b.addEventListener('click', function () { var id = b.closest('[data-ntz]').getAttribute('data-ntz'); OPEN[id] = !OPEN[id]; draw(); });
			});
		}
		var t = null;
		q.addEventListener('input', function () { clearTimeout(t); t = setTimeout(function () { save(); draw(); }, 150); });
		rok.addEventListener('change', function () { save(); draw(); });
		kl.addEventListener('change', function () { save(); draw(); });
		main.querySelector('[data-ntclr]').addEventListener('click', function () { q.value = ''; rok.value = ''; kl.value = ''; save(); draw(); });
		var first = true;
		function fetchList() {
			return api('/prod/notatki', { query: { _: Date.now() } }).then(function (r) {
				ALL = r.zlecenia;
				if (first) {
					first = false;
					uniq(ALL.map(function (z) { return z.rok; })).sort().reverse().forEach(function (y) { rok.insertAdjacentHTML('beforeend', '<option value="' + esc(y) + '">' + esc(y) + '</option>'); });
					uniq(ALL.map(function (z) { return z.klient || '(bez klienta)'; })).sort(function (a, b) { return a.localeCompare(b, 'pl'); })
						.forEach(function (k) { kl.insertAdjacentHTML('beforeend', '<option value="' + esc(k) + '">' + esc(k) + '</option>'); });
					rok.value = F.rok || ''; kl.value = F.kl || '';
				}
				draw();
			}).catch(function (e) { box.innerHTML = '<p class="msm-alert msm-alert-err">' + esc(e.message) + '</p>'; });
		}
		fetchList();
		function onVis() {
			if (!document.body.contains(box)) { document.removeEventListener('visibilitychange', onVis); return; }
			if (!document.hidden) fetchList();
		}
		document.addEventListener('visibilitychange', onVis);
	}
	/* ================================================================
	   TABLICA KIEROWNIKA – co wymaga uwagi (każda sekcja wg uprawnień)
	   ================================================================ */
	function renderTablica() {
		var main = document.getElementById('msm-main');
		var dzien = new Date().toLocaleDateString('pl-PL', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
		main.innerHTML = '<div class="msm-cat msm-tb"><div class="msm-pagehead"><div><h1>Pulpit</h1><p class="msm-muted">' + esc(dzien.charAt(0).toUpperCase() + dzien.slice(1)) + ' · <span data-tbtime></span></p></div>' +
			'<div class="msm-pagehead__tools"><span class="msm-tbedit-tools" data-tbedtools hidden><span data-tbpropbox></span><button type="button" class="msm-btn msm-btn-ghost" data-tbreset>Przywróć domyślny układ</button><button type="button" class="msm-btn msm-btn-primary" data-tbdone>Gotowe</button></span>' +
			'<button type="button" class="msm-btn" data-tbedit><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="3" width="7" height="9" rx="1.5"/><rect x="14" y="3" width="7" height="5" rx="1.5"/><rect x="14" y="12" width="7" height="9" rx="1.5"/><rect x="3" y="16" width="7" height="5" rx="1.5"/></svg> Ułóż moduły</button>' +
			'<button type="button" class="msm-btn" data-tbref><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 12a9 9 0 1 1-3-6.7L21 8"/><path d="M21 3v5h-5"/></svg> Odśwież</button></div></div>' +
			'<div data-tb><div class="msm-loading">Ładowanie…</div></div></div>';
		var box = main.querySelector('[data-tb]');
		var timer = null, LAYOUT = null, EDIT = false;
		/* Moduły w siatce 12 kolumn: kolejność + szerokość każdego modułu (jak kafelki z liczbami). */
		var MW = [[2, '1/6'], [3, '1/4'], [4, '1/3'], [6, '1/2'], [8, '2/3'], [9, '3/4'], [12, 'Cała szerokość']];
		var MW_OK = MW.map(function (x) { return x[0]; });
		/* Dawny układ (pas + kolumny) – kolejność wierszami, szerokość z proporcji kolumn. */
		var DEF = { top: ['zlecenia'], cols: [['pomiar', 'elektro', 'przesylki'], ['zamowienia', 'kopia'], ['produkcja', 'dzisiaj', 'bhp']], prop: '1-1-1' };
		var MST = null;
		function mst(L) {
			if (L && L.mods && Array.isArray(L.mods.order)) {
				var w = {}; Object.keys(L.mods.w || {}).forEach(function (k) { if (MW_OK.indexOf(+L.mods.w[k]) >= 0) w[k] = +L.mods.w[k]; });
				return { order: L.mods.order.slice(), w: w };
			}
			L = L && (L.top || L.cols) ? L : DEF;
			var P = String(L.prop || '1-1-1').split('-').map(Number), sum = P.reduce(function (a, b) { return a + b; }, 0) || 3;
			var C = [0, 1, 2].map(function (i) { return ((L.cols || [])[i] || []).slice(); });
			if (P.length === 2) { C[1] = C[1].concat(C[2]); C[2] = []; P.push(0); }
			var out = { order: [], w: {} }, seen = {};
			(L.top || []).forEach(function (k) { if (!seen[k]) { seen[k] = 1; out.order.push(k); out.w[k] = 12; } });
			for (var r = 0, max = Math.max(C[0].length, C[1].length, C[2].length); r < max; r++) {
				for (var i = 0; i < 3; i++) {
					var k = C[i][r]; if (!k || seen[k]) continue;
					seen[k] = 1; out.order.push(k);
					var w = Math.round(12 * P[i] / sum); out.w[k] = MW_OK.indexOf(w) >= 0 ? w : 4;
				}
			}
			return out;
		}
		function wOf(k) { return MST.w[k] || (k === 'zlecenia' ? 12 : 4); }
		function tbKeys() {
			var seen = {}, out = [];
			MST.order.concat(ORDER).forEach(function (k) { if (CARDS[k] && !seen[k]) { seen[k] = 1; out.push(k); } }); // nowe moduły (np. po nadaniu uprawnień) – na końcu
			return out;
		}
		function tbLayoutHtml() {
			return '<div class="msm-tblayout msm-tbmods' + (EDIT ? ' is-edit' : '') + '" data-tblayout>' + tbKeys().map(function (k) {
				var w = wOf(k);
				return CARDS[k].replace('data-tbkey="' + k + '"', 'data-tbkey="' + k + '" data-w="' + w + '"')
					.replace('<!--tbw-->', '<label class="msm-tbwsel" title="Szerokość modułu"><span>Szerokość</span><select data-tbw aria-label="Szerokość modułu">' +
						MW.map(function (x) { return '<option value="' + x[0] + '"' + (x[0] === w ? ' selected' : '') + '>' + x[1] + '</option>'; }).join('') + '</select></label>');
			}).join('') + '</div>';
		}
		function tbRead() {
			var lay = box.querySelector('[data-tblayout]');
			var keys = lay ? Array.prototype.map.call(lay.querySelectorAll(':scope > [data-tbkey]'), function (c) { return c.getAttribute('data-tbkey'); }) : [];
			/* Moduły niewidoczne teraz (np. pusta lista BHP) zostają w kolejności. */
			MST.order.forEach(function (k) { if (keys.indexOf(k) < 0) keys.push(k); });
			MST.order = keys;
			var l = { mods: { order: keys.slice(), w: MST.w } };
			if (KST) { l.kpi = KST; if (KORDER.length) l.kpi.order = kpiKeys().concat(KST.order.filter(function (k) { return !KPIS[k]; })); } // kafelki chwilowo niedostępne zostają w kolejności
			return l;
		}
		function tbSave(l) {
			LAYOUT = l;
			return api('/tablica/uklad', { method: 'POST', body: { uklad: l } }).catch(function (e) { toast(e.message, 'err'); });
		}
		function tbSetEdit(on) {
			EDIT = on;
			var lay = box.querySelector('[data-tblayout]'); if (lay) lay.classList.toggle('is-edit', on);
			main.querySelector('[data-tbedtools]').hidden = !on;
			main.querySelector('[data-tbedit]').hidden = on;
			main.querySelector('[data-tbref]').hidden = on;
			if (on) tbToolsBind();
			kpiRedraw();
		}
		function tbToolsBind() {
			var b = main.querySelector('[data-tbpropbox]');
			b.innerHTML = KORDER.length ? '<label class="msm-check msm-tbzero"><input type="checkbox" data-tbzero' + (KST && KST.zero ? ' checked' : '') + '> Ukryj kafelki z zerem</label>' : '';
			var zc = b.querySelector('[data-tbzero]');
			if (zc) zc.addEventListener('change', function () { KST.zero = zc.checked; kpiSave(); kpiRedraw(); });
		}
		/* Przeciąganie modułów (mysz i dotyk – Pointer Events) + wybór szerokości, tylko w trybie „Ułóż moduły”. */
		function tbDragBind() {
			var lay = box.querySelector('[data-tblayout]');
			if (!lay) return;
			lay.querySelectorAll('[data-tbw]').forEach(function (sel) {
				sel.addEventListener('change', function () {
					var c = sel.closest('[data-tbkey]'), k = c.getAttribute('data-tbkey');
					MST.w[k] = +sel.value; c.setAttribute('data-w', sel.value);
					tbSave(tbRead());
				});
			});
			lay.querySelectorAll('[data-tbdrag]').forEach(function (h) {
				h.addEventListener('pointerdown', function (e) {
					if (!EDIT || (e.pointerType === 'mouse' && e.button !== 0)) return;
					e.preventDefault();
					var cardEl = h.closest('[data-tbkey]'), r = cardEl.getBoundingClientRect(), dx = e.clientX - r.left, dy = e.clientY - r.top;
					var ph = document.createElement('div'); ph.className = 'msm-tbph'; ph.setAttribute('data-w', cardEl.getAttribute('data-w')); ph.style.minHeight = Math.min(r.height, 220) + 'px';
					lay.insertBefore(ph, cardEl);
					cardEl.classList.add('is-drag');
					cardEl.style.width = r.width + 'px'; cardEl.style.left = r.left + 'px'; cardEl.style.top = r.top + 'px';
					try { h.setPointerCapture(e.pointerId); } catch (er) {}
					var scrollT = null, lastX = e.clientX, lastY = e.clientY;
					function place(x, y) {
						cardEl.style.left = (x - dx) + 'px'; cardEl.style.top = (y - dy) + 'px';
						var u = document.elementFromPoint(x, y), t = u && u.closest('[data-tbkey]:not(.is-drag)');
						if (!t || t.parentNode !== lay) {
							/* Poniżej ostatniego modułu – na koniec. */
							var last = lay.querySelector(':scope > [data-tbkey]:not(.is-drag):last-of-type');
							if (last && y > last.getBoundingClientRect().bottom) lay.appendChild(ph);
							return;
						}
						var rr = t.getBoundingClientRect();
						/* Lewa połowa modułu – przed nim, prawa – za nim (moduł na całą szerokość: góra/dół). */
						var before = rr.width > lay.clientWidth * .8 ? y < rr.top + rr.height / 2 : x < rr.left + rr.width / 2;
						lay.insertBefore(ph, before ? t : t.nextSibling);
					}
					function autoscroll() {
						var m = 70, v = lastY < m ? -14 : lastY > innerHeight - m ? 14 : 0;
						if (v) { window.scrollBy(0, v); place(lastX, lastY); }
						scrollT = requestAnimationFrame(autoscroll);
					}
					scrollT = requestAnimationFrame(autoscroll);
					function move(ev) { lastX = ev.clientX; lastY = ev.clientY; place(ev.clientX, ev.clientY); }
					function up() {
						cancelAnimationFrame(scrollT);
						h.removeEventListener('pointermove', move); h.removeEventListener('pointerup', up); h.removeEventListener('pointercancel', up);
						lay.insertBefore(cardEl, ph); ph.remove();
						cardEl.classList.remove('is-drag'); cardEl.style.width = cardEl.style.left = cardEl.style.top = '';
						tbSave(tbRead());
					}
					h.addEventListener('pointermove', move); h.addEventListener('pointerup', up); h.addEventListener('pointercancel', up);
				});
			});
		}
		main.querySelector('[data-tbedit]').addEventListener('click', function () { tbSetEdit(true); });
		main.querySelector('[data-tbdone]').addEventListener('click', function () { tbSetEdit(false); toast('Układ Pulpitu zapisany.'); });
		main.querySelector('[data-tbreset]').addEventListener('click', function () {
			api('/tablica/uklad', { method: 'POST', body: { uklad: null } }).then(function () { LAYOUT = null; toast('Przywrócono domyślny układ.'); load(); }).catch(function (e) { toast(e.message, 'err'); });
		});

		function dni(n) { return n + ' ' + (Math.abs(n) === 1 ? 'dzień' : 'dni'); }
		/* Kafelki z liczbami: kolejność, szerokość (części 12-kolumnowej siatki) i ukrywanie – w trybie „Ułóż moduły”. */
		var KW = [[2, '1/6'], [3, '1/4'], [4, '1/3'], [6, '1/2']];
		var ICO_EYE = '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/></svg>';
		var ICO_EYE_OFF = '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 3l18 18"/><path d="M10.6 5.1A10.4 10.4 0 0 1 12 5c6.5 0 10 7 10 7a17 17 0 0 1-3.2 4.1M6.6 6.6C3.8 8.4 2 12 2 12s3.5 7 10 7c1.8 0 3.4-.5 4.8-1.3"/><path d="M9.9 9.9a3 3 0 0 0 4.2 4.2"/></svg>';
		var KPIS = {}, KORDER = [], KST = null, PRODD = null;
		function kst(src) {
			src = src || {};
			var w = {}; Object.keys(src.w || {}).forEach(function (k) { if ([2, 3, 4, 6].indexOf(+src.w[k]) >= 0) w[k] = +src.w[k]; });
			return { order: (src.order || []).slice(), w: w, hide: (src.hide || []).slice(), zero: !!src.zero };
		}
		function kpi(key, n, label, href, tone, sub) {
			KPIS[key] = { n: +n || 0, html: '<a class="msm-tbk' + (n > 0 && tone ? ' is-' + tone : '') + '" href="' + href + '" data-kflt="' + key + '"><b>' + n + '</b><span>' + esc(label) + '</span>' + (sub ? '<small>' + sub + '</small>' : '') + '</a>', label: label };
			KORDER.push(key);
			return '';
		}
		function kpiKeys() {
			var seen = {}, out = [];
			KST.order.concat(KORDER).forEach(function (k) { if (KPIS[k] && !seen[k]) { seen[k] = 1; out.push(k); } });
			return out;
		}
		function kpisHtml() {
			if (!KORDER.length) return '';
			return '<div class="msm-tbkpis' + (EDIT ? ' is-edit' : '') + '" data-tbkpis>' + kpiKeys().map(function (k) {
				var K = KPIS[k], hid = KST.hide.indexOf(k) >= 0, zero = KST.zero && K.n === 0, w = KST.w[k] || 2;
				if (!EDIT && (hid || zero)) return '';
				return '<div class="msm-tbkw' + (hid || zero ? ' is-off' : '') + '" data-kkey="' + k + '" data-w="' + w + '">' + K.html +
					(EDIT ? '<div class="msm-tbkctl"><button type="button" class="msm-tbdrag" data-kdrag aria-label="Przenieś kafelek „' + esc(K.label) + '”" title="Przeciągnij, aby przenieść">' + ICO_GRIP + '</button>' +
						'<span class="msm-tbkw__w" role="radiogroup" aria-label="Szerokość">' + KW.map(function (x) { return '<button type="button" role="radio" aria-checked="' + (x[0] === w) + '" class="' + (x[0] === w ? 'is-on' : '') + '" data-kw="' + x[0] + '">' + x[1] + '</button>'; }).join('') + '</span>' +
						'<button type="button" class="msm-tbkeye" data-khide aria-pressed="' + hid + '" title="' + (hid ? 'Pokaż kafelek' : 'Ukryj kafelek') + '">' + (hid ? ICO_EYE_OFF : ICO_EYE) + '</button></div>' +
						(hid ? '<em class="msm-tbkw__off">ukryty</em>' : zero ? '<em class="msm-tbkw__off">ukryty, bo 0</em>' : '') : '') + '</div>';
			}).join('') + '</div>';
		}
		/* Kliknięcie kafelka otwiera listę już przefiltrowaną (np. tylko zlecenia po terminie). */
		function kfltSet(key) {
			var day = function (n) { var d = new Date(); d.setDate(d.getDate() + n); return d.getFullYear() + '-' + ('0' + (d.getMonth() + 1)).slice(-2) + '-' + ('0' + d.getDate()).slice(-2); };
			var pg = function (t) {
				/* Lista zleceń pokazuje jeden rok – otwieramy najnowszy rok, w którym są takie zlecenia. */
				var ly = (PRODD && PRODD.lata && PRODD.lata[t]) || {}, ys = Object.keys(ly).sort().reverse();
				try { if (ys.length) sessionStorage.setItem('msm_pg_rok', ys[0]); else sessionStorage.removeItem('msm_pg_rok'); } catch (e) {}
				var o = {}; o[t] = true; return { q: '', klient: {}, termin: o, wyk: {} };
			};
			var map = {
				late: ['msm_pg_flt', pg('late')],
				risk: ['msm_pg_flt', pg('risk')],
				elektro: ['msm_el_flt', { q: '', typ: '', lok: '', term: 'late' }],
				pomiar: ['msm_pm_flt', { q: '', lok: '', pre: '', miej: '', term: 'late', stat: '' }],
				przesylki: ['msm_prz_flt', { q: '', od: day(-14), do: '', nad: '', fak: '', dmg: true }],
				przes_dzis: ['msm_prz_flt', { q: '', od: day(0), do: day(0), nad: '', fak: '', dmg: false }]
			};
			if (!map[key]) return;
			try { sessionStorage.setItem(map[key][0], JSON.stringify(map[key][1])); } catch (e) {}
		}
		box.addEventListener('click', function (e) {
			var a = e.target.closest('a[data-kflt]');
			if (a && !EDIT) kfltSet(a.getAttribute('data-kflt'));
		});
		function kpiSave() { var l = tbRead(); tbSave(l); }
		function kpiRedraw() {
			var old = box.querySelector('[data-tbkpis]'), html = kpisHtml();
			if (old) old.outerHTML = html; else if (html) box.insertAdjacentHTML('afterbegin', html);
			kpiBind();
		}
		function kpiBind() {
			var wrap = box.querySelector('[data-tbkpis]');
			if (!wrap || !EDIT) return;
			wrap.querySelectorAll('[data-kw]').forEach(function (b) {
				b.addEventListener('click', function () { KST.w[b.closest('[data-kkey]').getAttribute('data-kkey')] = +b.getAttribute('data-kw'); kpiSave(); kpiRedraw(); });
			});
			wrap.querySelectorAll('[data-khide]').forEach(function (b) {
				b.addEventListener('click', function () {
					var k = b.closest('[data-kkey]').getAttribute('data-kkey'), i = KST.hide.indexOf(k);
					if (i >= 0) KST.hide.splice(i, 1); else KST.hide.push(k);
					kpiSave(); kpiRedraw();
				});
			});
			wrap.querySelectorAll('[data-kdrag]').forEach(function (h) {
				h.addEventListener('pointerdown', function (e) {
					if (e.pointerType === 'mouse' && e.button !== 0) return;
					e.preventDefault();
					var el = h.closest('[data-kkey]'), r = el.getBoundingClientRect(), dx = e.clientX - r.left, dy = e.clientY - r.top;
					var ph = document.createElement('div'); ph.className = 'msm-tbkw msm-tbkph'; ph.setAttribute('data-w', el.getAttribute('data-w')); ph.style.height = r.height + 'px';
					el.parentNode.insertBefore(ph, el);
					el.classList.add('is-drag'); el.style.width = r.width + 'px'; el.style.height = r.height + 'px'; el.style.left = r.left + 'px'; el.style.top = r.top + 'px';
					try { h.setPointerCapture(e.pointerId); } catch (er) {}
					function move(ev) {
						el.style.left = (ev.clientX - dx) + 'px'; el.style.top = (ev.clientY - dy) + 'px';
						var u = document.elementFromPoint(ev.clientX, ev.clientY), t = u && u.closest('.msm-tbkw:not(.is-drag):not(.msm-tbkph)');
						if (!t || t.parentNode !== wrap) return;
						var rr = t.getBoundingClientRect();
						wrap.insertBefore(ph, ev.clientX < rr.left + rr.width / 2 ? t : t.nextSibling);
					}
					function up() {
						h.removeEventListener('pointermove', move); h.removeEventListener('pointerup', up); h.removeEventListener('pointercancel', up);
						wrap.insertBefore(el, ph); ph.remove();
						el.classList.remove('is-drag'); el.style.width = el.style.height = el.style.left = el.style.top = '';
						KST.order = Array.prototype.map.call(wrap.querySelectorAll('[data-kkey]'), function (x) { return x.getAttribute('data-kkey'); });
						kpiSave();
					}
					h.addEventListener('pointermove', move); h.addEventListener('pointerup', up); h.addEventListener('pointercancel', up);
				});
			});
		}
		/* Uwagi do projektu pod zleceniem: skrót, „więcej” rozwija całość. */
		function tbUwagi(z) {
			var t = String(z.uwagi).replace(/\s*\n\s*/g, ' · ').trim(), LIM = 200, long = t.length > LIM;
			return '<div class="msm-tbuw" data-tbuw><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>' +
				'<p><span data-tbuws>' + esc(long ? t.slice(0, LIM).replace(/\s+\S*$/, '') + '…' : t) + '</span>' + (long ? '<span data-tbuwf hidden>' + esc(z.uwagi).replace(/\n/g, '<br>') + '</span> <button type="button" class="msm-link" data-tbuwm>więcej</button>' : '') + '</p></div>';
		}
		/* Moduł Pulpitu (klucz = miejsce w układzie użytkownika). Zwraca '' – moduły trafiają do CARDS i są układane w kolumnach. */
		var CARDS = {}, ORDER = [];
		function card(key, title, href, linkLbl, inner, cls) {
			CARDS[key] = '<section class="msm-card msm-tbc' + (cls ? ' ' + cls : '') + '" data-tbkey="' + key + '"><header>' +
				'<button type="button" class="msm-tbdrag" data-tbdrag aria-label="Przenieś moduł „' + esc(title) + '”" title="Przeciągnij, aby przenieść">' + ICO_GRIP + '</button>' +
				'<h2>' + esc(title) + '</h2><!--tbw-->' + (href ? '<a class="msm-link" href="' + href + '">' + esc(linkLbl) + ' ›</a>' : '') + '</header>' + inner + '</section>';
			ORDER.push(key);
			return '';
		}
		function load() {
			api('/tablica').then(function (d) {
				var k = '', cards = '';
				CARDS = {}; ORDER = []; KPIS = {}; KORDER = []; LAYOUT = d.uklad || null; KST = kst(LAYOUT && LAYOUT.kpi); MST = mst(LAYOUT);
				PRODD = d.produkcja || null;
				var PS = d.przesylki, P = d.produkcja, B = d.braki, W = d.wnioski, R = d.rezerwacje, H = d.bhp, K = d.kopia, A = d.aktywnosc || {};

				if (P) {
					/* Zlecenia z wcześniejszych lat (lista pokazuje jeden rok naraz). */
					var older = function (st) { var ly = (P.lata && P.lata[st]) || {}, ys = Object.keys(ly).sort().reverse(); return ys.slice(1).map(function (y) { return 'w tym ' + ly[y] + ' z ' + y; }).join(', '); };
					var riskSub = [P.stany.slow ? P.stany.slow + ' z postępem poniżej planu' : '', older('risk')].filter(Boolean).join(' · ');
					k += kpi('late', P.stany.late, 'zleceń po terminie', '#produkcja', 'red', older('late')) + kpi('risk', P.stany.risk, 'zleceń zagrożonych (do ' + PROG.zlecenia + ' dni)', '#produkcja', 'amber', riskSub);
					var total = P.n || 1, seg = [['late', 'Po terminie'], ['risk', 'Zagrożone (do ' + PROG.zlecenia + ' dni)'], ['slow', 'Poniżej planu'], ['ok', 'W terminie'], ['wait', 'Przed startem'], ['done', 'Zrealizowane'], ['none', 'Bez daty']];
					var bar = '<div class="msm-tbbar">' + seg.map(function (s) { var n = P.stany[s[0]]; return n ? '<i class="is-' + s[0] + '" style="flex:' + n + '" title="' + s[1] + ': ' + n + '"></i>' : ''; }).join('') + '</div>' +
						'<ul class="msm-tblegend">' + seg.map(function (s) { return '<li class="is-' + s[0] + '"><i></i>' + s[1] + ' <b>' + (P.stany[s[0]] || 0) + '</b></li>'; }).join('') + '</ul>';
					var list = P.lista.length ? '<ul class="msm-tblist">' + P.lista.map(function (z) {
						return '<li><a href="#prod-' + z.id + '"><span class="msm-tbdot is-' + z.state + '"></span><b>' + esc(z.nr || '(bez numeru)') + '</b><span class="msm-tblist__c">' + esc(z.klient || '') + '</span>' +
							'<span class="msm-tblist__s is-' + z.state + '">' + (z.state === 'late' ? 'po terminie ' + dni(-z.left) : z.left === 0 ? 'termin dziś' : 'zostało ' + dni(z.left)) + '</span><span class="msm-tblist__p">' + fmtNum(z.proc, 1) + '%</span></a>' + (z.uwagi ? tbUwagi(z) : '') + '</li>';
					}).join('') + '</ul>' + (P.alert_n > P.lista.length ? '<p class="msm-muted msm-small">…i jeszcze ' + (P.alert_n - P.lista.length) + '.</p>' : '')
						: '<p class="msm-tbok">Wszystkie zlecenia idą zgodnie z planem.</p>';
					cards += card('zlecenia', 'Zlecenia wymagające uwagi', '#produkcja', 'Pokaż na liście', list, '" data-tbprod="1') +
						card('produkcja', 'Produkcja w liczbach', '#produkcja', 'Produkcja', '<p class="msm-tbbig"><b>' + P.n + '</b> zleceń (wszystkie lata)</p>' + bar);
				}
				if (W) k += kpi('wnioski', W.nowe, 'wniosków do decyzji', '#wnioski', 'amber', W.do_wydania ? W.do_wydania + ' do wydania' : '');
				if (R) k += kpi('rezerwacje', R.nowe, 'rezerwacji do akceptacji', '#rezerwacje', 'amber', R.aktywne + ' aktywnych' + (R.wygasaja ? ' · ' + R.wygasaja + ' wygasa w 7 dni' : ''));
				if (B) {
					k += kpi('braki', B.n, 'pozycji poniżej minimum', '#zamowienia', 'red');
					cards += card('zamowienia', 'Do zamówienia', '#zamowienia', 'Do zamówienia', B.lista.length ? '<ul class="msm-tbrows">' + B.lista.map(function (x) { return '<li><span>' + esc(x.nazwa) + '</span><b>brak ' + fmtNum(x.brak) + ' szt.</b></li>'; }).join('') + '</ul>' : '<p class="msm-tbok">Stany powyżej minimum.</p>');
				}
				if (H) {
					k += kpi('bhp', H.n, 'BHP do wymiany', '#bhp_wymiana', 'amber');
					if (H.n) cards += card('bhp', 'BHP – do wymiany', '#bhp_wymiana', 'Do wymiany', '<ul class="msm-tbrows">' + H.lista.map(function (x) { return '<li><span>' + esc(x.osoba) + ' · ' + esc(x.kategoria || x.nazwa || '') + '</span><b>od ' + esc(fmtDate(x.termin)) + '</b></li>'; }).join('') + '</ul>');
				}
				var ZB = d.zam;
				if (ZB) k += kpi('zam_braki', ZB.braki, 'braków dla zleceń do zamówienia', '#zamowienia', 'amber', ZB.w_drodze ? ZB.w_drodze + ' ' + (ZB.w_drodze === 1 ? 'zamówienie' : 'zamówień') + ' w drodze' : '');
				var PMR = d.pomiar;
				if (PMR) {
					k += kpi('pomiar', PMR.po_terminie, 'przyrządów pomiarowych po terminie wzorcowania', '#narz-pomiarowe', 'red', PMR.wkrotce ? PMR.wkrotce + ' w ciągu ' + PROG.pomiar + ' dni' : '');
					if (PMR.lista.length) cards += card('pomiar', 'Przyrządy pomiarowe – wzorcowanie', '#narz-pomiarowe', 'Przyrządy pomiarowe', '<ul class="msm-tbrows">' + PMR.lista.map(function (x) {
						var late = x.dni < 0;
						return '<li><span><a href="#narz-pomiarowe-' + x.id + '"><b>' + esc(x.nr_ew) + '</b></a> ' + esc(x.nazwa) + (x.lokalizacja || x.miejsce ? ' <small class="msm-muted">' + esc([x.lokalizacja, x.miejsce].filter(Boolean).join(' · ')) + '</small>' : '') + '</span><b class="' + (late ? 'msm-tb-late' : 'msm-tb-soon') + '">' + esc(fmtDate(x.data_nast)) + '<small>' + (late ? (-x.dni) + ' dni po terminie' : x.dni === 0 ? 'dziś' : 'za ' + x.dni + ' dni') + '</small></b></li>';
					}).join('') + (PMR.po_terminie + PMR.wkrotce > PMR.lista.length ? '<li class="msm-tbmore"><a href="#narz-pomiarowe">+ ' + (PMR.po_terminie + PMR.wkrotce - PMR.lista.length) + ' kolejnych – zobacz wszystkie</a></li>' : '') + '</ul>');
				}
				var EL = d.elektro;
				if (EL) {
					k += kpi('elektro', EL.po_terminie, 'elektronarzędzi po terminie sprawdzenia', '#narz-elektro', 'red', EL.wkrotce ? EL.wkrotce + ' w ciągu ' + PROG.elektro + ' dni' : '');
					if (EL.lista.length) cards += card('elektro', 'Elektronarzędzia po terminie sprawdzenia', '#narz-elektro', 'Elektronarzędzia', '<ul class="msm-tbrows">' + EL.lista.map(function (x) {
						return '<li><span><a href="#narz-elektro-' + x.id + '"><b>' + esc(x.symbol) + '</b></a> ' + esc(x.nazwa) + (x.model || x.lokalizacja ? ' <small class="msm-muted">' + esc([x.model, x.lokalizacja].filter(Boolean).join(' · ')) + '</small>' : '') + '</span><b class="msm-tb-late">' + esc(fmtDate(x.data_nast)) + '<small>' + x.dni + ' dni po terminie</small></b></li>';
					}).join('') + (EL.po_terminie > EL.lista.length ? '<li class="msm-tbmore"><a href="#narz-elektro">+ ' + (EL.po_terminie - EL.lista.length) + ' kolejnych – zobacz wszystkie</a></li>' : '') + '</ul>');
				}
				if (PS) {
					k += kpi('przes_dzis', PS.dzis, 'przesyłek przyjętych dziś', '#przesylki', 'blue', PS.dzis_poz !== undefined ? PS.dzis_poz + ' ' + (PS.dzis_poz === 1 ? 'pozycja' : PS.dzis_poz % 10 >= 2 && PS.dzis_poz % 10 <= 4 && (PS.dzis_poz % 100 < 10 || PS.dzis_poz % 100 >= 20) ? 'pozycje' : 'pozycji') + ' w przesyłkach' : '');
					k += kpi('przesylki', PS.uszkodzone.length, 'uszkodzonych przesyłek (14 dni)', '#przesylki', 'red');
					if (PS.uszkodzone.length) cards += card('przesylki', 'Przesyłki uszkodzone', '#przesylki', 'Przesyłki', '<ul class="msm-tbrows">' + PS.uszkodzone.map(function (x) {
						var dt = przDT(x.data_spr);
						return '<li><span><b>' + esc(x.nadawca) + '</b>' + (x.zlecenie ? ' · ' + esc(x.zlecenie) : '') + (x.uwagi ? '<br><small class="msm-muted">' + esc(x.uwagi.length > 90 ? x.uwagi.slice(0, 89) + '…' : x.uwagi) + '</small>' : '') + '</span><b>' + esc(dt.d) + '</b></li>';
					}).join('') + '</ul>');
				}
				var KZ = d.karty_zmian;
				if (KZ) cards += card('karty_zmian', 'Ostatnio dodane karty zmian', '#prod-karty', 'Karty zmian', KZ.lista.length ? '<ul class="msm-tbrows msm-tbkz">' + KZ.lista.map(function (x) {
					return '<li><a class="msm-tbkz__a" href="#prod-karty-' + x.id + '"><span class="msm-tbkz__z">' + (x.zlecenia.length ? x.zlecenia.map(function (z) {
						return '<span class="msm-tbkz__o"><b>' + esc(z.nr) + '</b><i>' + esc(fmtNum(z.dobre)) + ' szt.</i></span>';
					}).join('') : '<span class="msm-muted">bez programów</span>') + '</span>' +
						'<span class="msm-tbkz__d"><b>' + esc(fmtDate(x.data)) + '</b><small>' + esc(x.linia) + ' · zm. ' + esc(x.zmiana) + '</small></span></a></li>';
				}).join('') + (KZ.n > KZ.lista.length ? '<li class="msm-tbmore"><a href="#prod-karty">Wszystkie karty zmian (' + KZ.n + ') ›</a></li>' : '') + '</ul>' : '<p class="msm-muted msm-small">Nie dodano jeszcze żadnej karty zmiany.</p>');
				var akt = [['pobrania', 'pobrań', '#pobrania'], ['wz', 'dokumentów WZ', '#wz'], ['pz', 'przyjęć PZ', '#pz'], ['zmiany', 'zmian w systemie', '#historia']].filter(function (a) { return A[a[0]] !== undefined; });
				if (akt.length) cards += card('dzisiaj', 'Dzisiaj', '', '', '<div class="msm-tbtoday">' + akt.map(function (a) { return '<a href="' + a[2] + '"><b>' + A[a[0]] + '</b><span>' + a[1] + '</span></a>'; }).join('') + '</div>');
				if (K) {
					var st = K.error ? ['err', 'Ostatnia kopia nie powiodła się: ' + K.error] : !K.enabled ? ['warn', 'Automatyczna kopia jest wyłączona.'] : (!K.last || Date.now() / 1000 - K.last > 2 * 86400) ? ['warn', 'Brak świeżej kopii (ponad 2 dni).'] : ['ok', 'Kopia aktualna.'];
					cards += card('kopia', 'Kopia danych', '#kopia', 'Kopia danych', '<p class="msm-tbcopy is-' + st[0] + '"><span></span>' + esc(st[1]) + '</p><p class="msm-muted msm-small">Ostatnia: ' + (K.last ? esc(fmtDateTime(new Date(K.last * 1000).toISOString())) : 'nigdy') + '</p>');
				}
				box.innerHTML = k + kpisHtml() + (ORDER.length ? tbLayoutHtml() : '') ||
					'<div class="msm-card msm-empty"><p class="msm-muted">Brak sekcji do pokazania – poproś administratora o dostęp do zakładek (Produkcja, Wnioski, Rezerwacje…).</p></div>';
				box.querySelectorAll('[data-tbuwm]').forEach(function (b) {
					b.addEventListener('click', function () {
						var w = b.closest('[data-tbuw]'), f = w.querySelector('[data-tbuwf]'), open = f.hidden;
						f.hidden = !open; w.querySelector('[data-tbuws]').hidden = open; b.textContent = open ? 'mniej' : 'więcej';
					});
				});
				var pl = box.querySelector('[data-tbprod] header .msm-link');
				if (pl) pl.addEventListener('click', function () {
					try { sessionStorage.setItem('msm_pg_flt', JSON.stringify({ q: '', klient: {}, termin: { late: true, risk: true }, wyk: {} })); } catch (e) {}
				});
				tbDragBind(); kpiBind();
				var tt = main.querySelector('[data-tbtime]'); if (tt) tt.textContent = 'stan na ' + new Date().toLocaleTimeString('pl-PL', { hour: '2-digit', minute: '2-digit' });
			}).catch(function (e) { box.innerHTML = '<p class="msm-alert msm-alert-err">' + esc(e.message) + '</p>'; });
		}
		main.querySelector('[data-tbref]').addEventListener('click', load);
		/* Odświeżanie co 5 minut, dopóki tablica jest otwarta. */
		timer = setInterval(function () {
			if (!document.body.contains(box)) { clearInterval(timer); return; }
			if (!document.hidden) load();
		}, 300000);
		load();
	}
	/* ================================================================
	   PRODUKCJA → KARTY ZMIAN: lista kart i formularz karty zmiany
	   (obsada, stanowisko, do 10 programów) z eksportem do arkusza Excela 1:1 z wzorem firmy.
	   ================================================================ */
	var KZ_COLORS = ['#ff0000', '#00b050', '#00b0f0', '#7030a0', '#ff0000', '#ffc000', '#ffff00', '#92d050', '#00b0f0', '#0070c0']; // jak paski w arkuszu
	var KZ_MAX = 10;
	var KZ_PF = [
		['nazwa', 'Nazwa programu', 'txt', 'full'],
		['zadana', 'Ilość zadana', 'num'],
		['dobre', 'Ilość wykonana – detale dobre', 'num'],
		['zle', 'Ilość wykonana – detale złe / zniszczone', 'num'],
		['wyjasnienie', 'Wyjaśnienie rozbieżności', 'area', 'full'],
		['gatunek', 'Materiał – gatunek', 'txt'],
		['format', 'Materiał – format', 'txt'],
		['zmierzone', 'Ilość zmierzonych detali', 'num'],
		['arkusze', 'Ilość zużytych arkuszy', 'num'],
		['stos', 'Wielkość stosu wyciętego', 'txt'],
		['ulozone', 'Wszystkie detale ułożone', 'taknie'],
		['uwagi', 'Uwagi', 'area', 'full']
	];
	function kzUrl(id) { return buildUrl('/karty-zmian/' + id + '/xlsx', { _wpnonce: C.nonce }); }
	var KZ_XL = '<svg class="msm-ico" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5M9 12l6 6M15 12l-6 6"/></svg>';
	var KZ_CP = '<svg class="msm-ico" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15H4a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v1"/></svg>';
	var KZ_DONE = ['dobre', 'zle', 'wyjasnienie', 'zmierzone', 'arkusze', 'stos', 'ulozone', 'uwagi']; // wyniki zmiany – przy kopii zwykle do wpisania od nowa
	/* Kopia karty: wybór programów i czyszczenie ilości wykonanych → nowa karta (data i godzina – teraz). */
	function kzCopy(k) {
		var P = k.programy || [];
		var body = '<p class="msm-muted">Nowa karta z obsadą, linią i zmianą z karty <b>' + esc(fmtDate(k.data) + ' · ' + k.linia + ' · zm. ' + k.zmiana) + '</b>. Data i godzina ustawią się na teraz – wszystko możesz zmienić przed zapisem.</p>' +
			(P.length ? '<div class="msm-kz-cpl"><span class="msm-kz-cpl__h">Programy do skopiowania</span>' + P.map(function (p, i) {
				return '<label class="msm-check"><input type="checkbox" data-cpp="' + i + '" checked> <span><b>' + esc(p.nazwa || 'Program ' + (i + 1)) + '</b>' + (p.gatunek || p.format ? ' <small class="msm-muted">' + esc([p.gatunek, p.format].filter(Boolean).join(' · ')) + '</small>' : '') + '</span></label>';
			}).join('') + '</div>' : '<p class="msm-muted">Karta nie ma programów.</p>') +
			'<label class="msm-check msm-kz-cpclr"><input type="checkbox" data-cpclr checked> <span>Wyczyść wyniki zmiany – zostaw nazwę programu, ilość zadaną i materiał<br><small class="msm-muted">czyści: detale dobre i złe, wyjaśnienie, zmierzone detale, arkusze, stos, ułożenie, uwagi</small></span></label>' +
			'<label class="msm-check"><input type="checkbox" data-cpst checked> <span>Wyczyść „Problemy techniczne” i „Uwagi do poprzedniej zmiany”</span></label>';
		var m = openModal('Kopiuj kartę zmiany', body, '<button type="button" class="msm-btn" data-close>Anuluj</button><button type="button" class="msm-btn msm-btn-primary" data-cpgo>' + KZ_CP + 'Utwórz kopię</button>');
		m.querySelector('[data-cpgo]').addEventListener('click', function () {
			var clr = m.querySelector('[data-cpclr]').checked, st = m.querySelector('[data-cpst]').checked;
			var progs = P.filter(function (p, i) { var c = m.querySelector('[data-cpp="' + i + '"]'); return !c || c.checked; }).map(function (p) {
				var o = Object.assign({}, p); if (clr) KZ_DONE.forEach(function (f) { o[f] = ''; }); return o;
			});
			var pre = { linia: k.linia, zmiana: k.zmiana, operator1: k.operator1, operator2: k.operator2, pomocnik1: k.pomocnik1, pomocnik2: k.pomocnik2, pomocnik3: k.pomocnik3, porzadek: k.porzadek, przyrzady: k.przyrzady, problemy: st ? '' : k.problemy, uwagi_poprz: st ? '' : k.uwagi_poprz, programy: progs, _z: fmtDate(k.data) + ' · ' + k.linia + ' · zm. ' + k.zmiana };
			try { sessionStorage.setItem('msm_kz_copy', JSON.stringify(pre)); } catch (e) {}
			closeModal();
			if (location.hash === '#prod-karty-new') renderKartaZmiany(0); else location.hash = '#prod-karty-new';
		});
	}
	/* „16*48”, „1 250,5”, „16x48” → liczba (jak w Excelu); null – nie liczba. */
	function kzNum(v) {
		var s = String(v == null ? '' : v).replace(/[\s ]/g, '').replace(/,/g, '.').replace(/[x×X]/g, '*');
		if (!s) return '';
		if (/^-?\d+(\.\d+)?$/.test(s)) return +s;
		if (!/^\d+(\.\d+)?([*+\-]\d+(\.\d+)?){1,6}$/.test(s)) return null;
		var terms = [];
		s.replace(/([*+\-]?)(\d+(?:\.\d+)?)/g, function (m, op, n) { n = +n; if (op === '*') terms[terms.length - 1] *= n; else terms.push(op === '-' ? -n : n); return m; });
		return terms.reduce(function (a, b) { return a + b; }, 0);
	}

	/* Komórki listy: każdy program w osobnej linii z własnym wynikiem (karta może mieć programy kilku zleceń). */
	function kzProgCells(k) {
		var P = (k.prog_lista || []).filter(function (p) { return p.nazwa || p.dobre !== '' || p.zle !== ''; });
		if (!P.length) return '<td data-label="Programy"><span class="msm-muted">—</span></td><td data-label="Detale dobre" class="num"><span class="msm-muted">—</span></td><td data-label="Złe" class="num"><span class="msm-muted">0</span></td>';
		var many = P.length > 1, nv = function (v) { return v === '' || v == null ? '—' : fmtNum(v); };
		var mob = function (d, z) { return '<span class="msm-kzl__m"><b>' + esc(d) + '</b>' + (+z ? ' <span class="msm-kz-bad">· złe ' + esc(fmtNum(z)) + '</span>' : '') + '</span>'; };
		var names = P.map(function (p) { return '<span class="msm-kzl__r"><span class="msm-eltag msm-kz-zl">' + esc(p.zlec || '—') + '</span><small title="' + esc(p.nazwa) + '">' + esc(p.nazwa || 'bez nazwy') + '</small>' + (many ? mob(nv(p.dobre), p.zle) : '') + '</span>'; }).join('');
		var good = P.map(function (p) { return '<span class="msm-kzl__r">' + esc(nv(p.dobre)) + '</span>'; }).join('');
		var bad = P.map(function (p) { var z = +p.zle || 0; return '<span class="msm-kzl__r">' + (z ? '<b class="msm-kz-bad">' + esc(fmtNum(z)) + '</b>' : '<span class="msm-muted">0</span>') + '</span>'; }).join('');
		var mc = many ? ' msm-kzl--many' : '';
		return '<td data-label="Programy" class="msm-kzl' + mc + '">' + names + '</td><td data-label="Detale dobre" class="num msm-kzl' + mc + '">' + good + '</td><td data-label="Złe" class="num msm-kzl' + mc + '">' + bad + '</td>';
	}

	/* ---------- lista ---------- */
	function renderKartyZmian() {
		var main = document.getElementById('msm-main');
		var F = (function () { try { return JSON.parse(sessionStorage.getItem('msm_kz_flt')) || {}; } catch (e) { return {}; } })();
		try { sessionStorage.removeItem('msm_kz_from'); } catch (e) {}
		main.innerHTML = '<div class="msm-cat msm-kz"><div class="msm-pagehead"><div><h1>Karty zmian</h1><p class="msm-muted" data-kzcount>&nbsp;</p></div>' +
			'<div class="msm-pagehead__tools"><button type="button" class="msm-btn" data-kzimp>' + KZ_XL + 'Import z Excela</button><a class="msm-btn msm-btn-primary" href="#prod-karty-new">+ Nowa karta zmiany</a></div></div>' +
			'<div class="msm-filters" aria-label="Filtry"><div class="msm-filters__body msm-plf">' +
			'<label class="msm-f"><span>Miesiąc</span><select data-kzm><option value="">Wszystkie</option></select></label>' +
			'<label class="msm-f"><span>Linia</span><select data-kzl><option value="">Wszystkie</option></select></label>' +
			'<div class="msm-f msm-zam-fclear"><button type="button" class="msm-link" data-kzclr>Wyczyść filtry</button></div></div></div>' +
			'<div data-kzbox><div class="msm-loading">Ładowanie…</div></div></div>';
		var box = main.querySelector('[data-kzbox]'), sm = main.querySelector('[data-kzm]'), sl = main.querySelector('[data-kzl]'), first = true;
		function load() {
			F = { m: sm.value || F.m || '', l: sl.value || F.l || '' };
			if (!first) F = { m: sm.value, l: sl.value };
			try { sessionStorage.setItem('msm_kz_flt', JSON.stringify(F)); } catch (e) {}
			api('/karty-zmian', { query: { miesiac: F.m, linia: F.l, _: Date.now() } }).then(function (r) {
				if (first) {
					var MN = ['styczeń', 'luty', 'marzec', 'kwiecień', 'maj', 'czerwiec', 'lipiec', 'sierpień', 'wrzesień', 'październik', 'listopad', 'grudzień'];
					r.miesiace.forEach(function (m) { var p = m.split('-'); sm.insertAdjacentHTML('beforeend', '<option value="' + esc(m) + '">' + MN[+p[1] - 1] + ' ' + p[0] + '</option>'); });
					r.linie.forEach(function (l) { sl.insertAdjacentHTML('beforeend', '<option>' + esc(l) + '</option>'); });
					sm.value = F.m; sl.value = F.l; first = false;
				}
				draw(r.karty);
			}).catch(function (e) { box.innerHTML = '<div class="msm-card msm-empty"><p>' + esc(e.message) + '</p></div>'; });
		}
		function draw(L) {
			main.querySelector('[data-kzcount]').textContent = L.length ? plN(L.length, 'karta', 'karty', 'kart') + (F.m || F.l ? ' (filtr)' : '') : ' ';
			if (!L.length) { box.innerHTML = '<div class="msm-card msm-empty"><h3>Brak kart zmian</h3><p class="msm-muted">' + (F.m || F.l ? 'Dla wybranych filtrów nie ma kart.' : 'Wypełnij pierwszą kartę na koniec zmiany – przycisk „Nowa karta zmiany”.') + '</p></div>'; return; }
			box.innerHTML = '<div class="msm-table-wrap"><table class="msm-table msm-kzt"><thead><tr><th>Data</th><th>Linia</th><th>Zmiana</th><th>Wypełnił</th><th>Programy</th><th class="num">Detale dobre</th><th class="num">Złe</th><th>Zapisano</th><th class="msm-actions"></th></tr></thead><tbody>' +
				L.map(function (k) {
					var low = k.suma.zadana > 0 && k.suma.dobre < k.suma.zadana * 0.95;
					return '<tr data-kz="' + k.id + '"' + (low ? ' class="is-low"' : '') + '>' +
						'<td data-label="Data"><b>' + esc(fmtDate(k.data)) + '</b></td>' +
						'<td data-label="Linia"><span class="msm-kz-lin">' + esc(k.linia) + '</span></td>' +
						'<td data-label="Zmiana"><span>zm. ' + esc(k.zmiana) + (k.godzina ? ' <small class="msm-muted">' + esc(k.godzina) + '</small>' : '') + '</span></td>' +
						'<td data-label="Wypełnił">' + esc(k.wypelnil) + '</td>' +
						kzProgCells(k) +
						'<td data-label="Zapisano"><small>' + esc(k.autor) + '<br><span class="msm-muted">' + esc(fmtDate(k.updated_at || k.created_at)) + (k.zmienil ? ' (poprawiono)' : '') + '</span></small></td>' +
						'<td class="msm-actions"><span class="msm-kz-acts"><button type="button" class="msm-btn msm-btn-sm" data-kzcp title="Nowa karta na podstawie tej">' + KZ_CP + 'Kopiuj</button>' + xbtn('xlsx', 'download="' + esc(k.plik) + '" data-kzxl', 'Pobierz arkusz ' + k.plik, kzUrl(k.id), 'msm-btn-sm') + '</span></td></tr>';
				}).join('') + '</tbody></table></div>';
			box.querySelectorAll('[data-kz]').forEach(function (tr) {
				tr.addEventListener('click', function (e) {
					if (e.target.closest('[data-kzxl]')) return;
					if (e.target.closest('[data-kzcp]')) { api('/karty-zmian/' + tr.getAttribute('data-kz'), { query: { _: Date.now() } }).then(function (r) { kzCopy(r.karta); }).catch(function (er) { toast(er.message, 'err'); }); return; }
					location.hash = '#prod-karty-' + tr.getAttribute('data-kz');
				});
			});
		}
		main.querySelector('[data-kzimp]').addEventListener('click', function () { kzImport(load); });
		[sm, sl].forEach(function (s) { s.addEventListener('change', load); });
		main.querySelector('[data-kzclr]').addEventListener('click', function () { sm.value = sl.value = ''; load(); });
		load();
	}

	/* ---------- import z Excela (arkusze w układzie wzoru karty) ---------- */
	function kzImport(done) {
		var body = '<div class="msm-kzi">' +
			'<label class="msm-pz-drop msm-kzi__drop" data-kzidrop><input type="file" accept=".xlsx,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" multiple hidden data-kzifile>' +
			'<b>Wybierz pliki kart zmian (.xlsx)</b><span class="msm-muted">albo upuść je tutaj · można kilka naraz (np. cały tydzień)</span></label>' +
			'<p class="msm-muted msm-small">Arkusz musi mieć układ karty zmiany (jak wzór i eksport z systemu). Linia, a w razie potrzeby data i zmiana, są brane z nazwy pliku, np. <code>2026.11.14_L2_zm1.xlsx</code>.</p>' +
			'<div data-kziprev></div></div>';
		var m = openModal('Import kart zmian z Excela', body, '<button type="button" class="msm-btn" data-close>Zamknij</button><button type="button" class="msm-btn msm-btn-primary" data-kzigo disabled>Importuj</button>', true);
		var inp = m.querySelector('[data-kzifile]'), prev = m.querySelector('[data-kziprev]'), go = m.querySelector('[data-kzigo]'), drop = m.querySelector('[data-kzidrop]');
		var ROWS = [], LINIE = ['L1', 'L2'];
		function send(files) {
			var fd = new FormData(), n = 0;
			Array.prototype.forEach.call(files, function (f) { fd.append('pliki[]', f); n++; });
			if (!n) return;
			prev.innerHTML = '<div class="msm-loading">Odczyt ' + plN(n, 'pliku', 'plików', 'plików') + '…</div>'; go.disabled = true;
			api('/karty-zmian/import', { method: 'POST', form: fd }).then(function (r) { ROWS = r.pliki; LINIE = r.linie || LINIE; ROWS.forEach(function (x) { x.on = !!x.karta && !x.duplikat && !need(x).length; }); draw(); })
				.catch(function (e) { prev.innerHTML = '<p class="msm-alert msm-alert-err">' + esc(e.message) + '</p>'; });
		}
		function need(x) {
			var k = x.karta, b = []; if (!k) return b;
			if (!k.data) b.push('data'); if (!k.linia) b.push('linia'); if (!k.zmiana) b.push('zmiana'); if (!k.wypelnil) b.push('wypełnił');
			return b;
		}
		function draw() {
			if (!ROWS.length) { prev.innerHTML = ''; return; }
			prev.innerHTML = '<div class="msm-table-wrap"><table class="msm-table msm-kzi__t"><thead><tr><th></th><th>Plik</th><th>Data</th><th>Linia</th><th>Zm.</th><th>Wypełnił</th><th class="num">Progr.</th><th>Stan</th></tr></thead><tbody>' +
				ROWS.map(function (x, i) {
					var k = x.karta, miss = need(x);
					if (!k) return '<tr class="is-err"><td></td><td data-label="Plik">' + esc(x.plik) + '</td><td colspan="6" data-label="Stan"><span class="msm-eltag is-bad">' + esc(x.blad) + '</span></td></tr>';
					var st = x.zapisano ? '<span class="msm-eltag is-ok">Zaimportowano</span>' : x.blad ? '<span class="msm-eltag is-bad">' + esc(x.blad) + '</span>' :
						miss.length ? '<span class="msm-eltag is-warn">Brakuje: ' + esc(miss.join(', ')) + '</span>' :
						x.duplikat ? '<span class="msm-eltag is-warn">Taka karta już jest – <a href="#prod-karty-' + x.duplikat + '" target="_blank">zobacz</a>; zaznacz, by dodać mimo to</span>' : '<span class="msm-eltag is-ok">Gotowa</span>';
					return '<tr' + (x.zapisano ? ' class="is-done"' : '') + '><td><input type="checkbox" data-kzion="' + i + '"' + (x.on ? ' checked' : '') + (x.zapisano || miss.filter(function (f) { return f !== 'linia'; }).length ? ' disabled' : '') + '></td>' +
						'<td data-label="Plik" class="msm-kzi__f">' + esc(x.plik) + '</td>' +
						'<td data-label="Data">' + (k.data ? esc(fmtDate(k.data)) : '<span class="msm-kz-bad">—</span>') + '</td>' +
						'<td data-label="Linia">' + (x.zapisano ? esc(k.linia) : '<select data-kzilin="' + i + '"><option value="">—</option>' + LINIE.map(function (l) { return '<option' + (l === k.linia ? ' selected' : '') + '>' + esc(l) + '</option>'; }).join('') + '</select>') + '</td>' +
						'<td data-label="Zmiana">' + (k.zmiana ? esc(k.zmiana) : '<span class="msm-kz-bad">—</span>') + '</td>' +
						'<td data-label="Wypełnił">' + (k.wypelnil ? esc(k.wypelnil) : '<span class="msm-kz-bad">—</span>') + '</td>' +
						'<td data-label="Programy" class="num">' + k.programy.length + '</td>' +
						'<td data-label="Stan">' + st + '</td></tr>';
				}).join('') + '</tbody></table></div>';
			prev.querySelectorAll('[data-kzion]').forEach(function (c) { c.addEventListener('change', function () { ROWS[+c.getAttribute('data-kzion')].on = c.checked; count(); }); });
			prev.querySelectorAll('[data-kzilin]').forEach(function (s) {
				s.addEventListener('change', function () { var x = ROWS[+s.getAttribute('data-kzilin')]; x.karta.linia = s.value; x.on = !!s.value && !need(x).length && (!x.duplikat || x.on); x.blad = ''; draw(); });
			});
			count();
		}
		function sel() { return ROWS.filter(function (x) { return x.on && x.karta && !x.zapisano && !need(x).length; }); }
		function count() { var n = sel().length; go.disabled = !n; go.textContent = n ? 'Importuj ' + plN(n, 'kartę', 'karty', 'kart') : 'Importuj'; }
		inp.addEventListener('change', function () { send(inp.files); inp.value = ''; });
		['dragover', 'dragenter'].forEach(function (ev) { drop.addEventListener(ev, function (e) { e.preventDefault(); drop.classList.add('is-over'); }); });
		['dragleave', 'drop'].forEach(function (ev) { drop.addEventListener(ev, function (e) { e.preventDefault(); drop.classList.remove('is-over'); }); });
		drop.addEventListener('drop', function (e) { if (e.dataTransfer && e.dataTransfer.files) send(e.dataTransfer.files); });
		go.addEventListener('click', function () {
			var L = sel(), ok = 0, chain = Promise.resolve();
			go.disabled = true;
			L.forEach(function (x) {
				chain = chain.then(function () {
					return api('/karty-zmian', { method: 'POST', body: x.karta }).then(function () { x.zapisano = true; x.on = false; ok++; })
						.catch(function (e) { var f = e.data && e.data.fields ? ' (' + Object.keys(e.data.fields).map(function (k) { return k.replace(/^programy\.(\d+)\./, function (a, n) { return 'program ' + (+n + 1) + ': '; }); }).join(', ') + ')' : ''; x.blad = e.message + f; x.on = false; });
				}).then(draw);
			});
			chain.then(function () {
				toast(ok ? 'Zaimportowano ' + plN(ok, 'kartę zmiany', 'karty zmian', 'kart zmian') + '.' : 'Nie zaimportowano żadnej karty.', ok ? undefined : 'err');
				if (ok && done) done();
			});
		});
	}

	/* ---------- formularz ---------- */
	function renderKartaZmiany(id) {
		var main = document.getElementById('msm-main');
		main.innerHTML = '<div class="msm-cat msm-kz"><div class="msm-loading">Ładowanie…</div></div>';
		var req = id ? api('/karty-zmian/' + id, { query: { _: Date.now() } }) : api('/karty-zmian', { query: { miesiac: '1900-01', _: Date.now() } });
		req.then(function (r) { kzForm(main, id ? r.karta : null, r.pracownicy, r.linie); })
			.catch(function (e) { main.innerHTML = '<div class="msm-cat"><div class="msm-card msm-empty"><p>' + esc(e.message) + '</p><p><a href="#prod-karty">‹ Karty zmian</a></p></div></div>'; });
	}
	function kzMe(names) {
		/* „Michał Dróbka” (konto) ↔ „Dróbka Michał” (lista) – te same słowa w dowolnej kolejności */
		var me = srchNorm(C.user || '').split(/\s+/).filter(Boolean).sort().join(' ');
		return names.filter(function (n) { return srchNorm(n).split(/\s+/).filter(Boolean).sort().join(' ') === me; })[0] || '';
	}
	/* Numer zlecenia z nazwy programu: „B02516_v3_942_2670_KB_4k” → „B02516”. */
	function kzZlec(n) { var m = String(n || '').match(/^\s*([A-Za-z]\d{4,6})(?=[_\-\s.]|$)/); return m ? m[1].toUpperCase() : ''; }
	function kzForm(main, k, names, linie) {
		var now = new Date(), pad = function (n) { return ('0' + n).slice(-2); };
		var K = k || { data: now.getFullYear() + '-' + pad(now.getMonth() + 1) + '-' + pad(now.getDate()), linia: '', zmiana: '', godzina: pad(now.getHours()) + ':' + pad(now.getMinutes()), wypelnil: kzMe(names), porzadek: '', przyrzady: '', programy: [], moje: true };
		var fromCopy = '';
		if (!k) {
			var pre = null;
			try { pre = JSON.parse(sessionStorage.getItem('msm_kz_copy') || 'null'); sessionStorage.removeItem('msm_kz_copy'); } catch (e) {}
			if (pre) { fromCopy = pre._z || ''; delete pre._z; K = Object.assign(K, pre); }
		}
		/* Otwarta z zakładki zlecenia: podsumowanie tylko programów tego zlecenia, reszta przygaszona. */
		var FZ = null;
		if (k) { try { FZ = JSON.parse(sessionStorage.getItem('msm_kz_from') || 'null'); } catch (e) {} if (FZ && (FZ.ids || []).indexOf(k.id) < 0) FZ = null; }
		var ro = !!k && k.moje === false, dis = ro ? ' disabled' : '';
		var progs = (K.programy && K.programy.length ? K.programy : [{}]).map(function (p) { return Object.assign({}, p); });
		var TN = ['TAK', 'NIE', 'nie dotyczy'];
		function opts(list, val, ph) {
			var L = list.slice(); if (val && L.indexOf(val) < 0) L.push(val);
			return '<option value="">' + (ph || '—') + '</option>' + L.map(function (n) { return '<option' + (String(n) === String(val) ? ' selected' : '') + '>' + esc(n) + '</option>'; }).join('');
		}
		function sel(name, list, val, ph) { return '<select name="' + name + '"' + dis + '>' + opts(list, val, ph) + '</select>'; }
		function fld(key, label, inner, cls, req) { return '<label class="msm-field' + (cls ? ' ' + cls : '') + '" data-field="' + key + '"><span>' + label + (req ? ' <i class="msm-req">*</i>' : '') + '</span>' + inner + '<em class="msm-ferr"></em></label>'; }
		function sumHtml() {
			var z = 0, d = 0, b = 0, all = 0;
			progs.forEach(function (p) { all += +kzNum(p.dobre) || 0; });
			progs.filter(function (p) { return !FZ || kzZlec(p.nazwa) === FZ.nr; }).forEach(function (p) { var a = kzNum(p.zadana), c = kzNum(p.dobre), e = kzNum(p.zle); z += +a || 0; d += +c || 0; b += +e || 0; });
			var low = z > 0 && d < z * 0.95;
			return '<small>' + (FZ ? 'Zlecenie ' + esc(FZ.nr) + ' · detale dobre' : 'Detale dobre') + '</small><b>' + (d || z ? fmtNum(d) + (z ? ' <i>/ ' + fmtNum(z) + '</i>' : '') : '—') + '</b>' + (b ? '<span>złe: ' + fmtNum(b) + '</span>' : (low ? '<span>poniżej 95% zadanej</span>' : '')) +
				(FZ && all !== d ? '<span class="msm-kz-all">cała karta: ' + fmtNum(all) + '</span>' : '');
		}
		var title = k ? fmtDate(k.data) + ' <span class="msm-el-head__n">' + esc(k.linia) + ' · zmiana ' + esc(k.zmiana) + '</span>' : 'Nowa karta zmiany';
		main.innerHTML = '<div class="msm-cat msm-el msm-kz"><a class="msm-back" href="' + (FZ ? esc(FZ.back) : '#prod-karty') + '">← ' + (FZ ? 'Zlecenie ' + esc(FZ.nr) : 'Karty zmian') + '</a>' +
			'<div class="msm-pagehead msm-el-head"><div><h1>' + title + '</h1>' +
			'<p class="msm-el-head__meta">' + (k ? '<span class="msm-eltag">Wypełnił: ' + esc(k.wypelnil) + '</span><span class="msm-eltag">Zapisał ' + esc(k.autor) + ' · ' + esc(fmtDate(k.created_at)) + '</span>' + (k.zmienil ? '<span class="msm-eltag">Poprawił ' + esc(k.zmienil) + ' · ' + esc(fmtDate(k.updated_at)) + '</span>' : '') :
				(fromCopy ? '<span class="msm-eltag is-warn">Kopia karty ' + esc(fromCopy) + ' – sprawdź datę, zmianę i wyniki</span>' : '<span class="msm-eltag">Wypełniać na koniec zmiany</span>')) + '</p>' +
			(k ? '<p class="msm-kz-tools"><button type="button" class="msm-btn msm-btn-sm" data-kzcopy>' + KZ_CP + 'Kopiuj</button>' + xbtn('xlsx', 'download="' + esc(k.plik) + '"', 'Pobierz arkusz ' + k.plik, kzUrl(k.id), 'msm-btn-sm') + '</p>' : '') + '</div>' +
			'<div class="msm-el-status msm-kz-sum" data-kzsum>' + sumHtml() + '</div></div>' +
			(ro ? '<div class="msm-alert msm-kz-ro">Kartę może poprawić tylko jej autor (' + esc(k.autor) + ') albo administrator – możesz ją przejrzeć, skopiować i pobrać.</div>' : '') +
			'<form class="msm-card msm-form msm-el-form msm-kz-form" novalidate><div class="msm-form-err msm-alert msm-alert-err" hidden></div>' +
			'<h3 class="msm-pm-h">Zmiana</h3><div class="msm-grid msm-el-grid">' +
			fld('data', 'Data', '<input type="date" name="data" value="' + esc(K.data) + '"' + dis + '>', '', true) +
			fld('linia', 'Linia', sel('linia', linie, K.linia, '— wybierz —'), '', true) +
			fld('zmiana', 'Numer zmiany', sel('zmiana', [1, 2, 3], K.zmiana, '— wybierz —'), '', true) +
			fld('godzina', 'Godzina wypełnienia', '<input type="time" name="godzina" value="' + esc(K.godzina || '') + '"' + dis + '>') +
			fld('wypelnil', 'Wypełnił', sel('wypelnil', names, K.wypelnil, '— wybierz —'), '', true) +
			'</div><h3 class="msm-pm-h">Obsada</h3><div class="msm-grid msm-el-grid">' +
			fld('operator1', 'Operator 1', sel('operator1', names, K.operator1)) + fld('operator2', 'Operator 2', sel('operator2', names, K.operator2)) + '<span class="msm-kz-gap"></span>' +
			fld('pomocnik1', 'Pomocnik 1', sel('pomocnik1', names, K.pomocnik1)) + fld('pomocnik2', 'Pomocnik 2', sel('pomocnik2', names, K.pomocnik2)) + fld('pomocnik3', 'Pomocnik 3', sel('pomocnik3', names, K.pomocnik3)) +
			'</div><h3 class="msm-pm-h">Stanowisko</h3><div class="msm-grid msm-el-grid">' +
			fld('porzadek', 'Zachowany porządek na miejscu pracy', sel('porzadek', TN, K.porzadek)) +
			fld('przyrzady', 'Przyrządy pomiarowe – kompletność', sel('przyrzady', TN, K.przyrzady)) + '<span class="msm-kz-gap"></span>' +
			fld('problemy', 'Problemy techniczne – opisać', '<textarea name="problemy" rows="2"' + dis + '>' + esc(K.problemy || '') + '</textarea>', 'full') +
			fld('uwagi_poprz', 'Uwagi do poprzedniej zmiany', '<textarea name="uwagi_poprz" rows="2"' + dis + '>' + esc(K.uwagi_poprz || '') + '</textarea>', 'full') +
			'</div><h3 class="msm-pm-h msm-kz-ph">Programy <span class="msm-muted" data-kzpn></span></h3>' +
			'<div class="msm-kz-plist" data-kzprogs></div>' +
			(ro ? '' : '<button type="button" class="msm-pgd-add msm-kz-add" data-kzadd><span aria-hidden="true">+</span> Dodaj program</button>') +
			(ro ? '' : '<div class="msm-el-actions msm-kz-actions">' + (k ? '<button type="button" class="msm-btn msm-btn-danger-ghost" data-kzdel>Usuń kartę</button>' : '') +
				'<span class="msm-kz-actions__r"><a class="msm-btn" href="#prod-karty">Anuluj</a><button type="submit" class="msm-btn msm-btn-primary" data-kzsave>' + (k ? 'Zapisz zmiany' : 'Zapisz kartę') + '</button></span></div>') +
			'</form></div>';
		var form = main.querySelector('form'), pbox = main.querySelector('[data-kzprogs]'), sumBox = main.querySelector('[data-kzsum]');

		function drawProgs() {
			pbox.innerHTML = progs.map(function (p, i) {
				var zl = kzZlec(p.nazwa);
				return '<section class="msm-kz-prog' + (FZ ? (zl === FZ.nr ? ' is-this' : ' is-other') : '') + '" data-kzp="' + i + '" style="--kz-c:' + KZ_COLORS[i] + '">' +
					'<header class="msm-kz-prog__h"><span class="msm-kz-prog__no">' + (i + 1) + '</span><b>Program ' + (i + 1) + '</b>' +
					'<span class="msm-eltag msm-kz-zl" data-kzzl' + (zl ? '' : ' hidden') + '>Zlecenie ' + esc(zl) + '</span>' +
					(ro || progs.length < 2 ? '' : '<button type="button" class="msm-btn msm-btn-sm msm-btn-danger-ghost msm-kz-prm" data-kzprm>Usuń program</button>') + '</header>' +
					'<div class="msm-grid msm-el-grid">' + KZ_PF.map(function (f) {
						var v = p[f[0]] == null ? '' : p[f[0]], key = 'programy.' + i + '.' + f[0], inner;
						if (f[2] === 'area') inner = '<textarea data-pf="' + f[0] + '" rows="2"' + dis + '>' + esc(v) + '</textarea>';
						else if (f[2] === 'taknie') inner = '<select data-pf="' + f[0] + '"' + dis + '>' + opts(['TAK', 'NIE'], v) + '</select>';
						else inner = '<input type="text" data-pf="' + f[0] + '" value="' + esc(f[2] === 'num' ? String(v).replace('.', ',') : v) + '"' + (f[2] === 'num' ? ' inputmode="decimal"' + (f[0] === 'dobre' ? ' placeholder="np. 768 albo 16*48"' : '') : (f[0] === 'nazwa' ? ' placeholder="np. B02516_v3_942_2670_KB_4k"' : '')) + ' autocomplete="off"' + dis + '>' + (f[2] === 'num' ? '<small class="msm-kz-calc" data-calc></small>' : '');
						var cls = f[0] === 'nazwa' ? 'msm-kz-name' : (f[3] || '');
						return '<label class="msm-field' + (cls ? ' ' + cls : '') + '" data-field="' + key + '"><span>' + f[1] + '</span>' + inner + '<em class="msm-ferr"></em></label>';
					}).join('') + '</div><p class="msm-kz-warn" data-kzwarn hidden></p></section>';
			}).join('');
			main.querySelector('[data-kzpn]').textContent = '(' + progs.length + ' z ' + KZ_MAX + ')';
			var add = main.querySelector('[data-kzadd]'); if (add) add.hidden = progs.length >= KZ_MAX;
			pbox.querySelectorAll('[data-kzp]').forEach(function (sec) {
				var i = +sec.getAttribute('data-kzp');
				sec.querySelectorAll('[data-pf]').forEach(function (inp) {
					inp.addEventListener(inp.tagName === 'SELECT' ? 'change' : 'input', function () {
						progs[i][inp.getAttribute('data-pf')] = inp.value;
						if (inp.getAttribute('data-pf') === 'nazwa') { var z = kzZlec(inp.value), t = sec.querySelector('[data-kzzl]'); t.hidden = !z; t.textContent = 'Zlecenie ' + z; if (FZ) { sec.classList.toggle('is-this', z === FZ.nr); sec.classList.toggle('is-other', z !== FZ.nr); } }
						calc(sec, i);
					});
				});
				var rm = sec.querySelector('[data-kzprm]');
				if (rm) rm.addEventListener('click', function () { progs.splice(i, 1); drawProgs(); });
				calc(sec, i);
			});
		}
		/* Podpowiedź wyniku działania („16*48 = 768”) i ostrzeżenie < 95% ilości zadanej (jak w arkuszu). */
		function calc(sec, i) {
			sec.querySelectorAll('input[inputmode=decimal]').forEach(function (inp) {
				var n = kzNum(inp.value), h = inp.parentNode.querySelector('[data-calc]');
				h.textContent = n === null ? 'to nie jest liczba' : (n !== '' && !/^\s*-?[\d\s]+([.,]\d+)?\s*$/.test(inp.value) ? '= ' + fmtNum(n) : '');
				h.classList.toggle('is-err', n === null);
			});
			var z = kzNum(progs[i].zadana), d = kzNum(progs[i].dobre), w = sec.querySelector('[data-kzwarn]');
			var low = z !== null && z !== '' && d !== null && d !== '' && d < z * 0.95;
			w.hidden = !low;
			if (low) w.textContent = 'Detali dobrych (' + fmtNum(d) + ') jest mniej niż 95% ilości zadanej (' + fmtNum(z) + ') – opisz to w „Wyjaśnieniu rozbieżności”.';
			var dob = sec.querySelector('[data-pf=dobre]'); if (dob) dob.classList.toggle('is-low', low);
			sumBox.innerHTML = sumHtml();
			var zz = 0, dd = 0; progs.forEach(function (p) { zz += +kzNum(p.zadana) || 0; dd += +kzNum(p.dobre) || 0; });
			sumBox.classList.toggle('is-late', zz > 0 && dd < zz * 0.95);
		}
		drawProgs();
		/* poprawione pole – znika jego komunikat błędu */
		form.addEventListener('input', clrErr); form.addEventListener('change', clrErr);
		function clrErr(e) { var f = e.target.closest('.has-err'); if (f) { f.classList.remove('has-err'); var m = f.querySelector('.msm-ferr'); if (m) m.textContent = ''; } if (!form.querySelector('.has-err')) { var g = form.querySelector('.msm-form-err'); if (g) g.hidden = true; } }
		var cpb = main.querySelector('[data-kzcopy]'); if (cpb) cpb.addEventListener('click', function () { kzCopy(k); });
		if (ro) return;
		main.querySelector('[data-kzadd]').addEventListener('click', function () {
			if (progs.length >= KZ_MAX) return;
			var last = progs[progs.length - 1] || {};
			progs.push({ gatunek: last.gatunek || '', format: last.format || '' }); // materiał zwykle ten sam co w poprzednim programie
			drawProgs();
			var s = pbox.lastElementChild; if (s) { s.scrollIntoView({ behavior: 'smooth', block: 'start' }); var f = s.querySelector('[data-pf=nazwa]'); if (f) setTimeout(function () { f.focus(); }, 300); }
		});
		form.addEventListener('submit', function (e) {
			e.preventDefault();
			var body = {};
			['data', 'linia', 'zmiana', 'godzina', 'wypelnil', 'operator1', 'operator2', 'pomocnik1', 'pomocnik2', 'pomocnik3', 'porzadek', 'przyrzady', 'problemy', 'uwagi_poprz'].forEach(function (n) { var el = form.querySelector('[name="' + n + '"]'); body[n] = el ? el.value : ''; });
			body.programy = progs.map(function (p) {
				var o = {}; KZ_PF.forEach(function (f) { var v = p[f[0]] == null ? '' : String(p[f[0]]); if (f[2] === 'num') { var n = kzNum(v); o[f[0]] = n === null ? v : n; } else o[f[0]] = v; }); return o;
			});
			var b = form.querySelector('[data-kzsave]'); b.disabled = true;
			api(k ? '/karty-zmian/' + k.id : '/karty-zmian', { method: 'POST', body: body }).then(function (r) {
				toast(k ? 'Zapisano zmiany w karcie.' : 'Zapisano kartę zmiany.' + (r.duplikat ? ' Uwaga: jest już karta dla tej daty, linii i zmiany.' : ''), r.duplikat ? 'warn' : undefined);
				if (k) renderKartaZmiany(k.id); else location.hash = '#prod-karty-' + r.karta.id;
			}).catch(function (er) { b.disabled = false; showErrors(form, er); var f = form.querySelector('.has-err'); if (f) f.scrollIntoView({ behavior: 'smooth', block: 'center' }); toast(er.message, 'err'); });
		});
		var del = main.querySelector('[data-kzdel]');
		if (del) del.addEventListener('click', function () {
			confirmBox('Usunąć kartę zmiany?', 'Karta ' + esc(fmtDate(k.data) + ' · ' + k.linia + ' · zm. ' + k.zmiana) + ' zostanie usunięta (wpis zostaje w historii zmian).', 'Usuń', true).then(function (ok) {
				if (!ok) return;
				api('/karty-zmian/' + k.id + '/delete', { method: 'POST' }).then(function () { toast('Usunięto kartę zmiany.'); location.hash = '#prod-karty'; }).catch(function (er) { toast(er.message, 'err'); });
			});
		});
	}

	/* ---------- zakładka „Karty zmian” w zleceniu Produkcji ---------- */
	function renderKartyZlec(tb, o) {
		var nr = String(o.nr_zlec || '').trim().toUpperCase();
		tb.innerHTML = '<div class="msm-ptool"><span class="msm-muted" data-kzzc>Ładowanie…</span><span class="msm-ptool__btns"><a class="msm-btn msm-btn-primary" href="#prod-karty-new">+ Nowa karta zmiany</a></span></div><div data-kzstat></div><div data-kzzl></div>';
		var list = tb.querySelector('[data-kzzl]');
		if (!nr) { tb.querySelector('[data-kzzc]').textContent = 'Zlecenie nie ma numeru – karty zmian łączą się po numerze z nazwy programu.'; return; }
		api('/karty-zmian', { query: { zlec: nr, _: Date.now() } }).then(function (r) {
			var L = r.karty, sd = 0, sz = 0, bn = document.querySelector('[data-kztn]');
			o.karty_n = L.length; // licznik na zakładce – zawsze aktualny po otwarciu
			if (bn) { bn.textContent = L.length; bn.hidden = !L.length; }
			var sb = 0, lin = {};
			L.forEach(function (k) { lin[k.linia] = 1; (k.progs || []).forEach(function (p) { sd += +p.dobre || 0; sz += +p.zadana || 0; sb += +p.zle || 0; }); });
			if (L.length) {
				/* Podsumowanie: detale dobre razem (wyróżnione) + złe, liczba kart, ostatnia karta. */
				var zam = 0; (o.det || []).forEach(function (d) { zam += +d.ilosc_zam || 0; });
				var pct = zam > 0 ? Math.round(100 * sd / zam) : null, last = L[0];
				var tile = function (cls, lbl, val, sub) { return '<div class="msm-kzst__t' + cls + '"><span>' + lbl + '</span><b>' + val + '</b>' + (sub ? '<small>' + sub + '</small>' : '') + '</div>'; };
				tb.querySelector('[data-kzstat]').innerHTML = '<div class="msm-kzst">' +
					tile(' is-main', 'Detale dobre razem', esc(fmtNum(sd)), pct !== null ? esc(pct + '% z ' + fmtNum(zam) + ' zamówionych') + (sd < zam ? ' · pozostało ' + esc(fmtNum(zam - sd)) : '') : 'szt.') +
					tile(sb ? ' is-bad' : '', 'Złe', esc(fmtNum(sb)), sd + sb > 0 ? esc(String(Math.round(1000 * sb / (sd + sb)) / 10).replace('.', ',') + '%') : '') +
					tile('', 'Karty zmian', esc(L.length), esc(Object.keys(lin).sort().join(', '))) +
					tile('', 'Ostatnia', esc(fmtDate(last.data).slice(0, 5)), esc(fmtDate(last.data).slice(6) + ' · ' + last.linia + ' · zm. ' + last.zmiana)) +
					'</div>';
			}
			tb.querySelector('[data-kzzc]').innerHTML = L.length ? esc(plN(L.length, 'karta zmiany', 'karty zmian', 'kart zmian')) + ' z programami zlecenia <b>' + esc(nr) + '</b>' : 'Brak kart zmian z programami tego zlecenia (nazwa programu zaczynająca się od „' + esc(nr) + '_…”).';
			if (!L.length) return;
			list.innerHTML = '<div class="msm-table-wrap"><table class="msm-table msm-kzt msm-kzo"><thead><tr><th>Data</th><th>Linia / zmiana</th><th>Programy zlecenia</th><th class="num">Detale dobre</th><th class="num">Złe</th><th>Wypełnił</th><th>Zapisano</th><th class="msm-actions"></th></tr></thead><tbody>' +
				L.map(function (k) {
					var P = k.progs || [], d = 0, z = 0, b = 0;
					P.forEach(function (p) { d += +p.dobre || 0; z += +p.zadana || 0; b += +p.zle || 0; });
					var low = z > 0 && d < z * 0.95;
					return '<tr data-kzgo="' + k.id + '"' + (low ? ' class="is-low"' : '') + '>' +
						'<td data-label="Data"><b>' + esc(fmtDate(k.data)) + '</b></td>' +
						'<td data-label="Linia / zmiana"><span><span class="msm-kz-lin">' + esc(k.linia) + '</span> zm. ' + esc(k.zmiana) + (k.godzina ? ' <small class="msm-muted">' + esc(k.godzina) + '</small>' : '') + '</span></td>' +
						'<td data-label="Programy zlecenia"><span class="msm-kz-pl">' + P.map(function (p) { return '<span class="msm-kz-pn">' + esc(p.nazwa) + (P.length > 1 ? ' <small class="msm-muted">· ' + esc(p.dobre !== '' && p.dobre != null ? fmtNum(p.dobre) : '—') + '</small>' : '') + '</span>'; }).join('') + '</span></td>' +
						'<td data-label="Detale dobre" class="num"><span><b>' + esc(fmtNum(d)) + '</b>' + (z ? ' <small class="msm-muted">/ ' + esc(fmtNum(z)) + '</small>' : '') + '</span></td>' +
						'<td data-label="Złe" class="num">' + (b ? '<b class="msm-kz-bad">' + esc(fmtNum(b)) + '</b>' : '<span class="msm-muted">0</span>') + '</td>' +
						'<td data-label="Wypełnił">' + esc(k.wypelnil) + '</td>' +
						'<td data-label="Zapisano"><small>' + esc(fmtDate(k.updated_at || k.created_at)) + '</small></td>' +
						'<td class="msm-actions"><a class="msm-link" href="#prod-karty-' + k.id + '">Otwórz kartę ›</a></td></tr>';
				}).join('') + '</tbody></table></div>';
			var back = location.hash;
			function from() { try { sessionStorage.setItem('msm_kz_from', JSON.stringify({ nr: nr, back: back, ids: L.map(function (k) { return k.id; }) })); } catch (e) {} }
			list.querySelectorAll('a[href^="#prod-karty-"]').forEach(function (a) { a.addEventListener('click', from); });
			list.querySelectorAll('[data-kzgo]').forEach(function (tr) { tr.addEventListener('click', function (e) { if (e.target.closest('a')) return; from(); location.hash = '#prod-karty-' + tr.getAttribute('data-kzgo'); }); });
		}).catch(function (e) { list.innerHTML = '<p class="msm-alert msm-alert-err">' + esc(e.message) + '</p>'; });
	}
	/* ================================================================
	   DOKUMENTY → PRZESYŁKI: rejestr przesyłek przychodzących
	   ================================================================ */
	var PRZ = null; // ostatnio pobrane podpowiedzi: { nadawcy, sprawdzajacy, zlecenia, jedn, ja, admin }

	function przDT(v) { var m = String(v || '').match(/^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})/); return m ? { d: m[3] + '.' + m[2] + '.' + m[1], t: m[4] + ':' + m[5] } : { d: v || '', t: '' }; }
	function przNow() { var d = new Date(), p = function (n) { return ('0' + n).slice(-2); }; return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate()) + 'T' + p(d.getHours()) + ':' + p(d.getMinutes()); }
	function przIl(x) { return x.ilosc == null ? '' : fmtNum(x.ilosc) + (x.jedn ? ' ' + x.jedn : ''); }
	function przPoz(p) { return p.pozycje || []; }
	/* Numer zlecenia (link do zakładki Przesyłki zlecenia, gdy jest w Produkcji). */
	function przZlLink(id, nr) {
		if (!nr) return '<span class="msm-muted">—</span>';
		return id && mOn('produkcja') ? '<a class="msm-pgl-nr" href="#prod-' + id + '-przesylki">' + esc(nr) + '</a>' : esc(nr);
	}

	/* Tabela przesyłek (lista i zakładka zlecenia). Na telefonie – karty (data-label). */
	function przTable(L, admin, noZl) {
		return '<div class="msm-table-wrap"><table class="msm-table msm-przt"><thead><tr><th>Data / godzina</th><th>Nadawca</th>' +
			'<th>Faktura</th><th class="msm-przt__hpoz">' + (noZl ? 'Zawartość przesyłki' : 'Zlecenie · zawartość przesyłki') + '</th><th class="num">Ilość</th><th>Uwagi</th><th>Sprawdził</th>' + (admin ? '<th></th>' : '') + '</tr></thead><tbody>' +
			L.map(function (p) {
				var dt = przDT(p.data_spr);
				return '<tr class="' + (p.uszkodzona ? 'is-dmg' : '') + '" data-prz="' + p.id + '">' +
					'<td data-label="Data / godzina" class="msm-przt__d"><span class="msm-zt__v"><b>' + esc(dt.d) + '</b> <span class="msm-muted">' + esc(dt.t) + '</span></span></td>' +
					'<td data-label="Nadawca"><b>' + esc(p.nadawca) + '</b></td>' +
					'<td data-label="Faktura"><span class="msm-przf ' + (p.faktura ? 'is-yes' : 'is-no') + '">' + (p.faktura ? 'Tak' : 'Nie') + '</span></td>' +
					'<td data-label="Zawartość" class="msm-przt__poz" colspan="2"><ul class="msm-przpoz">' + przPoz(p).filter(function (x) { return !noZl || x.zlec_id === noZl; }).map(function (x) {
						return '<li>' + (noZl ? '' : '<span class="msm-przpoz__zl">' + przZlLink(x.zlec_id, x.zlecenie) + '</span>') + '<span class="msm-przpoz__o">' + esc(x.opis) + (x.uwagi ? '<small class="msm-przpoz__uw">' + esc(x.uwagi) + '</small>' : '') + '</span><b>' + esc(przIl(x)) + '</b></li>';
					}).join('') + (noZl && przPoz(p).length > przPoz(p).filter(function (x) { return x.zlec_id === noZl; }).length ? '<li class="msm-przpoz__more"><span class="msm-muted">+ pozycje do innych zleceń: ' + esc(przPoz(p).filter(function (x) { return x.zlec_id !== noZl; }).map(function (x) { return x.zlecenie || 'bez zlecenia'; }).filter(function (v, i, a) { return a.indexOf(v) === i; }).join(', ')) + '</span></li>' : '') + '</ul></td>' +
					'<td data-label="Uwagi" class="msm-przt__txt' + (!p.uszkodzona && !p.uwagi ? ' is-empty' : '') + '"><span>' + (p.uszkodzona ? '<span class="msm-przdmg">Uszkodzona</span> ' : '') + esc(p.uwagi).replace(/\n/g, '<br>') + '</span></td>' +
					'<td data-label="Sprawdził">' + esc(p.sprawdzil) + '</td>' +
					(admin ? '<td class="msm-pgl-act"><button type="button" class="msm-iconbtn" data-przm="' + p.id + '" aria-label="Akcje przesyłki">' + ICO_DOTS + '</button></td>' : '') +
					'</tr>';
			}).join('') + '</tbody></table></div>';
	}

	/* Formularz przesyłki (nowa albo poprawka). preset – np. { zlec_id, zlecenie } z zakładki zlecenia. */
	function przForm(row, preset, onSaved) {
		var H = PRZ || { nadawcy: [], sprawdzajacy: [], zlecenia: [], jedn: ['szt.'], ja: C.user };
		var v = row || { data_spr: przNow(), nadawca: '', faktura: null, pozycje: preset ? [{ zlec_id: preset.zlec_id, zlecenie: preset.zlecenie }] : [], uwagi: '', uszkodzona: false, sprawdzil: H.ja || C.user };
		var dl = function (id, a) { return '<datalist id="' + id + '">' + a.map(function (x) { return '<option value="' + esc(x) + '">'; }).join('') + '</datalist>'; };
		var zl = '<datalist id="msm-prz-zl">' + H.zlecenia.map(function (z) { return '<option value="' + esc(z.nr) + '">' + esc([z.klient, z.rok].filter(Boolean).join(' · ')) + '</option>'; }).join('') + '</datalist>';
		var fak = v.faktura === null || v.faktura === undefined ? '' : v.faktura ? '1' : '0';
		var body = '<form class="msm-form msm-przform" novalidate><div class="msm-form-err msm-alert msm-alert-err" hidden></div><div class="msm-grid">' +
			'<label class="msm-field" data-field="data_spr"><span>Data i godzina sprawdzenia <i class="msm-req">*</i></span><input type="datetime-local" name="data_spr" value="' + esc(String(v.data_spr).replace(' ', 'T').slice(0, 16)) + '"><em class="msm-ferr"></em></label>' +
			'<label class="msm-field" data-field="nadawca"><span>Nadawca przesyłki <i class="msm-req">*</i></span><input type="text" name="nadawca" list="msm-prz-nad" value="' + esc(v.nadawca) + '" autocomplete="off" placeholder="np. ArcelorMittal, DHL…"><em class="msm-ferr"></em></label>' +
			'<div class="msm-field" data-field="faktura"><span>Faktura <i class="msm-req">*</i></span><div class="msm-seg msm-przseg" role="radiogroup">' +
			'<label><input type="radio" name="faktura" value="1"' + (fak === '1' ? ' checked' : '') + '> Tak</label><label><input type="radio" name="faktura" value="0"' + (fak === '0' ? ' checked' : '') + '> Nie</label></div><em class="msm-ferr"></em></div>' +
			'<div class="msm-field full" data-field="pozycje"><span>Zawartość przesyłki <i class="msm-req">*</i></span>' +
			'<div class="msm-przrows"><div class="msm-przrow msm-przrow--h" aria-hidden="true"><span>Lp.</span><span>Zlecenie</span><span>Co przyszło</span><span>Ilość</span><span>J.m.</span><span></span></div><div data-przrows></div></div>' +
			'<button type="button" class="msm-btn msm-btn-sm" data-przrowadd>+ Dodaj pozycję</button><em class="msm-ferr"></em></div>' +
			'<label class="msm-field" data-field="sprawdzil"><span>Sprawdził <i class="msm-req">*</i></span><input type="text" name="sprawdzil" list="msm-prz-spr" value="' + esc(v.sprawdzil) + '" autocomplete="off"><em class="msm-field-hint">Domyślnie Ty – możesz wpisać inną osobę.</em><em class="msm-ferr"></em></label>' +
			'<label class="msm-field full" data-field="uwagi"><span>Uwagi do całej przesyłki</span><textarea name="uwagi" rows="2" placeholder="np. uszkodzone opakowanie, przesyłka niekompletna…">' + esc(v.uwagi) + '</textarea></label>' +
			'<label class="msm-check msm-przdmgck full"><input type="checkbox" name="uszkodzona"' + (v.uszkodzona ? ' checked' : '') + '> <span><b>Przesyłka uszkodzona</b> – wyróżnij na liście i na Pulpicie</span></label>' +
			'</div>' + dl('msm-prz-nad', H.nadawcy) + dl('msm-prz-spr', H.sprawdzajacy) + zl + '</form>';
		var m = openModal(row ? 'Przesyłka – poprawka' : 'Nowa przesyłka', body,
			'<button type="button" class="msm-btn" data-close>Anuluj</button><button type="button" class="msm-btn msm-btn-primary" data-przsave>' + (row ? 'Zapisz zmiany' : 'Zapisz przesyłkę') + '</button>', true);
		var f = m.querySelector('form'), err = f.querySelector('.msm-form-err');
		/* Pozycje zawartości: opis + ilość + j.m.; Enter w ostatniej ilości dodaje nowy wiersz. */
		var rowsBox = f.querySelector('[data-przrows]'), lastJ = 'szt.';
		/* Zlecenie pozycji: numer z Produkcji (podpowiedzi) albo dowolny tekst; nowa pozycja bierze zlecenie z poprzedniej. */
		function zFind(t) {
			t = String(t || '').trim().toLowerCase();
			return t ? H.zlecenia.filter(function (z) { return z.nr.toLowerCase() === t; })[0] || null : null;
		}
		function zMark(inp) {
			var z = zFind(inp.value), t = inp.value.trim();
			inp.classList.toggle('is-ok', !!z); inp.classList.toggle('is-free', !z && !!t);
			inp.title = z ? 'Zlecenie z Produkcji' + (z.klient ? ': ' + z.klient : '') + (z.rok ? ' (' + z.rok + ')' : '') : t ? 'Brak takiego zlecenia w Produkcji – zapisze się jako tekst.' : '';
		}
		function lastZl() { var r = rowsBox.lastElementChild; return r ? r.querySelector('[data-pz]').value.trim() : ''; }
		function rowHtml(x) {
			var j = x.jedn || lastJ;
			return '<div class="msm-przrow" data-przrow><span class="msm-przrow__lp"></span>' +
				'<input type="text" data-pz list="msm-prz-zl" value="' + esc(x.zlecenie || '') + '" placeholder="np. B02516" aria-label="Zlecenie" autocomplete="off">' +
				'<input type="text" data-po value="' + esc(x.opis || '') + '" placeholder="np. Blacha M400-50A 0,5 mm" aria-label="Co przyszło" autocomplete="off">' +
				'<input type="text" data-pi inputmode="decimal" value="' + esc(x.ilosc == null ? '' : String(x.ilosc).replace('.', ',')) + '" placeholder="0" aria-label="Ilość">' +
				'<select data-pj aria-label="Jednostka">' + H.jedn.concat(j && H.jedn.indexOf(j) < 0 ? [j] : []).map(function (u) { return '<option' + (u === j ? ' selected' : '') + '>' + esc(u) + '</option>'; }).join('') + '</select>' +
				'<button type="button" class="msm-iconbtn" data-prdel title="Usuń pozycję" aria-label="Usuń pozycję">×</button>' +
				'<input type="text" data-pu class="msm-przrow__uw" value="' + esc(x.uwagi || '') + '" placeholder="Uwagi do pozycji (np. uszkodzenia, braki)" aria-label="Uwagi do pozycji" autocomplete="off"></div>';
		}
		function renum() {
			var rs = rowsBox.querySelectorAll('[data-przrow]');
			rs.forEach(function (r, i) { r.querySelector('.msm-przrow__lp').textContent = (i + 1) + '.'; r.querySelector('[data-prdel]').disabled = rs.length === 1; });
		}
		function addRow(x, focus) {
			rowsBox.insertAdjacentHTML('beforeend', rowHtml(x || {}));
			var r = rowsBox.lastElementChild;
			r.querySelector('[data-prdel]').addEventListener('click', function () { r.remove(); renum(); });
			r.querySelector('[data-pj]').addEventListener('change', function (e) { lastJ = e.target.value; });
			r.querySelector('[data-pi]').addEventListener('keydown', function (e) {
				if (e.key === 'Enter') { e.preventDefault(); if (r === rowsBox.lastElementChild) addNext(); else r.nextElementSibling.querySelector('[data-pz]').focus(); }
			});
			r.querySelector('[data-po]').addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); r.querySelector('[data-pi]').focus(); } });
			r.querySelector('[data-pu]').addEventListener('keydown', function (e) {
				if (e.key === 'Enter') { e.preventDefault(); if (r === rowsBox.lastElementChild) addNext(); else r.nextElementSibling.querySelector('[data-pz]').focus(); }
			});
			var zi = r.querySelector('[data-pz]');
			zi.addEventListener('input', function () { zMark(zi); });
			zi.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); r.querySelector('[data-po]').focus(); } });
			zMark(zi);
			renum();
			if (focus) r.querySelector(x && x.zlecenie ? '[data-po]' : '[data-pz]').focus();
		}
		(v.pozycje && v.pozycje.length ? v.pozycje : [{}]).forEach(function (x) { addRow(x); });
		function addNext() {
			var last = rowsBox.lastElementChild; if (last) lastJ = last.querySelector('[data-pj]').value;
			addRow({ zlecenie: lastZl() }, true);
		}
		f.querySelector('[data-przrowadd]').addEventListener('click', addNext);
		function readRows() {
			var out = [], bad = '';
			rowsBox.querySelectorAll('[data-przrow]').forEach(function (r, i) {
				var o = r.querySelector('[data-po]').value.trim(), il = r.querySelector('[data-pi]').value.replace(/\s/g, '').replace(',', '.'), uw = r.querySelector('[data-pu]').value.trim();
				r.classList.remove('has-err');
				if (!o && !il && !uw) return;
				if (!o) { bad = bad || 'Pozycja ' + (i + 1) + ': opisz, co przyszło.'; r.classList.add('has-err'); return; }
				if (il && isNaN(+il)) { bad = bad || 'Pozycja ' + (i + 1) + ': ilość musi być liczbą.'; r.classList.add('has-err'); return; }
				var zt = r.querySelector('[data-pz]').value.trim(), z = zFind(zt);
				out.push({ opis: o, ilosc: il === '' ? '' : +il, jedn: r.querySelector('[data-pj]').value, zlec_id: z ? z.id : 0, zlecenie: z ? z.nr : zt, uwagi: uw });
			});
			return { list: out, bad: bad };
		}
		f.uszkodzona.addEventListener('change', function () { if (f.uszkodzona.checked && !f.uwagi.value.trim()) f.uwagi.focus(); });
		function fieldErr(name, msg) {
			var el = f.querySelector('[data-field="' + name + '"]'); if (!el) return;
			el.classList.add('has-err'); var e = el.querySelector('.msm-ferr'); if (e) e.textContent = msg;
		}
		function save() {
			f.querySelectorAll('.has-err').forEach(function (x) { x.classList.remove('has-err'); var e = x.querySelector('.msm-ferr'); if (e) e.textContent = ''; });
			err.hidden = true;
			var fk = f.querySelector('[name=faktura]:checked');
			var bad = 0;
			if (!f.data_spr.value) { fieldErr('data_spr', 'Podaj datę i godzinę.'); bad++; }
			if (!f.nadawca.value.trim()) { fieldErr('nadawca', 'Podaj nadawcę.'); bad++; }
			if (!fk) { fieldErr('faktura', 'Zaznacz: jest faktura czy nie.'); bad++; }
			var R = readRows();
			if (R.bad) { fieldErr('pozycje', R.bad); bad++; } else if (!R.list.length) { fieldErr('pozycje', 'Dodaj co najmniej jedną pozycję.'); bad++; }
			if (!f.sprawdzil.value.trim()) { fieldErr('sprawdzil', 'Podaj, kto sprawdził.'); bad++; }
			if (bad) { var first = f.querySelector('.has-err input, .has-err textarea'); if (first) first.focus(); else { var pr = f.querySelector('.msm-przrow.has-err [data-po]') || f.querySelector('[data-po]'); if (pr && f.querySelector('[data-field=pozycje].has-err')) pr.focus(); } return; }
			var body = { data_spr: f.data_spr.value, nadawca: f.nadawca.value.trim(), faktura: fk.value === '1',
				pozycje: R.list, uwagi: f.uwagi.value.trim(), uszkodzona: f.uszkodzona.checked, sprawdzil: f.sprawdzil.value.trim() };
			var b = m.querySelector('[data-przsave]'); b.disabled = true;
			api(row ? '/przesylki/' + row.id : '/przesylki', { method: 'POST', body: body }).then(function (r) {
				closeModal(); toast(row ? 'Zapisano zmiany.' : 'Zapisano przesyłkę od ' + r.przesylka.nadawca + '.');
				if (onSaved) onSaved(r.przesylka);
			}).catch(function (e) {
				b.disabled = false;
				if (e.data && e.data.field) fieldErr(e.data.field, e.message);
				err.textContent = e.message; err.hidden = false;
			});
		}
		m.querySelector('[data-przsave]').addEventListener('click', save);
		f.addEventListener('submit', function (e) { e.preventDefault(); save(); });
		return m;
	}

	/* Menu ⋯ przesyłki (poprawka / usunięcie – z uprawnieniem). */
	function przMenu(btn, p, reload) {
		popMenu(btn, 'Przesyłka od ' + p.nadawca, [
			{ label: 'Popraw…', run: function () { przForm(p, null, reload); } }, '-',
			{ label: 'Usuń', danger: true, run: function () {
				var dt = przDT(p.data_spr);
				confirmBox('Usunąć przesyłkę?', 'Przesyłka od <b>' + esc(p.nadawca) + '</b> z ' + esc(dt.d + ' ' + dt.t) + ' zniknie z rejestru (zostanie wpis w Historii zmian).', 'Usuń', true).then(function (ok) {
					if (!ok) return;
					api('/przesylki/' + p.id + '/delete', { method: 'POST', body: {} }).then(function () { toast('Usunięto przesyłkę.'); reload(); }).catch(function (e) { toast(e.message, 'err'); });
				});
			} }
		]);
	}

	function renderPrzesylki() {
		var main = document.getElementById('msm-main');
		main.innerHTML = '<div class="msm-cat msm-prz"><div class="msm-pagehead"><div><h1>Przesyłki</h1><p class="msm-muted" data-przcount>&nbsp;</p></div>' +
			'<div class="msm-pagehead__tools"><button type="button" class="msm-btn msm-btn-primary" data-przadd>+ Nowa przesyłka</button>' +
			'<button type="button" class="msm-btn" data-przprint>Drukuj rejestr</button>' + xbtn('xlsx', 'data-przexp="xlsx"') + '</div></div>' +
			'<div class="msm-filters" aria-label="Filtry"><div class="msm-filters__body msm-przflt">' +
			'<label class="msm-f msm-pgf__q"><span>Szukaj</span><input type="search" data-pq placeholder="nadawca, zlecenie, zawartość, uwagi, sprawdził…" autocomplete="off"></label>' +
			'<label class="msm-f"><span>Od</span><input type="date" data-pod></label><label class="msm-f"><span>Do</span><input type="date" data-pdo></label>' +
			'<label class="msm-f"><span>Nadawca</span><select data-pnad><option value="">Wszyscy</option></select></label>' +
			'<label class="msm-f"><span>Faktura</span><select data-pfak><option value="">Wszystkie</option><option value="1">Tak</option><option value="0">Nie</option></select></label>' +
			'<label class="msm-check msm-f msm-przflt__ck"><input type="checkbox" data-pdmg> Uszkodzone / z uwagami</label>' +
			'<div class="msm-f msm-zam-fclear"><button type="button" class="msm-link" data-pclr>Wyczyść filtry</button></div></div></div>' +
			'<div data-przl><div class="msm-loading">Ładowanie…</div></div></div>';
		var box = main.querySelector('[data-przl]'), $ = function (s) { return main.querySelector(s); };
		var q = $('[data-pq]'), od = $('[data-pod]'), dO = $('[data-pdo]'), nad = $('[data-pnad]'), fak = $('[data-pfak]'), dmg = $('[data-pdmg]');
		var ALL = [], VIS = [], F = (function () { try { return JSON.parse(sessionStorage.getItem('msm_prz_flt')) || {}; } catch (e) { return {}; } })();
		q.value = F.q || ''; od.value = F.od || ''; dO.value = F.do || ''; fak.value = F.fak || ''; dmg.checked = !!F.dmg;
		function save() { F = { q: q.value, od: od.value, do: dO.value, nad: nad.value, fak: fak.value, dmg: dmg.checked }; try { sessionStorage.setItem('msm_prz_flt', JSON.stringify(F)); } catch (e) {} }
		function match(p) {
			var d = p.data_spr.slice(0, 10);
			if (od.value && d < od.value) return false;
			if (dO.value && d > dO.value) return false;
			if (nad.value && p.nadawca !== nad.value) return false;
			if (fak.value && String(+p.faktura) !== fak.value) return false;
			if (dmg.checked && !p.uszkodzona && !p.uwagi) return false;
			var s = srchNorm(q.value.trim()); if (!s) return true;
			var dt = przDT(p.data_spr), hay = srchNorm([dt.d, dt.t, p.nadawca, p.zlecenie, p.faktura ? 'faktura tak' : 'faktura nie'].concat(przPoz(p).map(function (x) { return x.zlecenie + ' ' + x.opis + ' ' + przIl(x) + ' ' + (x.uwagi || ''); })).concat([p.uwagi, p.uszkodzona ? 'uszkodzona' : '', p.sprawdzil]).join(' | '));
			return s.split(/\s+/).every(function (w) { return hay.indexOf(w) >= 0; });
		}
		function draw() {
			VIS = ALL.filter(match);
			var nd = VIS.filter(function (p) { return p.uszkodzona; }).length, nf = VIS.filter(function (p) { return !p.faktura; }).length;
			$('[data-przcount]').textContent = (VIS.length === ALL.length ? plN(ALL.length, 'przesyłka', 'przesyłki', 'przesyłek') : 'Pokazano ' + VIS.length + ' z ' + ALL.length) +
				(nd ? ' · ' + plN(nd, 'uszkodzona', 'uszkodzone', 'uszkodzonych') : '') + (nf ? ' · bez faktury: ' + nf : '');
			if (!ALL.length) { box.innerHTML = '<div class="msm-card msm-empty"><h3>Brak przesyłek</h3><p class="msm-muted">Dodaj pierwszą przesyłkę przyciskiem „+ Nowa przesyłka”.</p></div>'; return; }
			if (!VIS.length) { box.innerHTML = '<div class="msm-card msm-empty"><p><b>Brak przesyłek dla wybranych filtrów.</b></p></div>'; return; }
			box.innerHTML = przTable(VIS, PRZ.admin);
			box.querySelectorAll('[data-przm]').forEach(function (b) {
				b.addEventListener('click', function () { var id = +b.getAttribute('data-przm'); przMenu(b, ALL.filter(function (p) { return p.id === id; })[0], load); });
			});
		}
		function load() {
			return api('/przesylki', { query: { _: Date.now() } }).then(function (r) {
				PRZ = r; ALL = r.przesylki;
				var cur = F.nad || nad.value;
				nad.innerHTML = '<option value="">Wszyscy</option>' + r.nadawcy.slice().sort(function (a, b) { return a.localeCompare(b, 'pl'); }).map(function (n) { return '<option>' + esc(n) + '</option>'; }).join('');
				nad.value = cur; if (nad.value !== cur) nad.value = '';
				draw();
			}).catch(function (e) { box.innerHTML = '<p class="msm-alert msm-alert-err">' + esc(e.message) + '</p>'; });
		}
		var t = null;
		q.addEventListener('input', function () { clearTimeout(t); t = setTimeout(function () { save(); draw(); }, 150); });
		[od, dO, nad, fak, dmg].forEach(function (el) { el.addEventListener('change', function () { save(); draw(); }); });
		$('[data-pclr]').addEventListener('click', function () { q.value = od.value = dO.value = nad.value = fak.value = ''; dmg.checked = false; save(); draw(); });
		$('[data-przadd]').addEventListener('click', function () { przForm(null, null, load); });
		$('[data-przexp]').addEventListener('click', function () { window.location.href = buildUrl('/przesylki/export', { format: 'xlsx', od: od.value, do: dO.value, _wpnonce: C.nonce }); });
		$('[data-przprint]').addEventListener('click', function () {
			if (!VIS.length) { toast('Brak przesyłek do wydruku dla wybranych filtrów.', 'err'); return; }
			var filtered = VIS.length !== ALL.filter(function (p) { var d = p.data_spr.slice(0, 10); return (!od.value || d >= od.value) && (!dO.value || d <= dO.value); }).length;
			var a = { msm_print: 'przesylki', od: od.value, do: dO.value };
			if (filtered) a.ids = VIS.map(function (p) { return p.id; }).join(',');
			window.open(printUrl(a), '_blank');
		});
		load();
	}

	/* Zakładka „Przesyłki” w zleceniu Produkcji. */
	function renderPrzesylkiZlec(tb, o) {
		tb.innerHTML = '<div class="msm-ptool"><span class="msm-muted" data-pzc>Ładowanie…</span><span class="msm-ptool__btns"><button type="button" class="msm-btn msm-btn-primary" data-pzadd>+ Nowa przesyłka do zlecenia</button></span></div><div data-pzl></div>';
		var list = tb.querySelector('[data-pzl]');
		function load() {
			api('/przesylki', { query: { zlec: o.id, _: Date.now() } }).then(function (r) {
				PRZ = r;
				var L = r.przesylki;
				tb.querySelector('[data-pzc]').textContent = L.length ? plN(L.length, 'przesyłka', 'przesyłki', 'przesyłek') + ' do zlecenia ' + (o.nr_zlec || '') : 'Brak przesyłek do tego zlecenia.';
				list.innerHTML = L.length ? przTable(L, r.admin, o.id) : '';
				list.querySelectorAll('[data-przm]').forEach(function (b) {
					b.addEventListener('click', function () { var id = +b.getAttribute('data-przm'); przMenu(b, L.filter(function (p) { return p.id === id; })[0], load); });
				});
			}).catch(function (e) { list.innerHTML = '<p class="msm-alert msm-alert-err">' + esc(e.message) + '</p>'; });
		}
		tb.querySelector('[data-pzadd]').addEventListener('click', function () { przForm(null, { zlec_id: o.id, zlecenie: o.nr_zlec || '' }, load); });
		load();
	}
	/* ================================================================
	   NARZĘDZIOWNIA → Przyrządy pomiarowe / Elektronarzędzia (zakładki przygotowane, zawartość wkrótce)
	   ================================================================ */
	function renderNarzWkrotce(t) {
		var main = document.getElementById('msm-main');
		var D = {
			'narz-pomiarowe': ['Przyrządy pomiarowe', 'Ewidencja przyrządów do mierzenia'],
			'narz-elektro': ['Elektronarzędzia', 'Lista ewidencyjna elektronarzędzi']
		}[t];
		main.innerHTML = '<div class="msm-cat"><div class="msm-pagehead"><div><h1>' + esc(D[0]) + '</h1><p class="msm-muted">' + esc(D[1]) + '</p></div></div>' +
			'<div class="msm-card msm-empty msm-soon"><svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M14.7 6.3a4 4 0 0 0-5.4 5.4L3 18l3 3 6.3-6.3a4 4 0 0 0 5.4-5.4l-2.5 2.5-2.4-.6-.6-2.4z"/></svg>' +
			'<h3>Zakładka w przygotowaniu</h3><p class="msm-muted">Zawartość i funkcje tej zakładki zostaną dodane wkrótce.</p></div></div>';
	}
	/* ================================================================
	   NARZĘDZIOWNIA → ELEKTRONARZĘDZIA: lista ewidencyjna, szczegóły, sprawdzenia
	   ================================================================ */
	var EL_FLT_KEY = 'msm_el_flt';

	/* Dni do terminu (ujemne = po terminie); null – brak terminu. */
	function elDays(d, today) {
		if (!d) return null;
		var a = Date.parse(d + 'T00:00:00Z'), b = Date.parse(today + 'T00:00:00Z');
		return Math.round((a - b) / 864e5);
	}
	function elState(e, today) {
		var n = elDays(e.data_nast, today);
		if (n === null) return { cls: 'none', txt: 'bez terminu' };
		if (n < 0) return { cls: 'late', txt: 'po terminie ' + plN(-n, 'dzień', 'dni', 'dni') };
		if (n === 0) return { cls: 'soon', txt: 'dziś' };
		if (n <= PROG.elektro) return { cls: 'soon', txt: 'za ' + plN(n, 'dzień', 'dni', 'dni') };
		return { cls: 'ok', txt: '' };
	}
	function elOcena(o) {
		return o ? '<span class="msm-eltag ' + (o === 'sprawne' ? 'is-ok' : 'is-bad') + '">' + (o === 'sprawne' ? 'Sprawne' : 'Niesprawne') + '</span>' : '';
	}

	/* Lokalizacja (Ligota Wołczyńska / Wrocław…) – lista z Ustawień; wspólne dla elektronarzędzi i przyrządów. */
	function lokField(list, cur, dis) {
		var L = (list || []).slice(); if (cur && L.indexOf(cur) < 0) L.push(cur);
		return '<label class="msm-field" data-field="lokalizacja"><span>Lokalizacja <i class="msm-req">*</i></span><select name="lokalizacja"' + (dis || '') + '>' +
			(cur ? '' : '<option value="">— wybierz —</option>') + L.map(function (v) { return '<option' + (v === cur ? ' selected' : '') + '>' + esc(v) + '</option>'; }).join('') + '</select><em class="msm-ferr"></em></label>';
	}
	function lokTag(v) { return v ? '<span class="msm-eltag msm-loktag">' + esc(v) + '</span>' : '<span class="msm-muted">—</span>'; }
	function lokOptions(sel, rows, list, cur) {
		var c = {}; rows.forEach(function (e) { if (e.lokalizacja) c[e.lokalizacja] = (c[e.lokalizacja] || 0) + 1; });
		(list || []).concat(Object.keys(c)).filter(function (v, i, a) { return a.indexOf(v) === i; }).forEach(function (k) { sel.insertAdjacentHTML('beforeend', '<option value="' + esc(k) + '">' + esc(k) + ' (' + (c[k] || 0) + ')</option>'); });
		sel.value = cur || '';
		if (sel.value !== (cur || '')) sel.value = '';
	}

	function renderElektro() {
		var main = document.getElementById('msm-main');
		main.innerHTML = '<div class="msm-cat msm-el"><div class="msm-pagehead"><div><h1>Elektronarzędzia</h1><p class="msm-muted" data-elcount>&nbsp;</p></div>' +
			'<div class="msm-pagehead__tools" data-eltools></div></div>' +
			'<div class="msm-filters" aria-label="Filtry"><div class="msm-filters__body msm-elflt">' +
			'<label class="msm-f msm-pgf__q"><span>Szukaj</span><input type="search" data-eq placeholder="symbol, nazwa, model, nr seryjny, producent…" autocomplete="off"></label>' +
			'<label class="msm-f"><span>Lokalizacja</span><select data-elok><option value="">Wszystkie</option></select></label>' +
			'<label class="msm-f"><span>Typ</span><select data-etyp><option value="">Wszystkie</option></select></label>' +
			'<label class="msm-f"><span>Sprawdzenie</span><select data-eterm><option value="">Wszystkie</option><option value="late">Po terminie</option><option value="soon">W ciągu ' + PROG.elektro + ' dni</option><option value="none">Bez terminu</option></select></label>' +
			'<div class="msm-f msm-zam-fclear"><button type="button" class="msm-link" data-eclr>Wyczyść filtry</button></div></div></div>' +
			'<div data-ell><div class="msm-loading">Ładowanie…</div></div></div>';
		var $ = function (s) { return main.querySelector(s); };
		var box = $('[data-ell]'), q = $('[data-eq]'), typ = $('[data-etyp]'), term = $('[data-eterm]'), lok = $('[data-elok]');
		var D = null, SORT = 'symbol', F = (function () { try { return JSON.parse(sessionStorage.getItem(EL_FLT_KEY)) || {}; } catch (e) { return {}; } })();
		q.value = F.q || ''; term.value = F.term || '';
		function save() { F = { q: q.value, typ: typ.value, term: term.value, lok: lok.value }; try { sessionStorage.setItem(EL_FLT_KEY, JSON.stringify(F)); } catch (e) {} }
		function match(e) {
			if (lok.value && e.lokalizacja !== lok.value) return false;
			if (typ.value && e.typ !== typ.value) return false;
			if (term.value && elState(e, D.dzis).cls !== term.value) return false;
			var s = srchNorm(q.value.trim()); if (!s) return true;
			var hay = srchNorm([e.symbol, e.nazwa, e.model, e.nr_seryjny, e.producent, e.zasilanie, e.uwagi, e.lokalizacja, D.typy[e.typ] || e.typ, fmtDate(e.data_nast), fmtDate(e.data_spr)].join(' | '));
			return s.split(/\s+/).every(function (w) { return hay.indexOf(w) >= 0; });
		}
		function draw() {
			var L = D.pozycje.filter(match), dup = {};
			D.pozycje.forEach(function (e) { var k = e.symbol.toUpperCase(); dup[k] = (dup[k] || 0) + 1; });
			if (SORT === 'data') L = L.slice().sort(function (a, b) { return (a.data_nast || '9999') < (b.data_nast || '9999') ? -1 : (a.data_nast || '9999') > (b.data_nast || '9999') ? 1 : a.symbol.localeCompare(b.symbol); });
			var late = D.pozycje.filter(function (e) { return elState(e, D.dzis).cls === 'late'; }).length;
			$('[data-elcount]').innerHTML = esc(L.length === D.pozycje.length ? plN(D.pozycje.length, 'pozycja', 'pozycje', 'pozycji') : 'Pokazano ' + L.length + ' z ' + D.pozycje.length) +
				(late ? ' · <b class="msm-el-latecnt">' + plN(late, 'po terminie sprawdzenia', 'po terminie sprawdzenia', 'po terminie sprawdzenia') + '</b>' : '');
			if (!D.pozycje.length) { box.innerHTML = '<div class="msm-card msm-empty"><h3>Brak elektronarzędzi</h3><p class="msm-muted">Dodaj pierwsze narzędzie przyciskiem „+ Dodaj narzędzie”.</p></div>'; return; }
			if (!L.length) { box.innerHTML = '<div class="msm-card msm-empty"><p><b>Brak pozycji dla wybranych filtrów.</b></p></div>'; return; }
			var arr = function (k) { return SORT === k ? ' <span aria-hidden="true">↓</span>' : ''; };
			box.innerHTML = '<div class="msm-table-wrap"><table class="msm-table msm-elt"><thead><tr>' +
				'<th><button type="button" class="msm-elsort" data-esort="symbol">Symbol' + arr('symbol') + '</button></th><th>Nazwa</th><th>Model</th><th>Lokalizacja</th>' +
				'<th><button type="button" class="msm-elsort" data-esort="data">Data nast. sprawdzenia' + arr('data') + '</button></th></tr></thead><tbody>' +
				L.map(function (e) {
					var st = elState(e, D.dzis);
					return '<tr class="is-' + st.cls + '">' +
						'<td data-label="Symbol"><span class="msm-el-v"><a class="msm-el-sym" href="#narz-elektro-' + e.id + '">' + esc(e.symbol) + '</a>' + (dup[e.symbol.toUpperCase()] > 1 ? ' <span class="msm-eltag is-warn" title="Ten sam symbol ma więcej niż jedno narzędzie – popraw symbol w szczegółach">duplikat</span>' : '') + '</span></td>' +
						'<td data-label="Nazwa"><span class="msm-el-v">' + esc(e.nazwa) + (e.uwagi ? '<small class="msm-el-uw">' + esc(e.uwagi) + '</small>' : '') + '</span></td>' +
						'<td data-label="Model">' + (e.model ? esc(e.model) : '<span class="msm-muted">—</span>') + '</td>' +
						'<td data-label="Lokalizacja">' + lokTag(e.lokalizacja) + '</td>' +
						'<td data-label="Nast. sprawdzenie" class="msm-el-date"><span class="msm-el-v"><b>' + (e.data_nast ? esc(fmtDate(e.data_nast)) : '<span class="msm-muted">—</span>') + '</b>' + (st.txt ? '<small>' + esc(st.txt) + '</small>' : '') + '</span></td></tr>';
				}).join('') + '</tbody></table></div>';
			box.querySelectorAll('[data-esort]').forEach(function (b) { b.addEventListener('click', function () { SORT = b.getAttribute('data-esort'); draw(); }); });
		}
		var t = null;
		q.addEventListener('input', function () { clearTimeout(t); t = setTimeout(function () { save(); draw(); }, 150); });
		[typ, term, lok].forEach(function (el) { el.addEventListener('change', function () { save(); draw(); }); });
		$('[data-eclr]').addEventListener('click', function () { q.value = typ.value = term.value = lok.value = ''; save(); draw(); });
		api('/elektro', { query: { _: Date.now() } }).then(function (r) {
			D = r;
			Object.keys(r.typy).forEach(function (k) {
				var n = r.pozycje.filter(function (e) { return e.typ === k; }).length;
				typ.insertAdjacentHTML('beforeend', '<option value="' + esc(k) + '">' + esc(k + ' – ' + r.typy[k]) + ' (' + n + ')</option>');
			});
			typ.value = F.typ || '';
			lokOptions(lok, r.pozycje, r.lokalizacje, F.lok);
			$('[data-eltools]').innerHTML = (r.edycja ? '<button type="button" class="msm-btn msm-btn-primary" data-eadd>+ Dodaj narzędzie</button>' : '') + xbtn('xlsx', 'data-eexp');
			var add = $('[data-eadd]'); if (add) add.addEventListener('click', function () { elNew(r); });
			$('[data-eexp]').addEventListener('click', function () { window.location.href = buildUrl('/elektro/export', { _wpnonce: C.nonce }); });
			draw();
		}).catch(function (e) { box.innerHTML = '<p class="msm-alert msm-alert-err">' + esc(e.message) + '</p>'; });
	}

	/* Nowe narzędzie: typ → kolejny wolny symbol (można zmienić). */
	function elNew(D) {
		var typy = Object.keys(D.typy);
		var body = '<form class="msm-form" novalidate><div class="msm-form-err msm-alert msm-alert-err" hidden></div><div class="msm-grid">' +
			'<label class="msm-field" data-field="typ"><span>Typ</span><select name="typ">' + typy.map(function (k) { return '<option value="' + esc(k) + '">' + esc(k + ' – ' + D.typy[k]) + '</option>'; }).join('') + '</select></label>' +
			'<label class="msm-field" data-field="symbol"><span>Symbol <i class="msm-req">*</i></span><input name="symbol" type="text" value="' + esc(D.nastepne[typy[0]]) + '" autocomplete="off"><em class="msm-field-hint">Kolejny wolny numer – możesz zmienić.</em><em class="msm-ferr"></em></label>' +
			'<label class="msm-field full" data-field="nazwa"><span>Nazwa <i class="msm-req">*</i></span><input name="nazwa" type="text" autocomplete="off" placeholder="np. SZLIFIERKA KĄTOWA"><em class="msm-ferr"></em></label>' +
			lokField(D.lokalizacje, D.lokalizacje.length === 1 ? D.lokalizacje[0] : '') +
			'<label class="msm-field" data-field="model"><span>Model</span><input name="model" type="text" autocomplete="off"></label>' +
			'<label class="msm-field" data-field="nr_seryjny"><span>Nr seryjny</span><input name="nr_seryjny" type="text" autocomplete="off"></label>' +
			'<label class="msm-field" data-field="producent"><span>Producent</span><input name="producent" type="text" list="msm-el-prod" autocomplete="off"></label>' +
			'<label class="msm-field" data-field="zasilanie"><span>AC/DC</span><select name="zasilanie"><option value="">—</option><option>AC</option><option>DC</option></select></label>' +
			'<label class="msm-field" data-field="data_spr"><span>Data ost. sprawdzenia</span><input name="data_spr" type="date"><em class="msm-field-hint">Następne sprawdzenie policzy się samo (+' + D.okres + ' dni).</em><em class="msm-ferr"></em></label>' +
			'</div><datalist id="msm-el-prod">' + D.pozycje.map(function (e) { return e.producent; }).filter(function (v, i, a) { return v && a.indexOf(v) === i; }).sort().map(function (v) { return '<option value="' + esc(v) + '">'; }).join('') + '</datalist></form>';
		var m = openModal('Nowe elektronarzędzie', body, '<button type="button" class="msm-btn" data-close>Anuluj</button><button type="button" class="msm-btn msm-btn-primary" data-ok>Dodaj</button>', true);
		var f = m.querySelector('form'), ok = m.querySelector('[data-ok]');
		var auto = f.symbol.value;
		f.typ.addEventListener('change', function () { if (f.symbol.value === auto) { auto = D.nastepne[f.typ.value]; f.symbol.value = auto; } });
		function go() {
			var b = {}; ['typ', 'symbol', 'nazwa', 'lokalizacja', 'model', 'nr_seryjny', 'producent', 'zasilanie', 'data_spr'].forEach(function (k) { b[k] = f[k].value; });
			elSubmit(f, ok, api('/elektro', { method: 'POST', body: b }), function (r) { closeModal(); toast('Dodano ' + b.symbol + '.'); location.hash = '#narz-elektro-' + r.id; });
		}
		ok.addEventListener('click', go);
		f.addEventListener('submit', function (e) { e.preventDefault(); go(); });
		setTimeout(function () { f.nazwa.focus(); }, 50);
	}

	/* Wspólna obsługa błędów formularza (pola z e.data.fields). */
	function elSubmit(f, btn, p, done) {
		var err = f.querySelector('.msm-form-err');
		f.querySelectorAll('.has-err').forEach(function (x) { x.classList.remove('has-err'); var e = x.querySelector('.msm-ferr'); if (e) e.textContent = ''; });
		if (err) err.hidden = true;
		btn.disabled = true;
		return p.then(function (r) { btn.disabled = false; done(r); }).catch(function (e) {
			btn.disabled = false;
			var fl = (e.data && e.data.fields) || {};
			Object.keys(fl).forEach(function (k) { var el = f.querySelector('[data-field="' + k + '"]'); if (el) { el.classList.add('has-err'); var x = el.querySelector('.msm-ferr'); if (x) x.textContent = fl[k]; } });
			if (err) { err.textContent = e.message; err.hidden = false; } else toast(e.message, 'err');
		});
	}

	/* Szczegóły narzędzia: wszystkie pola z Excela + historia sprawdzeń. */
	function renderElektroItem(id) {
		var main = document.getElementById('msm-main');
		main.innerHTML = '<div class="msm-cat msm-el"><a class="msm-back" href="#narz-elektro">← Elektronarzędzia</a><div data-eli><div class="msm-loading">Ładowanie…</div></div></div>';
		var box = main.querySelector('[data-eli]');
		function load() {
			return api('/elektro/' + id, { query: { _: Date.now() } }).then(draw).catch(function (e) { box.innerHTML = '<p class="msm-alert msm-alert-err">' + esc(e.message) + '</p>'; });
		}
		function draw(D) {
			var e = D.pozycja, ed = D.edycja, st = elState(e, D.dzis), dis = ed ? '' : ' disabled';
			var inp = function (k, label, extra, full) {
				return '<label class="msm-field' + (full ? ' full' : '') + '" data-field="' + k + '"><span>' + label + '</span><input name="' + k + '" type="' + (extra && extra.type || 'text') + '" value="' + esc(e[k] || '') + '"' + (extra && extra.list ? ' list="' + extra.list + '"' : '') + ' autocomplete="off"' + dis + '><em class="msm-ferr"></em></label>';
			};
			box.innerHTML =
				'<div class="msm-pagehead msm-el-head"><div><h1>' + esc(e.symbol) + ' <span class="msm-el-head__n">' + esc(e.nazwa) + '</span></h1>' +
				'<p class="msm-el-head__meta"><span class="msm-eltag">' + esc(D.typy[e.typ] || e.typ || '—') + '</span>' + (e.lokalizacja ? lokTag(e.lokalizacja) : '') + elOcena(e.ocena) +
				(D.dubel ? '<span class="msm-eltag is-warn">Symbol ma też inne narzędzie – zmień go na unikalny</span>' : '') + '</p></div>' +
				'<div class="msm-el-status is-' + st.cls + '"><small>Następne sprawdzenie</small><b>' + (e.data_nast ? esc(fmtDate(e.data_nast)) : '—') + '</b>' + (st.txt ? '<span>' + esc(st.txt) + '</span>' : '') + '</div></div>' +
				'<form class="msm-card msm-form msm-el-form" novalidate><div class="msm-form-err msm-alert msm-alert-err" hidden></div><div class="msm-grid msm-el-grid">' +
				inp('symbol', 'Symbol <i class="msm-req">*</i>') +
				'<label class="msm-field" data-field="typ"><span>Typ</span><select name="typ"' + dis + '>' + Object.keys(D.typy).concat(D.typy[e.typ] || !e.typ ? [] : [e.typ]).map(function (k) { return '<option value="' + esc(k) + '"' + (k === e.typ ? ' selected' : '') + '>' + esc(k + (D.typy[k] ? ' – ' + D.typy[k] : '')) + '</option>'; }).join('') + '</select></label>' +
				inp('nazwa', 'Nazwa <i class="msm-req">*</i>', null, true) +
				lokField(D.lokalizacje, e.lokalizacja, dis) +
				inp('model', 'Model') + inp('nr_seryjny', 'Nr seryjny') +
				inp('producent', 'Producent', { list: 'msm-el-prod' }) +
				'<label class="msm-field" data-field="zasilanie"><span>AC/DC</span><select name="zasilanie"' + dis + '><option value="">—</option>' + ['AC', 'DC'].map(function (v) { return '<option' + (v === e.zasilanie ? ' selected' : '') + '>' + v + '</option>'; }).join('') + '</select></label>' +
				inp('data_spr', 'Data ost. sprawdzenia', { type: 'date' }) +
				'<div class="msm-field" data-field="data_nast"><span>Data nast. sprawdzenia</span><input name="data_nast" type="date" value="' + esc(e.data_nast || '') + '"' + (ed && e.nast_recznie ? '' : ' disabled') + '>' +
				'<label class="msm-check msm-el-man"><input type="checkbox" name="nast_recznie"' + (e.nast_recznie ? ' checked' : '') + dis + '> ustaw ręcznie <span class="msm-muted">(inaczej: ost. sprawdzenie + ' + D.okres + ' dni)</span></label><em class="msm-ferr"></em></div>' +
				inp('data_prod', 'Data produkcji / rejestracji', { type: 'date' }) + inp('gwarancja', 'Termin gwarancji', { type: 'date' }) +
				'<label class="msm-field full" data-field="uwagi"><span>Uwagi</span><textarea name="uwagi" rows="2"' + dis + '>' + esc(e.uwagi || '') + '</textarea></label>' +
				'</div>' + (ed ? '<div class="msm-el-actions"><button type="button" class="msm-btn msm-btn-danger-ghost" data-edel>Usuń narzędzie</button><span class="msm-muted" data-edirty></span><button type="submit" class="msm-btn msm-btn-primary" data-esave disabled>Zapisz zmiany</button></div>' : '') +
				'<datalist id="msm-el-prod">' + D.producenci.map(function (v) { return '<option value="' + esc(v) + '">'; }).join('') + '</datalist></form>' +
				'<section class="msm-card msm-el-checks"><header><h2>Sprawdzenia <span class="msm-muted">(' + D.sprawdzenia.length + ')</span></h2>' + (ed ? '<button type="button" class="msm-btn msm-btn-primary" data-echeck>Zapisz sprawdzenie</button>' : '') + '</header>' +
				(D.sprawdzenia.length ? '<div class="msm-table-wrap"><table class="msm-table"><thead><tr><th>Data</th><th>Ocena</th><th>Sprawdził</th><th>Uwagi</th>' + (ed ? '<th></th>' : '') + '</tr></thead><tbody>' +
					D.sprawdzenia.map(function (s) {
						return '<tr><td data-label="Data"><b>' + esc(fmtDate(s.data)) + '</b></td><td data-label="Ocena">' + elOcena(s.ocena) + '</td><td data-label="Sprawdził">' + esc(s.sprawdzil) + '</td><td data-label="Uwagi">' + (s.uwagi ? esc(s.uwagi) : '<span class="msm-muted">—</span>') + '</td>' +
							(ed ? '<td class="msm-pgl-act"><button type="button" class="msm-iconbtn" data-echdel="' + s.id + '" title="Usuń wpis" aria-label="Usuń wpis">×</button></td>' : '') + '</tr>';
					}).join('') + '</tbody></table></div>'
					: '<p class="msm-muted msm-el-nochk">Brak zapisanych sprawdzeń' + (e.data_spr ? ' – ostatnie z Excela: ' + esc(fmtDate(e.data_spr)) : '') + '.</p>') + '</section>';
			if (!ed) return;
			var f = box.querySelector('.msm-el-form'), saveB = f.querySelector('[data-esave]'), nast = f.data_nast, man = f.nast_recznie;
			var start = JSON.stringify(read());
			function auto() { if (!man.checked) { var t = Date.parse(f.data_spr.value + 'T00:00:00Z'); nast.value = isNaN(t) ? '' : new Date(t + D.okres * 864e5).toISOString().slice(0, 10); } }
			function read() { var o = {}; ['symbol', 'typ', 'nazwa', 'lokalizacja', 'model', 'nr_seryjny', 'producent', 'zasilanie', 'data_spr', 'data_nast', 'data_prod', 'gwarancja', 'uwagi'].forEach(function (k) { o[k] = f[k].value; }); o.nast_recznie = man.checked ? 1 : 0; return o; }
			function dirty() { var d = JSON.stringify(read()) !== start; saveB.disabled = !d; f.querySelector('[data-edirty]').textContent = d ? 'Niezapisane zmiany' : ''; }
			man.addEventListener('change', function () { nast.disabled = !man.checked; auto(); dirty(); });
			f.data_spr.addEventListener('change', function () { auto(); });
			f.addEventListener('input', dirty); f.addEventListener('change', dirty);
			f.addEventListener('submit', function (ev) {
				ev.preventDefault();
				elSubmit(f, saveB, api('/elektro/' + id, { method: 'POST', body: read() }), function (r) { toast('Zapisano.'); if (r.pozycja.id !== id) return; draw(r); });
			});
			f.querySelector('[data-edel]').addEventListener('click', function () {
				confirmBox('Usunąć narzędzie?', '<b>' + esc(e.symbol + ' ' + e.nazwa) + '</b> zniknie z listy razem z historią sprawdzeń (zostanie wpis w Historii zmian).', 'Usuń', true).then(function (ok) {
					if (!ok) return;
					api('/elektro/' + id + '/delete', { method: 'POST', body: {} }).then(function () { toast('Usunięto ' + e.symbol + '.'); location.hash = '#narz-elektro'; }).catch(function (er) { toast(er.message, 'err'); });
				});
			});
			box.querySelector('[data-echeck]').addEventListener('click', function () { elCheck(D, draw); });
			box.querySelectorAll('[data-echdel]').forEach(function (b) {
				b.addEventListener('click', function () {
					confirmBox('Usunąć wpis sprawdzenia?', 'Daty sprawdzeń narzędzia się nie zmienią – w razie potrzeby popraw je w polach powyżej.', 'Usuń', true).then(function (ok) {
						if (!ok) return;
						api('/elektro/spr/' + b.getAttribute('data-echdel') + '/delete', { method: 'POST', body: {} }).then(function (r) { toast('Usunięto wpis.'); draw(r); }).catch(function (er) { toast(er.message, 'err'); });
					});
				});
			});
		}
		load();
	}

	/* Zapis sprawdzenia: data, ocena, kto, uwagi → nowe daty (ost. = data, nast. = data + 91 dni). */
	function elCheck(D, done) {
		var e = D.pozycja;
		var body = '<form class="msm-form" novalidate><div class="msm-form-err msm-alert msm-alert-err" hidden></div><p class="msm-muted">' + esc(e.symbol + ' · ' + e.nazwa + (e.model ? ' · ' + e.model : '')) + '</p><div class="msm-grid">' +
			'<label class="msm-field" data-field="data"><span>Data sprawdzenia <i class="msm-req">*</i></span><input name="data" type="date" value="' + esc(D.dzis) + '" max="' + esc(D.dzis) + '"><em class="msm-ferr"></em></label>' +
			'<div class="msm-field" data-field="ocena"><span>Ocena <i class="msm-req">*</i></span><div class="msm-seg msm-przseg" role="radiogroup"><label><input type="radio" name="ocena" value="sprawne"> Sprawne</label><label><input type="radio" name="ocena" value="niesprawne"> Niesprawne</label></div><em class="msm-ferr"></em></div>' +
			'<label class="msm-field" data-field="sprawdzil"><span>Sprawdził <i class="msm-req">*</i></span><input name="sprawdzil" type="text" list="msm-el-os" value="' + esc(D.ja) + '" autocomplete="off"><em class="msm-ferr"></em></label>' +
			'<label class="msm-field full" data-field="uwagi"><span>Uwagi</span><textarea name="uwagi" rows="2" placeholder="np. wymieniony przewód, uszkodzona obudowa…"></textarea></label>' +
			'</div><p class="msm-muted msm-small" data-enext></p><datalist id="msm-el-os">' + D.osoby.map(function (v) { return '<option value="' + esc(v) + '">'; }).join('') + '</datalist></form>';
		var m = openModal('Sprawdzenie ' + e.symbol, body, '<button type="button" class="msm-btn" data-close>Anuluj</button><button type="button" class="msm-btn msm-btn-primary" data-ok>Zapisz sprawdzenie</button>', true);
		var f = m.querySelector('form'), ok = m.querySelector('[data-ok]');
		function nxt() { var t = Date.parse(f.data.value + 'T00:00:00Z'); f.querySelector('[data-enext]').textContent = isNaN(t) ? '' : 'Następne sprawdzenie: ' + fmtDate(new Date(t + D.okres * 864e5).toISOString().slice(0, 10)) + ' (+' + D.okres + ' dni).'; }
		f.data.addEventListener('change', nxt); nxt();
		function go() {
			var o = f.querySelector('[name=ocena]:checked');
			elSubmit(f, ok, api('/elektro/' + e.id + '/sprawdzenie', { method: 'POST', body: { data: f.data.value, ocena: o ? o.value : '', sprawdzil: f.sprawdzil.value, uwagi: f.uwagi.value } }), function (r) { closeModal(); toast('Zapisano sprawdzenie ' + e.symbol + '.'); done(r); });
		}
		ok.addEventListener('click', go);
		f.addEventListener('submit', function (ev) { ev.preventDefault(); go(); });
	}
	/* ================================================================
	   NARZĘDZIOWNIA → PRZYRZĄDY POMIAROWE: ewidencja, szczegóły, wzorcowania ze świadectwami
	   ================================================================ */
	var PM_FLT_KEY = 'msm_pm_flt';

	function pmState(e, today, soon) {
		if (e.wycofany) return { cls: 'off', txt: 'wycofany z użycia' };
		var n = elDays(e.data_nast, today);
		if (n === null) return { cls: 'none', txt: 'bez terminu' };
		if (n < 0) return { cls: 'late', txt: 'po terminie ' + plN(-n, 'dzień', 'dni', 'dni') };
		if (n === 0) return { cls: 'soon', txt: 'dziś' };
		if (n <= soon) return { cls: 'soon', txt: 'za ' + plN(n, 'dzień', 'dni', 'dni') };
		return { cls: 'ok', txt: '' };
	}
	function pmPrefix(nr) { var m = String(nr || '').match(/^\s*([^\d\s-]+)/); return m ? m[1] : ''; }
	function pmSpr(v) {
		if (v === 'T') return '<span class="msm-eltag is-ok">Sprawny</span>';
		if (v === 'N') return '<span class="msm-eltag is-bad">Niesprawny</span>';
		return v ? '<span class="msm-eltag is-warn">' + esc(v) + '</span>' : '';
	}
	function pmOkres(m) { if (!m) return '—'; return m % 12 === 0 ? plN(m / 12, 'rok', 'lata', 'lat') : plN(m, 'miesiąc', 'miesiące', 'miesięcy'); }
	function pmAddMonths(d, m) {
		var t = String(d || '').match(/^(\d{4})-(\d{2})-(\d{2})$/); m = +m;
		if (!t || !m) return '';
		var y = +t[1], mo = +t[2] + m; y += Math.floor((mo - 1) / 12); mo = ((mo - 1) % 12) + 1;
		var last = new Date(Date.UTC(y, mo, 0)).getUTCDate();
		return y + '-' + ('0' + mo).slice(-2) + '-' + ('0' + Math.min(+t[3], last)).slice(-2);
	}

	function renderPomiar() {
		var main = document.getElementById('msm-main');
		main.innerHTML = '<div class="msm-cat msm-el"><div class="msm-pagehead"><div><h1>Przyrządy pomiarowe</h1><p class="msm-muted" data-pmcount>&nbsp;</p></div>' +
			'<div class="msm-pagehead__tools" data-pmtools></div></div>' +
			'<div class="msm-filters" aria-label="Filtry"><div class="msm-filters__body msm-elflt">' +
			'<label class="msm-f msm-pgf__q"><span>Szukaj</span><input type="search" data-pq placeholder="nr ewid., nazwa, producent, typ, nr fabryczny, zakres…" autocomplete="off"></label>' +
			'<label class="msm-f"><span>Lokalizacja</span><select data-plok><option value="">Wszystkie</option></select></label>' +
			'<label class="msm-f"><span>Rodzaj</span><select data-ppre><option value="">Wszystkie</option></select></label>' +
			'<label class="msm-f"><span>Miejsce</span><select data-pmiej><option value="">Wszystkie</option></select></label>' +
			'<label class="msm-f"><span>Wzorcowanie</span><select data-pterm><option value="">Wszystkie</option><option value="late">Po terminie</option><option value="soon">W ciągu ' + PROG.pomiar + ' dni</option><option value="none">Bez terminu</option></select></label>' +
			'<label class="msm-f"><span>Status</span><select data-pstat><option value="">Używane</option><option value="off">Wycofane</option><option value="all">Wszystkie</option></select></label>' +
			'<div class="msm-f msm-zam-fclear"><button type="button" class="msm-link" data-pclr>Wyczyść filtry</button></div></div></div>' +
			'<div data-pml><div class="msm-loading">Ładowanie…</div></div></div>';
		var $ = function (s) { return main.querySelector(s); };
		var box = $('[data-pml]'), q = $('[data-pq]'), pre = $('[data-ppre]'), miej = $('[data-pmiej]'), term = $('[data-pterm]'), stat = $('[data-pstat]'), lok = $('[data-plok]');
		var D = null, SORT = 'nr', F = (function () { try { return JSON.parse(sessionStorage.getItem(PM_FLT_KEY)) || {}; } catch (e) { return {}; } })();
		q.value = F.q || ''; term.value = F.term || ''; stat.value = F.stat || '';
		function save() { F = { q: q.value, lok: lok.value, pre: pre.value, miej: miej.value, term: term.value, stat: stat.value }; try { sessionStorage.setItem(PM_FLT_KEY, JSON.stringify(F)); } catch (e) {} }
		function match(e) {
			if (stat.value === '' && e.wycofany) return false;
			if (stat.value === 'off' && !e.wycofany) return false;
			if (lok.value && e.lokalizacja !== lok.value) return false;
			if (pre.value && pmPrefix(e.nr_ew) !== pre.value) return false;
			if (miej.value && e.miejsce !== miej.value) return false;
			if (term.value && pmState(e, D.dzis, D.ostrzezenie).cls !== term.value) return false;
			var s = srchNorm(q.value.trim()); if (!s) return true;
			var hay = srchNorm([e.nr_ew, e.nazwa, e.producent, e.typ, e.nr_fabr, e.miejsce, e.lokalizacja, e.zakres, e.rozdzielczosc, e.klasa, e.uwagi, fmtDate(e.data_nast), fmtDate(e.data_wzorc)].join(' | '));
			return s.split(/\s+/).every(function (w) { return hay.indexOf(w) >= 0; });
		}
		function draw() {
			var L = D.pozycje.filter(match), dup = {};
			D.pozycje.forEach(function (e) { var k = e.nr_ew.toLowerCase(); dup[k] = (dup[k] || 0) + 1; });
			if (SORT === 'nr') L = L.slice().sort(function (a, b) { return a.nr_ew.localeCompare(b.nr_ew, 'pl', { numeric: true }) || a.id - b.id; });
			if (SORT === 'data') L = L.slice().sort(function (a, b) { var x = a.data_nast || '9999', y = b.data_nast || '9999'; return x < y ? -1 : x > y ? 1 : a.nr_ew.localeCompare(b.nr_ew); });
			var act = D.pozycje.filter(function (e) { return !e.wycofany; });
			var late = act.filter(function (e) { return pmState(e, D.dzis, D.ostrzezenie).cls === 'late'; }).length;
			var soon = act.filter(function (e) { return pmState(e, D.dzis, D.ostrzezenie).cls === 'soon'; }).length;
			$('[data-pmcount]').innerHTML = esc(plN(act.length, 'przyrząd w użyciu', 'przyrządy w użyciu', 'przyrządów w użyciu')) + (L.length !== act.length ? ' · pokazano ' + L.length : '') +
				(late ? ' · <b class="msm-el-latecnt">' + late + ' po terminie wzorcowania</b>' : '') + (soon ? ' · <b class="msm-pm-soon">' + soon + ' w ciągu ' + D.ostrzezenie + ' dni</b>' : '');
			if (!D.pozycje.length) { box.innerHTML = '<div class="msm-card msm-empty"><h3>Brak przyrządów</h3><p class="msm-muted">Dodaj pierwszy przyrząd przyciskiem „+ Dodaj przyrząd”.</p></div>'; return; }
			if (!L.length) { box.innerHTML = '<div class="msm-card msm-empty"><p><b>Brak przyrządów dla wybranych filtrów.</b></p></div>'; return; }
			var arr = function (k) { return SORT === k ? ' <span aria-hidden="true">↓</span>' : ''; };
			box.innerHTML = '<div class="msm-table-wrap"><table class="msm-table msm-elt msm-pmt"><thead><tr>' +
				'<th><button type="button" class="msm-elsort" data-psort="nr">Nr ewid.' + arr('nr') + '</button></th><th>Nazwa przyrządu</th><th>Producent / typ</th><th>Lokalizacja</th><th>Miejsce</th>' +
				'<th><button type="button" class="msm-elsort" data-psort="data">Kolejne wzorcowanie' + arr('data') + '</button></th></tr></thead><tbody>' +
				L.map(function (e) {
					var st = pmState(e, D.dzis, D.ostrzezenie), pt = [e.producent, e.typ].filter(function (v) { return v && v !== '-'; }).join(' · ');
					return '<tr class="is-' + st.cls + '">' +
						'<td data-label="Nr ewid."><span class="msm-el-v"><a class="msm-el-sym" href="#narz-pomiarowe-' + e.id + '">' + esc(e.nr_ew) + '</a>' + (dup[e.nr_ew.toLowerCase()] > 1 ? ' <span class="msm-eltag is-warn" title="Ten sam numer ma więcej niż jeden przyrząd – popraw numer w szczegółach">duplikat</span>' : '') + '</span></td>' +
						'<td data-label="Nazwa"><span class="msm-el-v">' + esc(e.nazwa) + (e.zakres && e.zakres !== 'ND' && e.zakres !== '-' ? '<small class="msm-muted msm-pm-zak">' + esc(e.zakres) + '</small>' : '') + '</span></td>' +
						'<td data-label="Producent / typ">' + (pt ? esc(pt) : '<span class="msm-muted">—</span>') + '</td>' +
						'<td data-label="Lokalizacja">' + lokTag(e.lokalizacja) + '</td>' +
						'<td data-label="Miejsce">' + (e.miejsce ? '<span class="msm-eltag">' + esc(e.miejsce) + '</span>' : '<span class="msm-muted">—</span>') + '</td>' +
						'<td data-label="Kolejne wzorcowanie" class="msm-el-date"><span class="msm-el-v"><b>' + (e.data_nast ? esc(fmtDate(e.data_nast)) : '<span class="msm-muted">—</span>') + '</b>' + (st.txt ? '<small>' + esc(st.txt) + '</small>' : '') + '</span></td></tr>';
				}).join('') + '</tbody></table></div>';
			box.querySelectorAll('[data-psort]').forEach(function (b) { b.addEventListener('click', function () { SORT = b.getAttribute('data-psort'); draw(); }); });
		}
		var t = null;
		q.addEventListener('input', function () { clearTimeout(t); t = setTimeout(function () { save(); draw(); }, 150); });
		[lok, pre, miej, term, stat].forEach(function (el) { el.addEventListener('change', function () { save(); draw(); }); });
		$('[data-pclr]').addEventListener('click', function () { q.value = lok.value = pre.value = miej.value = term.value = stat.value = ''; save(); draw(); });
		api('/pomiar', { query: { _: Date.now() } }).then(function (r) {
			D = r;
			var cnt = function (f) { var o = {}; r.pozycje.forEach(function (e) { var k = f(e); if (k) o[k] = (o[k] || 0) + 1; }); return o; };
			var cp = cnt(function (e) { return pmPrefix(e.nr_ew); }), cm = cnt(function (e) { return e.miejsce; });
			var names = {}; r.pozycje.forEach(function (e) { var p = pmPrefix(e.nr_ew); if (p && !names[p]) names[p] = e.nazwa; });
			Object.keys(cp).sort().forEach(function (k) { pre.insertAdjacentHTML('beforeend', '<option value="' + esc(k) + '">' + esc(k + ' – ' + (names[k] || '')) + ' (' + cp[k] + ')</option>'); });
			Object.keys(cm).sort().forEach(function (k) { miej.insertAdjacentHTML('beforeend', '<option value="' + esc(k) + '">' + esc(k + (r.miejsca[k.charAt(0)] && k.length > 1 ? ' – ' + r.miejsca[k.charAt(0)] : r.miejsca[k] ? ' – ' + r.miejsca[k] : '')) + ' (' + cm[k] + ')</option>'); });
			pre.value = F.pre || ''; miej.value = F.miej || '';
			lokOptions(lok, r.pozycje, r.lokalizacje, F.lok);
			$('[data-pmtools]').innerHTML = (r.edycja ? '<button type="button" class="msm-btn msm-btn-primary" data-padd>+ Dodaj przyrząd</button>' : '') + xbtn('xlsx', 'data-pexp');
			var add = $('[data-padd]'); if (add) add.addEventListener('click', function () { pmNew(r); });
			$('[data-pexp]').addEventListener('click', function () { window.location.href = buildUrl('/pomiar/export', { _wpnonce: C.nonce }); });
			draw();
		}).catch(function (e) { box.innerHTML = '<p class="msm-alert msm-alert-err">' + esc(e.message) + '</p>'; });
	}

	/* Nowy przyrząd: rodzaj (prefiks) → kolejny wolny numer ewidencyjny. */
	function pmNew(D) {
		var pres = Object.keys(D.nastepne);
		var body = '<form class="msm-form" novalidate><div class="msm-form-err msm-alert msm-alert-err" hidden></div><div class="msm-grid">' +
			'<label class="msm-field" data-field="pre"><span>Rodzaj (prefiks)</span><select name="pre">' + pres.map(function (k) { return '<option value="' + esc(k) + '">' + esc(k) + '</option>'; }).join('') + '<option value="">inny…</option></select></label>' +
			'<label class="msm-field" data-field="nr_ew"><span>Nr ewidencyjny <i class="msm-req">*</i></span><input name="nr_ew" type="text" value="' + esc(D.nastepne[pres[0]] || '') + '" autocomplete="off"><em class="msm-field-hint">Kolejny wolny numer – możesz zmienić.</em><em class="msm-ferr"></em></label>' +
			'<label class="msm-field full" data-field="nazwa"><span>Nazwa przyrządu <i class="msm-req">*</i></span><input name="nazwa" type="text" autocomplete="off" placeholder="np. Suwmiarka"><em class="msm-ferr"></em></label>' +
			'<label class="msm-field" data-field="producent"><span>Producent</span><input name="producent" type="text" autocomplete="off"></label>' +
			'<label class="msm-field" data-field="typ"><span>Typ</span><input name="typ" type="text" autocomplete="off"></label>' +
			'<label class="msm-field" data-field="nr_fabr"><span>Nr fabryczny</span><input name="nr_fabr" type="text" autocomplete="off"></label>' +
			lokField(D.lokalizacje, D.lokalizacje.length === 1 ? D.lokalizacje[0] : '') +
			'<label class="msm-field" data-field="miejsce"><span>Miejsce użytkowania</span><input name="miejsce" type="text" autocomplete="off" placeholder="P/M1, S, T…"></label>' +
			'<label class="msm-field" data-field="zakres"><span>Zakres pomiarowy</span><input name="zakres" type="text" autocomplete="off"></label>' +
			'<label class="msm-field" data-field="okres_mies"><span>Okres wzorcowania [mies.]</span><input name="okres_mies" type="number" min="1" max="240" value="36"></label>' +
			'<label class="msm-field" data-field="data_wzorc"><span>Data ostatniego wzorcowania</span><input name="data_wzorc" type="date"><em class="msm-ferr"></em></label>' +
			'</div></form>';
		var m = openModal('Nowy przyrząd pomiarowy', body, '<button type="button" class="msm-btn" data-close>Anuluj</button><button type="button" class="msm-btn msm-btn-primary" data-ok>Dodaj</button>', true);
		var f = m.querySelector('form'), ok = m.querySelector('[data-ok]'), auto = f.nr_ew.value;
		f.pre.addEventListener('change', function () { if (f.nr_ew.value === auto) { auto = D.nastepne[f.pre.value] || ''; f.nr_ew.value = auto; if (!auto) f.nr_ew.focus(); } });
		function go() {
			var b = { wzorc_zew: 'TAK', wzorc_wew: 'ND', sprawny: 'T' };
			['nr_ew', 'nazwa', 'producent', 'typ', 'nr_fabr', 'lokalizacja', 'miejsce', 'zakres', 'okres_mies', 'data_wzorc'].forEach(function (k) { b[k] = f[k].value; });
			elSubmit(f, ok, api('/pomiar', { method: 'POST', body: b }), function (r) { closeModal(); toast('Dodano ' + b.nr_ew + '.'); location.hash = '#narz-pomiarowe-' + r.id; });
		}
		ok.addEventListener('click', go);
		f.addEventListener('submit', function (e) { e.preventDefault(); go(); });
		setTimeout(function () { f.nazwa.focus(); }, 50);
	}

	/* Szczegóły przyrządu: wszystkie kolumny ewidencji + historia wzorcowań. */
	function renderPomiarItem(id) {
		var main = document.getElementById('msm-main');
		main.innerHTML = '<div class="msm-cat msm-el"><a class="msm-back" href="#narz-pomiarowe">← Przyrządy pomiarowe</a><div data-pmi><div class="msm-loading">Ładowanie…</div></div></div>';
		var box = main.querySelector('[data-pmi]');
		function draw(D) {
			var e = D.pozycja, ed = D.edycja, st = pmState(e, D.dzis, D.ostrzezenie), dis = ed ? '' : ' disabled';
			var inp = function (k, label, o) {
				o = o || {};
				return '<label class="msm-field' + (o.full ? ' full' : '') + '" data-field="' + k + '"><span>' + label + '</span><input name="' + k + '" type="' + (o.type || 'text') + '" value="' + esc(e[k] == null ? '' : e[k]) + '"' + (o.list ? ' list="' + o.list + '"' : '') + (o.attr || '') + ' autocomplete="off"' + dis + '><em class="msm-ferr"></em></label>';
			};
			var tnd = function (k, label) {
				return '<label class="msm-field" data-field="' + k + '"><span>' + label + '</span><select name="' + k + '"' + dis + '>' + ['', 'TAK', 'NIE', 'ND'].map(function (v) { return '<option value="' + v + '"' + (v === e[k] ? ' selected' : '') + '>' + (v || '—') + '</option>'; }).join('') + '</select></label>';
			};
			var dl = function (id, arr) { return '<datalist id="' + id + '">' + arr.map(function (v) { return '<option value="' + esc(v) + '">'; }).join('') + '</datalist>'; };
			box.innerHTML =
				'<div class="msm-pagehead msm-el-head"><div><h1>' + esc(e.nr_ew) + ' <span class="msm-el-head__n">' + esc(e.nazwa) + '</span></h1>' +
				'<p class="msm-el-head__meta">' + (e.lokalizacja ? lokTag(e.lokalizacja) : '') + (e.miejsce ? '<span class="msm-eltag">' + esc(e.miejsce) + '</span>' : '') + pmSpr(e.sprawny) + (e.wycofany ? '<span class="msm-eltag is-bad">Wycofany z użycia</span>' : '') +
				(D.dubel ? '<span class="msm-eltag is-warn">Ten numer ma też inny przyrząd – zmień go na unikalny</span>' : '') + '</p></div>' +
				'<div class="msm-el-status is-' + st.cls + '"><small>Kolejne wzorcowanie</small><b>' + (e.data_nast ? esc(fmtDate(e.data_nast)) : '—') + '</b>' + (st.txt ? '<span>' + esc(st.txt) + '</span>' : '') + '</div></div>' +
				'<form class="msm-card msm-form msm-el-form" novalidate><div class="msm-form-err msm-alert msm-alert-err" hidden></div>' +
				'<h3 class="msm-pm-h">Dane przyrządu</h3><div class="msm-grid msm-el-grid">' +
				inp('nr_ew', 'Nr ewidencyjny <i class="msm-req">*</i>') + inp('nazwa', 'Nazwa przyrządu <i class="msm-req">*</i>', { full: false }) + inp('producent', 'Producent', { list: 'msm-pm-prod' }) +
				inp('typ', 'Typ') + inp('nr_fabr', 'Nr fabryczny') + inp('rok_prod', 'Rok produkcji') +
				lokField(D.lokalizacje, e.lokalizacja, dis) + inp('miejsce', 'Miejsce użytkowania', { list: 'msm-pm-miej' }) + inp('klasa', 'Klasa dokładności') + inp('rozdzielczosc', 'Rozdzielczość') +
				inp('zakres', 'Zakres pomiarowy', { full: true }) +
				'</div><h3 class="msm-pm-h">Wzorcowanie</h3><div class="msm-grid msm-el-grid">' +
				tnd('wzorc_wew', 'Wzorcowanie wewnętrznie') + tnd('wzorc_zew', 'Wzorcowanie na zewnątrz') +
				inp('sprawny', 'Sprawny metrologicznie (T/N)', { list: 'msm-pm-spr' }) +
				inp('data_wzorc', 'Data wzorcowania', { type: 'date' }) +
				inp('okres_mies', 'Okres wzorcowania [mies.]', { type: 'number', attr: ' min="1" max="240"' }) +
				'<div class="msm-field" data-field="data_nast"><span>Data kolejnego wzorcowania</span><input name="data_nast" type="date" value="' + esc(e.data_nast || '') + '"' + (ed && e.nast_recznie ? '' : ' disabled') + '>' +
				'<label class="msm-check msm-el-man"><input type="checkbox" name="nast_recznie"' + (e.nast_recznie ? ' checked' : '') + dis + '> ustaw ręcznie <span class="msm-muted">(inaczej: data wzorcowania + okres)</span></label><em class="msm-ferr"></em></div>' +
				'<label class="msm-field full" data-field="uwagi"><span>Uwagi</span><textarea name="uwagi" rows="2"' + dis + '>' + esc(e.uwagi || '') + '</textarea></label>' +
				'<label class="msm-check full msm-pm-off"><input type="checkbox" name="wycofany"' + (e.wycofany ? ' checked' : '') + dis + '> <span><b>Wycofany z użycia</b> – bez ostrzeżeń o terminie, ukryty na liście „Używane”</span></label>' +
				'</div>' + (ed ? '<div class="msm-el-actions"><button type="button" class="msm-btn msm-btn-danger-ghost" data-pdel>Usuń przyrząd</button><span class="msm-muted" data-pdirty></span><button type="submit" class="msm-btn msm-btn-primary" data-psave disabled>Zapisz zmiany</button></div>' : '') +
				dl('msm-pm-prod', D.producenci) + dl('msm-pm-miej', D.miejsca_list) + dl('msm-pm-spr', ['T', 'N', 'do wysłania']) + '</form>' +
				'<section class="msm-card msm-el-checks"><header><h2>Wzorcowania i sprawdzenia <span class="msm-muted">(' + D.wzorcowania.length + ')</span></h2>' + (ed ? '<button type="button" class="msm-btn msm-btn-primary" data-pwz>Zapisz wzorcowanie</button>' : '') + '</header>' +
				(D.wzorcowania.length ? '<div class="msm-table-wrap"><table class="msm-table"><thead><tr><th>Data</th><th>Wynik</th><th>Rodzaj</th><th>Wykonał</th><th>Świadectwo</th><th>Uwagi</th>' + (ed ? '<th></th>' : '') + '</tr></thead><tbody>' +
					D.wzorcowania.map(function (w) {
						return '<tr><td data-label="Data"><b>' + esc(fmtDate(w.data)) + '</b></td><td data-label="Wynik">' + pmSpr(w.wynik) + '</td><td data-label="Rodzaj">' + esc(w.rodzaj) + '</td><td data-label="Wykonał">' + esc(w.wykonal) + '</td>' +
							'<td data-label="Świadectwo">' + (w.nr_swiad ? esc(w.nr_swiad) : '') + (w.plik ? (w.nr_swiad ? '<br>' : '') + '<a class="msm-pm-file" href="' + esc(w.plik.url) + '" target="_blank" rel="noopener" data-view="' + (/\.(jpe?g|png|webp)$/i.test(w.plik.nazwa) ? 'img' : 'file') + '" data-name="' + esc(w.plik.nazwa) + '">📄 ' + esc(w.plik.nazwa) + '</a>' : (w.nr_swiad ? '' : '<span class="msm-muted">—</span>')) + '</td>' +
							'<td data-label="Uwagi">' + (w.uwagi ? esc(w.uwagi) : '<span class="msm-muted">—</span>') + '</td>' +
							(ed ? '<td class="msm-pgl-act"><button type="button" class="msm-iconbtn" data-pwzdel="' + w.id + '" title="Usuń wpis" aria-label="Usuń wpis">×</button></td>' : '') + '</tr>';
					}).join('') + '</tbody></table></div>'
					: '<p class="msm-muted msm-el-nochk">Brak zapisanych wzorcowań' + (e.data_wzorc ? ' – ostatnie z Excela: ' + esc(fmtDate(e.data_wzorc)) : '') + '.</p>') + '</section>';
			if (!ed) return;
			var f = box.querySelector('.msm-el-form'), saveB = f.querySelector('[data-psave]'), nast = f.data_nast, man = f.nast_recznie;
			var keys = ['nr_ew', 'nazwa', 'producent', 'typ', 'nr_fabr', 'rok_prod', 'lokalizacja', 'miejsce', 'klasa', 'rozdzielczosc', 'zakres', 'wzorc_wew', 'wzorc_zew', 'sprawny', 'data_wzorc', 'okres_mies', 'data_nast', 'uwagi'];
			function read() { var o = {}; keys.forEach(function (k) { o[k] = f[k].value; }); o.nast_recznie = man.checked ? 1 : 0; o.wycofany = f.wycofany.checked ? 1 : 0; return o; }
			var start = JSON.stringify(read());
			function auto() { if (!man.checked) nast.value = pmAddMonths(f.data_wzorc.value, f.okres_mies.value); }
			function dirty() { var d = JSON.stringify(read()) !== start; saveB.disabled = !d; f.querySelector('[data-pdirty]').textContent = d ? 'Niezapisane zmiany' : ''; }
			man.addEventListener('change', function () { nast.disabled = !man.checked; auto(); dirty(); });
			[f.data_wzorc, f.okres_mies].forEach(function (x) { x.addEventListener('input', auto); x.addEventListener('change', auto); });
			f.addEventListener('input', dirty); f.addEventListener('change', dirty);
			f.addEventListener('submit', function (ev) { ev.preventDefault(); elSubmit(f, saveB, api('/pomiar/' + id, { method: 'POST', body: read() }), function (r) { toast('Zapisano.'); draw(r); }); });
			f.querySelector('[data-pdel]').addEventListener('click', function () {
				confirmBox('Usunąć przyrząd?', '<b>' + esc(e.nr_ew + ' ' + e.nazwa) + '</b> zniknie z ewidencji razem z historią wzorcowań i świadectwami (zostanie wpis w Historii zmian). Jeśli przyrząd tylko przestał być używany, zaznacz „Wycofany z użycia”.', 'Usuń', true).then(function (ok) {
					if (!ok) return;
					api('/pomiar/' + id + '/delete', { method: 'POST', body: {} }).then(function () { toast('Usunięto ' + e.nr_ew + '.'); location.hash = '#narz-pomiarowe'; }).catch(function (er) { toast(er.message, 'err'); });
				});
			});
			box.querySelector('[data-pwz]').addEventListener('click', function () { pmWz(D, draw); });
			box.querySelectorAll('[data-pwzdel]').forEach(function (b) {
				b.addEventListener('click', function () {
					confirmBox('Usunąć wpis wzorcowania?', 'Wpis i dołączone świadectwo zostaną usunięte. Daty przyrządu się nie zmienią – w razie potrzeby popraw je powyżej.', 'Usuń', true).then(function (ok) {
						if (!ok) return;
						api('/pomiar/wz/' + b.getAttribute('data-pwzdel') + '/delete', { method: 'POST', body: {} }).then(function (r) { toast('Usunięto wpis.'); draw(r); }).catch(function (er) { toast(er.message, 'err'); });
					});
				});
			});
		}
		api('/pomiar/' + id, { query: { _: Date.now() } }).then(draw).catch(function (e) { box.innerHTML = '<p class="msm-alert msm-alert-err">' + esc(e.message) + '</p>'; });
	}

	/* Zapis wzorcowania: data, wynik, rodzaj, kto, nr świadectwa, plik, okres → data kolejnego. */
	function pmWz(D, done) {
		var e = D.pozycja, ok0 = e.okres_mies || 36;
		var body = '<form class="msm-form" novalidate><div class="msm-form-err msm-alert msm-alert-err" hidden></div><p class="msm-muted">' + esc(e.nr_ew + ' · ' + e.nazwa + (e.zakres && e.zakres !== 'ND' ? ' · ' + e.zakres : '')) + '</p><div class="msm-grid">' +
			'<label class="msm-field" data-field="data"><span>Data wzorcowania <i class="msm-req">*</i></span><input name="data" type="date" value="' + esc(D.dzis) + '" max="' + esc(D.dzis) + '"><em class="msm-ferr"></em></label>' +
			'<div class="msm-field" data-field="wynik"><span>Wynik <i class="msm-req">*</i></span><div class="msm-seg msm-przseg" role="radiogroup"><label><input type="radio" name="wynik" value="T"> Sprawny</label><label><input type="radio" name="wynik" value="N"> Niesprawny</label></div><em class="msm-ferr"></em></div>' +
			'<div class="msm-field" data-field="rodzaj"><span>Rodzaj</span><div class="msm-seg msm-przseg" role="radiogroup"><label><input type="radio" name="rodzaj" value="zewnętrzne"' + (e.wzorc_wew === 'TAK' && e.wzorc_zew !== 'TAK' ? '' : ' checked') + '> Na zewnątrz</label><label><input type="radio" name="rodzaj" value="wewnętrzne"' + (e.wzorc_wew === 'TAK' && e.wzorc_zew !== 'TAK' ? ' checked' : '') + '> Wewnętrznie</label></div></div>' +
			'<label class="msm-field" data-field="wykonal"><span>Wykonał (firma / osoba) <i class="msm-req">*</i></span><input name="wykonal" type="text" list="msm-pm-wyk" autocomplete="off"><em class="msm-ferr"></em></label>' +
			'<label class="msm-field" data-field="nr_swiad"><span>Nr świadectwa</span><input name="nr_swiad" type="text" autocomplete="off"></label>' +
			'<label class="msm-field" data-field="file"><span>Świadectwo (PDF / zdjęcie)</span><input name="file" type="file" accept="application/pdf,image/*"><em class="msm-ferr"></em></label>' +
			'<label class="msm-field" data-field="okres_mies"><span>Okres do kolejnego [mies.]</span><input name="okres_mies" type="number" min="1" max="240" value="' + ok0 + '"></label>' +
			'<label class="msm-field" data-field="data_nast"><span>Kolejne wzorcowanie</span><input name="data_nast" type="date"><em class="msm-field-hint">Liczy się samo z okresu – możesz zmienić.</em><em class="msm-ferr"></em></label>' +
			'<label class="msm-field full" data-field="uwagi"><span>Uwagi</span><textarea name="uwagi" rows="2"></textarea></label>' +
			'</div><datalist id="msm-pm-wyk">' + D.wykonawcy.map(function (v) { return '<option value="' + esc(v) + '">'; }).join('') + '</datalist></form>';
		var m = openModal('Wzorcowanie ' + e.nr_ew, body, '<button type="button" class="msm-btn" data-close>Anuluj</button><button type="button" class="msm-btn msm-btn-primary" data-ok>Zapisz wzorcowanie</button>', true);
		var f = m.querySelector('form'), ok = m.querySelector('[data-ok]'), touched = false;
		function nx() { if (!touched) f.data_nast.value = pmAddMonths(f.data.value, f.okres_mies.value); }
		f.data_nast.addEventListener('input', function () { touched = !!f.data_nast.value; });
		[f.data, f.okres_mies].forEach(function (x) { x.addEventListener('input', nx); x.addEventListener('change', nx); });
		nx();
		function go() {
			var fd = new FormData(f), w = f.querySelector('[name=wynik]:checked');
			if (!w) fd.set('wynik', '');
			if (!f.file.files.length) fd.delete('file');
			elSubmit(f, ok, api('/pomiar/' + e.id + '/wzorcowanie', { method: 'POST', form: fd }), function (r) { closeModal(); toast('Zapisano wzorcowanie ' + e.nr_ew + '.'); done(r); });
		}
		ok.addEventListener('click', go);
		f.addEventListener('submit', function (ev) { ev.preventDefault(); go(); });
	}
	/* ================================================================
	   ZAMÓWIENIA DO DOSTAWCÓW: lista, szczegóły, tworzenie z „Do zamówienia”, wysyłka e-mailem, dostawcy
	   ================================================================ */
	var ZAM_MAG = { blachy_pelne: 'Blachy pełne', kregi: 'Kręgi', stal: 'Stal' };
	var ZAM_FIELDS = {
		blachy_pelne: [['gatunek', 'Gatunek', 'np. CZARNA, DC01'], ['grubosc', 'Grubość [mm]', '4', 1], ['wymiar_a', 'Wymiar A [mm]', '1250', 1], ['wymiar_b', 'Wymiar B [mm]', '2500', 1], ['material', 'Materiał', 'np. S235']],
		kregi: [['oznaczenie', 'Oznaczenie blachy', 'np. M400-50A'], ['izolacja', 'Izolacja', 'np. C5'], ['grubosc', 'Grubość [mm]', '0,5', 1], ['szerokosc', 'Szerokość [mm]', '250', 1]],
		stal: [['opis', 'Rodzaj', 'np. PŁASKOWNIK'], ['szer', 'Szer. / śr. [mm]', '50', 1], ['wys', 'Wys. [mm]', '10', 1], ['scianka', 'Gr. ścianki [mm]', '', 1], ['gatunek', 'Gatunek', 'np. S235'], ['dlugosc', 'Długość [m]', '6', 1]]
	};
	var ZAM_ST_CLS = { szkic: 'is-draft', wyslane: 'is-sent', czesciowo: 'is-part', zrealizowane: 'is-done', zamkniete: 'is-closed', anulowane: 'is-cancel' };
	var ZAM_HINTS = null;
	function zamHints() { return ZAM_HINTS ? Promise.resolve(ZAM_HINTS) : api('/zap/podpowiedzi').then(function (h) { ZAM_HINTS = h; return h; }).catch(function () { return {}; }); }
	function zamUnit(jm) { return jm === 'kg' ? 'kg' : 'szt.'; }
	function zamTag(st, txt) { return '<span class="msm-zst ' + (ZAM_ST_CLS[st] || '') + '">' + esc(txt || st) + '</span>'; }

	/* Pola specyfikacji materiału (z podpowiedziami z magazynu). */
	function zamSpecHtml(table, spec, uid, hints) {
		spec = spec || {};
		return '<div class="msm-zspec">' + (ZAM_FIELDS[table] || []).map(function (f) {
			var lid = 'zh-' + uid + '-' + f[0], list = ((hints || {})[table] || {})[f[0]] || [];
			var v = spec[f[0]] === undefined || spec[f[0]] === null ? '' : String(spec[f[0]]).replace('.', ',');
			return '<label class="msm-field"><span>' + esc(f[1]) + '</span><input type="text" data-sk="' + f[0] + '" value="' + esc(v) + '" placeholder="' + esc(f[2]) + '"' + (f[3] ? ' inputmode="decimal"' : '') + (list.length ? ' list="' + lid + '"' : '') + ' autocomplete="off">' +
				(list.length ? '<datalist id="' + lid + '">' + list.map(function (x) { return '<option value="' + esc(x) + '">'; }).join('') + '</datalist>' : '') + '</label>';
		}).join('') + '</div>';
	}
	function zamSpecRead(box) {
		var o = {};
		box.querySelectorAll('[data-sk]').forEach(function (i) { if (i.value.trim()) o[i.getAttribute('data-sk')] = i.value.trim(); });
		return o;
	}

	/* ---------- Zapotrzebowanie przy pozycji zlecenia (Produkcja) ---------- */
	function zapForm(d, nr, done) {
		var p = (d.material || '').toUpperCase(), g = p.match(/\b(S\d{3}[A-Z0-9+]*|DC0\d|DX5\d[A-Z]*|M\d{3,4}-\d{2,3}[A-Z]*)\b/), t = p.match(/(\d+(?:[.,]\d+)?)\s*MM/);
		var isCoil = /^M\d{3}/.test(g ? g[1] : '');
		var pre = isCoil ? { tabela: 'kregi', spec: { oznaczenie: g[1], izolacja: (p.match(/\bC\d\b/) || [''])[0] } } : { tabela: 'blachy_pelne', spec: g ? { material: g[1] } : {} };
		if (t) pre.spec.grubosc = t[1];
		zamHints().then(function (H) {
			var body = '<form class="msm-form" novalidate><div class="msm-form-err msm-alert msm-alert-err" hidden></div>' +
				'<p class="msm-muted">' + esc((d.nazwa_detalu || 'Pozycja') + (nr ? ' · zlecenie ' + nr : '') + (d.material ? ' · ' + d.material : '')) + '</p>' +
				'<div class="msm-field"><span>Magazyn</span><div class="msm-seg msm-przseg" role="radiogroup">' + Object.keys(ZAM_MAG).map(function (k) { return '<label><input type="radio" name="tabela" value="' + k + '"' + (k === pre.tabela ? ' checked' : '') + '> ' + ZAM_MAG[k] + '</label>'; }).join('') + '</div></div>' +
				'<div data-zspec>' + zamSpecHtml(pre.tabela, pre.spec, 'zap', H) + '</div>' +
				'<div class="msm-grid"><label class="msm-field" data-field="ilosc"><span data-zunit>Potrzebna ilość [' + (pre.tabela === 'kregi' ? 'kg' : 'szt.') + '] <i class="msm-req">*</i></span><input name="ilosc" type="text" inputmode="decimal" autocomplete="off"><em class="msm-ferr"></em></label>' +
				'<label class="msm-field"><span>Uwagi</span><input name="uwagi" type="text" autocomplete="off" placeholder="np. atest 3.1, pilne"></label></div>' +
				'<label class="msm-check"><input type="checkbox" name="rezerwuj" checked> Zarezerwuj od razu to, co jest wolne na magazynie</label>' +
				'<p class="msm-small msm-muted">Brakującą resztę zobaczysz w Magazyn → Do zamówienia, z numerem tego zlecenia. Po dostawie (PZ) materiał zarezerwuje się sam.</p></form>';
			var m = openModal('Zapotrzebowanie na materiał', body, '<button type="button" class="msm-btn" data-close>Anuluj</button><button type="button" class="msm-btn msm-btn-primary" data-ok>Zgłoś zapotrzebowanie</button>', true);
			var f = m.querySelector('form'), ok = m.querySelector('[data-ok]');
			f.querySelectorAll('[name=tabela]').forEach(function (r) {
				r.addEventListener('change', function () {
					f.querySelector('[data-zspec]').innerHTML = zamSpecHtml(r.value, r.value === pre.tabela ? pre.spec : {}, 'zap', H);
					f.querySelector('[data-zunit]').innerHTML = 'Potrzebna ilość [' + (r.value === 'kregi' ? 'kg' : 'szt.') + '] <i class="msm-req">*</i>';
				});
			});
			function go() {
				var tb = f.querySelector('[name=tabela]:checked').value;
				var b = { det_id: d.id, tabela: tb, spec: zamSpecRead(f.querySelector('[data-zspec]')), ilosc: f.ilosc.value, uwagi: f.uwagi.value, rezerwuj: f.rezerwuj.checked };
				elSubmit(f, ok, api('/zap', { method: 'POST', body: b }), function (r) { closeModal(); toast(r.message); done(r); });
			}
			ok.addEventListener('click', go);
			f.addEventListener('submit', function (e) { e.preventDefault(); go(); });
			setTimeout(function () { f.ilosc.focus(); }, 60);
		});
	}
	function zapChips(d, canDel) {
		return (d.zap || []).map(function (z) {
			var u = z.jm === 'kg' ? 'kg' : 'szt.';
			var st = z.brak <= 0 ? (z.oczekuje > 0 ? '<em>czeka na akceptację</em>' : '<em>pokryte</em>') : z.do_zam > 0 ? '<em>do zamówienia ' + fmtNum(z.do_zam) + ' ' + u + '</em>' : '<em>zamówione ' + esc(z.zam.join(', ')) + '</em>';
			return '<span class="msm-rzchip msm-zapchip ' + (z.brak <= 0 ? (z.oczekuje > 0 ? 'is-nowa' : 'is-aktywna') : z.do_zam > 0 ? 'is-brak' : 'is-zam') + '" title="Zapotrzebowanie: ' + esc(z.opis) + ' – ' + fmtNum(z.ilosc) + ' ' + u + (z.zarezerw ? ', zarezerwowano ' + fmtNum(z.zarezerw) : '') + (z.oczekuje ? ' (w tym ' + fmtNum(z.oczekuje) + ' czeka na akceptację)' : '') + '"><b>' + fmtNum(z.ilosc) + ' ' + u + '</b> ' + esc(z.opis) + ' ' + st +
				(canDel ? '<button type="button" class="msm-zapchip__x" data-zapdel="' + z.id + '" title="Usuń zapotrzebowanie" aria-label="Usuń zapotrzebowanie">×</button>' : '') + '</span>';
		}).join('');
	}

	/* ---------- Tworzenie zamówienia ---------- */
	function zamCreate(poz) {
		Promise.all([api('/zam/dostawcy'), api('/zam').catch(function () { return { zamowienia: [] }; }), zamHints()]).then(function (R) {
			var D = R[0], drafts = (R[1].zamowienia || []).filter(function (z) { return z.status === 'szkic'; }), H = R[2];
			var rows = poz.slice();
			var body = '<form class="msm-form" novalidate><div class="msm-form-err msm-alert msm-alert-err" hidden></div><div class="msm-grid">' +
				'<label class="msm-field full" data-field="dost_id"><span>Dostawca <i class="msm-req">*</i></span><select name="dost_id"><option value="">— wybierz —</option>' +
				D.dostawcy.map(function (d) { return '<option value="' + d.id + '">' + esc(d.nazwa + (d.email ? ' · ' + d.email : ' · brak e-maila')) + '</option>'; }).join('') + '<option value="new">+ Nowy dostawca…</option></select></label>' +
				'<div class="msm-zc-new full" data-znew hidden><label class="msm-field"><span>Nazwa dostawcy</span><input name="dostawca" type="text" list="zc-pz" autocomplete="off"><datalist id="zc-pz">' + D.z_pz.map(function (n) { return '<option value="' + esc(n) + '">'; }).join('') + '</datalist></label>' +
				'<label class="msm-field"><span>E-mail do zamówień</span><input name="email" type="email" autocomplete="off" placeholder="zamowienia@dostawca.pl"></label></div>' +
				'<label class="msm-check full" data-zdraft hidden><input type="checkbox" name="do_szkicu"> <span data-zdraftl></span></label>' +
				'<label class="msm-field" data-zhead><span>Oczekiwany termin dostawy</span><input name="termin" type="date"></label>' +
				'<label class="msm-field full" data-zhead><span>Uwagi do zamówienia</span><textarea name="uwagi" rows="2" placeholder="np. atesty 3.1, dostawa na plac Ligota Wołczyńska"></textarea></label>' +
				'</div><h3 class="msm-zc-h">Pozycje</h3><div data-zrows></div><button type="button" class="msm-kt-add" data-zaddrow>+ Dodaj pozycję ręcznie</button></form>';
			var m = openModal('Nowe zamówienie do dostawcy', body, '<button type="button" class="msm-btn" data-close>Anuluj</button><button type="button" class="msm-btn msm-btn-primary" data-ok>Utwórz zamówienie</button>', true);
			var f = m.querySelector('form'), ok = m.querySelector('[data-ok]'), rbox = f.querySelector('[data-zrows]');
			function drawRows() {
				rbox.innerHTML = rows.length ? '<div class="msm-zc-rows">' + rows.map(function (r, i) {
					if (r.manual) {
						return '<div class="msm-zc-row is-manual" data-zr="' + i + '"><div class="msm-zc-row__m"><select data-zrt>' + Object.keys(ZAM_MAG).map(function (k) { return '<option value="' + k + '"' + (k === r.tabela ? ' selected' : '') + '>' + ZAM_MAG[k] + '</option>'; }).join('') + '</select>' +
							zamSpecHtml(r.tabela, r.spec, 'm' + i, H) + '</div><label class="msm-zc-row__q"><input type="text" inputmode="decimal" data-zrq value="' + esc(r.ilosc || '') + '" placeholder="ilość"><span>' + (r.tabela === 'kregi' ? 'kg' : 'szt.') + '</span></label><button type="button" class="msm-iconbtn" data-zrdel="' + i + '" aria-label="Usuń">×</button></div>';
					}
					return '<div class="msm-zc-row" data-zr="' + i + '"><div class="msm-zc-row__m"><b>' + esc(r.opis) + '</b>' + (r.zlecenia && r.zlecenia.length ? '<small class="msm-muted">dla zleceń: ' + r.zlecenia.map(esc).join(', ') + '</small>' : '<small class="msm-muted">uzupełnienie stanu minimalnego</small>') + '</div>' +
						'<label class="msm-zc-row__q"><input type="text" inputmode="decimal" data-zrq value="' + esc(String(r.ilosc).replace('.', ',')) + '"><span>' + zamUnit(r.jm) + '</span></label><button type="button" class="msm-iconbtn" data-zrdel="' + i + '" aria-label="Usuń">×</button></div>';
				}).join('') + '</div>' : '<p class="msm-muted msm-small">Brak pozycji – dodaj pozycję ręcznie.</p>';
				rbox.querySelectorAll('[data-zr]').forEach(function (el) {
					var i = +el.getAttribute('data-zr');
					el.querySelector('[data-zrq]').addEventListener('input', function () { rows[i].ilosc = this.value; });
					var t = el.querySelector('[data-zrt]');
					if (t) t.addEventListener('change', function () { readManual(); rows[i].tabela = t.value; rows[i].spec = {}; drawRows(); });
					el.querySelector('[data-zrdel]').addEventListener('click', function () { readManual(); rows.splice(i, 1); drawRows(); });
				});
			}
			function readManual() { rbox.querySelectorAll('.is-manual').forEach(function (el) { rows[+el.getAttribute('data-zr')].spec = zamSpecRead(el); }); }
			f.querySelector('[data-zaddrow]').addEventListener('click', function () { readManual(); rows.push({ manual: true, tabela: 'blachy_pelne', spec: {}, ilosc: '' }); drawRows(); });
			drawRows();
			function syncDost() {
				var v = f.dost_id.value, isNew = v === 'new';
				f.querySelector('[data-znew]').hidden = !isNew;
				var dr = v && !isNew ? drafts.filter(function (z) { return String(z.dost_id) === v; })[0] : null;
				var wrap = f.querySelector('[data-zdraft]');
				wrap.hidden = !dr; if (!dr) f.do_szkicu.checked = false;
				if (dr) { f.do_szkicu.value = dr.id; f.querySelector('[data-zdraftl]').innerHTML = 'Dopisz do niewysłanego szkicu <b>' + esc(dr.numer) + '</b> (' + dr.pozycji + ' poz.)'; }
				f.querySelectorAll('[data-zhead]').forEach(function (x) { x.hidden = f.do_szkicu.checked; });
				if (isNew) f.dostawca.focus();
			}
			f.dost_id.addEventListener('change', syncDost);
			f.do_szkicu.addEventListener('change', syncDost);
			function go() {
				readManual();
				var b = { termin: f.termin.value, uwagi: f.uwagi.value, pozycje: rows.map(function (r) { return { tabela: r.tabela, spec: r.spec, item_id: r.item_id || 0, ilosc: r.ilosc, zap: r.zap || [] }; }) };
				if (f.dost_id.value === 'new') { b.dostawca = f.dostawca.value; b.email = f.email.value; } else b.dost_id = +f.dost_id.value || 0;
				if (f.do_szkicu.checked) b.do_szkicu = +f.do_szkicu.value;
				if (!b.dost_id && !b.dostawca && !b.do_szkicu) { var er = f.querySelector('.msm-form-err'); er.textContent = 'Wybierz dostawcę.'; er.hidden = false; return; }
				elSubmit(f, ok, api('/zam', { method: 'POST', body: b }), function (r) { closeModal(); toast(r.message); location.hash = '#zam-' + r.id; });
			}
			ok.addEventListener('click', go);
			f.addEventListener('submit', function (e) { e.preventDefault(); go(); });
		}).catch(function (e) { toast(e.message, 'err'); });
	}

	/* ---------- Lista zamówień ---------- */
	function renderZam() {
		var main = document.getElementById('msm-main');
		main.innerHTML = '<div class="msm-cat msm-zam"><div class="msm-pagehead"><div><h1>Zamówienia do dostawców</h1><p class="msm-muted" data-zcount>&nbsp;</p></div><div class="msm-pagehead__tools" data-ztools></div></div>' +
			'<div class="msm-filters"><div class="msm-filters__body msm-zflt"><label class="msm-f msm-pgf__q"><span>Szukaj</span><input type="search" data-zq placeholder="numer, dostawca, materiał…" autocomplete="off"></label>' +
			'<label class="msm-f"><span>Status</span><select data-zst><option value="open">Otwarte (szkic, wysłane, częściowo)</option><option value="">Wszystkie</option></select></label></div></div>' +
			'<div data-zl><div class="msm-loading">Ładowanie…</div></div></div>';
		var box = main.querySelector('[data-zl]'), q = main.querySelector('[data-zq]'), st = main.querySelector('[data-zst]'), D = null;
		try { var F = JSON.parse(sessionStorage.getItem('msm_zam_flt')) || {}; q.value = F.q || ''; st.value = F.st === undefined ? 'open' : F.st; } catch (e) {}
		function draw() {
			try { sessionStorage.setItem('msm_zam_flt', JSON.stringify({ q: q.value, st: st.value })); } catch (e) {}
			var s = srchNorm(q.value.trim());
			var L = D.zamowienia.filter(function (z) {
				if (st.value === 'open' && ['szkic', 'wyslane', 'czesciowo'].indexOf(z.status) < 0) return false;
				if (st.value && st.value !== 'open' && z.status !== st.value) return false;
				return !s || s.split(/\s+/).every(function (w) { return srchNorm([z.numer, z.dostawca, z.opis, z.email].join(' ')).indexOf(w) >= 0; });
			});
			var open = D.zamowienia.filter(function (z) { return ['wyslane', 'czesciowo'].indexOf(z.status) >= 0; }).length;
			main.querySelector('[data-zcount]').textContent = plN(D.zamowienia.length, 'zamówienie', 'zamówienia', 'zamówień') + (open ? ' · ' + open + ' w drodze' : '');
			if (!D.zamowienia.length) { box.innerHTML = '<div class="msm-card msm-empty"><h3>Brak zamówień</h3><p class="msm-muted">Zamówienie utworzysz w Magazyn → Do zamówienia: zaznacz braki i kliknij „Utwórz zamówienie”.</p><p><a class="msm-btn" href="#zamowienia">Przejdź do „Do zamówienia”</a></p></div>'; return; }
			if (!L.length) { box.innerHTML = '<div class="msm-card msm-empty"><p><b>Brak zamówień dla wybranych filtrów.</b></p></div>'; return; }
			box.innerHTML = '<div class="msm-table-wrap"><table class="msm-table msm-zlt"><thead><tr><th>Numer</th><th>Dostawca</th><th>Pozycje</th><th>Status</th><th>Utworzono</th><th>Termin</th></tr></thead><tbody>' +
				L.map(function (z) {
					return '<tr data-zid="' + z.id + '"><td data-label="Numer"><a class="msm-zlt__nr" href="#zam-' + z.id + '">' + esc(z.numer) + '</a></td>' +
						'<td data-label="Dostawca"><span class="msm-zb__v"><b>' + esc(z.dostawca) + '</b>' + (z.email ? '<small class="msm-muted">' + esc(z.email) + '</small>' : '') + '</span></td>' +
						'<td data-label="Pozycje"><span class="msm-zb__v">' + esc(z.opis || '—') + '<small class="msm-muted">' + plN(z.pozycji, 'pozycja', 'pozycje', 'pozycji') + '</small></span></td>' +
						'<td data-label="Status"><span class="msm-zb__v">' + zamTag(z.status, z.status_txt) + (z.status === 'czesciowo' ? '<small class="msm-muted">przyjęto ' + z.proc + '%</small>' : '') + '</span></td>' +
						'<td data-label="Utworzono" class="msm-pgl-d">' + esc(fmtDate(z.kiedy)) + '</td>' +
						'<td data-label="Termin" class="msm-pgl-d">' + (z.termin ? esc(fmtDate(z.termin)) : '<span class="msm-muted">—</span>') + '</td></tr>';
				}).join('') + '</tbody></table></div>';
			box.querySelectorAll('tr[data-zid]').forEach(function (tr) { tr.addEventListener('click', function (e) { if (!e.target.closest('a')) location.hash = '#zam-' + tr.getAttribute('data-zid'); }); });
		}
		var t;
		q.addEventListener('input', function () { clearTimeout(t); t = setTimeout(draw, 150); });
		st.addEventListener('change', draw);
		api('/zam', { query: { _: Date.now() } }).then(function (r) {
			D = r;
			Object.keys(r.statusy).forEach(function (k) { st.insertAdjacentHTML('beforeend', '<option value="' + k + '">' + esc(r.statusy[k]) + '</option>'); });
			try { var F2 = JSON.parse(sessionStorage.getItem('msm_zam_flt')) || {}; if (F2.st) st.value = F2.st; } catch (e) {}
			main.querySelector('[data-ztools]').innerHTML = '<button type="button" class="msm-btn" data-zdost>Dostawcy</button>' + (r.edycja ? '<a class="msm-btn msm-btn-primary" href="#zamowienia">Do zamówienia</a>' : '');
			main.querySelector('[data-zdost]').addEventListener('click', function () { zamDostawcy(r.edycja); });
			draw();
		}).catch(function (e) { box.innerHTML = '<p class="msm-alert msm-alert-err">' + esc(e.message) + '</p>'; });
	}

	/* ---------- Szczegóły zamówienia ---------- */
	function renderZamItem(id) {
		var main = document.getElementById('msm-main');
		main.innerHTML = '<div class="msm-cat msm-zam"><a class="msm-back" href="#zam">← Zamówienia do dostawców</a><div data-zi><div class="msm-loading">Ładowanie…</div></div></div>';
		var box = main.querySelector('[data-zi]'), DOST = null, HINTS = null;
		function pdfUrl(dl) { return buildUrl('/zam/' + id + '/pdf', dl ? { _wpnonce: C.nonce, pobierz: 1 } : { _wpnonce: C.nonce }); }
		function draw(R) {
			var z = R.zamowienie, ed = R.edycja && z.status !== 'anulowane', draft = ed && z.status === 'szkic';
			var lines = z.linie.map(function (l) { return { id: l.id, tabela: l.tabela, spec: l.spec, ilosc: l.ilosc, uwagi: l.uwagi }; });
			var acts = [];
			if (ed && z.status === 'szkic') acts.push(['wyslane', 'Oznacz jako wysłane (bez e-maila)']);
			if (ed && z.status === 'wyslane') acts.push(['szkic', 'Wróć do szkicu (popraw pozycje)']);
			if (ed && (z.status === 'wyslane' || z.status === 'czesciowo')) acts.push(['zamkniete', 'Zamknij – reszta nie przyjdzie']);
			if (ed && (z.status === 'szkic' || z.status === 'wyslane') && !z.pz.length) acts.push(['anulowane', 'Anuluj zamówienie']);
			box.innerHTML =
				'<div class="msm-pagehead msm-zi-head"><div><h1>Zamówienie ' + esc(z.numer) + '</h1><p class="msm-zi-meta">' + zamTag(z.status, z.status_txt) +
				'<span class="msm-muted">utworzył(a) ' + esc(z.kto) + ', ' + esc(fmtDate(z.kiedy)) + '</span>' + (z.wyslano ? '<span class="msm-muted">wysłano ' + esc(fmtDateTime(z.wyslano)) + (z.wyslano_do ? ' → ' + esc(z.wyslano_do) : '') + '</span>' : '') + '</p></div>' +
				'<div class="msm-pagehead__tools"><a class="msm-btn" href="' + esc(pdfUrl(true)) + '" data-view="file" data-open="' + esc(pdfUrl(false)) + '" data-name="' + esc('zamowienie-' + z.numer.replace(/[\s\/]+/g, '-') + '.pdf') + '">PDF</a>' +
				(ed ? '<button type="button" class="msm-btn' + (z.status === 'szkic' ? ' msm-btn-primary' : '') + '" data-zsend>' + (z.wyslano ? 'Wyślij ponownie' : 'Wyślij e-mailem') + '</button>' : '') +
				(acts.length ? '<button type="button" class="msm-iconbtn msm-zi-more" data-zmore aria-label="Więcej akcji">' + ICO_DOTS + '<span class="msm-zi-more__t">Więcej akcji</span></button>' : '') + '</div></div>' +
				'<form class="msm-card msm-form msm-zi-form" novalidate><div class="msm-form-err msm-alert msm-alert-err" hidden></div><div class="msm-grid msm-zi-grid">' +
				'<label class="msm-field"><span>Dostawca</span><select name="dost_id"' + (ed ? '' : ' disabled') + '><option value="' + z.dost_id + '">' + esc(z.dostawca) + '</option></select></label>' +
				'<div class="msm-field"><span>E-mail dostawcy</span><p class="msm-zi-mail">' + (z.email ? esc(z.email) : '<span class="msm-muted">brak – podasz przy wysyłce</span>') + '</p></div>' +
				'<label class="msm-field"><span>Oczekiwany termin dostawy</span><input name="termin" type="date" value="' + esc(z.termin) + '"' + (ed ? '' : ' disabled') + '></label>' +
				'<label class="msm-field full"><span>Uwagi do zamówienia (trafiają do PDF)</span><textarea name="uwagi" rows="2"' + (ed ? '' : ' disabled') + '>' + esc(z.uwagi) + '</textarea></label></div>' +
				'<div class="msm-table-wrap"><table class="msm-table msm-zit"><thead><tr><th class="num">Lp.</th><th>Materiał</th><th>Dla zleceń</th><th class="num">Ilość</th><th class="num">Przyjęto</th><th class="num">Brakuje</th><th>Uwagi</th>' + (draft ? '<th></th>' : '') + '</tr></thead><tbody data-zlines>' +
				z.linie.map(function (l, i) {
					var u = zamUnit(l.jm);
					return '<tr data-li="' + i + '"><td class="num" data-label="Lp.">' + (i + 1) + '.</td><td data-label="Materiał"><span class="msm-zb__v"><b>' + esc(l.opis) + '</b><small class="msm-muted">' + esc(l.magazyn) + '</small></span></td>' +
						'<td data-label="Dla zleceń">' + (l.zlecenia.length ? '<span class="msm-zb__v msm-zb__zl">' + l.zlecenia.map(function (x) { return '<span class="msm-chip msm-chip-sm">' + esc(x.nr) + ' · ' + fmtNum(x.ilosc) + '</span>'; }).join('') + '</span>' : '<span class="msm-muted">—</span>') + '</td>' +
						'<td class="num" data-label="Ilość">' + (draft ? '<span class="msm-zit__q"><input type="text" inputmode="decimal" data-lq value="' + esc(String(l.ilosc).replace('.', ',')) + '"> ' + u + '</span>' : '<b>' + fmtNum(l.ilosc) + ' ' + u + '</b>') + '</td>' +
						'<td class="num" data-label="Przyjęto">' + (l.przyjeto ? fmtNum(l.przyjeto) + ' ' + u : '<span class="msm-muted">—</span>') + '</td>' +
						'<td class="num" data-label="Brakuje">' + (l.brakuje > 0 && z.status !== 'szkic' ? '<b class="msm-brak">' + fmtNum(l.brakuje) + ' ' + u + '</b>' : (l.brakuje > 0 ? '<span class="msm-muted">' + fmtNum(l.brakuje) + ' ' + u + '</span>' : '<span class="msm-zam-ok">komplet</span>')) + '</td>' +
						'<td data-label="Uwagi">' + (draft ? '<input type="text" data-lu value="' + esc(l.uwagi) + '" placeholder="np. atest 3.1">' : (l.uwagi ? esc(l.uwagi) : '<span class="msm-muted">—</span>')) + '</td>' +
						(draft ? '<td class="msm-pgl-act"><button type="button" class="msm-iconbtn" data-ldel="' + i + '" title="Usuń pozycję" aria-label="Usuń pozycję">×</button></td>' : '') + '</tr>';
				}).join('') + '</tbody></table></div>' +
				(draft ? '<div data-znewline></div><button type="button" class="msm-kt-add msm-zi-add" data-zaddl>+ Dodaj pozycję</button>' : '') +
				(ed ? '<div class="msm-el-actions"><span class="msm-muted" data-zdirty></span><button type="submit" class="msm-btn msm-btn-primary" data-zsave disabled>Zapisz zmiany</button></div>' : '') + '</form>' +
				'<section class="msm-card msm-zi-pz"><header><h2>Dostawy (PZ)</h2></header>' + (z.pz.length ? '<ul class="msm-zi-pzl">' + z.pz.map(function (p) {
					return '<li><b>' + esc(p.pz) + '</b> <span class="msm-muted">' + esc(fmtDate(p.kiedy)) + '</span> · ' + esc(p.opis) + ' – <b>' + fmtNum(p.ilosc) + '</b>' + (p.rez ? ' <span class="msm-chip msm-chip-sm">zarezerwowano dla zleceń</span>' : '') + '</li>';
				}).join('') + '</ul>' : '<p class="msm-muted">Jeszcze nic nie przyjęto. Przy przyjęciu PZ od tego dostawcy system sam podpowie to zamówienie.</p>') + '</section>';
			if (!ed) return;
			var f = box.querySelector('.msm-zi-form'), save = f.querySelector('[data-zsave]'), dirty = false, added = [];
			function mark() { dirty = true; save.disabled = false; f.querySelector('[data-zdirty]').textContent = 'Niezapisane zmiany'; }
			f.addEventListener('input', mark); f.addEventListener('change', mark);
			if (DOST) fillDost(); else api('/zam/dostawcy').then(function (d) { DOST = d; fillDost(); }).catch(function () {});
			function fillDost() {
				var s = f.dost_id;
				s.innerHTML = DOST.dostawcy.map(function (d) { return '<option value="' + d.id + '"' + (d.id === z.dost_id ? ' selected' : '') + '>' + esc(d.nazwa) + '</option>'; }).join('');
				if (!DOST.dostawcy.some(function (d) { return d.id === z.dost_id; })) s.insertAdjacentHTML('afterbegin', '<option value="' + z.dost_id + '" selected>' + esc(z.dostawca) + '</option>');
			}
			if (draft) {
				box.querySelectorAll('[data-ldel]').forEach(function (b) { b.addEventListener('click', function () { b.closest('tr').hidden = true; b.closest('tr').setAttribute('data-gone', '1'); mark(); }); });
				box.querySelector('[data-zaddl]').addEventListener('click', function () {
					(HINTS ? Promise.resolve(HINTS) : zamHints().then(function (h) { HINTS = h; return h; })).then(function (H) {
						var i = added.length, wrap = document.createElement('div');
						wrap.className = 'msm-zc-row is-manual'; added.push({ el: wrap, tabela: 'blachy_pelne' });
						function inner(t) {
							return '<div class="msm-zc-row__m"><select data-zrt>' + Object.keys(ZAM_MAG).map(function (k) { return '<option value="' + k + '"' + (k === t ? ' selected' : '') + '>' + ZAM_MAG[k] + '</option>'; }).join('') + '</select>' + zamSpecHtml(t, {}, 'n' + i, H) + '</div>' +
								'<label class="msm-zc-row__q"><input type="text" inputmode="decimal" data-zrq placeholder="ilość"><span>' + (t === 'kregi' ? 'kg' : 'szt.') + '</span></label><button type="button" class="msm-iconbtn" data-zrdel aria-label="Usuń">×</button>';
						}
						function bind() {
							wrap.querySelector('[data-zrt]').addEventListener('change', function () { added[i].tabela = this.value; wrap.innerHTML = inner(this.value); bind(); });
							wrap.querySelector('[data-zrdel]').addEventListener('click', function () { wrap.remove(); added[i] = null; });
						}
						wrap.innerHTML = inner('blachy_pelne'); bind();
						box.querySelector('[data-znewline]').appendChild(wrap); mark();
					});
				});
			}
			f.addEventListener('submit', function (e) {
				e.preventDefault();
				var b = { dost_id: +f.dost_id.value, termin: f.termin.value, uwagi: f.uwagi.value };
				if (draft) {
					b.linie = [];
					box.querySelectorAll('[data-zlines] tr[data-li]').forEach(function (tr) {
						if (tr.getAttribute('data-gone')) return;
						var l = lines[+tr.getAttribute('data-li')];
						b.linie.push({ id: l.id, ilosc: tr.querySelector('[data-lq]').value, uwagi: tr.querySelector('[data-lu]').value });
					});
					added.forEach(function (a) { if (a && a.el.isConnected) b.linie.push({ tabela: a.tabela, spec: zamSpecRead(a.el), ilosc: a.el.querySelector('[data-zrq]').value }); });
				}
				elSubmit(f, save, api('/zam/' + id, { method: 'POST', body: b }), function (r) { toast('Zapisano.'); draw(r); });
			});
			var sendB = box.querySelector('[data-zsend]');
			if (sendB) sendB.addEventListener('click', function () { if (dirty) { toast('Najpierw zapisz zmiany.', 'warn'); return; } zamSend(z, R.ja, draw); });
			var more = box.querySelector('[data-zmore]');
			if (more) more.addEventListener('click', function (e) {
				e.stopPropagation();
				var old = document.querySelector('.msm-zi-menu'); if (old) { old.remove(); return; }
				var mn = document.createElement('div'); mn.className = 'msm-zi-menu msm-card';
				mn.innerHTML = acts.map(function (a) { return '<button type="button" data-zact="' + a[0] + '"' + (a[0] === 'anulowane' ? ' class="is-danger"' : '') + '>' + esc(a[1]) + '</button>'; }).join('');
				more.parentNode.style.position = 'relative'; more.parentNode.appendChild(mn);
				setTimeout(function () { document.addEventListener('click', function cl() { mn.remove(); document.removeEventListener('click', cl); }); }, 0);
				mn.querySelectorAll('[data-zact]').forEach(function (b) {
					b.addEventListener('click', function () {
						var to = b.getAttribute('data-zact');
						var go = function () { api('/zam/' + id + '/status', { method: 'POST', body: { status: to } }).then(function (r) { toast(r.message); draw(r); }).catch(function (er) { toast(er.message, 'err'); }); };
						if (to === 'anulowane' || to === 'zamkniete') {
							confirmBox(to === 'anulowane' ? 'Anulować zamówienie?' : 'Zamknąć zamówienie?', to === 'anulowane' ? 'Zamówienie ' + esc(z.numer) + ' zostanie anulowane, a braki zleceń wrócą do „Do zamówienia”. Dostawcy nic nie wysyłamy – poinformuj go sam, jeśli zamówienie było wysłane.' : 'Niedostarczone ilości przestaną być „w drodze” i wrócą do „Do zamówienia”.', to === 'anulowane' ? 'Anuluj zamówienie' : 'Zamknij', to === 'anulowane').then(function (ok) { if (ok) go(); });
						} else go();
					});
				});
			});
		}
		api('/zam/' + id, { query: { _: Date.now() } }).then(draw).catch(function (e) { box.innerHTML = '<p class="msm-alert msm-alert-err">' + esc(e.message) + '</p>'; });
	}

	function zamSend(z, me, done) {
		var body = '<form class="msm-form" novalidate><div class="msm-form-err msm-alert msm-alert-err" hidden></div>' +
			'<label class="msm-field" data-field="do"><span>Do (e-mail dostawcy) <i class="msm-req">*</i></span><input name="do" type="text" value="' + esc(z.email) + '" placeholder="zamowienia@dostawca.pl" autocomplete="off"><em class="msm-ferr"></em></label>' +
			'<label class="msm-check" data-zrem hidden><input type="checkbox" name="zapamietaj" checked> Zapisz ten adres u dostawcy</label>' +
			'<label class="msm-check"><input type="checkbox" name="kopia" checked> Wyślij kopię do mnie' + (me ? ' (' + esc(me) + ')' : '') + '</label>' +
			'<label class="msm-field"><span>Dodatkowa wiadomość (opcjonalnie, na początku e-maila)</span><textarea name="tresc" rows="3"></textarea></label>' +
			'<p class="msm-small msm-muted">W załączniku PDF zamówienia ' + esc(z.numer) + '. Odpowiedź dostawcy trafi na Twój adres. Treść e-maila zmienisz w Techniczne → Szablony e-maili.</p></form>';
		var m = openModal('Wyślij ' + z.numer + ' do dostawcy', body, '<button type="button" class="msm-btn" data-close>Anuluj</button><button type="button" class="msm-btn msm-btn-primary" data-ok>Wyślij</button>');
		var f = m.querySelector('form'), ok = m.querySelector('[data-ok]');
		f.do.addEventListener('input', function () { f.querySelector('[data-zrem]').hidden = f.do.value.trim() === z.email; });
		function go() {
			elSubmit(f, ok, api('/zam/' + z.id + '/wyslij', { method: 'POST', body: { do: f.do.value, kopia: f.kopia.checked, tresc: f.tresc.value, zapamietaj: !f.querySelector('[data-zrem]').hidden && f.zapamietaj.checked } }), function (r) { closeModal(); toast(r.message); done(r); });
		}
		ok.addEventListener('click', go);
		f.addEventListener('submit', function (e) { e.preventDefault(); go(); });
		setTimeout(function () { f.do.focus(); }, 60);
	}

	/* ---------- Dostawcy ---------- */
	function zamDostawcy(edit) {
		var m = openModal('Dostawcy', '<div data-dl><div class="msm-loading">Ładowanie…</div></div>', '<button type="button" class="msm-btn" data-close>Zamknij</button>', true);
		var box = m.querySelector('[data-dl]');
		function load() { api('/zam/dostawcy').then(draw).catch(function (e) { box.innerHTML = '<p class="msm-alert msm-alert-err">' + esc(e.message) + '</p>'; }); }
		function draw(D) {
			box.innerHTML = (edit ? '<form class="msm-form msm-dform" novalidate><div class="msm-form-err msm-alert msm-alert-err" hidden></div><input type="hidden" name="id" value="0"><div class="msm-grid">' +
				'<label class="msm-field" data-field="nazwa"><span>Nazwa <i class="msm-req">*</i></span><input name="nazwa" list="dl-pz" autocomplete="off"><datalist id="dl-pz">' + D.z_pz.map(function (n) { return '<option value="' + esc(n) + '">'; }).join('') + '</datalist><em class="msm-ferr"></em></label>' +
				'<label class="msm-field" data-field="email"><span>E-mail do zamówień</span><input name="email" type="text" autocomplete="off" placeholder="można kilka, po przecinku"><em class="msm-ferr"></em></label>' +
				'<label class="msm-field"><span>Osoba kontaktowa</span><input name="kontakt" autocomplete="off"></label><label class="msm-field"><span>Telefon</span><input name="telefon" autocomplete="off"></label></div>' +
				'<div class="msm-dform__act"><button type="button" class="msm-btn msm-btn-ghost msm-btn-sm" data-dreset hidden>Anuluj edycję</button><button type="submit" class="msm-btn msm-btn-primary" data-dsave>Dodaj dostawcę</button></div></form>' : '') +
				(D.dostawcy.length ? '<ul class="msm-dlist">' + D.dostawcy.map(function (d) {
					return '<li><div><b>' + esc(d.nazwa) + '</b><small class="msm-muted">' + esc([d.email || 'brak e-maila', d.kontakt, d.telefon].filter(Boolean).join(' · ')) + '</small></div>' +
						(edit ? '<span><button type="button" class="msm-btn msm-btn-sm msm-btn-ghost" data-dedit="' + d.id + '">Edytuj</button><button type="button" class="msm-iconbtn" data-ddel="' + d.id + '" aria-label="Usuń">×</button></span>' : '') + '</li>';
				}).join('') + '</ul>' : '<p class="msm-muted">Brak dostawców. ' + (D.z_pz.length ? 'Nazwy z dotychczasowych PZ podpowiadają się w polu „Nazwa”.' : '') + '</p>');
			if (!edit) return;
			var f = box.querySelector('form'), sv = f.querySelector('[data-dsave]');
			function reset() { f.reset(); f.id.value = 0; sv.textContent = 'Dodaj dostawcę'; f.querySelector('[data-dreset]').hidden = true; }
			f.querySelector('[data-dreset]').addEventListener('click', reset);
			f.addEventListener('submit', function (e) {
				e.preventDefault();
				elSubmit(f, sv, api('/zam/dostawcy', { method: 'POST', body: { id: +f.id.value, nazwa: f.nazwa.value, email: f.email.value, kontakt: f.kontakt.value, telefon: f.telefon.value } }), function () { toast('Zapisano dostawcę.'); load(); });
			});
			box.querySelectorAll('[data-dedit]').forEach(function (b) {
				b.addEventListener('click', function () {
					var d = D.dostawcy.filter(function (x) { return x.id === +b.getAttribute('data-dedit'); })[0];
					f.id.value = d.id; f.nazwa.value = d.nazwa; f.email.value = d.email; f.kontakt.value = d.kontakt; f.telefon.value = d.telefon;
					sv.textContent = 'Zapisz zmiany'; f.querySelector('[data-dreset]').hidden = false; f.nazwa.focus();
				});
			});
			box.querySelectorAll('[data-ddel]').forEach(function (b) {
				b.addEventListener('click', function () {
					api('/zam/dostawcy/' + b.getAttribute('data-ddel') + '/delete', { method: 'POST', body: {} }).then(function () { toast('Usunięto dostawcę.'); load(); }).catch(function (e) { toast(e.message, 'err'); });
				});
			});
		}
		load();
	}
	/* ---------------- start ---------------- */

	shell();
	startIdleLogout();
	/* Tryb „sam nagłówek” na stronie innej wtyczki (np. Grafik pracy): menu prowadzi do systemu, bez treści i trasowania. */
	if (C.shellOnly) {
		var mm = root.querySelector('#msm-main'); if (mm) mm.remove();
		root.querySelectorAll('[data-inwbtn]').forEach(function (b) { b.remove(); });
		root.querySelectorAll('a[href^="#"]').forEach(function (a) { a.setAttribute('href', C.appUrl + a.getAttribute('href')); });
		root.querySelectorAll('[data-top="tech"]').forEach(function (a) { a.classList.add('active'); });
		root.querySelectorAll('.msm-techm__i').forEach(function (a) { if (C.shellOnly === 'grafik' && a.getAttribute('href') === C.grafik) a.classList.add('is-current'); });
		pollZam(); pollWnioski();
		setInterval(function () { if (!document.hidden) pollWnioski(); }, 60000);
		return;
	}
	syncInwUi();
	pollZam();
	try { var pending = sessionStorage.getItem('msm_toast'); if (pending) { sessionStorage.removeItem('msm_toast'); setTimeout(function () { toast(pending); }, 300); } } catch (e) {}
	pollWnioski();
	pwaInit();
	clAnnounce();
	/* W tle odpytujemy tylko, gdy użytkownik włączył powiadomienia (inaczej nie ma po co). */
	setInterval(function () { if (!document.hidden || pwaNotifOn()) pollWnioski(); }, 60000);
	document.addEventListener('visibilitychange', function () { if (!document.hidden) pollWnioski(); });
	window.addEventListener('hashchange', route);
	route();
})();
