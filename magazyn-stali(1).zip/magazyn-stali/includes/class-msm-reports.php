<?php
/**
 * Pulpit, karta zlecenia i stany minimalne (raporty tylko do odczytu).
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MSM_Reports {

	/** Dane pulpitu. */
	public static function dashboard() {
		global $wpdb;
		$P = msm_table( 'pobrania' );

		// Stan magazynu w kg.
		$stan = array();
		foreach ( array( 'stal', 'blachy_pelne', 'blachy_niepelne' ) as $t ) {
			$T = msm_table( $t );
			$kg = (float) $wpdb->get_var( "SELECT COALESCE(SUM(suma_kg),0) FROM `$T`" ); // phpcs:ignore
			$stan[] = array( 'label' => msm_schema()[ $t ]['label'], 'kg' => round( $kg, 1 ) );
		}
		$K = msm_table( 'kregi' );
		foreach ( $wpdb->get_results( "SELECT lokalizacja, COALESCE(SUM(ilosc),0) kg FROM `$K` GROUP BY lokalizacja", ARRAY_A ) as $r ) { // phpcs:ignore
			$stan[] = array( 'label' => 'Kręgi – ' . ( $r['lokalizacja'] ?: '—' ), 'kg' => round( (float) $r['kg'], 1 ) );
		}
		$stan_total = 0;
		foreach ( $stan as $s ) { $stan_total += $s['kg']; }

		// Pobrania: tydzień / miesiąc.
		$week  = gmdate( 'Y-m-d', current_time( 'timestamp' ) - 6 * DAY_IN_SECONDS );
		$month = current_time( 'Y-m-' ) . '01';
		$pob_week  = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM `$P` WHERE data >= %s", $week ) ); // phpcs:ignore
		$pob_month = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM `$P` WHERE data >= %s", $month ) ); // phpcs:ignore

		// Najczęściej pobierane (po materiale).
		$top = $wpdb->get_results( "SELECT material, COUNT(*) n FROM `$P` WHERE material <> '' GROUP BY material ORDER BY n DESC, material ASC LIMIT 8", ARRAY_A ); // phpcs:ignore
		$top = array_map( function ( $r ) { return array( 'material' => $r['material'], 'n' => (int) $r['n'] ); }, $top );

		// Wnioski czekające.
		$W = msm_table( 'wnioski' );
		$nowe       = (int) $wpdb->get_var( "SELECT COUNT(*) FROM `$W` WHERE status = 'nowy'" ); // phpcs:ignore
		$do_wydania = (int) $wpdb->get_var( "SELECT COUNT(*) FROM `$W` WHERE status = 'zaakceptowany'" ); // phpcs:ignore

		return array(
			'stan'        => $stan,
			'stan_total'  => round( $stan_total, 1 ),
			'pob_week'    => $pob_week,
			'pob_month'   => $pob_month,
			'top'         => $top,
			'wnioski'     => array( 'nowe' => $nowe, 'do_wydania' => $do_wydania ),
			'lowstock'    => count( self::low_stock() ),
		);
	}

	/** Karta zlecenia – wszystko powiązane z numerem zlecenia. */
	public static function zlecenie( $nr ) {
		global $wpdb;
		$nr = trim( (string) $nr );
		if ( '' === $nr ) {
			return array( 'nr' => '', 'pobrania' => array(), 'wnioski' => array(), 'wz' => array(), 'przesylki' => null, 'sumy' => self::empty_sumy() );
		}
		$like = '%' . $wpdb->esc_like( $nr ) . '%';

		$P = msm_table( 'pobrania' );
		$pob = $wpdb->get_results( $wpdb->prepare( "SELECT data, tabela, material, ilosc, jednostka, tryb, odc_szt, odc_dl, zlecenie, odbiorca, uwagi, wpisana, user_name, created_at FROM `$P` WHERE zlecenie LIKE %s ORDER BY data DESC, id DESC", $like ), ARRAY_A ); // phpcs:ignore

		$W = msm_table( 'wnioski' );
		$wn = $wpdb->get_results( $wpdb->prepare( "SELECT data, typ, material, ilosc, jednostka, zlecenie, rysunek, uwagi, status, user_name, decided_name, admin_note FROM `$W` WHERE zlecenie LIKE %s ORDER BY data DESC, id DESC", $like ), ARRAY_A ); // phpcs:ignore

		$WP = $wpdb->prefix . 'msm_wz_poz';
		$WZ = msm_table( 'wz' );
		$wz = $wpdb->get_results( $wpdb->prepare(
			"SELECT p.indeks, p.nazwa material, p.ilosc, p.jm jednostka, p.zlecenie, p.rysunek, p.src,
			        w.numer, w.data_wysylki, w.odbiorca, w.przeznaczenie, w.transport, w.status, w.uwagi
			 FROM `$WP` p JOIN `$WZ` w ON w.id = p.wz_id WHERE p.zlecenie LIKE %s ORDER BY w.id DESC, p.lp ASC", $like ), ARRAY_A ); // phpcs:ignore

		$R  = msm_table( 'rezerwacje' );
		$rez = $wpdb->get_results( $wpdb->prepare( "SELECT created_at, material, ilosc, tryb, termin, status, user_name, decided_name, uwagi FROM `$R` WHERE zlecenie LIKE %s ORDER BY id DESC", $like ), ARRAY_A ); // phpcs:ignore

		// Sumy kg / mb / szt z pobrań.
		$sumy = self::empty_sumy();
		foreach ( $pob as &$r ) {
			$r['ilosc'] = (float) $r['ilosc'];
			self::add_sum( $sumy, $r['jednostka'], $r['ilosc'] );
		}
		unset( $r );
		foreach ( $wn as &$r ) { $r['ilosc'] = (float) $r['ilosc']; }
		unset( $r );
		foreach ( $wz as &$r ) { $r['ilosc'] = (float) $r['ilosc']; }
		unset( $r );
		foreach ( $rez as &$r ) { $r['ilosc'] = (float) $r['ilosc']; }
		unset( $r );

		$materialy = array();
		foreach ( array_merge( $pob, $wn, $wz ) as $r ) {
			$mm = trim( (string) ( $r['material'] ?? '' ) );
			if ( '' !== $mm ) { $materialy[ $mm ] = true; }
		}

		// Przesyłki przychodzące do zlecenia – tylko dla osób z dostępem do zakładki Przesyłki (inaczej null = sekcja ukryta).
		$prz = null;
		if ( class_exists( 'MSM_Przesylki' ) && ! is_wp_error( MSM_Przesylki::can_view() ) ) {
			$prz = MSM_Przesylki::for_number( $nr );
		}

		return array(
			'nr'         => $nr,
			'przesylki'  => $prz,
			'pobrania'   => $pob,
			'wnioski'    => $wn,
			'wz'         => $wz,
			'rezerwacje' => $rez,
			'sumy'       => $sumy,
			'odbiorcy'   => array_values( array_unique( array_filter( array_map( function ( $r ) { return trim( (string) $r['odbiorca'] ); }, $pob ) ) ) ),
			'materialy'  => array_keys( $materialy ),
			'projekt'    => self::projekt( $nr ),
		);
	}

	/** Dane zlecenia z Produkcji (klient, nr zlecenia klienta, start i koniec) – po dokładnym numerze, najnowsze. */
	private static function projekt( $nr ) {
		global $wpdb;
		if ( ! class_exists( 'MSM_Prod' ) ) {
			return null;
		}
		$T = MSM_Prod::TZ();
		if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $T ) ) !== $T ) {
			return null;
		}
		$z = $wpdb->get_row( $wpdb->prepare( "SELECT id, nr_zlec, klient, nr_zlec_klienta, start_zlec, koniec_zlec, karta FROM `$T` WHERE UPPER(TRIM(nr_zlec)) = %s ORDER BY id DESC LIMIT 1", mb_strtoupper( trim( (string) $nr ) ) ), ARRAY_A ); // phpcs:ignore
		if ( ! $z ) {
			return null;
		}
		$k = json_decode( (string) $z['karta'], true );
		return array(
			'id'              => (int) $z['id'],
			'klient'          => (string) $z['klient'],
			'nr_zlec_klienta' => (string) $z['nr_zlec_klienta'],
			'start'           => (string) $z['start_zlec'],
			'koniec'          => (string) $z['koniec_zlec'],
			'nazwa'           => is_array( $k ) ? (string) ( $k['nazwa_projektu'] ?? '' ) : '',
			'link'            => class_exists( 'MSM_Perms' ) && MSM_Perms::menu_on( 'prod_zlecenia' ),
		);
	}

	private static function empty_sumy() {
		return array( 'kg' => 0, 'mb' => 0, 'szt' => 0 );
	}
	private static function add_sum( &$s, $jm, $val ) {
		$jm = mb_strtolower( trim( (string) $jm ) );
		if ( 'kg' === $jm ) { $s['kg'] += $val; }
		elseif ( 'm' === $jm || 'mb' === $jm ) { $s['mb'] += $val; }
		else { $s['szt'] += $val; }
		$s['kg'] = round( $s['kg'], 2 );
		$s['mb'] = round( $s['mb'], 2 );
		$s['szt'] = round( $s['szt'], 2 );
	}

	/** Pozycje poniżej stanu minimalnego (do zamówienia). */
	/**
	 * Do zamówienia. Obecnie wyłącznie blachy pełne (pogrupowane po tożsamości,
	 * z rozbiciem na rozmiary). W przyszłości dojdzie tu szafa BHP.
	 */
	public static function low_stock() {
		if ( ! msm_col( 'blachy_pelne', 'min_stan' ) ) {
			return array();
		}
		return self::low_stock_blachy_pelne( msm_table( 'blachy_pelne' ) );
	}

	/**
	 * Blachy pełne pogrupowane po tożsamości (gatunek + grubość + materiał).
	 * Grupa trafia do zamówienia, gdy choć jeden rozmiar jest poniżej stanu minimalnego;
	 * w rozbiciu pokazujemy wszystkie rozmiary tej blachy (również te, które są na stanie).
	 */
	private static function low_stock_blachy_pelne( $T ) {
		global $wpdb;
		$rows   = $wpdb->get_results( "SELECT * FROM `$T` ORDER BY gatunek, grubosc, wymiar_a, wymiar_b", ARRAY_A ); // phpcs:ignore
		$groups = array();
		foreach ( $rows as $r ) {
			$key = self::blacha_key( $r );
			if ( ! isset( $groups[ $key ] ) ) {
				$groups[ $key ] = array( 'ident' => $r, 'sizes' => array(), 'any_low' => false, 'brak_sum' => 0 );
			} elseif ( '' === trim( (string) ( $groups[ $key ]['ident']['material'] ?? '' ) ) && '' !== trim( (string) ( $r['material'] ?? '' ) ) ) {
				$groups[ $key ]['ident'] = $r; // nazwa grupy z pozycji z wypełnionym materiałem (np. „CZARNA · 4 mm · S235”)
			}
			$min = (float) $r['min_stan'];
			$ilo = (float) $r['ilosc'];
			$low = ( $min > 0 && $ilo < $min );
			if ( $low ) {
				$groups[ $key ]['any_low']   = true;
				$groups[ $key ]['brak_sum'] += ( $min - $ilo );
			}
			$groups[ $key ]['sizes'][] = array(
				'id'       => (int) $r['id'],
				'rozmiar'  => self::blacha_rozmiar( $r ),
				'ilosc'    => $ilo,
				'min_stan' => $min,
				'brak'     => $low ? round( $min - $ilo, 0 ) : 0,
				'low'      => $low,
				'opis'     => trim( (string) $r['gatunek'] ) . ( '' !== trim( (string) ( $r['material'] ?? '' ) ) ? ' · ' . trim( (string) $r['material'] ) : '' ),
			);
		}
		$out = array();
		foreach ( $groups as $g ) {
			if ( ! $g['any_low'] ) {
				continue;
			}
			// Opis pozycji tylko przy rozmiarach zapisanych inaczej niż nazwa grupy (np. „S235JR” z PZ obok „CZARNA · S235”).
			$own = trim( (string) $g['ident']['gatunek'] ) . ( '' !== trim( (string) ( $g['ident']['material'] ?? '' ) ) ? ' · ' . trim( (string) $g['ident']['material'] ) : '' );
			foreach ( $g['sizes'] as &$s ) {
				if ( mb_strtolower( $s['opis'] ) === mb_strtolower( $own ) ) {
					$s['opis'] = '';
				}
			}
			unset( $s );
			$out[] = array(
				'tabela'      => 'blachy_pelne',
				'label'       => msm_schema()['blachy_pelne']['label'],
				'nazwa'       => self::blacha_ident( $g['ident'] ),
				'grouped'     => true,
				'gatunek'     => trim( (string) $g['ident']['gatunek'] ),
				'grubosc'     => MSM_Calc::fmt( $g['ident']['grubosc'] ),
				'material'    => trim( (string) ( $g['ident']['material'] ?? '' ) ),
				'stal'        => self::blacha_grade( $g['ident'] ),
				'sizes'       => $g['sizes'],
				'brak'        => round( $g['brak_sum'], 0 ),
				'jednostka'   => 'szt',
			);
		}
		// Sortowanie: grubość rosnąco, potem gatunek, potem największy brak.
		usort( $out, function ( $a, $b ) {
			$ga = (float) str_replace( ',', '.', (string) $a['grubosc'] );
			$gb = (float) str_replace( ',', '.', (string) $b['grubosc'] );
			if ( $ga !== $gb ) {
				return $ga <=> $gb;
			}
			$c = strcmp( (string) $a['gatunek'], (string) $b['gatunek'] );
			if ( 0 !== $c ) {
				return $c;
			}
			return $b['brak'] <=> $a['brak'];
		} );
		return $out;
	}

	/**
	 * Filtruje listę „do zamówienia” po gatunku, grubości i rozmiarze (multi-select).
	 * Puste zestawy = bez filtra. Filtr rozmiaru zawęża też listę rozmiarów w grupie.
	 */
	public static function filter_zamowienia( $rows, $gat = array(), $grub = array(), $rozm = array(), $mat = array() ) {
		$norm = function ( $arr ) { return array_values( array_filter( array_map( function ( $v ) { return trim( (string) $v ); }, (array) $arr ), 'strlen' ) ); };
		$gat  = array_map( 'mb_strtolower', $norm( $gat ) );
		$grub = $norm( $grub );
		$rozm = $norm( $rozm );
		$mat  = array_map( 'mb_strtolower', $norm( $mat ) );
		$out  = array();
		foreach ( $rows as $r ) {
			if ( $mat && ! in_array( mb_strtolower( self::zam_material( $r ) ), $mat, true ) ) {
				continue;
			}
			if ( $gat && ! in_array( mb_strtolower( (string) ( $r['gatunek'] ?? '' ) ), $gat, true ) ) {
				continue;
			}
			if ( $grub && ! in_array( (string) ( $r['grubosc'] ?? '' ), $grub, true ) ) {
				continue;
			}
			if ( $rozm && ! empty( $r['sizes'] ) ) {
				$r['sizes'] = array_values( array_filter( $r['sizes'], function ( $s ) use ( $rozm ) {
					return in_array( (string) $s['rozmiar'], $rozm, true );
				} ) );
				if ( ! $r['sizes'] ) {
					continue;
				}
			}
			$out[] = $r;
		}
		return $out;
	}

	/**
	 * Gatunek stali blachy (S235, S355, DC01…) z pola Materiał albo Gatunek – bez oznaczeń jakości
	 * (S235JR → S235). Pusty, gdy to nie jest gatunek stali (NIERDZEWKA, MIEDŹ…).
	 */
	public static function blacha_grade( $r ) {
		foreach ( array( $r['material'] ?? '', $r['gatunek'] ?? '' ) as $v ) {
			$v = mb_strtoupper( preg_replace( '/\s+/u', '', (string) $v ) );
			if ( preg_match( '/(?<![A-Z0-9])(S\d{3}|DC0\d|DD1\d|DX5\d)/', $v, $m ) ) {
				return $m[1];
			}
		}
		return '';
	}

	/**
	 * Tożsamość blachy w „Do zamówienia”: grubość + gatunek stali, gdy da się go odczytać
	 * („CZARNA · S235” z Excela = „S235JR” z PZ), w przeciwnym razie gatunek + materiał.
	 */
	public static function blacha_key( $r ) {
		$norm  = function ( $v ) { return mb_strtolower( preg_replace( '/\s+/u', '', (string) $v ) ); };
		$grade = self::blacha_grade( $r );
		return (float) $r['grubosc'] . '|' . ( '' !== $grade ? 'stal:' . mb_strtolower( $grade ) : $norm( $r['gatunek'] ) . '|' . $norm( $r['material'] ?? '' ) );
	}

	/** Wartość filtra „Materiał”: gatunek stali (S235) albo wpisany materiał. */
	public static function zam_material( $r ) {
		return '' !== (string) ( $r['stal'] ?? '' ) ? (string) $r['stal'] : (string) ( $r['material'] ?? '' );
	}

	private static function blacha_ident( $r ) {
		$parts = array();
		if ( '' !== trim( (string) $r['gatunek'] ) ) {
			$parts[] = trim( (string) $r['gatunek'] );
		}
		if ( null !== $r['grubosc'] && '' !== (string) $r['grubosc'] ) {
			$parts[] = MSM_Calc::fmt( $r['grubosc'] ) . ' mm';
		}
		if ( ! empty( $r['material'] ) ) {
			$parts[] = trim( (string) $r['material'] );
		}
		return $parts ? implode( ' · ', $parts ) : 'Blacha';
	}

	private static function blacha_rozmiar( $r ) {
		$a = $r['wymiar_a'];
		$b = $r['wymiar_b'];
		if ( ( null === $a || '' === (string) $a ) && ( null === $b || '' === (string) $b ) ) {
			return '—';
		}
		if ( null === $b || '' === (string) $b ) {
			return MSM_Calc::fmt( $a );
		}
		return MSM_Calc::fmt( $a ) . ' × ' . MSM_Calc::fmt( $b );
	}
}
