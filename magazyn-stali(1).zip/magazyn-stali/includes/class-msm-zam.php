<?php
/**
 * Zapotrzebowanie materiału dla zleceń i zamówienia do dostawców.
 *
 * - Zapotrzebowanie (pozycja zlecenia): to, co jest na stanie, od razu rezerwuje się dla zlecenia,
 *   a brakująca reszta trafia do „Do zamówienia” (sekcja „Braki dla zleceń”).
 * - Zamówienie do dostawcy: tworzone z zaznaczonych braków i pozycji poniżej minimum, PDF, wysyłka e-mailem.
 * - Przyjęcie PZ: pozycje dostawy dopasowane do otwartych zamówień (po potwierdzeniu) zwiększają „przyjęto”,
 *   a przyjęty materiał od razu rezerwuje się dla zleceń, które na niego czekały.
 *
 * Materiały: stal (szt.), blachy pełne (szt.), kręgi (kg).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MSM_Zam {

	const TABLES = array( 'blachy_pelne', 'kregi', 'stal' );
	const KEYS   = array(
		'stal'         => array( 'opis', 'szer', 'wys', 'scianka', 'gatunek', 'dlugosc' ),
		'blachy_pelne' => array( 'gatunek', 'grubosc', 'wymiar_a', 'wymiar_b', 'material' ),
		'kregi'        => array( 'oznaczenie', 'izolacja', 'grubosc', 'szerokosc' ),
	);
	const NUM    = array( 'szer', 'wys', 'scianka', 'dlugosc', 'grubosc', 'wymiar_a', 'wymiar_b', 'szerokosc' );
	/** Statusy zamówienia: szkic → wysłane → częściowo przyjęte → zrealizowane; zamknięte (z brakami) / anulowane. */
	const ST     = array( 'szkic' => 'Szkic', 'wyslane' => 'Wysłane', 'czesciowo' => 'Częściowo przyjęte', 'zrealizowane' => 'Zrealizowane', 'zamkniete' => 'Zamknięte', 'anulowane' => 'Anulowane' );
	const OPEN   = array( 'szkic', 'wyslane', 'czesciowo' );

	public static function TD() { global $wpdb; return $wpdb->prefix . 'msm_dost'; }
	public static function TZ() { global $wpdb; return $wpdb->prefix . 'msm_zap'; }
	public static function T() { global $wpdb; return $wpdb->prefix . 'msm_zam'; }
	public static function TP() { global $wpdb; return $wpdb->prefix . 'msm_zam_poz'; }
	public static function TL() { global $wpdb; return $wpdb->prefix . 'msm_zam_pz'; }

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
	}

	public static function create_tables() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$c = $wpdb->get_charset_collate();
		dbDelta( 'CREATE TABLE ' . self::TD() . " (
id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
nazwa varchar(190) NOT NULL DEFAULT '',
email varchar(190) NOT NULL DEFAULT '',
kontakt varchar(190) NOT NULL DEFAULT '',
telefon varchar(60) NOT NULL DEFAULT '',
uwagi text NULL,
created_at datetime NULL,
PRIMARY KEY  (id),
KEY nazwa (nazwa)
) $c;" );
		dbDelta( 'CREATE TABLE ' . self::TZ() . " (
id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
zlec_id bigint(20) unsigned NOT NULL DEFAULT 0,
det_id bigint(20) unsigned NOT NULL DEFAULT 0,
nr_zlec varchar(60) NOT NULL DEFAULT '',
tabela varchar(30) NOT NULL DEFAULT '',
spec text NULL,
opis varchar(255) NOT NULL DEFAULT '',
jm varchar(10) NOT NULL DEFAULT 'szt',
ilosc decimal(14,3) NOT NULL DEFAULT 0,
zarezerw decimal(14,3) NOT NULL DEFAULT 0,
z_dost decimal(14,3) NOT NULL DEFAULT 0,
rez text NULL,
status varchar(20) NOT NULL DEFAULT 'otwarte',
uwagi text NULL,
created_by bigint(20) unsigned NOT NULL DEFAULT 0,
created_name varchar(190) NOT NULL DEFAULT '',
created_at datetime NULL,
PRIMARY KEY  (id),
KEY det (det_id),
KEY status (status)
) $c;" );
		dbDelta( 'CREATE TABLE ' . self::T() . " (
id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
numer varchar(40) NOT NULL DEFAULT '',
nr_seq int(11) NOT NULL DEFAULT 0,
rok smallint(6) NOT NULL DEFAULT 0,
miesiac tinyint(4) NOT NULL DEFAULT 0,
dost_id bigint(20) unsigned NOT NULL DEFAULT 0,
dostawca varchar(190) NOT NULL DEFAULT '',
email varchar(190) NOT NULL DEFAULT '',
status varchar(20) NOT NULL DEFAULT 'szkic',
termin date NULL,
uwagi text NULL,
created_by bigint(20) unsigned NOT NULL DEFAULT 0,
created_name varchar(190) NOT NULL DEFAULT '',
created_at datetime NULL,
updated_at datetime NULL,
sent_at datetime NULL,
sent_to varchar(255) NOT NULL DEFAULT '',
PRIMARY KEY  (id),
KEY status (status),
KEY rok (rok,nr_seq)
) $c;" );
		dbDelta( 'CREATE TABLE ' . self::TP() . " (
id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
zam_id bigint(20) unsigned NOT NULL,
lp int(11) NOT NULL DEFAULT 0,
tabela varchar(30) NOT NULL DEFAULT '',
spec text NULL,
opis varchar(255) NOT NULL DEFAULT '',
jm varchar(10) NOT NULL DEFAULT 'szt',
ilosc decimal(14,3) NOT NULL DEFAULT 0,
przyjeto decimal(14,3) NOT NULL DEFAULT 0,
zap text NULL,
uwagi varchar(255) NOT NULL DEFAULT '',
PRIMARY KEY  (id),
KEY zam (zam_id)
) $c;" );
		dbDelta( 'CREATE TABLE ' . self::TL() . " (
id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
zam_poz_id bigint(20) unsigned NOT NULL,
zam_id bigint(20) unsigned NOT NULL DEFAULT 0,
pz_id bigint(20) unsigned NOT NULL,
pz_numer varchar(40) NOT NULL DEFAULT '',
item_table varchar(30) NOT NULL DEFAULT '',
item_id bigint(20) unsigned NOT NULL DEFAULT 0,
ilosc decimal(14,3) NOT NULL DEFAULT 0,
rez text NULL,
created_at datetime NULL,
PRIMARY KEY  (id),
KEY poz (zam_poz_id),
KEY pz (pz_id)
) $c;" );
	}

	public static function ready() {
		global $wpdb;
		static $ok = null;
		if ( null === $ok ) {
			$ok = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', self::T() ) ) === self::T();
		}
		return $ok;
	}

	/* ---------------- uprawnienia ---------------- */

	public static function can_view() {
		if ( ! is_user_logged_in() || ! current_user_can( 'msm_view' ) ) {
			return new WP_Error( 'msm_forbidden', 'Brak dostępu.', array( 'status' => 403 ) );
		}
		return MSM_Perms::menu_on( 'zam_dost' ) || MSM_Perms::menu_on( 'zamowienia' ) ? true : new WP_Error( 'msm_forbidden', 'Zamówienia do dostawców są dla Ciebie wyłączone.', array( 'status' => 403 ) );
	}

	public static function is_editor() {
		return MSM_Perms::is_wp_admin() || MSM_Perms::cap_on( 'zamowienia' );
	}

	public static function can_edit() {
		$c = self::can_view();
		if ( is_wp_error( $c ) ) {
			return $c;
		}
		return self::is_editor() ? true : new WP_Error( 'msm_forbidden', 'Nie masz uprawnienia do zamówień u dostawców.', array( 'status' => 403 ) );
	}

	/** Zapotrzebowanie może zgłosić każdy z dostępem do zleceń produkcji. */
	public static function can_zap() {
		if ( ! is_user_logged_in() || ! current_user_can( 'msm_view' ) ) {
			return new WP_Error( 'msm_forbidden', 'Brak dostępu.', array( 'status' => 403 ) );
		}
		return MSM_Perms::menu_on( 'prod_zlecenia' ) ? true : new WP_Error( 'msm_forbidden', 'Brak dostępu do zleceń produkcji.', array( 'status' => 403 ) );
	}

	public static function routes() {
		$ns = MSM_Rest::NS;
		$v  = array( __CLASS__, 'can_view' );
		$e  = array( __CLASS__, 'can_edit' );
		$z  = array( __CLASS__, 'can_zap' );
		register_rest_route( $ns, '/zap', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'zap_add_r' ), 'permission_callback' => $z ) );
		register_rest_route( $ns, '/zap/(?P<id>\d+)/delete', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'zap_del_r' ), 'permission_callback' => $z ) );
		register_rest_route( $ns, '/zap/podpowiedzi', array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'hints_r' ), 'permission_callback' => $z ) );
		register_rest_route( $ns, '/zam/braki', array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'braki_r' ), 'permission_callback' => $v ) );
		register_rest_route( $ns, '/zam/dostawcy', array(
			array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'dost_list_r' ), 'permission_callback' => $v ),
			array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'dost_save_r' ), 'permission_callback' => $e ),
		) );
		register_rest_route( $ns, '/zam/dostawcy/(?P<id>\d+)/delete', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'dost_del_r' ), 'permission_callback' => $e ) );
		register_rest_route( $ns, '/zam', array(
			array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'list_r' ), 'permission_callback' => $v ),
			array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'add_r' ), 'permission_callback' => $e ),
		) );
		register_rest_route( $ns, '/zam/(?P<id>\d+)', array(
			array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'get_r' ), 'permission_callback' => $v ),
			array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'save_r' ), 'permission_callback' => $e ),
		) );
		register_rest_route( $ns, '/zam/(?P<id>\d+)/status', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'status_r' ), 'permission_callback' => $e ) );
		register_rest_route( $ns, '/zam/(?P<id>\d+)/wyslij', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'send_r' ), 'permission_callback' => $e ) );
		register_rest_route( $ns, '/zam/(?P<id>\d+)/pdf', array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'pdf_r' ), 'permission_callback' => $v ) );
		register_rest_route( $ns, '/zam/dopasuj', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'match_r' ), 'permission_callback' => function () { return current_user_can( 'msm_view' ); } ) );
	}

	/* ---------------- specyfikacja materiału ---------------- */

	public static function unit( $table ) {
		return 'kg' === msm_unit( $table ) ? 'kg' : 'szt';
	}

	/** Czyści specyfikację: tylko pola tożsamości materiału, liczby jako float. */
	public static function spec_clean( $table, $in ) {
		$out = array();
		foreach ( self::KEYS[ $table ] ?? array() as $k ) {
			$v = $in[ $k ] ?? '';
			if ( in_array( $k, self::NUM, true ) ) {
				$f = MSM_Calc::f( $v );
				if ( null !== $f && $f > 0 ) {
					$out[ $k ] = $f;
				}
			} else {
				$v = mb_substr( trim( sanitize_text_field( (string) $v ) ), 0, 120 );
				if ( '' !== $v ) {
					$out[ $k ] = $v;
				}
			}
		}
		return $out;
	}

	/** Minimalne dane, żeby dostawca wiedział, co dostarczyć. */
	public static function spec_missing( $table, array $s ) {
		switch ( $table ) {
			case 'blachy_pelne':
				if ( empty( $s['grubosc'] ) ) {
					return 'Podaj grubość blachy.';
				}
				if ( empty( $s['gatunek'] ) && empty( $s['material'] ) ) {
					return 'Podaj gatunek lub materiał blachy (np. S235, DC01).';
				}
				return '';
			case 'kregi':
				return empty( $s['oznaczenie'] ) || empty( $s['grubosc'] ) ? 'Podaj oznaczenie blachy i grubość kręgu.' : '';
			case 'stal':
				return empty( $s['opis'] ) || empty( $s['szer'] ) ? 'Podaj rodzaj profilu i wymiar.' : '';
		}
		return 'Nieznany magazyn.';
	}

	public static function describe( $table, array $s ) {
		$d = trim( preg_replace( '/\s+/u', ' ', MSM_Calc::describe( $table, $s ) ) );
		if ( 'blachy_pelne' === $table && empty( $s['wymiar_a'] ) ) {
			$d = trim( preg_replace( '/ ?–?×–?/u', '', str_replace( '–×–', '', $d ) ) ); // bez formatu
		}
		return $d;
	}

	private static function norm( $v ) {
		return mb_strtolower( preg_replace( '/[\s.\-_\/]+/u', '', (string) $v ) );
	}

	/** Czy wiersz magazynu / pozycja PZ pasuje do specyfikacji (puste pola specyfikacji = dowolne). */
	public static function matches( $table, array $spec, array $row ) {
		if ( 'blachy_pelne' === $table && class_exists( 'MSM_Reports' ) ) {
			$gs = MSM_Reports::blacha_grade( $spec );
			if ( '' !== $gs ) {
				if ( MSM_Reports::blacha_grade( $row ) !== $gs ) {
					return false;
				}
				$spec = array_diff_key( $spec, array( 'gatunek' => 1, 'material' => 1 ) );
			}
		}
		foreach ( $spec as $k => $v ) {
			if ( in_array( $k, self::NUM, true ) ) {
				$r = MSM_Calc::f( $row[ $k ] ?? null );
				if ( null === $r || abs( $r - (float) $v ) > 0.001 ) {
					return false;
				}
			} elseif ( self::norm( $v ) !== self::norm( $row[ $k ] ?? '' ) ) {
				return false;
			}
		}
		return true;
	}

	private static function key_of( $table, array $spec ) {
		if ( 'blachy_pelne' === $table && class_exists( 'MSM_Reports' ) ) {
			$g = MSM_Reports::blacha_grade( $spec );
			if ( '' !== $g ) { // „CZARNA · S235” = „S235JR” – ta sama blacha
				$spec = array_diff_key( $spec, array( 'gatunek' => 1, 'material' => 1 ) ) + array( 'material' => $g );
			}
		}
		$p = array();
		foreach ( self::KEYS[ $table ] as $k ) {
			$p[] = isset( $spec[ $k ] ) ? ( in_array( $k, self::NUM, true ) ? (string) round( (float) $spec[ $k ], 3 ) : self::norm( $spec[ $k ] ) ) : '';
		}
		return $table . '|' . implode( '|', $p );
	}

	private static function qty( $table, $v ) {
		$f = MSM_Calc::f( $v );
		if ( null === $f || $f <= 0 ) {
			return null;
		}
		return 'kg' === self::unit( $table ) ? round( $f, 3 ) : (float) floor( $f + 1e-9 );
	}

	/* ---------------- zapotrzebowanie ---------------- */

	/**
	 * Pokrycie zapotrzebowań liczone na bieżąco z ich rezerwacji: zarezerw = aktywne + wydane + czekające na akceptację,
	 * oczekuje = czekające. Rezerwacje odrzucone, anulowane i wygasłe przestają pokrywać – brak wraca do „Do zamówienia”.
	 */
	public static function with_cover( array $rows ) {
		global $wpdb;
		$ids = array();
		foreach ( $rows as $z ) {
			foreach ( (array) json_decode( (string) ( $z['rez'] ?? '' ), true ) as $rid ) {
				$ids[] = (int) $rid;
			}
		}
		$st = array();
		$ids = array_values( array_filter( array_unique( $ids ) ) );
		if ( $ids && class_exists( 'MSM_Rezerwacje' ) ) {
			foreach ( (array) $wpdb->get_results( 'SELECT id, ilosc, status FROM `' . MSM_Rezerwacje::T() . '` WHERE id IN (' . implode( ',', $ids ) . ')', ARRAY_A ) as $r ) { // phpcs:ignore
				$st[ (int) $r['id'] ] = $r;
			}
		}
		foreach ( $rows as &$z ) {
			$act = 0;
			$pen = 0;
			foreach ( (array) json_decode( (string) ( $z['rez'] ?? '' ), true ) as $rid ) {
				$r = $st[ (int) $rid ] ?? null;
				if ( ! $r ) {
					continue;
				}
				if ( in_array( $r['status'], array( 'aktywna', 'wydana' ), true ) ) {
					$act += (float) $r['ilosc'];
				} elseif ( 'nowa' === $r['status'] ) {
					$pen += (float) $r['ilosc'];
				}
			}
			$z['zarezerw'] = $act + $pen;
			$z['oczekuje'] = $pen;
		}
		unset( $z );
		return $rows;
	}

	private static function zap_cast( array $z, $pending = 0.0 ) {
		$brak = max( 0, (float) $z['ilosc'] - (float) $z['zarezerw'] );
		return array(
			'id'       => (int) $z['id'],
			'zlec_id'  => (int) $z['zlec_id'],
			'det_id'   => (int) $z['det_id'],
			'nr_zlec'  => (string) $z['nr_zlec'],
			'tabela'   => (string) $z['tabela'],
			'spec'     => json_decode( (string) $z['spec'], true ) ?: array(),
			'opis'     => (string) $z['opis'],
			'jm'       => (string) $z['jm'],
			'ilosc'    => (float) $z['ilosc'],
			'zarezerw' => (float) $z['zarezerw'],
			'oczekuje' => (float) ( $z['oczekuje'] ?? 0 ),
			'brak'     => $brak,
			'na_zam'   => min( $brak, (float) $pending ),
			'do_zam'   => max( 0, $brak - (float) $pending ),
			'status'   => (string) $z['status'],
			'uwagi'    => (string) $z['uwagi'],
			'kto'      => (string) $z['created_name'],
			'kiedy'    => (string) $z['created_at'],
		);
	}

	/**
	 * Ilości „w drodze” na otwartych zamówieniach: [zap_id => ilość zamówiona, jeszcze nie dostarczona]
	 * oraz numery zamówień: [zap_id => [ZAM …]].
	 */
	public static function pending_map() {
		global $wpdb;
		if ( ! self::ready() ) {
			return array( array(), array() );
		}
		$rows = (array) $wpdb->get_results( 'SELECT p.zap, z.numer FROM `' . self::TP() . '` p INNER JOIN `' . self::T() . "` z ON z.id = p.zam_id WHERE z.status IN ('szkic','wyslane','czesciowo') AND p.zap IS NOT NULL AND p.zap <> '' AND p.zap <> '[]'", ARRAY_A ); // phpcs:ignore
		$q    = array();
		$nr   = array();
		foreach ( $rows as $r ) {
			foreach ( (array) json_decode( (string) $r['zap'], true ) as $a ) {
				$id       = (int) ( $a['zap'] ?? 0 );
				$left     = max( 0, (float) ( $a['ilosc'] ?? 0 ) - (float) ( $a['dost'] ?? 0 ) );
				$q[ $id ] = ( $q[ $id ] ?? 0 ) + $left;
				if ( $left > 0 && ! in_array( $r['numer'], $nr[ $id ] ?? array(), true ) ) {
					$nr[ $id ][] = $r['numer'];
				}
			}
		}
		return array( $q, $nr );
	}

	/** Zapotrzebowania pozycji zleceń: [det_id => [ … ]] – do widoku produkcji. */
	public static function for_dets( array $ids ) {
		global $wpdb;
		$ids = array_values( array_filter( array_map( 'intval', $ids ) ) );
		if ( ! $ids || ! self::ready() ) {
			return array();
		}
		$rows = (array) $wpdb->get_results( 'SELECT * FROM `' . self::TZ() . "` WHERE status <> 'anulowane' AND det_id IN (" . implode( ',', $ids ) . ') ORDER BY id', ARRAY_A ); // phpcs:ignore
		if ( ! $rows ) {
			return array();
		}
		$rows = self::with_cover( $rows );
		list( $pend, $nr ) = self::pending_map();
		$out = array();
		foreach ( $rows as $z ) {
			$c                              = self::zap_cast( $z, $pend[ (int) $z['id'] ] ?? 0 );
			$c['zam']                       = $nr[ (int) $z['id'] ] ?? array();
			$out[ (int) $z['det_id'] ][]    = $c;
		}
		return $out;
	}

	/** Pasujące pozycje magazynu z dostępną ilością (stan minus rezerwacje). */
	private static function stock_for( $table, array $spec ) {
		global $wpdb;
		$T    = msm_table( $table );
		$rows = (array) $wpdb->get_results( "SELECT * FROM `$T` WHERE ilosc > 0 ORDER BY id", ARRAY_A ); // phpcs:ignore
		$hit  = array_values( array_filter( $rows, function ( $r ) use ( $table, $spec ) { return self::matches( $table, $spec, $r ); } ) );
		if ( ! $hit ) {
			return array();
		}
		$res = MSM_Rezerwacje::reserved_map( array_map( function ( $r ) { return (int) $r['id']; }, $hit ), $table );
		$out = array();
		foreach ( $hit as $r ) {
			$av = (float) $r['ilosc'] - (float) ( $res[ (int) $r['id'] ] ?? 0 );
			if ( $av > 0.0005 ) {
				$out[] = array( 'row' => $r, 'avail' => $av );
			}
		}
		usort( $out, function ( $a, $b ) { return $b['avail'] <=> $a['avail']; } );
		return $out;
	}

	/** Rezerwacja dla zapotrzebowania (bez e-maili). Zwraca zarezerwowaną ilość. */
	private static function reserve( array &$z, $table, $item_id, $qty, $note ) {
		if ( $qty <= 0 ) {
			return 0;
		}
		if ( 'kg' !== self::unit( $table ) ) {
			$qty = floor( $qty + 1e-9 );
			if ( $qty < 1 ) {
				return 0;
			}
		}
		$r = MSM_Rezerwacje::create( array(
			'item_table'  => $table,
			'item_id'     => (int) $item_id,
			'ilosc'       => $qty,
			'zlecenie'    => $z['nr_zlec'],
			'prod_det_id' => (int) $z['det_id'],
			'uwagi'       => $note,
			'cicho'       => current_user_can( 'msm_edit' ) ? 1 : 0, // prośba pracownika → e-mail do administratorów
		) );
		if ( is_wp_error( $r ) ) {
			return 0;
		}
		$list   = json_decode( (string) ( $z['rez'] ?? '' ), true ) ?: array();
		$list[] = (int) $r['id'];
		$z['rez']       = wp_json_encode( $list );
		$z['zarezerw']  = (float) $z['zarezerw'] + $qty;
		return $qty;
	}

	public static function zap_add_r( WP_REST_Request $r ) {
		global $wpdb;
		$p     = (array) $r->get_json_params();
		$table = (string) ( $p['tabela'] ?? '' );
		if ( ! isset( self::KEYS[ $table ] ) ) {
			return new WP_Error( 'msm_400', 'Wybierz magazyn: blachy pełne, kręgi albo stal.', array( 'status' => 400, 'fields' => array( 'tabela' => 'Wymagany' ) ) );
		}
		$det = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM `' . MSM_Prod::TD() . '` WHERE id = %d', (int) ( $p['det_id'] ?? 0 ) ), ARRAY_A ); // phpcs:ignore
		if ( ! $det ) {
			return new WP_Error( 'msm_404', 'Pozycja zlecenia nie istnieje.', array( 'status' => 404 ) );
		}
		$nr = (string) $wpdb->get_var( $wpdb->prepare( 'SELECT nr_zlec FROM `' . MSM_Prod::TZ() . '` WHERE id = %d', (int) $det['zlec_id'] ) ); // phpcs:ignore
		if ( '' === trim( $nr ) ) {
			return new WP_Error( 'msm_400', 'Zlecenie nie ma numeru – uzupełnij go w szczegółach projektu.', array( 'status' => 400 ) );
		}
		$spec = self::spec_clean( $table, (array) ( $p['spec'] ?? array() ) );
		$miss = self::spec_missing( $table, $spec );
		if ( $miss ) {
			return new WP_Error( 'msm_400', $miss, array( 'status' => 400 ) );
		}
		$qty = self::qty( $table, $p['ilosc'] ?? null );
		if ( ! $qty ) {
			return new WP_Error( 'msm_400', 'kg' === self::unit( $table ) ? 'Podaj ilość w kg.' : 'Podaj liczbę sztuk.', array( 'status' => 400, 'fields' => array( 'ilosc' => 'Wymagana' ) ) );
		}
		$z = array(
			'zlec_id'      => (int) $det['zlec_id'],
			'det_id'       => (int) $det['id'],
			'nr_zlec'      => mb_strtoupper( trim( $nr ) ),
			'tabela'       => $table,
			'spec'         => wp_json_encode( $spec ),
			'opis'         => mb_substr( self::describe( $table, $spec ), 0, 255 ),
			'jm'           => self::unit( $table ),
			'ilosc'        => $qty,
			'zarezerw'     => 0,
			'z_dost'       => 0,
			'rez'          => '[]',
			'status'       => 'otwarte',
			'uwagi'        => mb_substr( sanitize_textarea_field( (string) ( $p['uwagi'] ?? '' ) ), 0, 1000 ),
			'created_by'   => get_current_user_id(),
			'created_name' => MSM_Repo::user_name(),
			'created_at'   => current_time( 'mysql' ),
		);
		$got = 0;
		if ( ! array_key_exists( 'rezerwuj', $p ) || ! empty( $p['rezerwuj'] ) ) {
			foreach ( self::stock_for( $table, $spec ) as $s ) {
				$need = $qty - $z['zarezerw'];
				if ( $need <= 0.0005 ) {
					break;
				}
				$got += self::reserve( $z, $table, (int) $s['row']['id'], min( $need, $s['avail'] ), 'Zapotrzebowanie zlecenia ' . $z['nr_zlec'] );
			}
		}
		if ( $z['zarezerw'] + 0.0005 >= $qty ) {
			$z['status'] = 'pokryte';
		}
		$wpdb->insert( self::TZ(), $z );
		$id   = (int) $wpdb->insert_id;
		$brak = max( 0, $qty - $z['zarezerw'] );
		$u    = 'kg' === $z['jm'] ? 'kg' : 'szt.';
		MSM_Repo::log( 'Zapotrzebowanie: zgłoszono', 'zap', $id, $z['nr_zlec'] . ' – ' . $z['opis'] . ': ' . MSM_Calc::fmt( $qty ) . ' ' . $u . ( $got ? ', zarezerwowano ' . MSM_Calc::fmt( $got ) . ' ' . $u : '' ) . ( $brak ? ', do zamówienia ' . MSM_Calc::fmt( $brak ) . ' ' . $u : '' ), array( 'po' => array( 'uwagi' => $z['uwagi'] ) ) );
		$adm = current_user_can( 'msm_edit' );
		$msg = $got ? ( $adm ? 'Zarezerwowano ' . MSM_Calc::fmt( $got ) . ' ' . $u . ' z magazynu.' : 'Wysłano prośbę o rezerwację ' . MSM_Calc::fmt( $got ) . ' ' . $u . ' – czeka na akceptację administratora.' ) : 'Na magazynie nie ma wolnego materiału.';
		$msg .= $brak ? ' Brakuje ' . MSM_Calc::fmt( $brak ) . ' ' . $u . ' – dodano do „Do zamówienia”.' : ' Całość pokryta z magazynu.';
		return rest_ensure_response( self::det_payload( (int) $det['id'] ) + array( 'message' => $msg ) );
	}

	public static function zap_del_r( WP_REST_Request $r ) {
		global $wpdb;
		$z = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM `' . self::TZ() . '` WHERE id = %d', (int) $r['id'] ), ARRAY_A ); // phpcs:ignore
		if ( ! $z ) {
			return new WP_Error( 'msm_404', 'Zapotrzebowanie nie istnieje.', array( 'status' => 404 ) );
		}
		$wpdb->update( self::TZ(), array( 'status' => 'anulowane' ), array( 'id' => (int) $z['id'] ) );
		// Zwolnienie materiału zarezerwowanego dla tego zapotrzebowania (domyślnie tak).
		$rel  = 0;
		$keep = 0;
		if ( ! empty( $r->get_json_params()['zwolnij'] ) && class_exists( 'MSM_Rezerwacje' ) ) {
			foreach ( (array) json_decode( (string) $z['rez'], true ) as $rid ) {
				$w = MSM_Rezerwacje::get( (int) $rid );
				if ( ! $w || ! in_array( $w['status'], array( 'nowa', 'aktywna' ), true ) ) {
					continue;
				}
				$res = MSM_Rezerwacje::action( (int) $rid, 'anuluj', 'Usunięto zapotrzebowanie zlecenia ' . $z['nr_zlec'] );
				if ( is_wp_error( $res ) ) {
					$keep++;
				} else {
					$rel++;
				}
			}
		}
		MSM_Repo::log( 'Zapotrzebowanie: usunięto', 'zap', (int) $z['id'], $z['nr_zlec'] . ' – ' . $z['opis'] . ' (' . MSM_Calc::fmt( $z['ilosc'] ) . ' ' . $z['jm'] . ')' . ( $rel ? ', zwolniono rezerwacje: ' . $rel : '' ) );
		$msg = 'Usunięto zapotrzebowanie.' . ( $rel ? ' Zwolniono zarezerwowany materiał (' . $rel . ' ' . ( 1 === $rel ? 'rezerwacja' : 'rezerwacje' ) . ').' : '' ) . ( $keep ? ' ' . $keep . ' rezerwacji nie udało się zwolnić – może to zrobić administrator w Rezerwacjach.' : '' );
		return rest_ensure_response( self::det_payload( (int) $z['det_id'] ) + array( 'message' => $msg ) );
	}

	private static function det_payload( $det_id ) {
		return array(
			'zap' => self::for_dets( array( $det_id ) )[ $det_id ] ?? array(),
			'rez' => MSM_Prod::det_reservations( array( $det_id ) )[ $det_id ] ?? array(),
		);
	}

	/** Podpowiedzi do formularza zapotrzebowania: wartości z magazynu dla każdego pola. */
	public static function hints_r() {
		global $wpdb;
		$out = array();
		foreach ( self::KEYS as $t => $keys ) {
			$T = msm_table( $t );
			foreach ( $keys as $k ) {
				$col = (array) $wpdb->get_col( "SELECT DISTINCT `$k` FROM `$T` WHERE `$k` IS NOT NULL AND `$k` <> '' ORDER BY `$k` LIMIT 200" ); // phpcs:ignore
				$out[ $t ][ $k ] = array_values( array_map( function ( $v ) use ( $k ) { return in_array( $k, self::NUM, true ) ? MSM_Calc::fmt( $v ) : (string) $v; }, $col ) );
			}
		}
		return rest_ensure_response( $out );
	}

	/* ---------------- braki dla zleceń (Do zamówienia) ---------------- */

	/** Otwarte braki pogrupowane po materiale. */
	public static function braki() {
		global $wpdb;
		if ( ! self::ready() ) {
			return array();
		}
		$rows = self::with_cover( (array) $wpdb->get_results( 'SELECT * FROM `' . self::TZ() . "` WHERE status <> 'anulowane' ORDER BY created_at, id", ARRAY_A ) ); // phpcs:ignore
		list( $pend, $nrs ) = self::pending_map();
		$g = array();
		foreach ( $rows as $z ) {
			$c = self::zap_cast( $z, $pend[ (int) $z['id'] ] ?? 0 );
			if ( $c['brak'] <= 0.0005 ) {
				continue;
			}
			$k = self::key_of( $c['tabela'], $c['spec'] );
			if ( ! isset( $g[ $k ] ) ) {
				$g[ $k ] = array( 'klucz' => md5( $k ), 'tabela' => $c['tabela'], 'magazyn' => msm_schema()[ $c['tabela'] ]['label'], 'spec' => $c['spec'], 'opis' => $c['opis'], 'jm' => $c['jm'], 'brak' => 0, 'na_zam' => 0, 'do_zam' => 0, 'zam' => array(), 'zap' => array() );
			}
			$g[ $k ]['brak']   += $c['brak'];
			$g[ $k ]['na_zam'] += $c['na_zam'];
			$g[ $k ]['do_zam'] += $c['do_zam'];
			$g[ $k ]['zam']     = array_values( array_unique( array_merge( $g[ $k ]['zam'], $nrs[ $c['id'] ] ?? array() ) ) );
			$g[ $k ]['zap'][]   = array( 'id' => $c['id'], 'nr_zlec' => $c['nr_zlec'], 'zlec_id' => $c['zlec_id'], 'brak' => $c['brak'], 'do_zam' => $c['do_zam'], 'kto' => $c['kto'], 'kiedy' => $c['kiedy'] );
		}
		$out = array_values( $g );
		usort( $out, function ( $a, $b ) { return $b['do_zam'] <=> $a['do_zam'] ?: strcmp( $a['opis'], $b['opis'] ); } );
		return $out;
	}

	public static function braki_r() {
		return rest_ensure_response( array( 'braki' => self::braki(), 'edycja' => self::is_editor() ) );
	}

	/* ---------------- dostawcy ---------------- */

	private static function dost_cast( array $d ) {
		return array( 'id' => (int) $d['id'], 'nazwa' => (string) $d['nazwa'], 'email' => (string) $d['email'], 'kontakt' => (string) $d['kontakt'], 'telefon' => (string) $d['telefon'], 'uwagi' => (string) $d['uwagi'] );
	}

	public static function dost_list_r() {
		global $wpdb;
		$list = array_map( array( __CLASS__, 'dost_cast' ), (array) $wpdb->get_results( 'SELECT * FROM `' . self::TD() . '` ORDER BY nazwa', ARRAY_A ) ); // phpcs:ignore
		$have = array_map( function ( $d ) { return self::norm( $d['nazwa'] ); }, $list );
		$pz   = array();
		if ( class_exists( 'MSM_PZ' ) ) {
			foreach ( (array) $wpdb->get_col( 'SELECT DISTINCT dostawca FROM `' . MSM_PZ::T() . "` WHERE dostawca <> '' ORDER BY dostawca LIMIT 300" ) as $n ) { // phpcs:ignore
				if ( ! in_array( self::norm( $n ), $have, true ) ) {
					$pz[] = $n;
				}
			}
		}
		return rest_ensure_response( array( 'dostawcy' => $list, 'z_pz' => $pz, 'edycja' => self::is_editor() ) );
	}

	private static function dost_input( array $p ) {
		$nazwa = mb_substr( trim( sanitize_text_field( (string) ( $p['nazwa'] ?? '' ) ) ), 0, 190 );
		$email = trim( (string) ( $p['email'] ?? '' ) );
		if ( '' === $nazwa ) {
			return new WP_Error( 'msm_400', 'Podaj nazwę dostawcy.', array( 'status' => 400, 'fields' => array( 'nazwa' => 'Wymagana' ) ) );
		}
		$emails = array_filter( array_map( 'trim', preg_split( '/[,;\s]+/', $email ) ) );
		foreach ( $emails as $e ) {
			if ( ! is_email( $e ) ) {
				return new WP_Error( 'msm_400', 'Nieprawidłowy adres e-mail: ' . $e, array( 'status' => 400, 'fields' => array( 'email' => 'Nieprawidłowy' ) ) );
			}
		}
		return array(
			'nazwa'   => $nazwa,
			'email'   => implode( ', ', array_map( 'sanitize_email', $emails ) ),
			'kontakt' => mb_substr( sanitize_text_field( (string) ( $p['kontakt'] ?? '' ) ), 0, 190 ),
			'telefon' => mb_substr( sanitize_text_field( (string) ( $p['telefon'] ?? '' ) ), 0, 60 ),
			'uwagi'   => mb_substr( sanitize_textarea_field( (string) ( $p['uwagi'] ?? '' ) ), 0, 1000 ),
		);
	}

	public static function dost_save_r( WP_REST_Request $r ) {
		global $wpdb;
		$p   = (array) $r->get_json_params();
		$row = self::dost_input( $p );
		if ( is_wp_error( $row ) ) {
			return $row;
		}
		$id = (int) ( $p['id'] ?? 0 );
		if ( $id ) {
			$wpdb->update( self::TD(), $row, array( 'id' => $id ) );
			MSM_Repo::log( 'Dostawcy: edycja', 'dost', $id, $row['nazwa'] );
		} else {
			$wpdb->insert( self::TD(), $row + array( 'created_at' => current_time( 'mysql' ) ) );
			$id = (int) $wpdb->insert_id;
			MSM_Repo::log( 'Dostawcy: nowy', 'dost', $id, $row['nazwa'] . ( $row['email'] ? ' (' . $row['email'] . ')' : '' ) );
		}
		$d = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM `' . self::TD() . '` WHERE id = %d', $id ), ARRAY_A ); // phpcs:ignore
		return rest_ensure_response( array( 'dostawca' => self::dost_cast( $d ) ) );
	}

	public static function dost_del_r( WP_REST_Request $r ) {
		global $wpdb;
		$d = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM `' . self::TD() . '` WHERE id = %d', (int) $r['id'] ), ARRAY_A ); // phpcs:ignore
		if ( $d ) {
			$wpdb->delete( self::TD(), array( 'id' => (int) $d['id'] ) );
			MSM_Repo::log( 'Dostawcy: usunięto', 'dost', (int) $d['id'], $d['nazwa'] );
		}
		return rest_ensure_response( array( 'ok' => true ) );
	}

	/* ---------------- zamówienia ---------------- */

	private static function get( $id ) {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM `' . self::T() . '` WHERE id = %d', (int) $id ), ARRAY_A ) ?: null; // phpcs:ignore
	}

	private static function lines( $zam_id ) {
		global $wpdb;
		return (array) $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM `' . self::TP() . '` WHERE zam_id = %d ORDER BY lp, id', (int) $zam_id ), ARRAY_A ); // phpcs:ignore
	}

	private static function line_cast( array $l, array $nrz = array() ) {
		$zap = json_decode( (string) $l['zap'], true ) ?: array();
		$zl  = array();
		foreach ( $zap as $a ) {
			$n = $nrz[ (int) $a['zap'] ] ?? '';
			if ( '' !== $n ) {
				$zl[ $n ] = ( $zl[ $n ] ?? 0 ) + (float) $a['ilosc'];
			}
		}
		return array(
			'id'       => (int) $l['id'],
			'lp'       => (int) $l['lp'],
			'tabela'   => (string) $l['tabela'],
			'magazyn'  => msm_schema()[ $l['tabela'] ]['label'] ?? $l['tabela'],
			'spec'     => json_decode( (string) $l['spec'], true ) ?: array(),
			'opis'     => (string) $l['opis'],
			'jm'       => (string) $l['jm'],
			'ilosc'    => (float) $l['ilosc'],
			'przyjeto' => (float) $l['przyjeto'],
			'brakuje'  => max( 0, (float) $l['ilosc'] - (float) $l['przyjeto'] ),
			'uwagi'    => (string) $l['uwagi'],
			'zlecenia' => array_map( function ( $n, $q ) { return array( 'nr' => $n, 'ilosc' => $q ); }, array_keys( $zl ), array_values( $zl ) ),
		);
	}

	private static function zap_numbers( array $lines ) {
		global $wpdb;
		$ids = array();
		foreach ( $lines as $l ) {
			foreach ( (array) json_decode( (string) $l['zap'], true ) as $a ) {
				$ids[] = (int) ( $a['zap'] ?? 0 );
			}
		}
		$ids = array_values( array_filter( array_unique( $ids ) ) );
		if ( ! $ids ) {
			return array();
		}
		$out = array();
		foreach ( (array) $wpdb->get_results( 'SELECT id, nr_zlec FROM `' . self::TZ() . '` WHERE id IN (' . implode( ',', $ids ) . ')', ARRAY_A ) as $r ) { // phpcs:ignore
			$out[ (int) $r['id'] ] = $r['nr_zlec'];
		}
		return $out;
	}

	private static function cast( array $z, $full = false ) {
		$lines = self::lines( $z['id'] );
		$sumz  = 0;
		$sump  = 0;
		foreach ( $lines as $l ) {
			$sumz += min( (float) $l['ilosc'], (float) $l['przyjeto'] );
			$sump += (float) $l['ilosc'];
		}
		$out = array(
			'id'         => (int) $z['id'],
			'numer'      => (string) $z['numer'],
			'dost_id'    => (int) $z['dost_id'],
			'dostawca'   => (string) $z['dostawca'],
			'email'      => (string) $z['email'],
			'status'     => (string) $z['status'],
			'status_txt' => self::ST[ $z['status'] ] ?? $z['status'],
			'termin'     => $z['termin'] ? (string) $z['termin'] : '',
			'uwagi'      => (string) $z['uwagi'],
			'kto'        => (string) $z['created_name'],
			'kiedy'      => (string) $z['created_at'],
			'wyslano'    => $z['sent_at'] ? (string) $z['sent_at'] : '',
			'wyslano_do' => (string) $z['sent_to'],
			'pozycji'    => count( $lines ),
			'proc'       => $sump > 0 ? (int) floor( 100 * $sumz / $sump ) : 0,
			'opis'       => implode( ', ', array_slice( array_map( function ( $l ) { return $l['opis']; }, $lines ), 0, 3 ) ) . ( count( $lines ) > 3 ? '…' : '' ),
		);
		if ( $full ) {
			$nrz           = self::zap_numbers( $lines );
			$out['linie']  = array_map( function ( $l ) use ( $nrz ) { return self::line_cast( $l, $nrz ); }, $lines );
			$out['pz']     = self::pz_links( (int) $z['id'] );
		}
		return $out;
	}

	private static function pz_links( $zam_id ) {
		global $wpdb;
		$rows = (array) $wpdb->get_results( $wpdb->prepare( 'SELECT l.*, p.opis FROM `' . self::TL() . '` l INNER JOIN `' . self::TP() . '` p ON p.id = l.zam_poz_id WHERE l.zam_id = %d ORDER BY l.id', (int) $zam_id ), ARRAY_A ); // phpcs:ignore
		return array_map( function ( $l ) {
			return array( 'pz_id' => (int) $l['pz_id'], 'pz' => (string) $l['pz_numer'], 'opis' => (string) $l['opis'], 'ilosc' => (float) $l['ilosc'], 'kiedy' => (string) $l['created_at'], 'rez' => count( json_decode( (string) $l['rez'], true ) ?: array() ) );
		}, $rows );
	}

	public static function list_r( WP_REST_Request $r ) {
		global $wpdb;
		$rows = (array) $wpdb->get_results( 'SELECT * FROM `' . self::T() . '` ORDER BY created_at DESC, id DESC LIMIT 500', ARRAY_A ); // phpcs:ignore
		return rest_ensure_response( array( 'zamowienia' => array_map( function ( $z ) { return self::cast( $z ); }, $rows ), 'statusy' => self::ST, 'edycja' => self::is_editor() ) );
	}

	public static function get_r( WP_REST_Request $r ) {
		$z = self::get( (int) $r['id'] );
		if ( ! $z ) {
			return new WP_Error( 'msm_404', 'Zamówienie nie istnieje.', array( 'status' => 404 ) );
		}
		return rest_ensure_response( array( 'zamowienie' => self::cast( $z, true ), 'statusy' => self::ST, 'edycja' => self::is_editor(), 'ja' => wp_get_current_user()->user_email ) );
	}

	/** Numer jak PZ: „ZAM 01/11/2026” – kolejny w miesiącu. */
	private static function next_number( $year, $month ) {
		global $wpdb;
		$seq = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT MAX(nr_seq) FROM `' . self::T() . '` WHERE rok = %d AND miesiac = %d', (int) $year, (int) $month ) ) + 1; // phpcs:ignore
		return array( $seq, sprintf( 'ZAM %02d/%02d/%04d', $seq, $month, $year ) );
	}

	/** Dostawca z listy (id) albo nowy (nazwa + e-mail – od razu dopisany do listy). */
	private static function resolve_dost( array $p ) {
		global $wpdb;
		$id = (int) ( $p['dost_id'] ?? 0 );
		if ( $id ) {
			$d = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM `' . self::TD() . '` WHERE id = %d', $id ), ARRAY_A ); // phpcs:ignore
			return $d ? $d : new WP_Error( 'msm_400', 'Wybrany dostawca nie istnieje.', array( 'status' => 400 ) );
		}
		$row = self::dost_input( array( 'nazwa' => $p['dostawca'] ?? '', 'email' => $p['email'] ?? '' ) );
		if ( is_wp_error( $row ) ) {
			return $row;
		}
		$have = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM `' . self::TD() . '` WHERE nazwa = %s', $row['nazwa'] ), ARRAY_A ); // phpcs:ignore
		if ( $have ) {
			if ( '' === $have['email'] && '' !== $row['email'] ) {
				$wpdb->update( self::TD(), array( 'email' => $row['email'] ), array( 'id' => (int) $have['id'] ) );
				$have['email'] = $row['email'];
			}
			return $have;
		}
		$wpdb->insert( self::TD(), $row + array( 'created_at' => current_time( 'mysql' ) ) );
		return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM `' . self::TD() . '` WHERE id = %d', (int) $wpdb->insert_id ), ARRAY_A ); // phpcs:ignore
	}

	/**
	 * Pozycje z „Do zamówienia”: [{tabela, spec, ilosc, zap: [ids], item_id}].
	 * Braki zleceń: ilość dzielona na zapotrzebowania (każde dostaje swoje „do zamówienia”, nadwyżka trafia do ostatniego).
	 */
	private static function build_lines( array $in ) {
		global $wpdb;
		list( $pend ) = self::pending_map();
		$out = array();
		foreach ( array_slice( $in, 0, 200 ) as $i => $l ) {
			$table = (string) ( $l['tabela'] ?? '' );
			$spec  = array();
			if ( ! empty( $l['item_id'] ) && in_array( $table, array( 'stal', 'blachy_pelne', 'kregi' ), true ) ) {
				$item = MSM_Repo::get( $table, (int) $l['item_id'] );
				if ( $item ) {
					$spec = self::spec_clean( $table, $item );
				}
			} elseif ( isset( self::KEYS[ $table ] ) ) {
				$spec = self::spec_clean( $table, (array) ( $l['spec'] ?? array() ) );
			}
			if ( ! isset( self::KEYS[ $table ] ) ) {
				return new WP_Error( 'msm_400', 'Pozycja ' . ( $i + 1 ) . ': nieznany magazyn.', array( 'status' => 400 ) );
			}
			$miss = self::spec_missing( $table, $spec );
			if ( $miss ) {
				return new WP_Error( 'msm_400', 'Pozycja ' . ( $i + 1 ) . ': ' . $miss, array( 'status' => 400 ) );
			}
			$qty = self::qty( $table, $l['ilosc'] ?? null );
			if ( ! $qty ) {
				return new WP_Error( 'msm_400', 'Pozycja ' . ( $i + 1 ) . ': podaj ilość.', array( 'status' => 400 ) );
			}
			$zap  = array();
			$ids  = array_values( array_filter( array_map( 'intval', (array) ( $l['zap'] ?? array() ) ) ) );
			$left = $qty;
			if ( $ids ) {
				$rows = self::with_cover( (array) $wpdb->get_results( 'SELECT * FROM `' . self::TZ() . "` WHERE status <> 'anulowane' AND id IN (" . implode( ',', $ids ) . ') ORDER BY created_at, id', ARRAY_A ) ); // phpcs:ignore
				foreach ( $rows as $k => $z ) {
					$c    = self::zap_cast( $z, $pend[ (int) $z['id'] ] ?? 0 );
					$take = $k === count( $rows ) - 1 ? $left : min( $left, $c['do_zam'] );
					if ( $take <= 0 ) {
						continue;
					}
					$zap[] = array( 'zap' => (int) $z['id'], 'ilosc' => $take, 'dost' => 0 );
					$left -= $take;
				}
			}
			$out[] = array(
				'tabela' => $table,
				'spec'   => wp_json_encode( $spec ),
				'opis'   => mb_substr( self::describe( $table, $spec ), 0, 255 ),
				'jm'     => self::unit( $table ),
				'ilosc'  => $qty,
				'zap'    => wp_json_encode( $zap ),
				'uwagi'  => mb_substr( sanitize_text_field( (string) ( $l['uwagi'] ?? '' ) ), 0, 255 ),
			);
		}
		return $out;
	}

	public static function add_r( WP_REST_Request $r ) {
		global $wpdb;
		$p     = (array) $r->get_json_params();
		$lines = self::build_lines( (array) ( $p['pozycje'] ?? array() ) );
		if ( is_wp_error( $lines ) ) {
			return $lines;
		}
		if ( ! $lines ) {
			return new WP_Error( 'msm_400', 'Zaznacz co najmniej jedną pozycję do zamówienia.', array( 'status' => 400 ) );
		}
		// Dopisanie do istniejącego szkicu.
		$into = (int) ( $p['do_szkicu'] ?? 0 );
		if ( $into ) {
			$z = self::get( $into );
			if ( ! $z || 'szkic' !== $z['status'] ) {
				return new WP_Error( 'msm_400', 'Szkic zamówienia nie istnieje albo został już wysłany.', array( 'status' => 400 ) );
			}
			$lp = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT MAX(lp) FROM `' . self::TP() . '` WHERE zam_id = %d', $into ) ); // phpcs:ignore
			foreach ( $lines as $l ) {
				$wpdb->insert( self::TP(), $l + array( 'zam_id' => $into, 'lp' => ++$lp, 'przyjeto' => 0 ) );
			}
			$wpdb->update( self::T(), array( 'updated_at' => current_time( 'mysql' ) ), array( 'id' => $into ) );
			MSM_Repo::log( 'Zamówienia: dopisano pozycje', 'zam', $into, $z['numer'] . ' – ' . $z['dostawca'] . ': +' . count( $lines ) . ' poz.' );
			return rest_ensure_response( array( 'id' => $into, 'message' => 'Dopisano ' . count( $lines ) . ' poz. do ' . $z['numer'] . '.' ) );
		}
		$d = self::resolve_dost( $p );
		if ( is_wp_error( $d ) ) {
			return $d;
		}
		$termin = preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) ( $p['termin'] ?? '' ) ) ? $p['termin'] : null;
		$year   = (int) current_time( 'Y' );
		$month  = (int) current_time( 'n' );
		$wpdb->query( 'START TRANSACTION' );
		list( $seq, $numer ) = self::next_number( $year, $month );
		$wpdb->insert( self::T(), array(
			'numer'        => $numer,
			'nr_seq'       => $seq,
			'rok'          => $year,
			'miesiac'      => $month,
			'dost_id'      => (int) $d['id'],
			'dostawca'     => $d['nazwa'],
			'email'        => $d['email'],
			'status'       => 'szkic',
			'termin'       => $termin,
			'uwagi'        => mb_substr( sanitize_textarea_field( (string) ( $p['uwagi'] ?? '' ) ), 0, 2000 ),
			'created_by'   => get_current_user_id(),
			'created_name' => MSM_Repo::user_name(),
			'created_at'   => current_time( 'mysql' ),
			'updated_at'   => current_time( 'mysql' ),
		) );
		$id = (int) $wpdb->insert_id;
		$wpdb->query( 'COMMIT' );
		foreach ( $lines as $i => $l ) {
			$wpdb->insert( self::TP(), $l + array( 'zam_id' => $id, 'lp' => $i + 1, 'przyjeto' => 0 ) );
		}
		MSM_Repo::log( 'Zamówienia: nowe', 'zam', $id, $numer . ' – ' . $d['nazwa'] . ', pozycji: ' . count( $lines ) );
		return rest_ensure_response( array( 'id' => $id, 'message' => 'Utworzono ' . $numer . ' (szkic).' ) );
	}

	/** Zapis szkicu: nagłówek (zawsze, póki nie anulowane) i pozycje (tylko szkic). */
	public static function save_r( WP_REST_Request $r ) {
		global $wpdb;
		$z = self::get( (int) $r['id'] );
		if ( ! $z ) {
			return new WP_Error( 'msm_404', 'Zamówienie nie istnieje.', array( 'status' => 404 ) );
		}
		if ( 'anulowane' === $z['status'] ) {
			return new WP_Error( 'msm_400', 'Anulowanego zamówienia nie można zmieniać.', array( 'status' => 400 ) );
		}
		$p   = (array) $r->get_json_params();
		$upd = array( 'updated_at' => current_time( 'mysql' ) );
		if ( array_key_exists( 'termin', $p ) ) {
			$upd['termin'] = preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $p['termin'] ) ? $p['termin'] : null;
		}
		if ( array_key_exists( 'uwagi', $p ) ) {
			$upd['uwagi'] = mb_substr( sanitize_textarea_field( (string) $p['uwagi'] ), 0, 2000 );
		}
		if ( ! empty( $p['dost_id'] ) || ! empty( $p['dostawca'] ) ) {
			$d = self::resolve_dost( $p );
			if ( is_wp_error( $d ) ) {
				return $d;
			}
			$upd += array( 'dost_id' => (int) $d['id'], 'dostawca' => $d['nazwa'], 'email' => $d['email'] );
		}
		if ( isset( $p['linie'] ) && is_array( $p['linie'] ) ) {
			if ( 'szkic' !== $z['status'] ) {
				return new WP_Error( 'msm_400', 'Pozycje można zmieniać tylko w szkicu (przed wysłaniem).', array( 'status' => 400 ) );
			}
			$have = array();
			foreach ( self::lines( $z['id'] ) as $l ) {
				$have[ (int) $l['id'] ] = $l;
			}
			$keep = array();
			$lp   = 0;
			foreach ( array_slice( $p['linie'], 0, 200 ) as $i => $l ) {
				$lid = (int) ( $l['id'] ?? 0 );
				if ( $lid && isset( $have[ $lid ] ) ) {
					$qty = self::qty( $have[ $lid ]['tabela'], $l['ilosc'] ?? null );
					if ( ! $qty ) {
						return new WP_Error( 'msm_400', 'Pozycja ' . ( $i + 1 ) . ': podaj ilość.', array( 'status' => 400 ) );
					}
					$wpdb->update( self::TP(), array( 'lp' => ++$lp, 'ilosc' => $qty, 'uwagi' => mb_substr( sanitize_text_field( (string) ( $l['uwagi'] ?? '' ) ), 0, 255 ), 'zap' => self::trim_zap( $have[ $lid ]['zap'], $qty ) ), array( 'id' => $lid ) );
					$keep[] = $lid;
				} elseif ( ! $lid ) {
					$nl = self::build_lines( array( $l ) );
					if ( is_wp_error( $nl ) ) {
						return new WP_Error( 'msm_400', str_replace( 'Pozycja 1', 'Pozycja ' . ( $i + 1 ), $nl->get_error_message() ), array( 'status' => 400 ) );
					}
					$wpdb->insert( self::TP(), $nl[0] + array( 'zam_id' => (int) $z['id'], 'lp' => ++$lp, 'przyjeto' => 0 ) );
					$keep[] = (int) $wpdb->insert_id;
				}
			}
			foreach ( array_diff( array_keys( $have ), $keep ) as $del ) {
				$wpdb->delete( self::TP(), array( 'id' => (int) $del ) );
			}
		}
		$wpdb->update( self::T(), $upd, array( 'id' => (int) $z['id'] ) );
		MSM_Repo::log( 'Zamówienia: edycja', 'zam', (int) $z['id'], $z['numer'] . ' – ' . ( $upd['dostawca'] ?? $z['dostawca'] ) );
		return self::get_r( $r );
	}

	/** Po zmniejszeniu ilości pozycji – przydział dla zleceń nie może jej przekraczać. */
	private static function trim_zap( $json, $qty ) {
		$out  = array();
		$left = $qty;
		foreach ( (array) json_decode( (string) $json, true ) as $a ) {
			$q = min( (float) $a['ilosc'], $left );
			if ( $q <= 0 ) {
				break;
			}
			$a['ilosc'] = $q;
			$out[]      = $a;
			$left      -= $q;
		}
		return wp_json_encode( $out );
	}

	public static function status_r( WP_REST_Request $r ) {
		global $wpdb;
		$z = self::get( (int) $r['id'] );
		if ( ! $z ) {
			return new WP_Error( 'msm_404', 'Zamówienie nie istnieje.', array( 'status' => 404 ) );
		}
		$to    = (string) ( $r->get_json_params()['status'] ?? '' );
		$allow = array(
			'wyslane'   => array( 'szkic' ),
			'zamkniete' => array( 'wyslane', 'czesciowo' ),
			'anulowane' => array( 'szkic', 'wyslane' ),
			'szkic'     => array( 'wyslane' ),
		);
		if ( ! isset( $allow[ $to ] ) || ! in_array( $z['status'], $allow[ $to ], true ) ) {
			return new WP_Error( 'msm_400', 'Tej zmiany statusu nie można wykonać.', array( 'status' => 400 ) );
		}
		if ( 'anulowane' === $to && (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM `' . self::TL() . '` WHERE zam_id = %d', (int) $z['id'] ) ) ) { // phpcs:ignore
			return new WP_Error( 'msm_400', 'Do zamówienia przyjęto już dostawę – zamiast anulować, zamknij je.', array( 'status' => 400 ) );
		}
		$upd = array( 'status' => $to, 'updated_at' => current_time( 'mysql' ) );
		if ( 'wyslane' === $to && ! $z['sent_at'] ) {
			$upd['sent_at'] = current_time( 'mysql' );
			$upd['sent_to'] = 'oznaczono ręcznie';
		}
		$wpdb->update( self::T(), $upd, array( 'id' => (int) $z['id'] ) );
		MSM_Repo::log( 'Zamówienia: ' . mb_strtolower( self::ST[ $to ] ), 'zam', (int) $z['id'], $z['numer'] . ' – ' . $z['dostawca'] );
		$msg = array( 'wyslane' => 'Oznaczono jako wysłane.', 'zamkniete' => 'Zamknięto zamówienie. Niedostarczone ilości wracają do „Do zamówienia”.', 'anulowane' => 'Anulowano zamówienie. Braki zleceń wracają do „Do zamówienia”.', 'szkic' => 'Przywrócono do szkicu – możesz poprawić pozycje.' );
		return rest_ensure_response( array( 'message' => $msg[ $to ] ) + (array) self::get_r( $r )->get_data() );
	}

	/** Przelicza status po przyjęciu / cofnięciu dostawy. */
	private static function recalc( $zam_id ) {
		global $wpdb;
		$z = self::get( $zam_id );
		if ( ! $z || in_array( $z['status'], array( 'anulowane', 'zamkniete' ), true ) ) {
			return;
		}
		$all = true;
		$any = false;
		foreach ( self::lines( $zam_id ) as $l ) {
			if ( (float) $l['przyjeto'] > 0 ) {
				$any = true;
			}
			if ( (float) $l['przyjeto'] + 0.0005 < (float) $l['ilosc'] ) {
				$all = false;
			}
		}
		$st = $all && $any ? 'zrealizowane' : ( $any ? 'czesciowo' : ( 'szkic' === $z['status'] ? 'szkic' : 'wyslane' ) );
		if ( $st !== $z['status'] ) {
			$wpdb->update( self::T(), array( 'status' => $st, 'updated_at' => current_time( 'mysql' ) ), array( 'id' => $zam_id ) );
		}
	}

	/* ---------------- PDF i wysyłka ---------------- */

	public static function pdf( array $z ) {
		$c   = self::cast( $z, true );
		$pdf = new MSM_Pdf();
		$pdf->add_page();
		$L = 42;
		$R = MSM_Pdf::W - 42;
		$y = 38;
		$h = $pdf->image( MSM_DIR . 'assets/logo-mail.png', $L, $y, 150 );
		$pdf->font( 'n', 9 )->text( $R, $y + 10, msm_opt( 'firma_nazwa' ), '1a2233', 'R' )->text( $R, $y + 22, msm_opt( 'firma_adres' ), '6b7285', 'R' );
		$y += max( 46, is_numeric( $h ) ? $h + 14 : 46 );
		$pdf->font( 'b', 20 )->text( $L, $y + 14, 'Zamówienie ' . $c['numer'] );
		$pdf->font( 'n', 10 )->text( $R, $y + 14, 'Data: ' . mysql2date( 'd.m.Y', $c['kiedy'] ), '6b7285', 'R' );
		$y += 34;
		// Dostawca / zamawiający.
		$col = ( $R - $L - 16 ) / 2;
		$me  = wp_get_current_user();
		$blk = function ( $x, $title, $lines ) use ( $pdf, &$y, $col ) {
			$pdf->font( 'b', 8 )->text( $x, $y, mb_strtoupper( $title ), '6b7285' );
			$yy = $y + 15;
			foreach ( $lines as $i => $t ) {
				if ( '' === trim( (string) $t ) ) {
					continue;
				}
				foreach ( $pdf->font( 0 === $i ? 'b' : 'n', 0 === $i ? 11 : 9.5 )->wrap( $t, $col ) as $w ) {
					$pdf->text( $x, $yy, $w );
					$yy += 0 === $i ? 15 : 13;
				}
			}
			return $yy;
		};
		$d  = self::dost_by_id( $c['dost_id'] );
		$y1 = $blk( $L, 'Dostawca', array( $c['dostawca'], $d ? trim( $d['kontakt'] . ( $d['telefon'] ? '  tel. ' . $d['telefon'] : '' ) ) : '', $c['email'] ) );
		$y2 = $blk( $L + $col + 16, 'Zamawiający', array( msm_opt( 'firma_nazwa' ), msm_opt( 'firma_adres' ), 'Osoba kontaktowa: ' . $me->display_name, $me->user_email ) );
		$y  = max( $y1, $y2 ) + 10;
		if ( $c['termin'] ) {
			$pdf->rect( $L, $y, $R - $L, 24, 'eef3fc' )->font( 'b', 10 )->text( $L + 10, $y + 16, 'Oczekiwany termin dostawy: ' . mysql2date( 'd.m.Y', $c['termin'] ), '1f3f8f' );
			$y += 36;
		}
		// Tabela pozycji.
		$cols = array( array( 'Lp.', 28, 'L' ), array( 'Materiał', 0, 'L' ), array( 'Ilość', 64, 'R' ), array( 'J.m.', 36, 'L' ), array( 'Uwagi', 130, 'L' ) );
		$fix  = 0;
		foreach ( $cols as $k ) {
			$fix += $k[1];
		}
		$cols[1][1] = $R - $L - $fix;
		$head = function () use ( $pdf, &$y, $cols, $L, $R ) {
			$pdf->rect( $L, $y, $R - $L, 22, 'f1f3f7' );
			$x = $L;
			foreach ( $cols as $k ) {
				$pdf->font( 'b', 8.5 )->text( 'R' === $k[2] ? $x + $k[1] - 6 : $x + 6, $y + 14.5, $k[0], '4a5263', $k[2] );
				$x += $k[1];
			}
			$y += 22;
		};
		$head();
		foreach ( $c['linie'] as $i => $l ) {
			$pdf->font( 'n', 9.5 );
			$m = $pdf->wrap( $l['opis'], $cols[1][1] - 12 );
			$u = $l['uwagi'] ? $pdf->wrap( $l['uwagi'], $cols[4][1] - 12 ) : array();
			$rh = max( count( $m ), count( $u ), 1 ) * 12.5 + 10;
			if ( $y + $rh > MSM_Pdf::H - 90 ) {
				$pdf->add_page();
				$y = 42;
				$head();
			}
			$x  = $L;
			$by = $y + 15;
			$pdf->font( 'n', 9.5 )->text( $x + 6, $by, ( $i + 1 ) . '.', '6b7285' );
			$x += $cols[0][1];
			foreach ( $m as $j => $t ) {
				$pdf->text( $x + 6, $by + $j * 12.5, $t );
			}
			$x += $cols[1][1];
			$pdf->font( 'b', 9.5 )->text( $x + $cols[2][1] - 6, $by, MSM_Calc::fmt( $l['ilosc'] ) );
			$x += $cols[2][1];
			$pdf->font( 'n', 9.5 )->text( $x + 6, $by, 'kg' === $l['jm'] ? 'kg' : 'szt.' );
			$x += $cols[3][1];
			foreach ( $u as $j => $t ) {
				$pdf->font( 'n', 8.5 )->text( $x + 6, $by + $j * 12.5, $t, '4a5263' );
			}
			$y += $rh;
			$pdf->line( $L, $y, $R, $y, 'e3e6ec' );
		}
		$y += 18;
		if ( '' !== trim( $c['uwagi'] ) ) {
			$pdf->font( 'b', 8 )->text( $L, $y, 'UWAGI', '6b7285' );
			$y += 14;
			foreach ( $pdf->font( 'n', 9.5 )->wrap( $c['uwagi'], $R - $L ) as $t ) {
				if ( $y > MSM_Pdf::H - 70 ) {
					$pdf->add_page();
					$y = 42;
				}
				$pdf->text( $L, $y, $t );
				$y += 13;
			}
			$y += 8;
		}
		$pdf->font( 'n', 9 )->text( $L, min( $y + 8, MSM_Pdf::H - 60 ), 'Prosimy o potwierdzenie przyjęcia zamówienia i terminu dostawy oraz o podanie numeru zamówienia na dokumencie WZ.', '4a5263' );
		$pdf->line( $L, MSM_Pdf::H - 40, $R, MSM_Pdf::H - 40, 'e3e6ec' )->font( 'n', 8 )->text( $L, MSM_Pdf::H - 28, msm_opt( 'firma_nazwa' ) . ' · ' . msm_opt( 'firma_adres' ), '8a90a0' )->text( $R, MSM_Pdf::H - 28, $c['numer'], '8a90a0', 'R' );
		return $pdf->output( 'Zamówienie ' . $c['numer'] );
	}

	private static function dost_by_id( $id ) {
		global $wpdb;
		return $id ? $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM `' . self::TD() . '` WHERE id = %d', (int) $id ), ARRAY_A ) : null; // phpcs:ignore
	}

	public static function file_name( array $z ) {
		return 'zamowienie-' . sanitize_file_name( str_replace( array( ' ', '/' ), '-', $z['numer'] ) ) . '.pdf';
	}

	public static function pdf_r( WP_REST_Request $r ) {
		$z = self::get( (int) $r['id'] );
		if ( ! $z ) {
			return new WP_Error( 'msm_404', 'Zamówienie nie istnieje.', array( 'status' => 404 ) );
		}
		$bin = self::pdf( $z );
		nocache_headers();
		header( 'Content-Type: application/pdf' );
		header( 'Content-Disposition: ' . ( $r->get_param( 'pobierz' ) ? 'attachment' : 'inline' ) . '; filename="' . self::file_name( $z ) . '"' );
		header( 'Content-Length: ' . strlen( $bin ) );
		echo $bin; // phpcs:ignore
		exit;
	}

	/** Lista pozycji do treści e-maila. */
	private static function mail_lines( array $c ) {
		$h = '<table cellpadding="6" cellspacing="0" style="border-collapse:collapse;margin:8px 0 14px;font-size:13px">';
		foreach ( $c['linie'] as $i => $l ) {
			$h .= '<tr><td style="border-bottom:1px solid #e3e6ec;color:#6b7285">' . ( $i + 1 ) . '.</td><td style="border-bottom:1px solid #e3e6ec">' . esc_html( $l['opis'] ) . ( $l['uwagi'] ? '<br><span style="color:#6b7285;font-size:12px">' . esc_html( $l['uwagi'] ) . '</span>' : '' ) . '</td><td style="border-bottom:1px solid #e3e6ec;text-align:right;white-space:nowrap"><strong>' . esc_html( MSM_Calc::fmt( $l['ilosc'] ) . ' ' . ( 'kg' === $l['jm'] ? 'kg' : 'szt.' ) ) . '</strong></td></tr>';
		}
		return $h . '</table>';
	}

	public static function send_r( WP_REST_Request $r ) {
		global $wpdb;
		$z = self::get( (int) $r['id'] );
		if ( ! $z ) {
			return new WP_Error( 'msm_404', 'Zamówienie nie istnieje.', array( 'status' => 404 ) );
		}
		if ( 'anulowane' === $z['status'] ) {
			return new WP_Error( 'msm_400', 'Zamówienie jest anulowane.', array( 'status' => 400 ) );
		}
		$p  = (array) $r->get_json_params();
		$to = array_values( array_filter( array_map( 'trim', preg_split( '/[,;\s]+/', (string) ( $p['do'] ?? $z['email'] ) ) ) ) );
		if ( ! $to ) {
			return new WP_Error( 'msm_400', 'Podaj adres e-mail dostawcy.', array( 'status' => 400, 'fields' => array( 'do' => 'Wymagany' ) ) );
		}
		foreach ( $to as $e ) {
			if ( ! is_email( $e ) ) {
				return new WP_Error( 'msm_400', 'Nieprawidłowy adres: ' . $e, array( 'status' => 400, 'fields' => array( 'do' => 'Nieprawidłowy' ) ) );
			}
		}
		if ( ! self::lines( $z['id'] ) ) {
			return new WP_Error( 'msm_400', 'Zamówienie nie ma pozycji.', array( 'status' => 400 ) );
		}
		$c    = self::cast( $z, true );
		$me   = wp_get_current_user();
		$vars = array(
			'numer'    => $c['numer'],
			'dostawca' => $c['dostawca'],
			'termin'   => $c['termin'] ? mysql2date( 'd.m.Y', $c['termin'] ) : 'do uzgodnienia',
			'uwagi'    => $c['uwagi'],
			'osoba'    => $me->display_name,
			'email'    => $me->user_email,
			'firma'    => msm_opt( 'firma_nazwa' ),
			'pozycje'  => self::mail_lines( $c ),
		);
		$tpl  = MSM_Mail::render( 'zam_dostawca', $vars );
		$note = trim( sanitize_textarea_field( (string) ( $p['tresc'] ?? '' ) ) );
		$body = ( '' !== $note ? '<p>' . nl2br( esc_html( $note ) ) . '</p>' : '' ) . $tpl['body'];
		$tmp  = trailingslashit( get_temp_dir() ) . self::file_name( $z );
		file_put_contents( $tmp, self::pdf( $z ) ); // phpcs:ignore
		$headers = array();
		if ( $me->user_email ) {
			$headers[] = 'Reply-To: ' . $me->display_name . ' <' . $me->user_email . '>';
			if ( ! empty( $p['kopia'] ) ) {
				$headers[] = 'Cc: ' . $me->user_email;
			}
		}
		$ok = MSM_Mail::send( implode( ',', $to ), $tpl['subject'], $body, array( 'prefix' => '', 'logo' => true, 'attachments' => array( $tmp ), 'headers' => $headers ) );
		@unlink( $tmp ); // phpcs:ignore
		if ( ! $ok ) {
			return new WP_Error( 'msm_mail', 'Nie udało się wysłać e-maila (sprawdź konfigurację poczty WordPressa). Możesz pobrać PDF i wysłać go ręcznie.', array( 'status' => 500 ) );
		}
		$upd = array( 'sent_at' => current_time( 'mysql' ), 'sent_to' => mb_substr( implode( ', ', $to ), 0, 255 ), 'updated_at' => current_time( 'mysql' ) );
		if ( 'szkic' === $z['status'] ) {
			$upd['status'] = 'wyslane';
		}
		$wpdb->update( self::T(), $upd, array( 'id' => (int) $z['id'] ) );
		if ( ! empty( $p['zapamietaj'] ) && $z['dost_id'] && $upd['sent_to'] !== $z['email'] ) {
			$wpdb->update( self::TD(), array( 'email' => $upd['sent_to'] ), array( 'id' => (int) $z['dost_id'] ) );
		}
		MSM_Repo::log( 'Zamówienia: wysłano', 'zam', (int) $z['id'], $z['numer'] . ' – ' . $z['dostawca'] . ' → ' . $upd['sent_to'] );
		return rest_ensure_response( array( 'message' => 'Wysłano ' . $z['numer'] . ' do ' . $upd['sent_to'] . '.' ) + (array) self::get_r( $r )->get_data() );
	}

	/* ---------------- PZ: dopasowanie i przyjęcie ---------------- */

	/** Otwarte pozycje zamówień (wysłane / częściowo przyjęte). */
	private static function open_lines() {
		global $wpdb;
		if ( ! self::ready() ) {
			return array();
		}
		return (array) $wpdb->get_results( 'SELECT p.*, z.numer, z.dostawca, z.created_at AS zam_data FROM `' . self::TP() . '` p INNER JOIN `' . self::T() . "` z ON z.id = p.zam_id WHERE z.status IN ('wyslane','czesciowo') AND p.przyjeto < p.ilosc ORDER BY z.created_at, p.lp", ARRAY_A ); // phpcs:ignore
	}

	private static function same_supplier( $a, $b ) {
		$a = self::norm( preg_replace( '/\b(sp\.?\s*z\s*o\.?\s*o\.?|s\.?a\.?|sp\.?\s*j\.?|sp\.?\s*k\.?)\b/iu', '', (string) $a ) );
		$b = self::norm( preg_replace( '/\b(sp\.?\s*z\s*o\.?\s*o\.?|s\.?a\.?|sp\.?\s*j\.?|sp\.?\s*k\.?)\b/iu', '', (string) $b ) );
		return '' !== $a && '' !== $b && ( $a === $b || false !== strpos( $a, $b ) || false !== strpos( $b, $a ) );
	}

	/** POST /zam/dopasuj {dostawca, lines:[{tabela, item_id, fields, ilosc}]} → propozycje dla każdej linii PZ. */
	public static function match_r( WP_REST_Request $r ) {
		$p     = (array) $r->get_json_params();
		$open  = self::open_lines();
		$dost  = (string) ( $p['dostawca'] ?? '' );
		$out   = array();
		$used  = array(); // ile już „rozdano” z danej pozycji zamówienia w tej PZ
		foreach ( array_slice( (array) ( $p['lines'] ?? array() ), 0, 200 ) as $i => $l ) {
			$table = (string) ( $l['tabela'] ?? '' );
			if ( ! isset( self::KEYS[ $table ] ) ) {
				$out[] = array();
				continue;
			}
			$row = array();
			if ( ! empty( $l['item_id'] ) ) {
				$row = (array) MSM_Repo::get( $table, (int) $l['item_id'] );
			}
			if ( ! $row ) {
				$row = (array) ( $l['fields'] ?? array() );
			}
			$qty  = (float) ( MSM_Calc::f( $l['ilosc'] ?? null ) ?? 0 );
			$cand = array();
			foreach ( $open as $o ) {
				if ( $o['tabela'] !== $table || ! self::matches( $table, json_decode( (string) $o['spec'], true ) ?: array(), $row ) ) {
					continue;
				}
				$left = (float) $o['ilosc'] - (float) $o['przyjeto'] - ( $used[ (int) $o['id'] ] ?? 0 );
				if ( $left <= 0.0005 ) {
					continue;
				}
				$same   = self::same_supplier( $dost, $o['dostawca'] );
				$cand[] = array( 'poz' => (int) $o['id'], 'zam_id' => (int) $o['zam_id'], 'numer' => $o['numer'], 'dostawca' => $o['dostawca'], 'opis' => $o['opis'], 'jm' => $o['jm'], 'zamowiono' => (float) $o['ilosc'], 'przyjeto' => (float) $o['przyjeto'], 'pozostalo' => $left, 'ten_dostawca' => $same );
			}
			usort( $cand, function ( $a, $b ) { return (int) $b['ten_dostawca'] - (int) $a['ten_dostawca']; } );
			if ( $cand && $cand[0]['ten_dostawca'] && $qty > 0 ) {
				$used[ $cand[0]['poz'] ] = ( $used[ $cand[0]['poz'] ] ?? 0 ) + min( $qty, $cand[0]['pozostalo'] );
			}
			$out[] = array_slice( $cand, 0, 5 );
		}
		return rest_ensure_response( array( 'linie' => $out ) );
	}

	/**
	 * Po zapisaniu PZ: $links = [{line, poz, ilosc}], $got = [line => [table, item_id, qty]].
	 * Zwiększa „przyjęto”, rezerwuje przyjęty materiał dla zleceń z tej pozycji zamówienia. Zwraca opis do komunikatu.
	 */
	public static function pz_receive( $pz_id, $pz_nr, array $links, array $got ) {
		global $wpdb;
		if ( ! self::ready() || ! $links ) {
			return '';
		}
		$zams = array();
		$rezt = array();
		foreach ( array_slice( $links, 0, 200 ) as $lk ) {
			$li  = (int) ( $lk['line'] ?? -1 );
			$pid = (int) ( $lk['poz'] ?? 0 );
			if ( ! isset( $got[ $li ] ) || ! $pid ) {
				continue;
			}
			list( $table, $item_id, $lqty ) = $got[ $li ];
			$poz = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM `' . self::TP() . '` WHERE id = %d', $pid ), ARRAY_A ); // phpcs:ignore
			if ( ! $poz || $poz['tabela'] !== $table ) {
				continue;
			}
			$z = self::get( (int) $poz['zam_id'] );
			if ( ! $z || ! in_array( $z['status'], array( 'wyslane', 'czesciowo', 'szkic' ), true ) ) {
				continue;
			}
			$q = min( (float) ( MSM_Calc::f( $lk['ilosc'] ?? null ) ?? 0 ), (float) $lqty );
			if ( $q <= 0 ) {
				continue;
			}
			$wpdb->update( self::TP(), array( 'przyjeto' => (float) $poz['przyjeto'] + $q ), array( 'id' => $pid ) );
			// Rezerwacje dla zleceń, które czekały na ten materiał.
			$zap  = json_decode( (string) $poz['zap'], true ) ?: array();
			$left = $q;
			$made = array();
			foreach ( $zap as &$a ) {
				if ( $left <= 0.0005 ) {
					break;
				}
				$zr = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM `' . self::TZ() . "` WHERE id = %d AND status <> 'anulowane'", (int) $a['zap'] ), ARRAY_A ); // phpcs:ignore
				if ( ! $zr ) {
					continue;
				}
				$zr = self::with_cover( array( $zr ) )[0];
				$want = min( $left, max( 0, (float) $a['ilosc'] - (float) $a['dost'] ), max( 0, (float) $zr['ilosc'] - (float) $zr['zarezerw'] ) );
				$before = (float) $zr['zarezerw'];
				$n      = self::reserve( $zr, $table, (int) $item_id, $want, 'Dostawa ' . $pz_nr . ' (' . $z['numer'] . ')' );
				if ( $n <= 0 ) {
					continue;
				}
				$ids    = json_decode( (string) $zr['rez'], true ) ?: array();
				$made[] = array( 'rez' => (int) end( $ids ), 'zap' => (int) $zr['id'], 'ilosc' => $n );
				$a['dost'] = (float) $a['dost'] + $n;
				$left     -= $n;
				$wpdb->update( self::TZ(), array( 'zarezerw' => $before + $n, 'z_dost' => (float) $zr['z_dost'] + $n, 'rez' => $zr['rez'], 'status' => $before + $n + 0.0005 >= (float) $zr['ilosc'] ? 'pokryte' : 'otwarte' ), array( 'id' => (int) $zr['id'] ) );
				$rezt[ $zr['nr_zlec'] ] = ( $rezt[ $zr['nr_zlec'] ] ?? 0 ) + $n;
			}
			unset( $a );
			$wpdb->update( self::TP(), array( 'zap' => wp_json_encode( $zap ) ), array( 'id' => $pid ) );
			$wpdb->insert( self::TL(), array( 'zam_poz_id' => $pid, 'zam_id' => (int) $z['id'], 'pz_id' => (int) $pz_id, 'pz_numer' => $pz_nr, 'item_table' => $table, 'item_id' => (int) $item_id, 'ilosc' => $q, 'rez' => wp_json_encode( $made ), 'created_at' => current_time( 'mysql' ) ) );
			$zams[ (int) $z['id'] ] = $z['numer'];
		}
		foreach ( array_keys( $zams ) as $zid ) {
			self::recalc( $zid );
			MSM_Repo::log( 'Zamówienia: dostawa', 'zam', $zid, $zams[ $zid ] . ' – przyjęto w ' . $pz_nr );
		}
		if ( ! $zams ) {
			return '';
		}
		$msg = ' Zaliczono na: ' . implode( ', ', array_values( $zams ) ) . '.';
		if ( $rezt ) {
			$msg .= ' Zarezerwowano dla zleceń: ' . implode( ', ', array_map( function ( $n, $q ) { return $n . ' (' . MSM_Calc::fmt( $q ) . ')'; }, array_keys( $rezt ), array_values( $rezt ) ) ) . '.';
		}
		return $msg;
	}

	/** Anulowanie PZ: cofa „przyjęto” i rezerwacje utworzone z tej dostawy. */
	public static function pz_cancel( $pz_id ) {
		global $wpdb;
		if ( ! self::ready() ) {
			return;
		}
		$links = (array) $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM `' . self::TL() . '` WHERE pz_id = %d', (int) $pz_id ), ARRAY_A ); // phpcs:ignore
		$zams  = array();
		foreach ( $links as $lk ) {
			$poz = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM `' . self::TP() . '` WHERE id = %d', (int) $lk['zam_poz_id'] ), ARRAY_A ); // phpcs:ignore
			if ( $poz ) {
				$zap = json_decode( (string) $poz['zap'], true ) ?: array();
				foreach ( json_decode( (string) $lk['rez'], true ) ?: array() as $m ) {
					$res = MSM_Rezerwacje::action( (int) $m['rez'], 'anuluj', 'Anulowano przyjęcie ' . $lk['pz_numer'] );
					$zr  = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM `' . self::TZ() . '` WHERE id = %d', (int) $m['zap'] ), ARRAY_A ); // phpcs:ignore
					if ( $zr && ! is_wp_error( $res ) ) {
						$wpdb->update( self::TZ(), array( 'zarezerw' => max( 0, (float) $zr['zarezerw'] - (float) $m['ilosc'] ), 'z_dost' => max( 0, (float) $zr['z_dost'] - (float) $m['ilosc'] ), 'status' => 'anulowane' === $zr['status'] ? 'anulowane' : 'otwarte' ), array( 'id' => (int) $zr['id'] ) );
					}
					foreach ( $zap as &$a ) {
						if ( (int) $a['zap'] === (int) $m['zap'] ) {
							$a['dost'] = max( 0, (float) $a['dost'] - (float) $m['ilosc'] );
						}
					}
					unset( $a );
				}
				$wpdb->update( self::TP(), array( 'przyjeto' => max( 0, (float) $poz['przyjeto'] - (float) $lk['ilosc'] ), 'zap' => wp_json_encode( $zap ) ), array( 'id' => (int) $poz['id'] ) );
				$zams[ (int) $poz['zam_id'] ] = 1;
			}
			$wpdb->delete( self::TL(), array( 'id' => (int) $lk['id'] ) );
		}
		foreach ( array_keys( $zams ) as $zid ) {
			$z = self::get( $zid );
			if ( $z && 'zrealizowane' === $z['status'] ) {
				$wpdb->update( self::T(), array( 'status' => 'czesciowo' ), array( 'id' => $zid ) );
			}
			self::recalc( $zid );
		}
	}

	/** PZ (widok): na jakie zamówienia zaliczono pozycje. */
	public static function for_pz( $pz_id ) {
		global $wpdb;
		if ( ! self::ready() ) {
			return array();
		}
		return array_map( function ( $l ) {
			return array( 'zam_id' => (int) $l['zam_id'], 'numer' => (string) $l['numer'], 'opis' => (string) $l['opis'], 'ilosc' => (float) $l['ilosc'] );
		}, (array) $wpdb->get_results( $wpdb->prepare( 'SELECT l.zam_id, l.ilosc, z.numer, p.opis FROM `' . self::TL() . '` l INNER JOIN `' . self::T() . '` z ON z.id = l.zam_id INNER JOIN `' . self::TP() . '` p ON p.id = l.zam_poz_id WHERE l.pz_id = %d ORDER BY l.id', (int) $pz_id ), ARRAY_A ) ); // phpcs:ignore
	}

	/** Pulpit: liczba otwartych braków i zamówień w drodze. */
	public static function tablica() {
		if ( ! self::ready() ) {
			return null;
		}
		global $wpdb;
		$braki = self::braki();
		$do    = count( array_filter( $braki, function ( $b ) { return $b['do_zam'] > 0.0005; } ) );
		return array(
			'braki'    => $do,
			'w_drodze' => (int) $wpdb->get_var( 'SELECT COUNT(*) FROM `' . self::T() . "` WHERE status IN ('wyslane','czesciowo')" ), // phpcs:ignore
			'szkice'   => (int) $wpdb->get_var( 'SELECT COUNT(*) FROM `' . self::T() . "` WHERE status = 'szkic'" ), // phpcs:ignore
		);
	}
}
