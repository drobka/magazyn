<?php
/**
 * Dokumenty WZ (wydanie zewnętrzne).
 *
 * Statusy: szkic → (do_zatwierdzenia) → wystawiona → anulowana.
 * Pozycje: ręczne (bez wpływu na stan), z magazynu (zdejmują stan przy wystawieniu),
 * z wydanych zapotrzebowań (stan już zdjęty – tylko odnośnik).
 * Numeracja: NN/MM/RRRR, licznik od 01 w każdym miesiącu (wg daty wysyłki).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MSM_WZ {

	const S_DRAFT    = 'szkic';
	const S_APPROVAL = 'do_zatwierdzenia';
	const S_ISSUED   = 'wystawiona';
	const S_CANCELED = 'anulowana';

	public static function labels() {
		return array(
			self::S_DRAFT    => 'Szkic',
			self::S_APPROVAL => 'Do zatwierdzenia',
			self::S_ISSUED   => 'Wystawiona',
			self::S_CANCELED => 'Anulowana',
		);
	}

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
		add_action( 'template_redirect', array( __CLASS__, 'maybe_print' ), 1 );
	}

	private static function T() {
		return msm_table( 'wz' );
	}

	private static function TP() {
		global $wpdb;
		return $wpdb->prefix . 'msm_wz_poz';
	}

	/* ------------------------------------------------------------------ *
	 * Odczyt
	 * ------------------------------------------------------------------ */

	public static function get( $id, $lock = false ) {
		global $wpdb;
		$w = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM `' . self::T() . '` WHERE id = %d' . ( $lock ? ' FOR UPDATE' : '' ), $id ), ARRAY_A ); // phpcs:ignore
		if ( ! $w ) {
			return null;
		}
		$w['lines'] = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM `' . self::TP() . '` WHERE wz_id = %d ORDER BY lp, id', $id ), ARRAY_A ); // phpcs:ignore
		return $w;
	}

	public static function public_doc( $w ) {
		$schema = msm_schema();
		$lines  = array();
		foreach ( $w['lines'] as $l ) {
			$item = null;
			if ( 'magazyn' === $l['src'] && in_array( $l['item_table'], msm_stock_tables(), true ) ) {
				$item = MSM_Repo::get( $l['item_table'], (int) $l['item_id'] );
			}
			$lines[] = array(
				'id'          => (int) $l['id'],
				'indeks'      => (string) $l['indeks'],
				'zlecenie'    => (string) $l['zlecenie'],
				'rysunek'     => (string) $l['rysunek'],
				'nazwa'       => (string) $l['nazwa'],
				'ilosc'       => null === $l['ilosc'] ? '' : (float) $l['ilosc'],
				'jm'          => (string) $l['jm'],
				'src'         => $l['src'],
				'item_table'  => $l['item_table'],
				'item_id'     => $l['item_id'] ? (int) $l['item_id'] : null,
				'wniosek_id'  => $l['wniosek_id'] ? (int) $l['wniosek_id'] : null,
				'pobranie_id' => $l['pobranie_id'] ? (int) $l['pobranie_id'] : null,
				'stock'       => $item ? (int) $item['ilosc'] : null,
				'stock_len'   => $item && isset( $item['dlugosc'] ) ? (float) $item['dlugosc'] : null,
				'magazyn'     => $l['item_table'] ? ( $schema[ $l['item_table'] ]['label'] ?? '' ) : '',
			);
		}
		$out          = MSM_Repo::cast_row( 'wz', $w );
		$out['lines'] = $lines;
		foreach ( array( 'data_dok', 'uwagi', 'issued_name', 'issued_at', 'canceled_name', 'canceled_at', 'created_at', 'edited_name', 'edited_at' ) as $k ) {
			$out[ $k ] = $w[ $k ] ?? null;
		}
		$out['edit_count']  = (int) ( $w['edit_count'] ?? 0 );
		$out['created_by']  = (int) $w['created_by'];
		$out['can_edit']    = self::can_edit( $w );
		$out['can_korekta'] = self::can_korekta( $w );
		$out['labels']     = self::labels();
		return $out;
	}

	/** Edycja wystawionej WZ (bez nowego numeru): administrator lub autor dokumentu. */
	private static function can_korekta( $w ) {
		return self::S_ISSUED === $w['status'] && ( current_user_can( 'msm_edit' ) || (int) $w['created_by'] === get_current_user_id() || (int) $w['issued_by'] === get_current_user_id() );
	}

	private static function can_edit( $w ) {
		if ( current_user_can( 'msm_edit' ) ) {
			return in_array( $w['status'], array( self::S_DRAFT, self::S_APPROVAL ), true );
		}
		return self::S_DRAFT === $w['status'] && (int) $w['created_by'] === get_current_user_id();
	}

	/* ------------------------------------------------------------------ *
	 * Zapis szkicu
	 * ------------------------------------------------------------------ */

	private static function clean_header( array $in ) {
		$t   = function ( $k, $max = 190 ) use ( $in ) {
			return mb_substr( trim( sanitize_text_field( wp_unslash( (string) ( $in[ $k ] ?? '' ) ) ) ), 0, $max );
		};
		$d   = function ( $k ) use ( $in ) {
			$v = (string) ( $in[ $k ] ?? '' );
			return preg_match( '/^\d{4}-\d{2}-\d{2}$/', $v ) ? $v : null;
		};
		return array(
			'odbiorca'      => $t( 'odbiorca' ),
			'przeznaczenie' => $t( 'przeznaczenie' ),
			'transport'     => $t( 'transport' ),
			'data_wysylki'  => $d( 'data_wysylki' ) ? $d( 'data_wysylki' ) : current_time( 'Y-m-d' ),
			'data_dok'      => $d( 'data_dok' ),
			'wystawil'      => $t( 'wystawil' ),
			'wydal'         => $t( 'wydal' ),
			'uwagi'         => mb_substr( sanitize_textarea_field( wp_unslash( (string) ( $in['uwagi'] ?? '' ) ) ), 0, 2000 ),
		);
	}

	private static function clean_lines( array $lines, &$errors ) {
		$out = array();
		$lp  = 0;
		foreach ( array_slice( $lines, 0, 300 ) as $i => $l ) {
			if ( ! is_array( $l ) ) {
				continue;
			}
			$t   = function ( $k, $max = 190 ) use ( $l ) {
				return mb_substr( trim( sanitize_text_field( wp_unslash( (string) ( $l[ $k ] ?? '' ) ) ) ), 0, $max );
			};
			$src = in_array( $l['src'] ?? '', array( 'magazyn', 'wniosek' ), true ) ? $l['src'] : 'reczna';
			$row = array(
				'indeks'     => $t( 'indeks' ),
				'zlecenie'   => mb_strtoupper( $t( 'zlecenie' ), 'UTF-8' ),
				'rysunek'    => $t( 'rysunek' ),
				'nazwa'      => $t( 'nazwa', 255 ),
				'ilosc'      => MSM_Calc::f( $l['ilosc'] ?? null ),
				'jm'         => $t( 'jm', 20 ),
				'src'        => $src,
				'item_table' => null,
				'item_id'    => null,
				'wniosek_id' => null,
				'_id'        => (int) ( $l['id'] ?? 0 ),
			);
			// Pusty wiersz – pomijamy.
			if ( '' === $row['nazwa'] && '' === $row['indeks'] && '' === $row['zlecenie'] && '' === $row['rysunek'] && null === $row['ilosc'] ) {
				continue;
			}
			$lp++;
			if ( '' === $row['nazwa'] ) {
				$errors[] = 'Wiersz ' . $lp . ': podaj nazwę.';
			}
			if ( null === $row['ilosc'] || $row['ilosc'] <= 0 ) {
				$errors[] = 'Wiersz ' . $lp . ': podaj ilość większą od zera.';
			}
			if ( '' === $row['jm'] ) {
				$row['jm'] = 'szt.';
			}
			if ( 'magazyn' === $src ) {
				$tab = (string) ( $l['item_table'] ?? '' );
				$iid = (int) ( $l['item_id'] ?? 0 );
				if ( ! in_array( $tab, msm_stock_tables(), true ) || ! MSM_Repo::get( $tab, $iid ) ) {
					$errors[] = 'Wiersz ' . $lp . ': pozycja magazynowa nie istnieje.';
				}
				$row['item_table'] = $tab;
				$row['item_id']    = $iid;
				if ( in_array( $tab, msm_stock_tables(), true ) && 'kg' === msm_unit( $tab ) ) {
					$row['jm'] = 'kg';
				} elseif ( 'm' !== $row['jm'] || 'stal' !== $tab ) {
					if ( null !== $row['ilosc'] && floor( $row['ilosc'] ) != $row['ilosc'] ) { // phpcs:ignore
						$errors[] = 'Wiersz ' . $lp . ': ilość sztuk musi być liczbą całkowitą.';
					}
				}
			}
			if ( 'wniosek' === $src ) {
				$row['wniosek_id'] = (int) ( $l['wniosek_id'] ?? 0 ) ?: null;
				$row['item_table'] = in_array( $l['item_table'] ?? '', msm_stock_tables(), true ) ? $l['item_table'] : null;
				$row['item_id']    = (int) ( $l['item_id'] ?? 0 ) ?: null;
			}
			$row['lp'] = $lp;
			$out[]     = $row;
		}
		return $out;
	}

	private static function summary_fields( array $lines ) {
		$zl = array();
		foreach ( $lines as $l ) {
			if ( '' !== (string) $l['zlecenie'] ) {
				$zl[ $l['zlecenie'] ] = true;
			}
		}
		return array(
			'zlecenia' => implode( ', ', array_keys( $zl ) ),
			'pozycji'  => count( $lines ),
		);
	}

	/** Tworzy lub zapisuje szkic. */
	public static function save( $id, array $in ) {
		global $wpdb;
		$errors = array();
		$head   = self::clean_header( (array) ( $in['header'] ?? $in ) );
		$lines  = self::clean_lines( (array) ( $in['lines'] ?? array() ), $errors );
		if ( $errors ) {
			return new WP_Error( 'msm_invalid', implode( "\n", $errors ), array( 'status' => 400, 'list' => $errors ) );
		}
		$now = current_time( 'mysql' );
		if ( $id ) {
			$w = self::get( $id );
			if ( ! $w ) {
				return new WP_Error( 'msm_not_found', 'Dokument nie istnieje.', array( 'status' => 404 ) );
			}
			if ( ! self::can_edit( $w ) ) {
				return new WP_Error( 'msm_forbidden', 'Tego dokumentu nie można już edytować.', array( 'status' => 403 ) );
			}
			$wpdb->update( self::T(), array_merge( $head, self::summary_fields( $lines ), array( 'updated_at' => $now ) ), array( 'id' => $id ) );
			$wpdb->delete( self::TP(), array( 'wz_id' => $id ) );
		} else {
			if ( '' === $head['wystawil'] ) {
				$head['wystawil'] = MSM_Repo::user_name();
			}
			$wpdb->insert( self::T(), array_merge( $head, self::summary_fields( $lines ), array(
				'status'       => self::S_DRAFT,
				'created_by'   => get_current_user_id(),
				'created_name' => MSM_Repo::user_name(),
				'created_at'   => $now,
				'updated_at'   => $now,
			) ) );
			$id = (int) $wpdb->insert_id;
			MSM_Repo::log( 'WZ: nowy szkic', 'wz', $id, 'Szkic WZ dla: ' . ( $head['odbiorca'] ? $head['odbiorca'] : '—' ) . ', pozycji: ' . count( $lines ) );
		}
		foreach ( $lines as $l ) {
			unset( $l['_id'] );
			$l['wz_id'] = $id;
			$wpdb->insert( self::TP(), $l );
		}
		foreach ( array( 'odbiorca', 'przeznaczenie', 'transport' ) as $k ) {
			if ( ! empty( $head[ $k ] ) ) {
				MSM_Slowniki::ensure( $k, $head[ $k ] );
			}
		}
		return self::public_doc( self::get( $id ) );
	}

	public static function delete_draft( $id ) {
		global $wpdb;
		$w = self::get( $id );
		if ( ! $w ) {
			return new WP_Error( 'msm_not_found', 'Dokument nie istnieje.', array( 'status' => 404 ) );
		}
		if ( ! in_array( $w['status'], array( self::S_DRAFT, self::S_APPROVAL ), true ) || ( ! current_user_can( 'msm_edit' ) && (int) $w['created_by'] !== get_current_user_id() ) ) {
			return new WP_Error( 'msm_forbidden', 'Usunąć można tylko własny szkic. Wystawioną WZ można anulować.', array( 'status' => 403 ) );
		}
		$wpdb->delete( self::TP(), array( 'wz_id' => $id ) );
		$wpdb->delete( self::T(), array( 'id' => $id ) );
		MSM_Repo::log( 'WZ: usunięty szkic', 'wz', $id, 'Usunięto szkic WZ dla: ' . $w['odbiorca'] );
		return array( 'ok' => true, 'message' => 'Szkic usunięty.' );
	}

	/* ------------------------------------------------------------------ *
	 * Wystawienie / zatwierdzenie / anulowanie
	 * ------------------------------------------------------------------ */

	/** Weryfikuje podpis: wyłącznie data URL PNG, rozsądny rozmiar. Zwraca '' gdy niepoprawny. */
	public static function clean_signature( $s ) {
		$s = (string) $s;
		if ( '' === $s ) {
			return '';
		}
		if ( ! preg_match( '#^data:image/png;base64,[A-Za-z0-9+/=\s]+$#', $s ) ) {
			return '';
		}
		if ( strlen( $s ) > 600000 ) {
			return '';
		}
		return $s;
	}

	public static function issue( $id, $podpis = '' ) {
		global $wpdb;
		$w = self::get( $id );
		if ( ! $w ) {
			return new WP_Error( 'msm_not_found', 'Dokument nie istnieje.', array( 'status' => 404 ) );
		}
		if ( ! self::can_edit( $w ) ) {
			return new WP_Error( 'msm_forbidden', 'Tego dokumentu nie można wystawić.', array( 'status' => 403 ) );
		}
		if ( current_user_can( 'msm_edit' ) && class_exists( 'MSM_Perms' ) && ! MSM_Perms::user_can( 'wz' ) ) {
			return new WP_Error( 'msm_forbidden', 'Brak uprawnień do wystawiania WZ.', array( 'status' => 403 ) );
		}
		if ( ! $w['lines'] ) {
			return new WP_Error( 'msm_invalid', 'Dodaj co najmniej jedną pozycję.', array( 'status' => 400 ) );
		}
		if ( '' === trim( (string) $w['odbiorca'] ) ) {
			return new WP_Error( 'msm_invalid', 'Podaj odbiorcę.', array( 'status' => 400 ) );
		}
		$stock_lines = array_filter( $w['lines'], function ( $l ) {
			return 'magazyn' === $l['src'];
		} );
		foreach ( $stock_lines as $l ) {
			if ( 'blachy_pelne' === $l['item_table'] && '' === trim( (string) $l['zlecenie'] ) ) {
				return new WP_Error( 'msm_invalid', 'Wiersz ' . (int) $l['lp'] . ' (' . $l['nazwa'] . '): podaj numer zlecenia – jest wymagany przy pobraniu blachy pełnej.', array( 'status' => 400 ) );
			}
		}

		// Przeglądający + pozycje z magazynu → do zatwierdzenia przez administratora.
		if ( $stock_lines && ! current_user_can( 'msm_edit' ) ) {
			$wpdb->update( self::T(), array( 'status' => self::S_APPROVAL, 'updated_at' => current_time( 'mysql' ) ), array( 'id' => $id ) );
			MSM_Repo::log( 'WZ: do zatwierdzenia', 'wz', $id, 'WZ dla: ' . $w['odbiorca'] . ' – ' . count( $stock_lines ) . ' poz. z magazynu, czeka na zatwierdzenie' );
			self::notify_approval( self::get( $id ) );
			return array(
				'doc'     => self::public_doc( self::get( $id ) ),
				'message' => 'WZ zawiera pozycje z magazynu – wysłano do zatwierdzenia przez administratora (powiadomienie i e-mail).',
			);
		}

		// Numer.
		$date = $w['data_wysylki'] ? $w['data_wysylki'] : current_time( 'Y-m-d' );
		$y    = (int) substr( $date, 0, 4 );
		$m    = (int) substr( $date, 5, 2 );
		$wpdb->query( 'START TRANSACTION' );
		$seq = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT MAX(nr_seq) FROM `' . self::T() . '` WHERE rok = %d AND miesiac = %d FOR UPDATE', $y, $m ) ) + 1; // phpcs:ignore
		$nr  = sprintf( '%02d/%02d/%04d', $seq, $m, $y );
		$ok  = $wpdb->update( self::T(), array( 'nr_seq' => $seq, 'rok' => $y, 'miesiac' => $m, 'numer' => $nr ), array( 'id' => $id ) );
		if ( false === $ok ) {
			$wpdb->query( 'ROLLBACK' );
			return new WP_Error( 'msm_db', 'Nie udało się nadać numeru WZ (ktoś w tej chwili wystawił inny dokument). Spróbuj ponownie.', array( 'status' => 409 ) );
		}
		$wpdb->query( 'COMMIT' );

		// Zdjęcie stanów (z kompensacją przy błędzie).
		$done = array();
		foreach ( $stock_lines as $l ) {
			$odc = 'stal' === $l['item_table'] && 'm' === $l['jm'];
			$res = MSM_Repo::pobranie( array(
				'tabela'   => $l['item_table'],
				'item_id'  => (int) $l['item_id'],
				'tryb'     => $odc ? 'odcinek' : 'szt',
				'ilosc'    => $l['ilosc'],
				'dlugosc'  => $l['ilosc'],
				'zlecenie' => (string) $l['zlecenie'],
				'odbiorca' => trim( $w['odbiorca'] . ' (WZ ' . $nr . ')' ),
				'uwagi'    => trim( 'WZ ' . $nr . ( $l['zlecenie'] ? ', zlecenie ' . $l['zlecenie'] : '' ) ),
				'data'     => $date,
			) );
			if ( is_wp_error( $res ) ) {
				foreach ( array_reverse( $done ) as $pid ) {
					MSM_Repo::cancel_pobranie( $pid );
				}
				$wpdb->update( self::T(), array( 'nr_seq' => null, 'rok' => null, 'miesiac' => null, 'numer' => null ), array( 'id' => $id ) );
				return new WP_Error( 'msm_stock', 'Wiersz ' . (int) $l['lp'] . ' (' . $l['nazwa'] . '): ' . $res->get_error_message() . ' Nic nie zostało zdjęte ze stanu.', array( 'status' => 400 ) );
			}
			$pid    = (int) $res['pobranie']['id'];
			$done[] = $pid;
			$wpdb->update( self::TP(), array( 'pobranie_id' => $pid ), array( 'id' => (int) $l['id'] ) );
		}

		$upd = array(
			'status'      => self::S_ISSUED,
			'issued_by'   => get_current_user_id(),
			'issued_name' => MSM_Repo::user_name(),
			'issued_at'   => current_time( 'mysql' ),
			'data_dok'    => $w['data_dok'] ? $w['data_dok'] : current_time( 'Y-m-d' ),
			'wydal'       => $w['wydal'] ? $w['wydal'] : MSM_Repo::user_name(),
			'updated_at'  => current_time( 'mysql' ),
		);
		$sig = self::clean_signature( $podpis );
		if ( '' !== $sig ) {
			$upd['podpis'] = $sig;
		}
		$wpdb->update( self::T(), $upd, array( 'id' => $id ) );
		MSM_Repo::log( 'WZ: wystawiona', 'wz', $id, 'WZ ' . $nr . ' dla: ' . $w['odbiorca'] . ' – pozycji: ' . count( $w['lines'] ) . ( $stock_lines ? ', z magazynu: ' . count( $stock_lines ) : '' ) );
		$doc = self::get( $id );
		if ( self::S_APPROVAL === $w['status'] ) {
			self::notify_creator( $doc, 'WZ ' . $nr . ' została zatwierdzona i wystawiona.' );
		}
		return array(
			'doc'     => self::public_doc( $doc ),
			'message' => 'Wystawiono WZ ' . $nr . ( $stock_lines ? '. Zdjęto ze stanu ' . count( $stock_lines ) . ' poz.' : '.' ),
		);
	}

	/* ------------------------------------------------------------------ *
	 * Edycja wystawionej WZ (numer bez zmian, zmiany zapisane w historii)
	 * ------------------------------------------------------------------ */

	const HEAD_LABELS = array(
		'odbiorca'      => 'Odbiorca',
		'przeznaczenie' => 'Przeznaczenie',
		'transport'     => 'Środek transportu',
		'data_wysylki'  => 'Data wysyłki',
		'data_dok'      => 'Data wydania',
		'wystawil'      => 'Wystawił',
		'wydal'         => 'Wydał',
		'uwagi'         => 'Uwagi',
	);
	const LINE_LABELS = array(
		'indeks'   => 'nr indeksu',
		'zlecenie' => 'nr zlecenia',
		'rysunek'  => 'nr rysunku',
		'nazwa'    => 'nazwa',
		'ilosc'    => 'ilość',
		'jm'       => 'j.m.',
	);

	private static function qty( $v ) {
		return null === $v || '' === $v ? '' : rtrim( rtrim( number_format( (float) $v, 3, ',', '' ), '0' ), ',' );
	}

	public static function korekta( $id, array $in ) {
		global $wpdb;
		$w = self::get( $id );
		if ( ! $w ) {
			return new WP_Error( 'msm_not_found', 'Dokument nie istnieje.', array( 'status' => 404 ) );
		}
		if ( ! self::can_korekta( $w ) ) {
			return new WP_Error( 'msm_forbidden', self::S_ISSUED === $w['status'] ? 'Brak uprawnień do edycji tej WZ.' : 'Edytować w ten sposób można tylko wystawioną WZ.', array( 'status' => 403 ) );
		}
		$admin  = current_user_can( 'msm_edit' );
		$errors = array();
		$head   = self::clean_header( (array) ( $in['header'] ?? array() ) );
		$lines  = self::clean_lines( (array) ( $in['lines'] ?? array() ), $errors );
		$powod  = mb_substr( sanitize_text_field( wp_unslash( (string) ( $in['powod'] ?? '' ) ) ), 0, 500 );
		if ( '' === $head['odbiorca'] ) {
			$errors[] = 'Podaj odbiorcę.';
		}
		if ( ! $lines ) {
			$errors[] = 'WZ musi mieć co najmniej jedną pozycję.';
		}
		if ( '' === (string) $head['wystawil'] ) {
			$head['wystawil'] = $w['wystawil'];
		}

		$old = array();
		foreach ( $w['lines'] as $l ) {
			$old[ (int) $l['id'] ] = $l;
		}
		$kept  = array();
		$added = array();
		foreach ( $lines as $k => $l ) {
			$oid = $l['_id'];
			if ( $oid && isset( $old[ $oid ] ) && ! isset( $kept[ $oid ] ) ) {
				$o = $old[ $oid ];
				// Pozycje powiązane ze stanem: źródło, ilość i j.m. bez zmian (stan już zdjęty).
				if ( in_array( $o['src'], array( 'magazyn', 'wniosek' ), true ) ) {
					foreach ( array( 'src', 'item_table', 'item_id', 'wniosek_id' ) as $f ) {
						$lines[ $k ][ $f ] = $o[ $f ];
					}
					$lines[ $k ]['ilosc'] = (float) $o['ilosc'];
					$lines[ $k ]['jm']    = $o['jm'];
				}
				$lines[ $k ]['pobranie_id'] = $o['pobranie_id'];
				$kept[ $oid ]               = $k;
			} else {
				$lines[ $k ]['_id']         = 0;
				$lines[ $k ]['pobranie_id'] = null;
				if ( 'magazyn' === $l['src'] ) {
					if ( ! $admin ) {
						$errors[] = 'Wiersz ' . $l['lp'] . ': pozycje z magazynu do wystawionej WZ może dodać tylko administrator.';
					}
					$added[] = $k;
				}
			}
		}
		$removed = array_diff_key( $old, $kept );
		foreach ( $removed as $o ) {
			if ( $o['pobranie_id'] && ! $admin ) {
				$errors[] = 'Usunąć pozycję pobraną z magazynu („' . $o['nazwa'] . '”) może tylko administrator.';
			}
		}
		if ( $errors ) {
			return new WP_Error( 'msm_invalid', implode( "\n", array_unique( $errors ) ), array( 'status' => 400 ) );
		}

		// Lista zmian (do historii – nie trafia na wydruk).
		$changes = array();
		foreach ( self::HEAD_LABELS as $f => $lab ) {
			$a = (string) $w[ $f ];
			$b = (string) $head[ $f ];
			if ( $a !== $b ) {
				$changes[] = array( 'pole' => $lab, 'przed' => $a, 'po' => $b );
			}
		}
		foreach ( $lines as $l ) {
			if ( ! $l['_id'] ) {
				$changes[] = array( 'pole' => 'Dodano wiersz', 'przed' => '', 'po' => $l['nazwa'] . ' – ' . self::qty( $l['ilosc'] ) . ' ' . $l['jm'] . ( 'magazyn' === $l['src'] ? ' (z magazynu – zdjęto ze stanu)' : '' ) );
				continue;
			}
			$o = $old[ $l['_id'] ];
			foreach ( self::LINE_LABELS as $f => $lab ) {
				$a = 'ilosc' === $f ? self::qty( $o[ $f ] ) : (string) $o[ $f ];
				$b = 'ilosc' === $f ? self::qty( $l[ $f ] ) : (string) $l[ $f ];
				if ( $a !== $b ) {
					$changes[] = array( 'pole' => 'Wiersz ' . $l['lp'] . ' (' . $o['nazwa'] . '): ' . $lab, 'przed' => $a, 'po' => $b );
				}
			}
			if ( (int) $o['lp'] !== (int) $l['lp'] ) {
				$changes[] = array( 'pole' => 'Kolejność: „' . $l['nazwa'] . '”', 'przed' => 'Lp. ' . $o['lp'], 'po' => 'Lp. ' . $l['lp'] );
			}
		}
		foreach ( $removed as $o ) {
			$changes[] = array( 'pole' => 'Usunięto wiersz', 'przed' => $o['nazwa'] . ' – ' . self::qty( $o['ilosc'] ) . ' ' . $o['jm'] . ( $o['pobranie_id'] ? ' (stan zwrócony na magazyn)' : '' ), 'po' => '' );
		}
		if ( ! $changes ) {
			return array( 'doc' => self::public_doc( $w ), 'message' => 'Brak zmian do zapisania.', 'unchanged' => true );
		}

		// Nowe pozycje z magazynu → zdjęcie stanu (z kompensacją).
		$done = array();
		foreach ( $added as $k ) {
			$l   = $lines[ $k ];
			$odc = 'stal' === $l['item_table'] && 'm' === $l['jm'];
			$res = MSM_Repo::pobranie( array(
				'tabela'   => $l['item_table'],
				'item_id'  => (int) $l['item_id'],
				'tryb'     => $odc ? 'odcinek' : 'szt',
				'ilosc'    => $l['ilosc'],
				'dlugosc'  => $l['ilosc'],
				'zlecenie' => (string) $l['zlecenie'],
				'odbiorca' => trim( $head['odbiorca'] . ' (WZ ' . $w['numer'] . ')' ),
				'uwagi'    => trim( 'WZ ' . $w['numer'] . ' (edycja)' . ( $l['zlecenie'] ? ', zlecenie ' . $l['zlecenie'] : '' ) ),
				'data'     => current_time( 'Y-m-d' ),
			) );
			if ( is_wp_error( $res ) ) {
				foreach ( array_reverse( $done ) as $pid ) {
					MSM_Repo::cancel_pobranie( $pid );
				}
				return new WP_Error( 'msm_stock', 'Wiersz ' . (int) $l['lp'] . ' (' . $l['nazwa'] . '): ' . $res->get_error_message() . ' Nic nie zostało zmienione.', array( 'status' => 400 ) );
			}
			$done[]                     = (int) $res['pobranie']['id'];
			$lines[ $k ]['pobranie_id'] = (int) $res['pobranie']['id'];
		}
		// Usunięte pozycje z magazynu → zwrot stanu.
		$warn = array();
		foreach ( $removed as $o ) {
			if ( $o['pobranie_id'] ) {
				$r = MSM_Repo::cancel_pobranie( (int) $o['pobranie_id'] );
				if ( is_wp_error( $r ) ) {
					$warn[] = $o['nazwa'] . ': ' . $r->get_error_message();
				}
			}
		}

		$wpdb->delete( self::TP(), array( 'wz_id' => $id ) );
		foreach ( $lines as $l ) {
			unset( $l['_id'] );
			$l['wz_id'] = $id;
			$wpdb->insert( self::TP(), $l );
		}
		$wpdb->update( self::T(), array_merge( $head, self::summary_fields( $lines ), array(
			'edit_count'  => (int) $w['edit_count'] + 1,
			'edited_name' => MSM_Repo::user_name(),
			'edited_at'   => current_time( 'mysql' ),
			'updated_at'  => current_time( 'mysql' ),
		) ), array( 'id' => $id ) );
		foreach ( array( 'odbiorca', 'przeznaczenie', 'transport' ) as $k ) {
			if ( ! empty( $head[ $k ] ) ) {
				MSM_Slowniki::ensure( $k, $head[ $k ] );
			}
		}
		$summary = array_map( function ( $c ) {
			return $c['pole'] . ( '' !== $c['przed'] || '' !== $c['po'] ? ': ' . ( '' === $c['przed'] ? '—' : $c['przed'] ) . ' → ' . ( '' === $c['po'] ? '—' : $c['po'] ) : '' );
		}, $changes );
		MSM_Repo::log( 'WZ: edycja', 'wz', $id, 'WZ ' . $w['numer'] . ' – ' . count( $changes ) . ' ' . ( 1 === count( $changes ) ? 'zmiana' : 'zmian(y)' ) . ( $powod ? ' (powód: ' . $powod . ')' : '' ) . ': ' . implode( '; ', $summary ), array( 'zmiany' => $changes, 'powod' => $powod ) );
		return array(
			'doc'     => self::public_doc( self::get( $id ) ),
			'message' => 'Zapisano zmiany w WZ ' . $w['numer'] . ' (numer bez zmian, edycja zapisana w historii).' . ( $warn ? ' Uwaga: ' . implode( '; ', $warn ) : '' ),
		);
	}

	/** Historia dokumentu (z dziennika). */
	public static function history( $id ) {
		global $wpdb;
		$L    = msm_table( 'historia' );
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT czas, user_name, akcja, opis, dane FROM `$L` WHERE tabela_key = 'wz' AND item_id = %d ORDER BY czas DESC, id DESC LIMIT 200", $id ), ARRAY_A ); // phpcs:ignore
		return array_map( function ( $r ) {
			$d = $r['dane'] ? json_decode( $r['dane'], true ) : null;
			return array(
				'czas'   => $r['czas'],
				'user'   => $r['user_name'],
				'akcja'  => preg_replace( '/^WZ: /', '', $r['akcja'] ),
				'opis'   => $r['opis'],
				'zmiany' => is_array( $d ) && isset( $d['zmiany'] ) ? $d['zmiany'] : null,
				'powod'  => is_array( $d ) && ! empty( $d['powod'] ) ? $d['powod'] : '',
			);
		}, $rows );
	}

	/** Administrator zwraca WZ do poprawy (z do_zatwierdzenia do szkicu). */
	public static function reject( $id, $note ) {
		global $wpdb;
		if ( ! current_user_can( 'msm_edit' ) ) {
			return new WP_Error( 'msm_forbidden', 'Brak uprawnień.', array( 'status' => 403 ) );
		}
		$w = self::get( $id );
		if ( ! $w || self::S_APPROVAL !== $w['status'] ) {
			return new WP_Error( 'msm_state', 'Ten dokument nie czeka na zatwierdzenie.', array( 'status' => 400 ) );
		}
		$note = mb_substr( sanitize_textarea_field( wp_unslash( (string) $note ) ), 0, 1000 );
		$wpdb->update( self::T(), array( 'status' => self::S_DRAFT, 'uwagi' => trim( $w['uwagi'] . ( $note ? "\nUwagi administratora: " . $note : '' ) ) ), array( 'id' => $id ) );
		MSM_Repo::log( 'WZ: zwrócona do poprawy', 'wz', $id, 'WZ dla: ' . $w['odbiorca'] . ( $note ? ' (' . $note . ')' : '' ) );
		self::notify_creator( self::get( $id ), 'WZ dla „' . $w['odbiorca'] . '” została zwrócona do poprawy.' . ( $note ? ' Uwagi: ' . $note : '' ) );
		return array( 'doc' => self::public_doc( self::get( $id ) ), 'message' => 'Zwrócono do poprawy.' );
	}

	public static function cancel( $id, $note ) {
		global $wpdb;
		if ( ! current_user_can( 'msm_edit' ) ) {
			return new WP_Error( 'msm_forbidden', 'Anulować WZ może administrator magazynu.', array( 'status' => 403 ) );
		}
		$w = self::get( $id );
		if ( ! $w || self::S_ISSUED !== $w['status'] ) {
			return new WP_Error( 'msm_state', 'Anulować można tylko wystawioną WZ.', array( 'status' => 400 ) );
		}
		$warn = array();
		foreach ( $w['lines'] as $l ) {
			if ( $l['pobranie_id'] ) {
				$r = MSM_Repo::cancel_pobranie( (int) $l['pobranie_id'] );
				if ( is_wp_error( $r ) ) {
					$warn[] = 'wiersz ' . $l['lp'] . ': ' . $r->get_error_message();
				} elseif ( ! empty( $r['warning'] ) ) {
					$warn[] = 'wiersz ' . $l['lp'] . ': ' . $r['warning'];
				}
			}
		}
		$note = mb_substr( sanitize_text_field( wp_unslash( (string) $note ) ), 0, 500 );
		$wpdb->update( self::T(), array(
			'status'        => self::S_CANCELED,
			'canceled_name' => MSM_Repo::user_name(),
			'canceled_at'   => current_time( 'mysql' ),
			'uwagi'         => trim( $w['uwagi'] . ( $note ? "\nAnulowano: " . $note : '' ) ),
		), array( 'id' => $id ) );
		MSM_Repo::log( 'WZ: anulowana', 'wz', $id, 'WZ ' . $w['numer'] . ' dla: ' . $w['odbiorca'] . ' – stan z pozycji magazynowych zwrócony' . ( $note ? ' (' . $note . ')' : '' ) );
		return array( 'doc' => self::public_doc( self::get( $id ) ), 'message' => 'WZ ' . $w['numer'] . ' anulowana, stan zwrócony.' . ( $warn ? ' Uwaga: ' . implode( '; ', $warn ) : '' ) );
	}

	public static function duplicate( $id ) {
		$w = self::get( $id );
		if ( ! $w ) {
			return new WP_Error( 'msm_not_found', 'Dokument nie istnieje.', array( 'status' => 404 ) );
		}
		$lines = array_map( function ( $l ) {
			unset( $l['id'], $l['wz_id'], $l['pobranie_id'] );
			if ( 'wniosek' === $l['src'] ) {
				$l['src'] = 'reczna';
			}
			return $l;
		}, $w['lines'] );
		$head  = $w;
		unset( $head['lines'] );
		$head['data_wysylki'] = current_time( 'Y-m-d' );
		$head['data_dok']     = '';
		$head['wystawil']     = MSM_Repo::user_name();
		$head['wydal']        = '';
		$head['uwagi']        = '';
		return self::save( 0, array( 'header' => $head, 'lines' => $lines ) );
	}

	/** Wydane zapotrzebowania dla zlecenia – do dodania na WZ (bez ponownego zdejmowania stanu). */
	public static function issued_requests( $zl ) {
		global $wpdb;
		$zl = mb_strtoupper( trim( sanitize_text_field( (string) $zl ) ), 'UTF-8' );
		if ( '' === $zl ) {
			return array();
		}
		$W    = msm_table( 'wnioski' );
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `$W` WHERE typ = 'pobranie' AND status = 'wydany' AND zlecenie = %s ORDER BY id DESC LIMIT 200", $zl ), ARRAY_A ); // phpcs:ignore
		$used = $wpdb->get_col( 'SELECT DISTINCT p.wniosek_id FROM `' . self::TP() . '` p INNER JOIN `' . self::T() . "` w ON w.id = p.wz_id WHERE p.wniosek_id IS NOT NULL AND w.status <> 'anulowana'" ); // phpcs:ignore
		$used = array_map( 'intval', $used );
		return array_map( function ( $r ) use ( $used ) {
			return array(
				'id'         => (int) $r['id'],
				'material'   => $r['material'],
				'ilosc'      => (float) $r['ilosc'],
				'jednostka'  => $r['jednostka'],
				'user_name'  => $r['user_name'],
				'issued_at'  => $r['issued_at'],
				'item_table' => $r['item_table'],
				'item_id'    => (int) $r['item_id'],
				'on_wz'      => in_array( (int) $r['id'], $used, true ),
			);
		}, $rows );
	}

	public static function counts() {
		global $wpdb;
		return array( 'do_zatwierdzenia' => current_user_can( 'msm_edit' ) ? (int) $wpdb->get_var( 'SELECT COUNT(*) FROM `' . self::T() . "` WHERE status = 'do_zatwierdzenia'" ) : 0 ); // phpcs:ignore
	}

	/* ------------------------------------------------------------------ *
	 * E-maile
	 * ------------------------------------------------------------------ */

	private static function notify_approval( $w ) {
		$rows = '';
		foreach ( $w['lines'] as $l ) {
			$rows .= '<tr><td style="border-bottom:1px solid #e3e6ec;color:#6b7285">' . (int) $l['lp'] . '.</td><td style="border-bottom:1px solid #e3e6ec">' . esc_html( $l['nazwa'] ) . ( 'magazyn' === $l['src'] ? ' <span style="color:#1f4fbf;font-size:12px">[z magazynu]</span>' : '' ) . '</td><td style="border-bottom:1px solid #e3e6ec;text-align:right;white-space:nowrap"><strong>' . esc_html( MSM_Calc::fmt( $l['ilosc'] ) . ' ' . $l['jm'] ) . '</strong></td></tr>';
		}
		$t = MSM_Mail::render( 'wz_admin', array(
			'user_name' => $w['created_name'],
			'odbiorca'  => $w['odbiorca'],
			'data'      => mysql2date( 'd.m.Y', $w['data_wysylki'] ),
			'pozycje'   => '<table cellpadding="6" cellspacing="0" style="border-collapse:collapse;margin:8px 0 14px;font-size:13px">' . $rows . '</table>',
			'url'       => '<a href="' . esc_url( MSM_Access::app_url() . '#wz' ) . '">Otwórz dokumenty WZ</a>',
		) );
		MSM_Mail::send( MSM_Wnioski::admin_emails(), $t['subject'], $t['body'], array( 'footer' => true, 'logo' => true ) );
	}

	private static function notify_creator( $w, $text ) {
		$u = get_userdata( (int) $w['created_by'] );
		if ( ! $u || ! is_email( $u->user_email ) || (int) $w['created_by'] === get_current_user_id() ) {
			return;
		}
		$t = MSM_Mail::render( 'wz_status', array( 'komunikat' => $text, 'url' => '<a href="' . esc_url( MSM_Access::app_url() . '#wz' ) . '">Otwórz dokumenty WZ</a>' ) );
		MSM_Mail::send( $u->user_email, $t['subject'], $t['body'], array( 'footer' => true, 'logo' => true ) );
	}

	/* ------------------------------------------------------------------ *
	 * REST
	 * ------------------------------------------------------------------ */

	public static function routes() {
		$ns   = MSM_Rest::NS;
		$view = MSM_Rest::in_section( 'wz' ); // 1.84.0: wyłączona sekcja WZ blokuje też API
		$any  = array( 'MSM_Rest', 'can_view' ); // licznik w nawigacji
		register_rest_route( $ns, '/wz', array(
			'methods' => 'POST', 'permission_callback' => $view,
			'callback' => function ( WP_REST_Request $r ) {
				return rest_ensure_response( MSM_WZ::save( 0, (array) $r->get_json_params() ) );
			},
		) );
		register_rest_route( $ns, '/wz/zlecenie', array(
			'methods' => 'GET', 'permission_callback' => $view,
			'callback' => function ( WP_REST_Request $r ) {
				return rest_ensure_response( MSM_WZ::issued_requests( (string) $r->get_param( 'zl' ) ) );
			},
		) );
		register_rest_route( $ns, '/wz/count', array(
			'methods' => 'GET', 'permission_callback' => $any,
			'callback' => function () {
				return rest_ensure_response( MSM_WZ::counts() );
			},
		) );
		register_rest_route( $ns, '/wz/(?P<id>\d+)', array(
			array(
				'methods' => 'GET', 'permission_callback' => $view,
				'callback' => function ( WP_REST_Request $r ) {
					$w = MSM_WZ::get( (int) $r['id'] );
					return $w ? rest_ensure_response( MSM_WZ::public_doc( $w ) ) : new WP_Error( 'msm_not_found', 'Dokument nie istnieje.', array( 'status' => 404 ) );
				},
			),
			array(
				'methods' => 'POST', 'permission_callback' => $view,
				'callback' => function ( WP_REST_Request $r ) {
					return rest_ensure_response( MSM_WZ::save( (int) $r['id'], (array) $r->get_json_params() ) );
				},
			),
			array(
				'methods' => 'DELETE', 'permission_callback' => $view,
				'callback' => function ( WP_REST_Request $r ) {
					return rest_ensure_response( MSM_WZ::delete_draft( (int) $r['id'] ) );
				},
			),
		) );
		register_rest_route( $ns, '/wz/(?P<id>\d+)/korekta', array(
			'methods' => 'POST', 'permission_callback' => $view,
			'callback' => function ( WP_REST_Request $r ) {
				return rest_ensure_response( MSM_WZ::korekta( (int) $r['id'], (array) $r->get_json_params() ) );
			},
		) );
		register_rest_route( $ns, '/wz/(?P<id>\d+)/historia', array(
			'methods' => 'GET', 'permission_callback' => $view,
			'callback' => function ( WP_REST_Request $r ) {
				return MSM_WZ::get( (int) $r['id'] ) ? rest_ensure_response( MSM_WZ::history( (int) $r['id'] ) ) : new WP_Error( 'msm_not_found', 'Dokument nie istnieje.', array( 'status' => 404 ) );
			},
		) );
		register_rest_route( $ns, '/wz/(?P<id>\d+)/(?P<action>wystaw|zwroc|anuluj|duplikuj)', array(
			'methods' => 'POST', 'permission_callback' => $view,
			'callback' => function ( WP_REST_Request $r ) {
				$id   = (int) $r['id'];
				$note = (string) ( ( (array) $r->get_json_params() )['note'] ?? '' );
				switch ( $r['action'] ) {
					case 'wystaw':
						$podpis = (string) ( ( (array) $r->get_json_params() )['podpis'] ?? '' );
						$res = MSM_WZ::issue( $id, $podpis );
						break;
					case 'zwroc':
						$res = MSM_WZ::reject( $id, $note );
						break;
					case 'anuluj':
						$res = MSM_WZ::cancel( $id, $note );
						break;
					default:
						$res = MSM_WZ::duplicate( $id );
						if ( ! is_wp_error( $res ) ) {
							$res = array( 'doc' => $res, 'message' => 'Utworzono kopię jako nowy szkic.' );
						}
				}
				return rest_ensure_response( $res );
			},
		) );
	}

	/* ------------------------------------------------------------------ *
	 * Wydruk i Excel
	 * ------------------------------------------------------------------ */

	public static function maybe_print() {
		$what = isset( $_GET['msm_print'] ) ? sanitize_key( wp_unslash( $_GET['msm_print'] ) ) : ''; // phpcs:ignore
		if ( ! in_array( $what, array( 'wz', 'wzxlsx', 'wzlista' ), true ) || ! is_user_logged_in() ) {
			return;
		}
		if ( ! current_user_can( 'msm_view' ) || ( ! MSM_Perms::is_wp_admin() && ! MSM_Perms::menu_on( 'wz' ) ) ) {
			wp_die( 'Brak dostępu.', 403 );
		}
		nocache_headers();
		if ( 'wzlista' === $what ) {
			self::print_list();
			exit;
		}
		$w = self::get( (int) ( $_GET['id'] ?? 0 ) ); // phpcs:ignore
		if ( ! $w ) {
			wp_die( 'Dokument nie istnieje.', 404 );
		}
		if ( 'wzxlsx' === $what ) {
			self::xlsx( $w );
		} else {
			self::print_doc( $w );
		}
		exit;
	}

	private static function nr_label( $w ) {
		if ( self::S_ISSUED === $w['status'] || self::S_CANCELED === $w['status'] ) {
			return (string) $w['numer'];
		}
		return 'SZKIC';
	}

	private static function print_doc( $w ) {
		$labels = self::labels();
		$nr     = self::nr_label( $w );
		$draft  = ! in_array( $w['status'], array( self::S_ISSUED, self::S_CANCELED ), true );
		$sum    = array();
		foreach ( $w['lines'] as $l ) {
			$sum[ $l['jm'] ] = ( $sum[ $l['jm'] ] ?? 0 ) + (float) $l['ilosc'];
		}
		$fonts = MSM_URL . 'assets/fonts/';
		$n     = function ( $v ) {
			return MSM_Calc::fmt( $v );
		};
		?><!DOCTYPE html>
<html lang="pl"><head><meta charset="utf-8"><meta name="robots" content="noindex,nofollow"><title>WZ <?php echo esc_html( $nr ); ?></title>
<style>
@font-face{font-family:PJS;font-weight:400;src:url(<?php echo esc_url( $fonts ); ?>plus-jakarta-sans-latin-ext-400-normal.woff2) format("woff2");unicode-range:U+0100-02BA,U+1E00-1E9F}
@font-face{font-family:PJS;font-weight:400;src:url(<?php echo esc_url( $fonts ); ?>plus-jakarta-sans-latin-400-normal.woff2) format("woff2");unicode-range:U+0000-00FF,U+2000-206F}
@font-face{font-family:PJS;font-weight:600;src:url(<?php echo esc_url( $fonts ); ?>plus-jakarta-sans-latin-ext-600-normal.woff2) format("woff2");unicode-range:U+0100-02BA,U+1E00-1E9F}
@font-face{font-family:PJS;font-weight:600;src:url(<?php echo esc_url( $fonts ); ?>plus-jakarta-sans-latin-600-normal.woff2) format("woff2");unicode-range:U+0000-00FF,U+2000-206F}
@font-face{font-family:PJS;font-weight:800;src:url(<?php echo esc_url( $fonts ); ?>plus-jakarta-sans-latin-ext-800-normal.woff2) format("woff2");unicode-range:U+0100-02BA,U+1E00-1E9F}
@font-face{font-family:PJS;font-weight:800;src:url(<?php echo esc_url( $fonts ); ?>plus-jakarta-sans-latin-800-normal.woff2) format("woff2");unicode-range:U+0000-00FF,U+2000-206F}
@page{size:A4;margin:12mm 13mm}
*{box-sizing:border-box}
html,body{margin:0;background:#e9ebef}
body{font:9.5pt/1.4 PJS,sans-serif;color:#0b1020;-webkit-print-color-adjust:exact;print-color-adjust:exact}
.bar{position:sticky;top:0;display:flex;gap:10px;justify-content:center;align-items:center;padding:10px;background:#0b1020;color:#fff;font-size:13px;z-index:5}
.bar button,.bar a{font:600 13px PJS,system-ui;padding:8px 18px;border-radius:99px;border:0;background:#3d4bff;color:#fff;cursor:pointer;text-decoration:none}
.bar .g{background:transparent;border:1px solid rgba(255,255,255,.4)}
.bar .x{display:inline-flex;align-items:center;padding:5px 14px;background:#fff;border-color:#fff}
.copy-page{display:flex;flex-direction:column;min-height:271mm;position:relative}
.copy-page + .copy-page{break-before:page;page-break-before:always}
@media screen{.copy-page{width:210mm;min-height:297mm;padding:12mm 13mm;margin:16px auto;background:#fff;box-shadow:0 4px 24px rgba(0,0,0,.14)}.copy-page + .copy-page{display:none}}
@media print{html,body{background:#fff}.bar{display:none}}
.copy{font-size:6.5pt;font-weight:800;letter-spacing:.08em;text-transform:uppercase;color:#5a6274;text-align:right;margin-bottom:1.5mm}
.grid3{display:grid;grid-template-columns:62mm 1fr 44mm;border:1.5px solid #0b1020}
.grid3>div{border-right:1px solid #0b1020}.grid3>div:last-child{border-right:0}
.grid3.r2{border-top:0}
.cell{padding:2mm 3mm}
.lbl{display:block;font-size:6.8pt;text-transform:uppercase;letter-spacing:.06em;color:#5a6274;font-weight:600}
.stamp{display:flex;flex-direction:column;justify-content:space-between;min-height:30mm}
.stamp img{height:12mm;width:auto;max-width:100%;align-self:flex-start;margin-top:1.5mm}
.stamp small{font-size:7pt;color:#3a4256;line-height:1.35}
.mid{display:grid;grid-template-rows:1fr auto}
.mid .cell+.cell{border-top:1px solid #0b1020}
.big{font-size:11pt;font-weight:600}
.wz{display:flex;flex-direction:column;justify-content:center;align-items:center;text-align:center;background:#0E58A4;color:#fff}
.wz b{font-size:24pt;font-weight:800;line-height:1}
.wz span{font-size:12pt;font-weight:800;margin-top:1mm;color:#fff}
.wz.draft{background:#a76a00}
table{width:100%;border-collapse:collapse;margin-top:4mm;font-size:9pt}
thead{display:table-header-group}
tr{page-break-inside:avoid}
th{background:#eef1f6;border:1px solid #0b1020;padding:1.8mm 2mm;font-size:7pt;text-transform:uppercase;letter-spacing:.04em;font-weight:600;text-align:left;vertical-align:bottom}
td{border:1px solid #9aa0aa;padding:2.2mm 2mm;vertical-align:top}
td.n,th.n{text-align:right}td.c,th.c{text-align:center}
.src{display:block;font-size:6.5pt;color:#6b7285;margin-top:.5mm}
tfoot td{font-weight:800;background:#fafaf8;border-color:#0b1020}
.notes{margin-top:3mm;font-size:8.5pt;white-space:pre-line}
.sign{display:grid;grid-template-columns:1fr 1fr .8fr 1fr;border:1.5px solid #0b1020;margin-top:auto}
.sign>div{border-right:1px solid #0b1020;padding:2mm 3mm;min-height:20mm;display:flex;flex-direction:column;justify-content:space-between}
.sign>div:last-child{border-right:0}
.sign .v{font-weight:600}
.sign .sig{max-height:16mm;max-width:100%;object-fit:contain;align-self:center;margin-top:1mm}
.spacer{height:8mm}
.ft{display:flex;justify-content:space-between;font-size:6.5pt;color:#6b7285;margin-top:2mm}
.stamp-cancel{position:absolute;top:95mm;left:50%;transform:translateX(-50%) rotate(-18deg);font-size:46pt;font-weight:800;color:rgba(196,55,44,.22);border:6px solid rgba(196,55,44,.22);padding:2mm 8mm;border-radius:4mm;pointer-events:none}
</style></head><body>
<div class="bar"><span>WZ <?php echo esc_html( $nr ); ?> · <b>Format A4 · drukowane są 2 kopie (Oryginał i Kopia)</b></span>
<button onclick="window.print()">Drukuj</button>
<a class="g x" href="<?php echo esc_url( add_query_arg( array( 'msm_print' => 'wzxlsx', 'id' => (int) $w['id'] ), MSM_Access::app_url() ) ); ?>" title="Pobierz WZ w Excelu (.xlsx)" aria-label="Pobierz WZ w Excelu (.xlsx)"><svg width="22" height="22" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 2h8l5 5v13a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2z" fill="#fff" stroke="#1d6f42" stroke-width="1.6"/><path d="M14 2v5h5" fill="none" stroke="#1d6f42" stroke-width="1.6"/><rect x="1.5" y="11" width="15" height="8" rx="1.6" fill="#1d6f42"/><text x="9" y="17.2" text-anchor="middle" font-family="Arial,Helvetica,sans-serif" font-size="6.2" font-weight="700" fill="#fff">XLS</text></svg></a>
<button class="g" onclick="window.close()">Zamknij</button></div>
		<?php foreach ( array( 'Oryginał', 'Kopia' ) as $copy ) : ?>
<div class="copy-page">
  <?php if ( self::S_CANCELED === $w['status'] ) : ?><div class="stamp-cancel">ANULOWANA</div><?php endif; ?>
  <div class="copy"><?php echo esc_html( $copy ); ?><?php echo $draft ? ' · ' . esc_html( $labels[ $w['status'] ] ) . ' – dokument niewystawiony' : ''; ?></div>
  <div class="grid3">
    <div class="cell stamp"><span class="lbl">Pieczęć firmowa</span><img src="<?php echo esc_url( MSM_URL . 'assets/logo-wz.svg?v=' . MSM_VERSION ); ?>" alt="Kisielewski"><small><b><?php echo esc_html( msm_opt( 'firma_nazwa' ) ); ?></b><br>Magazyn: <?php echo esc_html( msm_opt( 'magazyn_nazwa' ) ); ?></small></div>
    <div class="mid">
      <div class="cell"><span class="lbl">Odbiorca</span><div class="big"><?php echo esc_html( $w['odbiorca'] ); ?></div></div>
      <div class="cell"><span class="lbl">Przeznaczenie</span><div class="big"><?php echo esc_html( $w['przeznaczenie'] ); ?>&nbsp;</div></div>
    </div>
    <div class="wz<?php echo $draft ? ' draft' : ''; ?>"><b>WZ</b><span><?php echo esc_html( $nr ); ?></span></div>
  </div>
  <div class="grid3 r2">
    <div class="cell"><span class="lbl">Środek transportu</span><div class="big"><?php echo esc_html( $w['transport'] ); ?>&nbsp;</div></div>
    <div class="cell"><span class="lbl">Zlecenia na dokumencie</span><div><?php echo esc_html( $w['zlecenia'] ? $w['zlecenia'] : '—' ); ?></div></div>
    <div class="cell"><span class="lbl">Data wysyłki</span><div class="big"><?php echo esc_html( mysql2date( 'd.m.Y', $w['data_wysylki'] ) ); ?></div></div>
  </div>
  <table>
    <thead><tr><th class="c" style="width:9mm">Lp.</th><th style="width:28mm">Nr indeksu materiałowego</th><th style="width:22mm">Numer zlecenia</th><th style="width:27mm">Numer rysunku</th><th>Nazwa</th><th class="n" style="width:15mm">Ilość</th><th style="width:11mm">j.m.</th></tr></thead>
    <tbody>
    <?php foreach ( $w['lines'] as $l ) : ?>
      <tr><td class="c"><?php echo (int) $l['lp']; ?>.</td><td><?php echo esc_html( $l['indeks'] ); ?></td><td><?php echo esc_html( $l['zlecenie'] ); ?></td><td><?php echo esc_html( $l['rysunek'] ? $l['rysunek'] : '–' ); ?></td>
      <td><?php echo esc_html( $l['nazwa'] ); ?><?php echo 'magazyn' === $l['src'] ? '<span class="src">z magazynu' . ( $draft ? ' · stan zostanie zdjęty przy wystawieniu' : '' ) . '</span>' : ( 'wniosek' === $l['src'] ? '<span class="src">wydane wg zapotrzebowania #' . (int) $l['wniosek_id'] . '</span>' : '' ); ?></td>
      <td class="n"><?php echo esc_html( $n( $l['ilosc'] ) ); ?></td><td><?php echo esc_html( $l['jm'] ); ?></td></tr>
    <?php endforeach; ?>
    </tbody>
    <tfoot><tr><td colspan="5">Razem pozycji: <?php echo count( $w['lines'] ); ?></td><td class="n" colspan="2"><?php echo esc_html( implode( ' + ', array_map( function ( $jm, $v ) use ( $n ) { return $n( $v ) . ' ' . $jm; }, array_keys( $sum ), $sum ) ) ); ?></td></tr></tfoot>
  </table>
  <?php if ( trim( (string) $w['uwagi'] ) ) : ?><div class="notes"><span class="lbl">Uwagi</span><?php echo esc_html( $w['uwagi'] ); ?></div><?php endif; ?>
  <div class="spacer"></div>
  <div class="sign">
    <div><span class="lbl">Wystawił</span><span class="v"><?php echo esc_html( $w['wystawil'] ); ?></span></div>
    <div><span class="lbl">Wydał</span><span class="v"><?php echo esc_html( $w['wydal'] ); ?></span></div>
    <div><span class="lbl">Data</span><span class="v"><?php echo esc_html( $w['data_dok'] ? mysql2date( 'd.m.Y', $w['data_dok'] ) : '' ); ?></span></div>
    <div><span class="lbl">Odebrał (podpis)</span><?php if ( ! empty( $w['podpis'] ) ) : ?><img class="sig" src="<?php echo esc_attr( $w['podpis'] ); ?>" alt="podpis odbierającego"><?php else : ?><span>&nbsp;</span><?php endif; ?></div>
  </div>
  <div class="ft"><span>© Copyright by <?php echo esc_html( msm_opt( 'firma_nazwa' ) ); ?></span><span>WZ <?php echo esc_html( $nr ); ?> · <?php echo esc_html( $copy ); ?></span></div>
</div>
		<?php endforeach; ?>
<script>window.addEventListener('load',function(){setTimeout(function(){window.print();},300);});</script>
</body></html>
		<?php
	}

	private static function print_list() {
		$p = array(
			'q'        => isset( $_GET['q'] ) ? sanitize_text_field( wp_unslash( $_GET['q'] ) ) : null, // phpcs:ignore
			'f'        => isset( $_GET['f'] ) ? map_deep( wp_unslash( (array) $_GET['f'] ), 'sanitize_text_field' ) : array(), // phpcs:ignore
			'min'      => isset( $_GET['min'] ) ? map_deep( wp_unslash( (array) $_GET['min'] ), 'sanitize_text_field' ) : array(), // phpcs:ignore
			'max'      => isset( $_GET['max'] ) ? map_deep( wp_unslash( (array) $_GET['max'] ), 'sanitize_text_field' ) : array(), // phpcs:ignore
			'per_page' => 0,
		);
		$p      = array_filter( $p, function ( $v ) {
			return null !== $v;
		} );
		$res    = MSM_Repo::query( 'wz', $p );
		$labels = self::labels();
		$fonts  = MSM_URL . 'assets/fonts/';
		?><!DOCTYPE html><html lang="pl"><head><meta charset="utf-8"><title>Rejestr WZ</title>
<style>
@font-face{font-family:PJS;font-weight:400;src:url(<?php echo esc_url( $fonts ); ?>plus-jakarta-sans-latin-ext-400-normal.woff2) format("woff2");unicode-range:U+0100-02BA,U+1E00-1E9F}
@font-face{font-family:PJS;font-weight:400;src:url(<?php echo esc_url( $fonts ); ?>plus-jakarta-sans-latin-400-normal.woff2) format("woff2");unicode-range:U+0000-00FF,U+2000-206F}
@font-face{font-family:PJS;font-weight:800;src:url(<?php echo esc_url( $fonts ); ?>plus-jakarta-sans-latin-800-normal.woff2) format("woff2");unicode-range:U+0000-00FF,U+2000-206F}
@page{size:A4 landscape;margin:10mm}
body{margin:0;font:8.5pt/1.4 PJS,sans-serif;color:#0b1020}
.bar{display:flex;justify-content:center;gap:10px;padding:10px;background:#0b1020;color:#fff}
.bar button{font:600 13px PJS;padding:8px 18px;border-radius:99px;border:0;background:#3d4bff;color:#fff;cursor:pointer}
@media print{.bar{display:none}}
.wrap{padding:8mm}
@media print{.wrap{padding:0}}
.hd{display:flex;justify-content:space-between;align-items:flex-end;border-bottom:1.5px solid #0b1020;padding-bottom:3mm;margin-bottom:3mm}
.hd img{height:12mm}.hd h1{margin:0;font-size:14pt;font-weight:800}
table{width:100%;border-collapse:collapse}thead{display:table-header-group}
th{background:#eef1f6;text-align:left;font-size:6.8pt;text-transform:uppercase;padding:1.6mm 2mm;border:1px solid #c8ccd4}
td{padding:1.8mm 2mm;border:1px solid #c8ccd4;vertical-align:top}
</style></head><body>
<div class="bar"><button onclick="window.print()">Drukuj</button></div>
<div class="wrap"><div class="hd"><img src="<?php echo esc_url( MSM_URL . 'assets/logo-wz.svg?v=' . MSM_VERSION ); ?>" alt=""><div style="text-align:right"><h1>Rejestr dokumentów WZ</h1><div style="font-size:7.5pt;color:#6b7285">wydrukował <?php echo esc_html( MSM_Repo::user_name() ); ?> · <?php echo esc_html( current_time( 'd.m.Y H:i' ) ); ?></div></div></div>
<table><thead><tr><th>Numer</th><th>Data wysyłki</th><th>Odbiorca</th><th>Przeznaczenie</th><th>Zlecenia</th><th>Pozycji</th><th>Status</th><th>Utworzył</th><th>Wystawił</th></tr></thead><tbody>
<?php foreach ( $res['rows'] as $r ) : ?>
<tr><td><b><?php echo esc_html( $r['numer'] ? 'WZ ' . $r['numer'] : '—' ); ?></b></td><td><?php echo esc_html( mysql2date( 'd.m.Y', $r['data_wysylki'] ) ); ?></td><td><?php echo esc_html( $r['odbiorca'] ); ?></td><td><?php echo esc_html( $r['przeznaczenie'] ); ?></td><td><?php echo esc_html( $r['zlecenia'] ); ?></td><td><?php echo (int) $r['pozycji']; ?></td><td><?php echo esc_html( $labels[ $r['status'] ] ?? $r['status'] ); ?></td><td><?php echo esc_html( $r['created_name'] ); ?></td><td><?php echo esc_html( $r['wystawil'] ); ?></td></tr>
<?php endforeach; ?>
</tbody></table><p><b>Razem dokumentów: <?php echo (int) $res['total']; ?></b></p></div>
<script>window.addEventListener('load',function(){setTimeout(function(){window.print();},300);});</script>
</body></html>
		<?php
	}

	/** Excel w układzie wzoru użytkownika (pola i kolejność jak w pliku WZ). */
	private static function xlsx( $w ) {
		$nr   = self::nr_label( $w );
		$rows = array();
		$rows[] = array( array( 'Pieczęć firmowa', 'h' ), null, null, array( 'Odbiorca', 'h' ), null, null, array( 'WZ', 'wz' ), null );
		$rows[] = array( msm_opt( 'firma_nazwa' ), null, null, array( $w['odbiorca'], 'b' ), null, null, array( $nr, 'wz' ), null );
		$rows[] = array( 'Magazyn: ' . msm_opt( 'magazyn_nazwa' ), null, null, array( 'Przeznaczenie', 'h' ), null, null, null, null );
		$rows[] = array( null, null, null, array( $w['przeznaczenie'], 'b' ), null, null, null, null );
		$rows[] = array( array( 'Środek transportu', 'h' ), null, null, array( 'Zlecenia', 'h' ), null, null, array( 'Data wysyłki', 'h' ), null );
		$rows[] = array( array( $w['transport'], 'b' ), null, null, $w['zlecenia'], null, null, array( mysql2date( 'd.m.Y', $w['data_wysylki'] ), 'b' ), null );
		$rows[] = array( array( 'Lp.', 'th' ), array( 'Nr indeksu materiałowego', 'th' ), array( 'Numer zlecenia', 'th' ), array( 'Numer rysunku', 'th' ), array( 'Nazwa', 'th' ), array( '', 'th' ), array( 'Ilość', 'th' ), array( 'j.m', 'th' ) );
		foreach ( $w['lines'] as $l ) {
			$rows[] = array( array( $l['lp'] . '.', 'td' ), array( $l['indeks'], 'td' ), array( $l['zlecenie'], 'td' ), array( $l['rysunek'] ? $l['rysunek'] : '-', 'td' ), array( $l['nazwa'], 'td' ), array( '', 'td' ), array( (float) $l['ilosc'], 'tdn' ), array( $l['jm'], 'td' ) );
		}
		$rows[] = array();
		$rows[] = array( array( 'Wystawił', 'h' ), null, array( 'Wydał', 'h' ), null, null, array( 'Data', 'h' ), array( 'Odebrał', 'h' ), null );
		$rows[] = array( $w['wystawil'], null, $w['wydal'], null, null, $w['data_dok'] ? mysql2date( 'd.m.Y', $w['data_dok'] ) : '', '', null );

		$n      = count( $w['lines'] );
		$merges = array( 'A1:C1', 'D1:F1', 'G1:H1', 'A2:C2', 'D2:F2', 'G2:H4', 'A3:C3', 'D3:F3', 'D4:F4', 'A5:C5', 'D5:F5', 'G5:H5', 'A6:C6', 'D6:F6', 'G6:H6', 'E7:F7' );
		for ( $i = 0; $i < $n; $i++ ) {
			$merges[] = 'E' . ( 8 + $i ) . ':F' . ( 8 + $i );
		}
		$f        = 8 + $n + 1;
		$merges[] = 'A' . $f . ':B' . $f;
		$merges[] = 'C' . $f . ':E' . $f;
		$merges[] = 'G' . $f . ':H' . $f;
		$merges[] = 'A' . ( $f + 1 ) . ':B' . ( $f + 1 );
		$merges[] = 'C' . ( $f + 1 ) . ':E' . ( $f + 1 );
		$merges[] = 'G' . ( $f + 1 ) . ':H' . ( $f + 1 );

		if ( ! function_exists( 'wp_tempnam' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		$tmp = wp_tempnam( 'msm-wz' );
		MSM_Xlsx::write_layout( $tmp, 'WZ', $rows, array( 7.5, 18, 14, 17, 22, 8, 9, 9 ), $merges );
		$fname = 'WZ-' . str_replace( '/', '-', $nr ) . '.xlsx';
		header( 'Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' );
		header( 'Content-Disposition: attachment; filename="' . $fname . '"' );
		header( 'Content-Length: ' . filesize( $tmp ) );
		readfile( $tmp ); // phpcs:ignore
		@unlink( $tmp ); // phpcs:ignore
	}
}
