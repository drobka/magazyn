<?php
/**
 * Wnioski o pobranie składane przez przeglądających.
 *
 * Przepływ: nowy → zaakceptowany (admin) → wydany (admin potwierdza fizyczne wydanie; stan maleje).
 * W każdej chwili przed wydaniem: odrzucony (admin) lub anulowany (wnioskujący, tylko gdy „nowy”).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MSM_Wnioski {

	const ST_NEW      = 'nowy';
	const ST_ACCEPTED = 'zaakceptowany';
	const ST_ISSUED   = 'wydany';
	const ST_REJECTED = 'odrzucony';
	const ST_CANCELED = 'anulowany';
	const ST_IN_STOCK = 'potwierdzony';
	const ST_MISSING  = 'brak';

	const TYPE_ISSUE = 'pobranie';
	const TYPE_CHECK = 'sprawdzenie';

	public static function labels() {
		return array(
			self::ST_NEW      => 'Nowy',
			self::ST_ACCEPTED => 'Zaakceptowany – do wydania',
			self::ST_ISSUED   => 'Wydany',
			self::ST_REJECTED => 'Odrzucony',
			self::ST_CANCELED => 'Anulowany',
			self::ST_IN_STOCK => 'Jest na stanie',
			self::ST_MISSING  => 'Brak na stanie',
		);
	}

	/** Złożenie wniosku. */
	public static function create( array $in ) {
		global $wpdb;
		$table = isset( $in['tabela'] ) ? (string) $in['tabela'] : '';
		if ( ! in_array( $table, msm_stock_tables(), true ) ) {
			return new WP_Error( 'msm_invalid', 'Nieznany magazyn.', array( 'status' => 400 ) );
		}
		$item = MSM_Repo::get( $table, (int) ( $in['item_id'] ?? 0 ) );
		if ( ! $item ) {
			return new WP_Error( 'msm_not_found', 'Pozycja nie istnieje.', array( 'status' => 404 ) );
		}
		$kgu   = 'kg' === msm_unit( $table );
		$stock = $kgu ? (float) $item['ilosc'] : (int) $item['ilosc'];
		$typ   = ( self::TYPE_CHECK === ( $in['typ'] ?? '' ) ) ? self::TYPE_CHECK : self::TYPE_ISSUE;
		$tryb  = ( 'stal' === $table && 'odcinek' === ( $in['tryb'] ?? '' ) ) ? 'odcinek' : 'szt';

		$odc = null;
		if ( 'odcinek' === $tryb ) {
			$odc = MSM_Calc::odcinki( $in );
			if ( is_wp_error( $odc ) ) {
				return $odc;
			}
			$qty = $odc[2];
			$len = MSM_Calc::f( $item['dlugosc'] );
			if ( $stock < 1 ) {
				return new WP_Error( 'msm_stock', 'Brak sztuk na stanie.', array( 'status' => 400 ) );
			}
			if ( null === $qty || $qty <= 0 ) {
				return new WP_Error( 'msm_invalid', 'Podaj długość odcinka w metrach.', array( 'status' => 400, 'fields' => array( 'dlugosc' => 'Podaj długość' ) ) );
			}
			if ( null === $len || $qty > $len + 1e-9 ) {
				return new WP_Error( 'msm_stock', ( $odc[0] > 1 ? 'Razem ' . $odc[0] . ' × ' . MSM_Calc::fmt( $odc[1] ) . ' m = ' . MSM_Calc::fmt( $qty ) . ' m – więcej niż sztuka na stanie (' . MSM_Calc::fmt( $len ) . ' m). Zmniejsz liczbę odcinków albo złóż osobny wniosek.' : 'Odcinek dłuższy niż sztuka na stanie (' . MSM_Calc::fmt( $len ) . ' m).' ), array( 'status' => 400, 'fields' => array( 'dlugosc' => 'Za długi' ) ) );
			}
			$unit = 'm';
		} elseif ( $kgu ) {
			$qty = MSM_Calc::f( $in['ilosc'] ?? null );
			if ( null === $qty || $qty <= 0 ) {
				return new WP_Error( 'msm_invalid', 'Podaj ilość w kg.', array( 'status' => 400, 'fields' => array( 'ilosc' => 'Podaj ilość w kg' ) ) );
			}
			$qty = round( $qty, 3 );
			if ( $qty > $stock + 1e-9 ) {
				return new WP_Error( 'msm_stock', 'Na stanie jest tylko ' . MSM_Calc::fmt( $stock ) . ' kg.', array( 'status' => 400, 'fields' => array( 'ilosc' => 'Max ' . MSM_Calc::fmt( $stock ) ) ) );
			}
			$unit = 'kg';
		} else {
			$qty = MSM_Calc::f( $in['ilosc'] ?? null );
			if ( null === $qty || $qty < 1 || floor( $qty ) != $qty ) { // phpcs:ignore
				return new WP_Error( 'msm_invalid', 'Podaj liczbę sztuk.', array( 'status' => 400, 'fields' => array( 'ilosc' => 'Podaj liczbę sztuk' ) ) );
			}
			if ( $qty > $stock ) {
				return new WP_Error( 'msm_stock', 'Na stanie jest tylko ' . $stock . ' szt.', array( 'status' => 400, 'fields' => array( 'ilosc' => 'Max ' . $stock ) ) );
			}
			$unit = 'szt';
		}

		$uwagi    = mb_substr( sanitize_textarea_field( wp_unslash( (string) ( $in['uwagi'] ?? '' ) ) ), 0, 2000 );
		$zlecenie = mb_substr( mb_strtoupper( trim( sanitize_text_field( wp_unslash( (string) ( $in['zlecenie'] ?? '' ) ) ) ), 'UTF-8' ), 0, 60 );
		$rysunek  = mb_substr( trim( sanitize_text_field( wp_unslash( (string) ( $in['rysunek'] ?? '' ) ) ), 'UTF-8' ), 0, 190 );
		if ( 'blachy_pelne' === $table && self::TYPE_ISSUE === $typ && '' === $zlecenie ) {
			return new WP_Error( 'msm_invalid', 'Podaj numer zlecenia – jest wymagany przy pobraniu blachy pełnej.', array( 'status' => 400, 'fields' => array( 'zlecenie' => 'Wymagany przy blasze pełnej' ) ) );
		}
		$wpdb->insert( msm_table( 'wnioski' ), array(
			'data'       => current_time( 'mysql' ),
			'user_id'    => get_current_user_id(),
			'user_name'  => MSM_Repo::user_name(),
			'item_table' => $table,
			'item_id'    => (int) $item['id'],
			'tryb'       => $tryb,
			'material'   => MSM_Calc::describe( $table, $item ),
			'ilosc'      => $qty,
			'jednostka'  => $unit,
			'zlecenie'   => '' === $zlecenie ? null : $zlecenie,
			'rysunek'    => '' === $rysunek ? null : $rysunek,
			'uwagi'      => '' === $uwagi ? null : $uwagi,
			'status'     => self::ST_NEW,
			'typ'        => $typ,
			'odc_szt'    => $odc ? $odc[0] : null,
			'odc_dl'     => $odc ? $odc[1] : null,
		) );
		$id = (int) $wpdb->insert_id;
		if ( ! $id ) {
			return new WP_Error( 'msm_db', 'Nie udało się zapisać wniosku.', array( 'status' => 500 ) );
		}
		$w = MSM_Repo::get( 'wnioski', $id );
		$check = self::TYPE_CHECK === $typ;
		MSM_Repo::log( $check ? 'sprawdzenie' : 'wniosek', 'wnioski', $id, self::summary( $w ) . ' – złożył ' . $w['user_name'], null, array( $w['item_table'], (int) $w['item_id'] ) );
		self::notify_admins( $w );
		return array(
			'wniosek' => MSM_Repo::cast_row( 'wnioski', $w ),
			'message' => $check
				? 'Prośba o sprawdzenie wysłana do magazyniera. Odpowiedź zobaczysz w zakładce „Wnioski” i dostaniesz e-mailem.'
				: 'Zapotrzebowanie wysłane do magazyniera. Status zobaczysz w zakładce „Wnioski”.',
		);
	}

	/**
	 * Poprawka wniosku przez wnioskodawcę (albo administratora), dopóki nie został rozpatrzony (status „nowy”):
	 * ilość (poza odcinkami), numer zlecenia, numer rysunku, uwagi. Do magazynu idzie nowy e-mail z poprawioną wersją.
	 */
	public static function update( $id, array $in ) {
		global $wpdb;
		$w = MSM_Repo::get( 'wnioski', (int) $id );
		if ( ! $w ) {
			return new WP_Error( 'msm_not_found', 'Wniosek nie istnieje.', array( 'status' => 404 ) );
		}
		if ( (int) $w['user_id'] !== get_current_user_id() && ! current_user_can( 'msm_edit' ) ) {
			return self::forbidden();
		}
		if ( self::ST_NEW !== $w['status'] ) {
			return new WP_Error( 'msm_state', 'Można poprawić tylko wniosek, który nie został jeszcze rozpatrzony. Odśwież listę.', array( 'status' => 409 ) );
		}
		$set = array();
		if ( array_key_exists( 'ilosc', $in ) && 'odcinek' !== $w['tryb'] ) {
			$item  = MSM_Repo::get( $w['item_table'], (int) $w['item_id'] );
			$stock = $item ? (float) $item['ilosc'] : 0;
			$qty   = MSM_Calc::f( $in['ilosc'] );
			if ( 'kg' === $w['jednostka'] ) {
				if ( null === $qty || $qty <= 0 ) {
					return new WP_Error( 'msm_invalid', 'Podaj ilość w kg.', array( 'status' => 400, 'fields' => array( 'ilosc' => 'Podaj ilość w kg' ) ) );
				}
				$qty = round( $qty, 3 );
				if ( self::TYPE_ISSUE === $w['typ'] && $qty > $stock + 1e-9 ) {
					return new WP_Error( 'msm_stock', 'Na stanie jest tylko ' . MSM_Calc::fmt( $stock ) . ' kg.', array( 'status' => 400, 'fields' => array( 'ilosc' => 'Max ' . MSM_Calc::fmt( $stock ) ) ) );
				}
			} else {
				if ( null === $qty || $qty < 1 || floor( $qty ) != $qty ) { // phpcs:ignore
					return new WP_Error( 'msm_invalid', 'Podaj liczbę sztuk.', array( 'status' => 400, 'fields' => array( 'ilosc' => 'Podaj liczbę sztuk' ) ) );
				}
				if ( self::TYPE_ISSUE === $w['typ'] && $qty > $stock ) {
					return new WP_Error( 'msm_stock', 'Na stanie jest tylko ' . (int) $stock . ' szt.', array( 'status' => 400, 'fields' => array( 'ilosc' => 'Max ' . (int) $stock ) ) );
				}
			}
			if ( abs( (float) $qty - (float) $w['ilosc'] ) > 1e-9 ) {
				$set['ilosc'] = $qty;
			}
		}
		if ( array_key_exists( 'zlecenie', $in ) ) {
			$z = mb_substr( mb_strtoupper( trim( sanitize_text_field( wp_unslash( (string) $in['zlecenie'] ) ) ), 'UTF-8' ), 0, 60 );
			if ( 'blachy_pelne' === $w['item_table'] && self::TYPE_ISSUE === $w['typ'] && '' === $z ) {
				return new WP_Error( 'msm_invalid', 'Podaj numer zlecenia – jest wymagany przy pobraniu blachy pełnej.', array( 'status' => 400, 'fields' => array( 'zlecenie' => 'Wymagany przy blasze pełnej' ) ) );
			}
			if ( $z !== (string) $w['zlecenie'] ) {
				$set['zlecenie'] = '' === $z ? null : $z;
			}
		}
		if ( array_key_exists( 'rysunek', $in ) ) {
			$rys = mb_substr( trim( sanitize_text_field( wp_unslash( (string) $in['rysunek'] ) ) ), 0, 190 );
			if ( $rys !== (string) $w['rysunek'] ) {
				$set['rysunek'] = '' === $rys ? null : $rys;
			}
		}
		if ( array_key_exists( 'uwagi', $in ) ) {
			$uw = mb_substr( sanitize_textarea_field( wp_unslash( (string) $in['uwagi'] ) ), 0, 2000 );
			if ( $uw !== (string) $w['uwagi'] ) {
				$set['uwagi'] = '' === $uw ? null : $uw;
			}
		}
		if ( ! $set ) {
			return array( 'wniosek' => MSM_Repo::cast_row( 'wnioski', $w ), 'message' => 'Bez zmian – nic nie wysłano.' );
		}
		$wpdb->update( msm_table( 'wnioski' ), $set, array( 'id' => (int) $w['id'] ) );
		$after = MSM_Repo::get( 'wnioski', (int) $w['id'] );
		$names = array( 'ilosc' => 'Ilość', 'zlecenie' => 'Zlecenie', 'rysunek' => 'Nr rysunku', 'uwagi' => 'Uwagi' );
		$diff  = array();
		foreach ( $set as $k => $v ) {
			$old    = 'ilosc' === $k ? MSM_Calc::fmt( $w[ $k ] ) . ' ' . $w['jednostka'] : (string) $w[ $k ];
			$new    = 'ilosc' === $k ? MSM_Calc::fmt( $v ) . ' ' . $w['jednostka'] : (string) $v;
			$diff[] = array( $names[ $k ], '' === $old ? '—' : $old, '' === $new ? '—' : $new );
		}
		$check = self::TYPE_CHECK === $w['typ'];
		MSM_Repo::log( ( $check ? 'sprawdzenie' : 'wniosek' ) . ': poprawka', 'wnioski', (int) $w['id'], self::summary( $after ) . ' – poprawił ' . MSM_Repo::user_name() . ': ' . implode( '; ', array_map( function ( $d ) { return $d[0] . ': ' . $d[1] . ' → ' . $d[2]; }, $diff ) ), array( 'przed' => array_intersect_key( $w, $set ), 'po' => $set ), array( $after['item_table'], (int) $after['item_id'] ) );
		self::notify_admins( $after, $diff );
		return array(
			'wniosek' => MSM_Repo::cast_row( 'wnioski', $after ),
			'message' => 'Zapisano poprawki. Magazyn dostał e-mail z poprawioną wersją ' . ( $check ? 'prośby.' : 'wniosku.' ),
		);
	}

	/** Akcje na wniosku: akceptuj, odrzuc, wydaj, anuluj. */
	public static function action( $id, $action, $note = '' ) {
		global $wpdb;
		$w = MSM_Repo::get( 'wnioski', (int) $id );
		if ( ! $w ) {
			return new WP_Error( 'msm_not_found', 'Wniosek nie istnieje.', array( 'status' => 404 ) );
		}
		$note   = mb_substr( sanitize_textarea_field( wp_unslash( (string) $note ) ), 0, 2000 );
		$admin  = current_user_can( 'msm_edit' );
		$status = $w['status'];
		$set    = array();
		$msg    = '';

		$is_check = self::TYPE_CHECK === ( $w['typ'] ?: self::TYPE_ISSUE );
		if ( $is_check && in_array( $action, array( 'akceptuj', 'wydaj', 'odrzuc' ), true ) ) {
			return new WP_Error( 'msm_state', 'To jest prośba o sprawdzenie stanu – odpowiedz „Jest na stanie” albo „Brak na stanie”.', array( 'status' => 400 ) );
		}
		if ( ! $is_check && in_array( $action, array( 'jest', 'brak' ), true ) ) {
			return new WP_Error( 'msm_state', 'Ta akcja dotyczy tylko próśb o sprawdzenie stanu.', array( 'status' => 400 ) );
		}

		switch ( $action ) {
			case 'jest':
			case 'brak':
				if ( ! $admin ) {
					return self::forbidden();
				}
				if ( self::ST_NEW !== $status ) {
					return self::bad_state( $status );
				}
				$set = array( 'status' => 'jest' === $action ? self::ST_IN_STOCK : self::ST_MISSING );
				$msg = 'jest' === $action ? 'Potwierdzono: materiał jest na stanie.' : 'Zapisano: brak na stanie. Jeśli trzeba, popraw stan pozycji w magazynie.';
				break;

			case 'akceptuj':
				if ( ! $admin ) {
					return self::forbidden();
				}
				if ( self::ST_NEW !== $status ) {
					return self::bad_state( $status );
				}
				$set = array( 'status' => self::ST_ACCEPTED );
				$msg = 'Wniosek zaakceptowany. Po wydaniu materiału kliknij „Wydano”.';
				break;

			case 'odrzuc':
				if ( ! $admin ) {
					return self::forbidden();
				}
				if ( ! in_array( $status, array( self::ST_NEW, self::ST_ACCEPTED ), true ) ) {
					return self::bad_state( $status );
				}
				$set = array( 'status' => self::ST_REJECTED );
				$msg = 'Wniosek odrzucony.';
				break;

			case 'wydaj':
				if ( ! $admin ) {
					return self::forbidden();
				}
				if ( self::ST_ACCEPTED !== $status ) {
					return self::bad_state( $status );
				}
				$res = MSM_Repo::pobranie( array(
					'tabela'   => $w['item_table'],
					'item_id'  => (int) $w['item_id'],
					'tryb'     => $w['tryb'],
					'ilosc'    => $w['ilosc'],
					'dlugosc'  => ! empty( $w['odc_dl'] ) ? $w['odc_dl'] : $w['ilosc'],
					'odc_szt'  => ! empty( $w['odc_szt'] ) ? $w['odc_szt'] : 1,
					'zlecenie' => (string) $w['zlecenie'],
					'odbiorca' => $w['user_name'],
					'uwagi'    => trim( 'Wniosek #' . (int) $w['id'] . ( $w['zlecenie'] ? ', zlecenie ' . $w['zlecenie'] : '' ) . ( $w['uwagi'] ? ': ' . $w['uwagi'] : '' )
						. ( '' !== $note ? ' | ' . $note : ( ! empty( $w['admin_note'] ) ? ' | ' . $w['admin_note'] : '' ) ) ),
					'data'     => current_time( 'Y-m-d' ),
				) );
				if ( is_wp_error( $res ) ) {
					$res->add_data( array( 'status' => 400 ) );
					return new WP_Error( $res->get_error_code(), 'Nie można wydać: ' . $res->get_error_message(), array( 'status' => 400 ) );
				}
				$set = array(
					'status'      => self::ST_ISSUED,
					'issued_at'   => current_time( 'mysql' ),
					'pobranie_id' => (int) $res['pobranie']['id'],
				);
				$msg = 'Wydano. ' . $res['message'];
				break;

			case 'anuluj':
				if ( (int) $w['user_id'] !== get_current_user_id() && ! $admin ) {
					return self::forbidden();
				}
				if ( self::ST_NEW !== $status ) {
					return new WP_Error( 'msm_state', 'Można anulować tylko wniosek, który nie został jeszcze rozpatrzony.', array( 'status' => 400 ) );
				}
				$set = array( 'status' => self::ST_CANCELED );
				$msg = 'Wniosek anulowany.';
				break;

			default:
				return new WP_Error( 'msm_invalid', 'Nieznana akcja.', array( 'status' => 400 ) );
		}

		if ( 'anuluj' !== $action ) {
			$set['decided_by']   = get_current_user_id();
			$set['decided_name'] = MSM_Repo::user_name();
			$set['decided_at']   = current_time( 'mysql' );
		}
		if ( '' !== $note ) {
			$set['admin_note'] = $note;
		}
		$wpdb->update( msm_table( 'wnioski' ), $set, array( 'id' => (int) $w['id'] ) );
		$after  = MSM_Repo::get( 'wnioski', (int) $w['id'] );
		$labels = self::labels();
		MSM_Repo::log( ( $is_check ? 'sprawdzenie: ' : 'wniosek: ' ) . mb_strtolower( $labels[ $after['status'] ] ), 'wnioski', (int) $w['id'], self::summary( $after ) . ' – ' . $after['user_name'] . ( '' !== $note ? ' (' . $note . ')' : '' ), null, array( $after['item_table'], (int) $after['item_id'] ) );
		if ( 'anuluj' !== $action ) {
			self::notify_requester( $after );
		}
		return array(
			'wniosek' => MSM_Repo::cast_row( 'wnioski', $after ),
			'message' => $msg,
		);
	}

	/** Zamiana potwierdzonej prośby o sprawdzenie na zapotrzebowanie (bez ponownego wypełniania). */
	/** Zwrot reszty na magazyn po zaakceptowanym/wydanym zapotrzebowaniu – nowa pozycja (nowe wymiary). */
	public static function zwrot( $id, array $fields ) {
		$w = MSM_Repo::get( 'wnioski', (int) $id );
		if ( ! $w ) {
			return new WP_Error( 'msm_not_found', 'Wniosek nie istnieje.', array( 'status' => 404 ) );
		}
		if ( ! current_user_can( 'msm_edit' ) || ( class_exists( 'MSM_Perms' ) && ! MSM_Perms::user_can( 'edit' ) ) ) {
			return new WP_Error( 'msm_forbidden', 'Brak uprawnień do zwrotu na magazyn.', array( 'status' => 403 ) );
		}
		$table = (string) $w['item_table'];
		if ( ! in_array( $table, array( 'stal', 'blachy_pelne', 'blachy_niepelne' ), true ) ) {
			return new WP_Error( 'msm_400', 'Zwrot na magazyn dotyczy stali i blach.', array( 'status' => 400 ) );
		}
		if ( ! in_array( $w['status'], array( self::ST_ACCEPTED, self::ST_ISSUED ), true ) || self::TYPE_ISSUE !== $w['typ'] ) {
			return new WP_Error( 'msm_state', 'Zwrot można zrobić po zaakceptowaniu zapotrzebowania.', array( 'status' => 400 ) );
		}
		// Dopisek o pochodzeniu zwrotu do uwag.
		$tag = 'Zwrot ze zlecenia ' . ( $w['zlecenie'] ? $w['zlecenie'] : '—' ) . ( ! empty( $w['rysunek'] ) ? ', rys. ' . $w['rysunek'] : '' ) . ' (wniosek #' . (int) $w['id'] . ')';
		return self::do_zwrot( $table, $tag, $fields );
	}

	/**
	 * Zwrot na magazyn po zwykłym pobraniu (bez wniosku).
	 * $fields: tabela, zlecenie, rysunek, pobranie_id + pola nowej pozycji magazynowej.
	 */
	public static function zwrot_pobranie( array $fields ) {
		if ( ! current_user_can( 'msm_edit' ) || ( class_exists( 'MSM_Perms' ) && ! MSM_Perms::user_can( 'edit' ) ) ) {
			return new WP_Error( 'msm_forbidden', 'Brak uprawnień do zwrotu na magazyn.', array( 'status' => 403 ) );
		}
		$table = (string) ( $fields['tabela'] ?? '' );
		if ( ! in_array( $table, array( 'stal', 'blachy_pelne', 'blachy_niepelne' ), true ) ) {
			return new WP_Error( 'msm_400', 'Zwrot na magazyn dotyczy stali i blach.', array( 'status' => 400 ) );
		}
		$zlec = trim( (string) ( $fields['zlecenie'] ?? '' ) );
		$rys  = trim( (string) ( $fields['rysunek'] ?? '' ) );
		$pob  = (int) ( $fields['pobranie_id'] ?? 0 );
		$tag  = 'Zwrot ze zlecenia ' . ( $zlec ? $zlec : '—' ) . ( $rys ? ', rys. ' . $rys : '' ) . ( $pob ? ' (pobranie #' . $pob . ')' : '' );
		unset( $fields['tabela'], $fields['zlecenie'], $fields['rysunek'], $fields['pobranie_id'] );
		return self::do_zwrot( $table, $tag, $fields );
	}

	/** Wspólna logika: dopisek do uwag + utworzenie pozycji + wpis do historii. */
	private static function do_zwrot( $table, $tag, array $fields ) {
		$cur = trim( (string) ( $fields['uwagi'] ?? '' ) );
		$fields['uwagi'] = $cur ? ( $cur . ' | ' . $tag ) : $tag;

		$item = MSM_Repo::create( $table, $fields );
		if ( is_wp_error( $item ) ) {
			return $item;
		}
		MSM_Repo::log( 'Zwrot na magazyn', $table, (int) $item['id'], $tag . ': ' . MSM_Calc::describe( $table, $item ) );
		return array( 'item' => $item, 'message' => 'Dodano zwrot na magazyn: ' . MSM_Calc::describe( $table, $item ) );
	}

	public static function convert( $id ) {
		global $wpdb;
		$w = MSM_Repo::get( 'wnioski', (int) $id );
		if ( ! $w || ( (int) $w['user_id'] !== get_current_user_id() && ! current_user_can( 'msm_edit' ) ) ) {
			return new WP_Error( 'msm_not_found', 'Wniosek nie istnieje.', array( 'status' => 404 ) );
		}
		if ( self::TYPE_CHECK !== $w['typ'] || self::ST_IN_STOCK !== $w['status'] ) {
			return new WP_Error( 'msm_state', 'Zapotrzebowanie można wysłać tylko z potwierdzonej prośby („Jest na stanie”).', array( 'status' => 400 ) );
		}
		if ( ! empty( $w['next_id'] ) ) {
			return new WP_Error( 'msm_state', 'Zapotrzebowanie zostało już wysłane (wniosek #' . (int) $w['next_id'] . ').', array( 'status' => 409 ) );
		}
		$res = self::create( array(
			'typ'      => self::TYPE_ISSUE,
			'tabela'   => $w['item_table'],
			'item_id'  => (int) $w['item_id'],
			'tryb'     => $w['tryb'],
			'ilosc'    => $w['ilosc'],
			'dlugosc'  => ! empty( $w['odc_dl'] ) ? $w['odc_dl'] : $w['ilosc'],
			'odc_szt'  => ! empty( $w['odc_szt'] ) ? $w['odc_szt'] : 1,
			'zlecenie' => (string) $w['zlecenie'],
			'rysunek'  => (string) ( $w['rysunek'] ?? '' ),
			'uwagi'    => (string) $w['uwagi'],
		) );
		if ( is_wp_error( $res ) ) {
			return $res;
		}
		$wpdb->update( msm_table( 'wnioski' ), array( 'next_id' => (int) $res['wniosek']['id'] ), array( 'id' => (int) $w['id'] ) );
		$res['message'] = 'Zapotrzebowanie #' . (int) $res['wniosek']['id'] . ' wysłane do magazyniera.';
		return $res;
	}

	public static function counts() {
		global $wpdb;
		$T     = msm_table( 'wnioski' );
		$where = current_user_can( 'msm_edit' ) ? '' : $wpdb->prepare( ' AND user_id = %d', get_current_user_id() );
		return array(
			'nowe'       => (int) $wpdb->get_var( "SELECT COUNT(*) FROM `$T` WHERE status = 'nowy'$where" ), // phpcs:ignore
			'do_wydania' => (int) $wpdb->get_var( "SELECT COUNT(*) FROM `$T` WHERE status = 'zaakceptowany'$where" ), // phpcs:ignore
			'max_id'     => (int) $wpdb->get_var( "SELECT MAX(id) FROM `$T` WHERE 1=1$where" ), // phpcs:ignore
			// Potwierdzone „Jest na stanie”, z których wnioskujący nie wysłał jeszcze zapotrzebowania.
			'do_wyslania' => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM `$T` WHERE typ = 'sprawdzenie' AND status = 'potwierdzony' AND next_id IS NULL AND user_id = %d", get_current_user_id() ) ), // phpcs:ignore
		);
	}

	/* ---------------- e-maile ---------------- */

	private static function summary( $w ) {
		return 'Wniosek #' . (int) $w['id'] . ': ' . MSM_Calc::fmt( $w['ilosc'] ) . ' ' . $w['jednostka'] . ( MSM_Calc::odc_txt( $w ) ? ' (' . MSM_Calc::odc_txt( $w ) . ')' : '' ) . ' – ' . $w['material'] . ( ! empty( $w['zlecenie'] ) ? ' (zlecenie ' . $w['zlecenie'] . ')' : '' );
	}

	/** Adresy administratorów magazynu (rola z prawem edycji). Można zmienić filtrem 'msm_notify_emails'. */
	public static function admin_emails() {
		$emails = array();
		foreach ( get_users( array( 'role__in' => array( 'administrator', MSM_Install::ROLE_ADMIN ), 'fields' => array( 'user_email' ) ) ) as $u ) {
			if ( is_email( $u->user_email ) ) {
				$emails[] = $u->user_email;
			}
		}
		if ( ! $emails ) {
			$emails[] = get_option( 'admin_email' );
		}
		return array_values( array_unique( apply_filters( 'msm_notify_emails', $emails ) ) );
	}

	private static function mail( $to, $subject, array $lines ) {
		$body = implode( "\n", $lines ) . msm_mail_footer();
		return wp_mail( $to, '[K-ERP] ' . $subject, $body, array( 'Content-Type: text/plain; charset=UTF-8' ) );
	}

	/** Odbiorcy powiadomień o pobraniu blachy pełnej (loginy użytkowników). Filtr: 'msm_blachy_pelne_notify'. */
	public static function blacha_recipients() {
		$out = array();
		foreach ( (array) apply_filters( 'msm_blachy_pelne_notify', (array) MSM_Settings::get( 'blachy_notify' ) ) as $login ) {
			$u = get_user_by( 'login', $login );
			if ( ! $u && is_email( $login ) ) {
				$u = get_user_by( 'email', $login );
			}
			if ( $u && is_email( $u->user_email ) ) {
				$out[] = $u->user_email;
			}
		}
		return array_values( array_unique( $out ) );
	}

	/** E-mail: pobrano blachę pełną ze stanu. */
	public static function notify_blacha_pelna( $p, $item ) {
		$to = self::blacha_recipients();
		if ( ! $to || ! $p ) {
			return false;
		}
		$vars = array(
			'material'  => $p['material'],
			'ilosc'     => MSM_Calc::fmt( $p['ilosc'] ) . ' ' . $p['jednostka'],
			'zlecenie'  => $p['zlecenie'],
			'odbiorca'  => $p['odbiorca'] ? $p['odbiorca'] : '—',
			'uwagi'     => $p['uwagi'] ? $p['uwagi'] : '—',
			'user_name' => $p['user_name'],
			'data'      => mysql2date( 'd.m.Y H:i', $p['created_at'] ),
			'stan'      => $item ? (int) $item['ilosc'] . ' szt.' : '—',
			'url'       => self::link( MSM_Access::app_url() . '#pobrania' ),
		);
		$t = MSM_Mail::render( 'blacha_pelna', $vars );
		return MSM_Mail::send( $to, $t['subject'], $t['body'], array( 'footer' => true, 'logo' => true ) );
	}

	/** $diff – przy poprawce: [ [pole, było, jest], … ] → e-mail „POPRAWIONY …” z listą zmian nad treścią. */
	public static function notify_admins( $w, array $diff = array() ) {
		$check = self::TYPE_CHECK === $w['typ'];
		$vars  = array(
			'user_name' => $w['user_name'],
			'material'  => $w['material'],
			'ilosc'     => MSM_Calc::fmt( $w['ilosc'] ) . ' ' . $w['jednostka'] . ( MSM_Calc::odc_txt( $w ) ? ' (' . MSM_Calc::odc_txt( $w ) . ')' : ( 'odcinek' === $w['tryb'] ? ' (odcinek)' : '' ) ),
			'zlecenie'  => $w['zlecenie'] ? $w['zlecenie'] : '—',
			'cel'       => $w['uwagi'] ? $w['uwagi'] : '—',
			'data'      => mysql2date( 'd.m.Y H:i', $w['data'] ),
			'url'       => self::link( MSM_Access::app_url() . '#wnioski' ),
		);
		$t = MSM_Mail::render( $check ? 'sprawdzenie_admin' : 'wniosek_admin', $vars );
		if ( $diff ) {
			$t['subject'] = ( $check ? 'POPRAWIONA prośba #' : 'POPRAWIONY wniosek #' ) . (int) $w['id'] . ' – ' . $t['subject'];
			$rows = '';
			foreach ( $diff as $d ) {
				$rows .= '<tr><td style="padding:4px 10px 4px 0;color:#6b7285;vertical-align:top;white-space:nowrap">' . esc_html( $d[0] ) . '</td>'
					. '<td style="padding:4px 10px 4px 0;vertical-align:top;color:#8a8f9c;text-decoration:line-through">' . nl2br( esc_html( $d[1] ) ) . '</td>'
					. '<td style="padding:4px 0;vertical-align:top;font-weight:bold">' . nl2br( esc_html( $d[2] ) ) . '</td></tr>';
			}
			$t['body'] = '<div style="margin:0 0 18px;padding:12px 14px;border-radius:8px;background:#fff4dc;border:1px solid #f1d38f">'
				. '<p style="margin:0 0 8px;font-weight:bold;color:#7a4d00">' . esc_html( $w['user_name'] ) . ' poprawił(a) ' . ( $check ? 'prośbę' : 'wniosek' ) . ' #' . (int) $w['id'] . ' – poniżej aktualna wersja.</p>'
				. '<table role="presentation" cellpadding="0" cellspacing="0" style="border-collapse:collapse;font-size:13px">' . $rows . '</table></div>' . $t['body'];
		}
		return MSM_Mail::send( self::admin_emails(), $t['subject'], $t['body'], array( 'footer' => true, 'logo' => true ) );
	}

	/** Bezpieczny odnośnik HTML. */
	private static function link( $url ) {
		return '<a href="' . esc_url( $url ) . '">' . esc_html( $url ) . '</a>';
	}

	public static function notify_requester( $w ) {
		$u = get_userdata( (int) $w['user_id'] );
		if ( ! $u || ! is_email( $u->user_email ) ) {
			return false;
		}
		$labels = self::labels();
		$check  = self::TYPE_CHECK === $w['typ'];
		if ( $check && self::ST_IN_STOCK === $w['status'] ) {
			$url = 'Aby od razu wysłać zapotrzebowanie na ten materiał (bez ponownego wypełniania), otwórz:<br>' . self::link( MSM_Access::app_url() . '#wyslij-' . (int) $w['id'] );
		} else {
			$url = self::link( MSM_Access::app_url() . '#wnioski' );
		}
		$vars = array(
			'id'           => (int) $w['id'],
			'status'       => $labels[ $w['status'] ],
			'material'     => $w['material'],
			'ilosc'        => MSM_Calc::fmt( $w['ilosc'] ) . ' ' . $w['jednostka'] . ( MSM_Calc::odc_txt( $w ) ? ' (' . MSM_Calc::odc_txt( $w ) . ')' : '' ),
			'zlecenie'     => $w['zlecenie'] ? $w['zlecenie'] : '—',
			'decided_name' => $w['decided_name'],
			'odpowiedz'    => $w['admin_note'] ? '<p><strong>Odpowiedź:</strong> ' . esc_html( $w['admin_note'] ) . '</p>' : '',
			'url'          => $url,
		);
		$t = MSM_Mail::render( $check ? 'sprawdzenie_status' : 'wniosek_status', $vars );
		return MSM_Mail::send( $u->user_email, $t['subject'], $t['body'], array( 'footer' => true, 'logo' => true ) );
	}

	private static function forbidden() {
		return new WP_Error( 'msm_forbidden', 'Brak uprawnień.', array( 'status' => 403 ) );
	}

	private static function bad_state( $status ) {
		$labels = self::labels();
		return new WP_Error( 'msm_state', 'Tej akcji nie można wykonać – wniosek ma status „' . ( $labels[ $status ] ?? $status ) . '”. Odśwież listę.', array( 'status' => 409 ) );
	}
}
