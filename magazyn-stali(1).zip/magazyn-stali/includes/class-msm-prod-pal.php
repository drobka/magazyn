<?php
/**
 * Produkcja – Paletówki projektu.
 *
 * Paleta: wspólna numeracja dla wszystkich zleceń „P00127/26” (licznik roczny), kilka pozycji na palecie
 * (nazwa, numer części, ilość, waga brutto, ilość stosów, wysokość stosu, materiał).
 * Nadawca z Ustawień, odbiorca z karty projektu (z możliwością nadpisania w zleceniu).
 * Wydruk A4 – jedna paleta na stronę (drukuj / zapisz jako PDF).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MSM_Prod_Pal {

	const START = array( 2026 => 127 ); // pierwszy numer w danym roku (wcześniejsze palety były z Worda)
	const ROWS  = array( 'nazwa', 'rysunek', 'ilosc', 'waga', 'stosy', 'wysokosc', 'material' );

	public static function TP() {
		global $wpdb;
		return $wpdb->prefix . 'msm_prod_pal';
	}

	public static function TPP() {
		global $wpdb;
		return $wpdb->prefix . 'msm_prod_pal_poz';
	}

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
		add_action( 'template_redirect', array( __CLASS__, 'maybe_print' ), 1 );
	}

	public static function create_tables() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$c = $wpdb->get_charset_collate();
		dbDelta( 'CREATE TABLE ' . self::TP() . " (
id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
zlec_id bigint(20) unsigned NOT NULL,
rok smallint(5) unsigned NOT NULL,
nr int(10) unsigned NOT NULL,
created_at datetime NULL,
created_by bigint(20) unsigned NOT NULL DEFAULT 0,
updated_at datetime NULL,
updated_by bigint(20) unsigned NOT NULL DEFAULT 0,
PRIMARY KEY  (id),
UNIQUE KEY numer (rok,nr),
KEY zlec (zlec_id)
) $c;" );
		dbDelta( 'CREATE TABLE ' . self::TPP() . " (
id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
pal_id bigint(20) unsigned NOT NULL,
lp int(11) NOT NULL DEFAULT 0,
det_id bigint(20) unsigned NULL,
nazwa varchar(255) NOT NULL DEFAULT '',
rysunek varchar(255) NOT NULL DEFAULT '',
ilosc int(11) NOT NULL DEFAULT 0,
waga decimal(12,2) NULL,
stosy int(11) NULL,
wysokosc decimal(10,1) NULL,
material varchar(255) NOT NULL DEFAULT '',
PRIMARY KEY  (id),
KEY pal (pal_id),
KEY det (det_id)
) $c;" );
	}

	public static function routes() {
		$ns = MSM_Rest::NS;
		$p  = array( 'MSM_Prod', 'can' );
		register_rest_route( $ns, '/prod/order/(?P<id>\d+)/palety', array(
			array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'list_r' ), 'permission_callback' => $p ),
			array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'add_r' ), 'permission_callback' => $p ),
		) );
		register_rest_route( $ns, '/prod/order/(?P<id>\d+)/pal-odbiorca', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'odbiorca_r' ), 'permission_callback' => $p ) );
		register_rest_route( $ns, '/prod/pal/(?P<id>\d+)', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'save_r' ), 'permission_callback' => $p ) );
		register_rest_route( $ns, '/prod/pal/(?P<id>\d+)/numer', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'numer_r' ), 'permission_callback' => $p ) );
		register_rest_route( $ns, '/prod/palety', array(
			'methods'             => 'GET',
			'callback'            => array( __CLASS__, 'all_r' ),
			'permission_callback' => function () {
				$c = MSM_Prod::can();
				if ( is_wp_error( $c ) ) {
					return $c;
				}
				return MSM_Perms::is_wp_admin() || MSM_Perms::menu_on( 'prod_palety' ) ? true : new WP_Error( 'msm_forbidden', 'Lista Paletówek jest dla Ciebie wyłączona.', array( 'status' => 403 ) );
			},
		) );
		register_rest_route( $ns, '/prod/pal/sprawdz', array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'check_r' ), 'permission_callback' => $p ) );
		register_rest_route( $ns, '/prod/pal/(?P<id>\d+)/delete', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'delete_r' ), 'permission_callback' => array( 'MSM_Prod', 'can_manage' ) ) );
	}

	/* ---------------- numeracja ---------------- */

	public static function numer( $rok, $nr ) {
		return 'P' . str_pad( (string) (int) $nr, 5, '0', STR_PAD_LEFT ) . '/' . substr( (string) (int) $rok, -2 );
	}

	/** Najniższy wolny numer w roku (od numeru startowego) – numer usuniętej palety wraca do puli. */
	public static function next_nr( $rok ) {
		global $wpdb;
		$start = self::START[ (int) $rok ] ?? 1;
		$used  = array_flip( array_map( 'intval', (array) $wpdb->get_col( $wpdb->prepare( 'SELECT nr FROM `' . self::TP() . '` WHERE rok = %d AND nr >= %d', (int) $rok, $start ) ) ) ); // phpcs:ignore
		for ( $n = $start; isset( $used[ $n ] ); $n++ ) {} // phpcs:ignore
		return $n;
	}

	/** Usuwa wszystkie palety zlecenia (przy usuwaniu zlecenia). Zwraca usunięte numery. */
	public static function delete_for_order( $zid ) {
		global $wpdb;
		$ps = (array) $wpdb->get_results( $wpdb->prepare( 'SELECT id, rok, nr FROM `' . self::TP() . '` WHERE zlec_id = %d', (int) $zid ), ARRAY_A ); // phpcs:ignore
		foreach ( $ps as $p ) {
			$wpdb->delete( self::TPP(), array( 'pal_id' => (int) $p['id'] ) );
			$wpdb->delete( self::TP(), array( 'id' => (int) $p['id'] ) );
		}
		return array_map( function ( $p ) { return self::numer( $p['rok'], $p['nr'] ); }, $ps );
	}

	/** Sprzątanie: palety po zleceniach usuniętych wcześniej (przed 1.76.1) – usuwane, numery wracają do puli. */
	public static function purge_orphans() {
		global $wpdb;
		if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', self::TP() ) ) !== self::TP() ) {
			return;
		}
		$ids = array_map( 'intval', (array) $wpdb->get_col( 'SELECT p.id FROM `' . self::TP() . '` p LEFT JOIN `' . MSM_Prod::TZ() . '` z ON z.id = p.zlec_id WHERE z.id IS NULL' ) ); // phpcs:ignore
		if ( $ids ) {
			$in = implode( ',', $ids );
			$wpdb->query( 'DELETE FROM `' . self::TPP() . "` WHERE pal_id IN ($in)" ); // phpcs:ignore
			$wpdb->query( 'DELETE FROM `' . self::TP() . "` WHERE id IN ($in)" ); // phpcs:ignore
		}
	}

	/**
	 * Numer wpisany ręcznie: „P00127/26”, „127/26”, „P127/2026”, „127” (rok – domyślny).
	 * @return array|null [rok, nr]
	 */
	public static function parse_numer( $s, $rok_def ) {
		$s = strtoupper( preg_replace( '/\s+/', '', (string) $s ) );
		if ( ! preg_match( '/^P?0*(\d{1,7})(?:\/(\d{2}|\d{4}))?$/', $s, $m ) || (int) $m[1] < 1 ) {
			return null;
		}
		$rok = isset( $m[2] ) && '' !== $m[2] ? ( 2 === strlen( $m[2] ) ? 2000 + (int) $m[2] : (int) $m[2] ) : (int) $rok_def;
		if ( $rok < 2000 || $rok > 2099 ) {
			return null;
		}
		return array( $rok, (int) $m[1] );
	}

	/** Kto ma już ten numer (poza paletą $except): null albo {id, zlec_id, nr_zlec}. */
	public static function taken( $rok, $nr, $except = 0 ) {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( 'SELECT p.id, p.zlec_id, z.nr_zlec FROM `' . self::TP() . '` p LEFT JOIN `' . MSM_Prod::TZ() . '` z ON z.id = p.zlec_id WHERE p.rok = %d AND p.nr = %d AND p.id <> %d LIMIT 1', (int) $rok, (int) $nr, (int) $except ), ARRAY_A ); // phpcs:ignore
		return $row ? array( 'id' => (int) $row['id'], 'zlec_id' => (int) $row['zlec_id'], 'nr_zlec' => (string) $row['nr_zlec'] ) : null;
	}

	private static function taken_msg( $numer, array $t ) {
		return 'Numer ' . $numer . ' jest już użyty' . ( '' !== $t['nr_zlec'] ? ' w zleceniu ' . $t['nr_zlec'] : '' ) . '.';
	}

	/* ---------------- odczyt ---------------- */

	private static function order( $zid ) {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM `' . MSM_Prod::TZ() . '` WHERE id = %d', (int) $zid ), ARRAY_A ); // phpcs:ignore
	}

	/** Odbiorca: własny z zakładki Paletówki, a gdy pusty – „Odbiorca” z karty projektu. */
	public static function odbiorca( array $z ) {
		$own = trim( (string) ( $z['pal_odbiorca'] ?? '' ) );
		if ( '' !== $own ) {
			return $own;
		}
		$k = class_exists( 'MSM_Karta' ) ? MSM_Karta::decode( $z['karta'] ?? '' ) : array();
		return trim( (string) ( $k['odbiorca'] ?? '' ) );
	}

	/** Nadawca z Ustawień (zwykły tekst): nazwa, adres, POLAND, kontakt. */
	public static function nadawca_def() {
		$adr   = array_map( 'trim', explode( ',', (string) msm_opt( 'firma_adres' ) ) );
		$lines = array_merge( array( (string) msm_opt( 'firma_nazwa' ) ), array_filter( $adr ), array( 'POLAND' ) );
		$k     = (string) msm_opt( 'pal_kontakt' );
		return implode( "\n", $lines ) . ( '' !== $k ? "\nContact:  " . $k : '' );
	}

	/** Nadawca: własny dla paletówek zlecenia, a gdy pusty – z Ustawień. */
	public static function nadawca( array $z ) {
		$own = trim( (string) ( $z['pal_nadawca'] ?? '' ) );
		return '' !== $own ? $own : self::nadawca_def();
	}

	public static function pallets( $zid ) {
		global $wpdb;
		$ps = (array) $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM `' . self::TP() . '` WHERE zlec_id = %d ORDER BY rok ASC, nr ASC', (int) $zid ), ARRAY_A ); // phpcs:ignore
		if ( ! $ps ) {
			return array();
		}
		$ids  = implode( ',', array_map( 'intval', wp_list_pluck( $ps, 'id' ) ) );
		$rows = (array) $wpdb->get_results( 'SELECT * FROM `' . self::TPP() . "` WHERE pal_id IN ($ids) ORDER BY lp ASC, id ASC", ARRAY_A ); // phpcs:ignore
		$by   = array();
		foreach ( $rows as $r ) {
			$by[ (int) $r['pal_id'] ][] = array(
				'det_id'   => $r['det_id'] ? (int) $r['det_id'] : null,
				'nazwa'    => $r['nazwa'],
				'rysunek'  => $r['rysunek'],
				'ilosc'    => (int) $r['ilosc'],
				'waga'     => null === $r['waga'] ? null : (float) $r['waga'],
				'stosy'    => null === $r['stosy'] ? null : (int) $r['stosy'],
				'wysokosc' => null === $r['wysokosc'] ? null : (float) $r['wysokosc'],
				'material' => $r['material'],
			);
		}
		return array_map( function ( $p ) use ( $by ) {
			return array(
				'id'    => (int) $p['id'],
				'rok'   => (int) $p['rok'],
				'nr'    => (int) $p['nr'],
				'numer' => self::numer( $p['rok'], $p['nr'] ),
				'data'  => $p['created_at'] ? mysql2date( 'd.m.Y', $p['created_at'] ) : '',
				'poz'   => $by[ (int) $p['id'] ] ?? array(),
			);
		}, $ps );
	}

	private static function payload( $zid ) {
		$z = self::order( $zid );
		return array(
			'palety'          => self::pallets( $zid ),
			'odbiorca'        => self::odbiorca( $z ),
			'odbiorca_wlasny' => trim( (string) ( $z['pal_odbiorca'] ?? '' ) ),
			'odbiorca_karta'  => self::odbiorca( array_merge( $z, array( 'pal_odbiorca' => '' ) ) ),
			'nadawca'         => self::nadawca( $z ),
			'nadawca_wlasny'  => trim( (string) ( $z['pal_nadawca'] ?? '' ) ),
			'nadawca_def'     => self::nadawca_def(),
			'nastepny'        => self::numer( (int) current_time( 'Y' ), self::next_nr( (int) current_time( 'Y' ) ) ),
		);
	}

	/* ---------------- REST ---------------- */

	public static function list_r( WP_REST_Request $r ) {
		if ( ! self::order( (int) $r['id'] ) ) {
			return new WP_Error( 'msm_404', 'Nie ma takiego zlecenia.', array( 'status' => 404 ) );
		}
		return rest_ensure_response( self::payload( (int) $r['id'] ) );
	}

	/** Nowe palety: { ile: 1–50, wzor: id palety do powielenia | 0 } – bez wzoru jedna pusta pozycja z pierwszego detalu. */
	public static function add_r( WP_REST_Request $r ) {
		global $wpdb;
		$zid = (int) $r['id'];
		$z   = self::order( $zid );
		if ( ! $z ) {
			return new WP_Error( 'msm_404', 'Nie ma takiego zlecenia.', array( 'status' => 404 ) );
		}
		$p    = (array) $r->get_json_params();
		$ile  = max( 1, min( 50, (int) ( $p['ile'] ?? 1 ) ) );
		$wzor = array();
		if ( ! empty( $p['wzor'] ) ) {
			foreach ( self::pallets( $zid ) as $pal ) {
				if ( (int) $pal['id'] === (int) $p['wzor'] ) {
					$wzor = $pal['poz'];
				}
			}
		}
		if ( ! $wzor ) {
			$d    = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM `' . MSM_Prod::TD() . '` WHERE zlec_id = %d ORDER BY poz ASC, id ASC LIMIT 1', $zid ), ARRAY_A ); // phpcs:ignore
			$wzor = array( array( 'det_id' => $d ? (int) $d['id'] : null, 'nazwa' => $d['nazwa_detalu'] ?? '', 'rysunek' => $d['nr_rysunku'] ?? '', 'ilosc' => 0, 'waga' => null, 'stosy' => null, 'wysokosc' => null, 'material' => $d['material'] ?? '' ) );
		}
		$rok  = (int) current_time( 'Y' );
		$now  = current_time( 'mysql' );
		$uid  = get_current_user_id();
		$nums = array();
		for ( $i = 0; $i < $ile; $i++ ) {
			$ok = false;
			for ( $try = 0; $try < 5 && ! $ok; $try++ ) { // UNIQUE(rok,nr) chroni przed podwójnym numerem przy jednoczesnym dodawaniu
				$nr = self::next_nr( $rok );
				$ok = (bool) $wpdb->insert( self::TP(), array( 'zlec_id' => $zid, 'rok' => $rok, 'nr' => $nr, 'created_at' => $now, 'created_by' => $uid, 'updated_at' => $now, 'updated_by' => $uid ) );
			}
			if ( ! $ok ) {
				return new WP_Error( 'msm_db', 'Nie udało się nadać numeru palety.', array( 'status' => 500 ) );
			}
			self::write_rows( (int) $wpdb->insert_id, $wzor );
			$nums[] = self::numer( $rok, $nr );
		}
		MSM_Repo::log( 'Produkcja: palety', 'produkcja', $zid, 'Zlecenie ' . $z['nr_zlec'] . ' – dodano ' . ( 1 === $ile ? 'paletę ' : 'palety ' ) . implode( ', ', $nums ) );
		return rest_ensure_response( array_merge( self::payload( $zid ), array( 'dodane' => $nums ) ) );
	}

	private static function clean_rows( $rows ) {
		$out = array();
		foreach ( array_slice( (array) $rows, 0, 30 ) as $r ) {
			if ( ! is_array( $r ) ) {
				continue;
			}
			$f     = function ( $k ) use ( $r ) { return isset( $r[ $k ] ) && is_scalar( $r[ $k ] ) ? trim( (string) $r[ $k ] ) : ''; };
			$num   = function ( $k ) use ( $f ) { $v = str_replace( array( ' ', ',' ), array( '', '.' ), $f( $k ) ); return '' === $v || ! is_numeric( $v ) ? null : (float) $v; };
			$out[] = array(
				'det_id'   => ! empty( $r['det_id'] ) ? (int) $r['det_id'] : null,
				'nazwa'    => mb_substr( $f( 'nazwa' ), 0, 255 ),
				'rysunek'  => mb_substr( $f( 'rysunek' ), 0, 255 ),
				'ilosc'    => max( 0, (int) round( (float) $num( 'ilosc' ) ) ),
				'waga'     => $num( 'waga' ),
				'stosy'    => null === $num( 'stosy' ) ? null : (int) round( $num( 'stosy' ) ),
				'wysokosc' => $num( 'wysokosc' ),
				'material' => mb_substr( $f( 'material' ), 0, 255 ),
			);
		}
		return $out;
	}

	private static function write_rows( $pal_id, array $rows ) {
		global $wpdb;
		$wpdb->delete( self::TPP(), array( 'pal_id' => (int) $pal_id ) );
		foreach ( self::clean_rows( $rows ) as $i => $row ) {
			$wpdb->insert( self::TPP(), array_merge( $row, array( 'pal_id' => (int) $pal_id, 'lp' => $i + 1 ) ) );
		}
	}

	/** Zapis pozycji palety (cała tabela palety naraz). */
	public static function save_r( WP_REST_Request $r ) {
		global $wpdb;
		$pal = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM `' . self::TP() . '` WHERE id = %d', (int) $r['id'] ), ARRAY_A ); // phpcs:ignore
		if ( ! $pal ) {
			return new WP_Error( 'msm_404', 'Nie ma takiej palety.', array( 'status' => 404 ) );
		}
		$p = (array) $r->get_json_params();
		self::write_rows( (int) $pal['id'], (array) ( $p['poz'] ?? array() ) );
		$wpdb->update( self::TP(), array( 'updated_at' => current_time( 'mysql' ), 'updated_by' => get_current_user_id() ), array( 'id' => (int) $pal['id'] ) );
		$z = self::order( (int) $pal['zlec_id'] );
		MSM_Repo::log( 'Produkcja: paleta zmieniona', 'produkcja', (int) $pal['zlec_id'], 'Zlecenie ' . ( $z['nr_zlec'] ?? '' ) . ' – paleta ' . self::numer( $pal['rok'], $pal['nr'] ) );
		return rest_ensure_response( array( 'ok' => true ) );
	}

	/** GET /prod/palety – wszystkie palety ze wszystkich zleceń (najnowsze numery na górze). */
	public static function all_r() {
		global $wpdb;
		$TP = self::TP();
		$TZ = MSM_Prod::TZ();
		$ps = (array) $wpdb->get_results( "SELECT p.*, z.nr_zlec, z.klient, z.nr_zlec_klienta FROM `$TP` p INNER JOIN `$TZ` z ON z.id = p.zlec_id ORDER BY p.rok DESC, p.nr DESC", ARRAY_A ); // phpcs:ignore – tylko palety istniejących zleceń
		$rows = array();
		if ( $ps ) {
			$ids = implode( ',', array_map( 'intval', wp_list_pluck( $ps, 'id' ) ) );
			foreach ( (array) $wpdb->get_results( 'SELECT * FROM `' . self::TPP() . "` WHERE pal_id IN ($ids) ORDER BY lp ASC, id ASC", ARRAY_A ) as $r ) { // phpcs:ignore
				$rows[ (int) $r['pal_id'] ][] = $r;
			}
		}
		$out = array();
		foreach ( $ps as $p ) {
			$poz   = $rows[ (int) $p['id'] ] ?? array();
			$out[] = array(
				'id'       => (int) $p['id'],
				'numer'    => self::numer( $p['rok'], $p['nr'] ),
				'rok'      => (int) $p['rok'],
				'data'     => $p['created_at'] ? mysql2date( 'd.m.Y', $p['created_at'] ) : '',
				'zlec_id'  => (int) $p['zlec_id'],
				'nr_zlec'  => (string) $p['nr_zlec'],
				'klient'   => (string) $p['klient'],
				'zam'      => (string) $p['nr_zlec_klienta'],
				'nazwy'    => array_values( array_unique( array_filter( wp_list_pluck( $poz, 'nazwa' ) ) ) ),
				'rysunki'  => array_values( array_unique( array_filter( wp_list_pluck( $poz, 'rysunek' ) ) ) ),
				'material' => array_values( array_unique( array_filter( wp_list_pluck( $poz, 'material' ) ) ) ),
				'ilosc'    => array_sum( array_map( 'intval', wp_list_pluck( $poz, 'ilosc' ) ) ),
				'waga'     => array_sum( array_map( 'floatval', wp_list_pluck( $poz, 'waga' ) ) ),
				'stosy'    => array_sum( array_map( 'intval', wp_list_pluck( $poz, 'stosy' ) ) ),
			);
		}
		return rest_ensure_response( array( 'palety' => $out, 'nastepny' => self::numer( (int) current_time( 'Y' ), self::next_nr( (int) current_time( 'Y' ) ) ) ) );
	}

	/** GET /prod/pal/sprawdz?numer=&rok=&except= – czy numer jest wolny (sprawdzanie w trakcie wpisywania). */
	public static function check_r( WP_REST_Request $r ) {
		$pn = self::parse_numer( (string) $r->get_param( 'numer' ), (int) ( $r->get_param( 'rok' ) ?: current_time( 'Y' ) ) );
		if ( ! $pn ) {
			return rest_ensure_response( array( 'ok' => false, 'msg' => 'Wpisz numer w formacie P00127/26.' ) );
		}
		$numer = self::numer( $pn[0], $pn[1] );
		$t     = self::taken( $pn[0], $pn[1], (int) $r->get_param( 'except' ) );
		return rest_ensure_response( array( 'ok' => ! $t, 'numer' => $numer, 'msg' => $t ? self::taken_msg( $numer, $t ) : 'Numer ' . $numer . ' jest wolny.' ) );
	}

	/** POST /prod/pal/{id}/numer { numer } – zmiana numeru palety z kontrolą duplikatu. */
	public static function numer_r( WP_REST_Request $r ) {
		global $wpdb;
		$pal = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM `' . self::TP() . '` WHERE id = %d', (int) $r['id'] ), ARRAY_A ); // phpcs:ignore
		if ( ! $pal ) {
			return new WP_Error( 'msm_404', 'Nie ma takiej palety.', array( 'status' => 404 ) );
		}
		$pn = self::parse_numer( (string) ( $r->get_json_params()['numer'] ?? '' ), (int) $pal['rok'] );
		if ( ! $pn ) {
			return new WP_Error( 'msm_400', 'Wpisz numer w formacie P00127/26.', array( 'status' => 400, 'fields' => array( 'numer' => 'Format: P00127/26' ) ) );
		}
		$old   = self::numer( $pal['rok'], $pal['nr'] );
		$numer = self::numer( $pn[0], $pn[1] );
		if ( (int) $pal['rok'] === $pn[0] && (int) $pal['nr'] === $pn[1] ) {
			return rest_ensure_response( self::payload( (int) $pal['zlec_id'] ) );
		}
		$t = self::taken( $pn[0], $pn[1], (int) $pal['id'] );
		if ( $t ) {
			return new WP_Error( 'msm_dup', self::taken_msg( $numer, $t ), array( 'status' => 409, 'fields' => array( 'numer' => 'Numer zajęty' ) ) );
		}
		$ok = $wpdb->update( self::TP(), array( 'rok' => $pn[0], 'nr' => $pn[1], 'updated_at' => current_time( 'mysql' ), 'updated_by' => get_current_user_id() ), array( 'id' => (int) $pal['id'] ) );
		if ( false === $ok ) { // UNIQUE(rok,nr) – ktoś zajął numer w tej samej chwili
			return new WP_Error( 'msm_dup', 'Numer ' . $numer . ' został właśnie zajęty – wybierz inny.', array( 'status' => 409 ) );
		}
		$z = self::order( (int) $pal['zlec_id'] );
		MSM_Repo::log( 'Produkcja: zmiana numeru palety', 'produkcja', (int) $pal['zlec_id'], 'Zlecenie ' . ( $z['nr_zlec'] ?? '' ) . ' – paleta ' . $old . ' → ' . $numer );
		return rest_ensure_response( self::payload( (int) $pal['zlec_id'] ) );
	}

	public static function delete_r( WP_REST_Request $r ) {
		global $wpdb;
		$pal = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM `' . self::TP() . '` WHERE id = %d', (int) $r['id'] ), ARRAY_A ); // phpcs:ignore
		if ( ! $pal ) {
			return new WP_Error( 'msm_404', 'Nie ma takiej palety.', array( 'status' => 404 ) );
		}
		$wpdb->delete( self::TPP(), array( 'pal_id' => (int) $pal['id'] ) );
		$wpdb->delete( self::TP(), array( 'id' => (int) $pal['id'] ) );
		$z = self::order( (int) $pal['zlec_id'] );
		MSM_Repo::log( 'Produkcja: paleta usunięta', 'produkcja', (int) $pal['zlec_id'], 'Zlecenie ' . ( $z['nr_zlec'] ?? '' ) . ' – usunięto paletę ' . self::numer( $pal['rok'], $pal['nr'] ) . ' (numer wolny do ponownego użycia)' );
		return rest_ensure_response( self::payload( (int) $pal['zlec_id'] ) );
	}

	public static function odbiorca_r( WP_REST_Request $r ) {
		global $wpdb;
		$zid = (int) $r['id'];
		if ( ! self::order( $zid ) ) {
			return new WP_Error( 'msm_404', 'Nie ma takiego zlecenia.', array( 'status' => 404 ) );
		}
		$p   = (array) $r->get_json_params();
		$upd = array();
		foreach ( array( 'odbiorca' => 'pal_odbiorca', 'nadawca' => 'pal_nadawca' ) as $in => $col ) {
			if ( array_key_exists( $in, $p ) ) {
				$upd[ $col ] = MSM_Rich::clean( mb_substr( wp_check_invalid_utf8( (string) $p[ $in ] ), 0, 3000 ) );
			}
		}
		if ( $upd ) {
			$wpdb->update( MSM_Prod::TZ(), $upd, array( 'id' => $zid ) );
		}
		return rest_ensure_response( self::payload( $zid ) );
	}

	/* ---------------- wydruk A4 (PDF) ---------------- */

	public static function maybe_print() {
		if ( ! isset( $_GET['msm_print'] ) || 'prod_pal' !== sanitize_key( wp_unslash( $_GET['msm_print'] ) ) || ! is_user_logged_in() ) { // phpcs:ignore
			return;
		}
		if ( ! current_user_can( 'msm_view' ) || ! MSM_Perms::menu_on( 'produkcja' ) ) {
			wp_die( 'Brak dostępu.', 403 );
		}
		$zid   = (int) ( $_GET['id'] ?? 0 ); // phpcs:ignore
		$only  = array_values( array_filter( array_map( 'intval', explode( ',', (string) ( $_GET['pal'] ?? '' ) ) ) ) ); // phpcs:ignore
		$items = array();
		if ( $zid ) { // palety jednego zlecenia (wszystkie albo wybrane)
			$z = self::order( $zid );
			if ( ! $z ) {
				wp_die( 'Zlecenie nie istnieje.', 404 );
			}
			foreach ( self::pallets( $zid ) as $p ) {
				if ( ! $only || in_array( $p['id'], $only, true ) ) {
					$items[] = array( 'z' => $z, 'p' => $p );
				}
			}
		} elseif ( $only ) { // wybrane palety z różnych zleceń (lista Paletówki)
			global $wpdb;
			$zids   = $wpdb->get_col( 'SELECT DISTINCT zlec_id FROM `' . self::TP() . '` WHERE id IN (' . implode( ',', $only ) . ')' ); // phpcs:ignore
			$by     = array();
			foreach ( $zids as $zi ) {
				$z = self::order( (int) $zi );
				foreach ( self::pallets( (int) $zi ) as $p ) {
					if ( $z && in_array( $p['id'], $only, true ) ) {
						$by[ $p['rok'] * 1000000 + $p['nr'] ] = array( 'z' => $z, 'p' => $p );
					}
				}
			}
			ksort( $by );
			$items = array_values( $by );
		}
		nocache_headers();
		self::print_doc( $items, ! empty( $_GET['auto'] ), ! empty( $_GET['embed'] ), $zid ); // phpcs:ignore
		exit;
	}

	/** Słowa bez dzielenia w środku („M250-50A” nie łamie się na myślniku); długi opis może przejść do nowej linii między słowami. */
	/**
	 * Długie oznaczenia bez spacji (np. „BMZS008926-B_Poz1.01.03_Stator-core-sheet.”) – możliwe łamanie
	 * po „_ - . / ,” zamiast wychodzenia poza komórkę tabeli.
	 */
	public static function wrap( $s ) {
		return preg_replace( '~([_\-./,;:]+)(?=\S)~u', '$1<wbr>', esc_html( (string) $s ) );
	}

	/** Bardzo długi ciąg w jednej komórce – mniejsza czcionka. */
	private static function is_long( $s ) {
		$s = (string) $s;
		return mb_strlen( $s ) > 34 || max( array_map( 'mb_strlen', preg_split( '/\s+/u', $s ) ?: array( '' ) ) ) > 22;
	}

	private static function nobreak( $s ) {
		$w = preg_split( '/\s+/u', trim( (string) $s ), -1, PREG_SPLIT_NO_EMPTY );
		return implode( ' ', array_map( function ( $x ) { return '<span>' . esc_html( $x ) . '</span>'; }, $w ) );
	}

	private static function fmt( $v, $dec = 0 ) {
		if ( null === $v || '' === $v ) {
			return '';
		}
		$s = number_format( (float) $v, $dec, ',', '' );
		return $dec ? rtrim( rtrim( $s, '0' ), ',' ) : $s;
	}

	/** $items: [ { z: zlecenie, p: paleta } ] – jedna paleta na stronę A4. */
	private static function print_doc( array $items, $auto, $embed = false, $zid = 0 ) {
		$fonts = MSM_URL . 'assets/fonts/';
		$total = count( $items );
		$nrs   = array_values( array_unique( array_map( function ( $it ) { return $it['z']['nr_zlec']; }, $items ) ) );
		$title = 'Paletówki ' . ( 1 === count( $nrs ) ? $nrs[0] : '' ) . ( 1 === $total ? ' – ' . $items[0]['p']['numer'] : '' );
		$back  = MSM_Access::app_url() . ( $zid ? '#prod-' . (int) $zid . '-paletowki' : '#prod-palety' );
		?><!DOCTYPE html>
<html lang="pl"><head><meta charset="utf-8"><meta name="robots" content="noindex,nofollow"><title><?php echo esc_html( str_replace( '/', '-', $title ) ); ?></title>
<style>
@font-face{font-family:PJS;font-weight:400;src:url(<?php echo esc_url( $fonts ); ?>plus-jakarta-sans-latin-ext-400-normal.woff2) format("woff2");unicode-range:U+0100-02BA,U+1E00-1E9F}
@font-face{font-family:PJS;font-weight:400;src:url(<?php echo esc_url( $fonts ); ?>plus-jakarta-sans-latin-400-normal.woff2) format("woff2");unicode-range:U+0000-00FF,U+2000-206F}
@font-face{font-family:PJS;font-weight:700;src:url(<?php echo esc_url( $fonts ); ?>plus-jakarta-sans-latin-ext-800-normal.woff2) format("woff2");unicode-range:U+0100-02BA,U+1E00-1E9F}
@font-face{font-family:PJS;font-weight:700;src:url(<?php echo esc_url( $fonts ); ?>plus-jakarta-sans-latin-800-normal.woff2) format("woff2");unicode-range:U+0000-00FF,U+2000-206F}
<?php echo self::css(); // phpcs:ignore ?>
</style></head>
<body<?php echo $embed ? ' class="embed"' : ''; ?>>
<?php if ( ! $embed ) : ?><div class="bar"><button onclick="window.print()">Pobierz PDF / drukuj</button><a class="g" href="<?php echo esc_url( $back ); ?>">Zamknij</a></div><?php endif; ?>
<?php if ( ! $items ) : ?><div class="pal"><p>Brak palet do wydruku.</p></div><?php endif; ?>
<?php foreach ( $items as $i => $it ) : $z = $it['z']; $p = $it['p']; $nad = self::nadawca( $z ); $odb = self::odbiorca( $z ); ?>
<section class="pal">
	<header class="ph"><img src="<?php echo esc_url( MSM_URL . 'assets/logo-wz.svg?v=' . MSM_VERSION ); ?>" alt="Kisielewski"></header>
	<div class="pt"><div class="pn">Pallet number: <b><?php echo esc_html( $p['numer'] ); ?></b></div><div class="ps">Numer Palety</div></div>
	<table class="addr">
		<tr><td><div class="ah">NADAWCA / SENDER:</div><div class="al"><?php echo MSM_Rich::html( $nad ); // phpcs:ignore ?></div></td>
		<td><div class="ah">ODBIORCA / RECIPIENT:</div><div class="al"><?php echo MSM_Rich::html( $odb ); // phpcs:ignore ?></div></td></tr>
		<tr><td class="pr"><?php echo esc_html( msm_opt( 'firma_nazwa' ) ); ?> Project No. /<i>Nr zlecenia:</i><br><b class="red"><?php echo esc_html( $z['nr_zlec'] ); ?></b></td>
		<td class="pr"><b>Purchase Order / <i>Nr zamówienia</i></b><br><b class="red"><?php echo esc_html( $z['nr_zlec_klienta'] ); ?></b></td></tr>
	</table>
	<table class="items">
		<colgroup><col style="width:16%"><col style="width:17%"><col style="width:9%"><col style="width:8%"><col style="width:7%"><col style="width:9%"><col style="width:15%"><col style="width:11%"><col style="width:8%"></colgroup>
		<thead><tr><th>Detail name /<br><i>Nazwa</i></th><th>Item no. /<br><i>Numer części</i></th><th>Quantity (pieces) / <i>Ilość</i></th><th>Waga Brutto [kg]</th><th>Ilość stosów</th><th>Wysokość stosu [mm]</th><th>Materiał</th><th>Acepted by /<br><i>Zatwierdzony przez</i></th><th>Date /<br><i>Data</i></th></tr></thead>
		<tbody>
		<?php foreach ( $p['poz'] as $r ) : ?>
			<tr><td class="txt<?php echo self::is_long( $r['nazwa'] ) ? ' long' : ''; ?>"><?php echo self::wrap( $r['nazwa'] ); // phpcs:ignore ?></td><td class="txt<?php echo self::is_long( $r['rysunek'] ) ? ' long' : ''; ?>"><?php echo self::wrap( $r['rysunek'] ); // phpcs:ignore ?></td><td><?php echo esc_html( self::fmt( $r['ilosc'] ) ); ?></td><td><?php echo esc_html( self::fmt( $r['waga'], 2 ) ); ?></td><td><?php echo esc_html( self::fmt( $r['stosy'] ) ); ?></td><td><?php echo null === $r['wysokosc'] ? '' : esc_html( self::fmt( $r['wysokosc'], 1 ) . ' mm' ); ?></td><td class="mat"><?php echo self::nobreak( $r['material'] ); // phpcs:ignore ?></td><td class="sig"></td><td class="sig"></td></tr>
		<?php endforeach; ?>
		</tbody>
	</table>
	<footer class="pf"><div><b><?php echo esc_html( msm_opt( 'firma_nazwa' ) ); ?></b> &nbsp; www.kisielewski.pl<br><small>Zastrzega się wszelkie prawa do powielania dokumentacji i udostępniania osobom trzecim bez zezwolenia firmy <?php echo esc_html( msm_opt( 'firma_nazwa' ) ); ?></small></div><div class="pg">Page <?php echo (int) ( $i + 1 ); ?> of <?php echo (int) $total; ?></div></footer>
</section>
<?php endforeach; ?>
<?php if ( $auto && $items ) : ?><script>window.addEventListener('load',function(){setTimeout(function(){window.print();},300);});</script><?php endif; ?>
</body></html>
		<?php
	}

	/** Wygląd paletówki – wspólny dla wydruku i podglądu w aplikacji (klasy .pal …). */
	public static function css() {
		return '@page{size:A4;margin:0}
*{box-sizing:border-box}
html,body{margin:0;background:#e9ebef}
body{font:10pt/1.35 PJS,system-ui,sans-serif;color:#000;-webkit-print-color-adjust:exact;print-color-adjust:exact}
.bar{position:sticky;top:0;display:flex;gap:10px;justify-content:center;padding:10px;background:#0b1020;z-index:5}
.bar button,.bar a{font:700 13px PJS,system-ui;padding:8px 18px;border-radius:99px;border:0;background:#3d4bff;color:#fff;cursor:pointer;text-decoration:none}
.bar .g{background:transparent;border:1px solid rgba(255,255,255,.4)}
.pal{position:relative;width:210mm;height:297mm;padding:10mm 12mm 28mm;margin:16px auto;background:#fff;box-shadow:0 4px 24px rgba(0,0,0,.14);page-break-after:always;break-after:page;overflow:hidden}
.pal:last-of-type{page-break-after:auto;break-after:auto}
@media print{html,body{background:#fff}.bar{display:none}.pal{margin:0;box-shadow:none}}
.ph{padding-bottom:2.5mm;border-bottom:1px solid #000;margin:0 0 3.5mm}
.ph img{height:12mm;width:auto;display:block}
.pt{text-align:center;margin-bottom:4mm;line-height:1.15}
.pn{font-size:21pt;font-weight:400;letter-spacing:-.01em}
.pn b{color:#e10600;font-weight:700}
.ps{font-style:italic;font-size:10pt;margin-top:.5mm}
.addr{width:100%;border-collapse:collapse;margin-bottom:6mm}
.addr td{width:50%;border:1px solid #000;padding:2mm 2.5mm;vertical-align:top;font-size:9.5pt}
.ah{font-size:12pt;font-weight:700;margin-bottom:2mm}
.al ol,.al ul{margin:1mm 0;padding-left:5mm}
.al li{margin:0}
.pr i{font-style:italic}
.red{color:#e10600;font-weight:700}
.items{width:100%;margin:0;border-collapse:collapse;table-layout:fixed;font-size:7.5pt}
.items td.mat span{white-space:nowrap}
.items td.txt{overflow-wrap:anywhere;word-break:break-word;hyphens:none;line-height:1.3}
.items td.txt.long{font-size:7pt}
.items th{border:1px solid #000;padding:1.2mm 1mm;font-weight:700;text-align:center;vertical-align:middle}
.items td{border:1px solid #000;padding:1.2mm 1mm;text-align:center;vertical-align:middle;color:#e10600;font-weight:700;font-size:8pt}
.items td.sig{min-width:18mm;color:#000}
.pf{position:absolute;left:12mm;right:12mm;bottom:9mm;display:flex;justify-content:space-between;align-items:flex-end;gap:6mm;border-top:1px solid #000;padding-top:1mm;font-size:8pt}
.pf small{font-size:6.5pt}
.pf .pg{font-size:10pt;white-space:nowrap}
body.embed{background:transparent;overflow:hidden}
body.embed .pal{margin:0;box-shadow:none}';
	}
}
