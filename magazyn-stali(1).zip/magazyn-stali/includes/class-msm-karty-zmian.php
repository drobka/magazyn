<?php
/**
 * Produkcja → Karty zmian: formularz karty zmiany (obsada, stanowisko, do 10 programów),
 * zapis w systemie i eksport do arkusza Excela 1:1 z wzorem firmy (data/karta-zmiany.xlsx –
 * te same kolory, logo, listy wyboru i formatowanie warunkowe; wypełniane są tylko komórki kolumny C).
 * Dostęp tylko dla wskazanych osób (Użytkownicy → Produkcja → Karty zmian) + super administrator.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MSM_Karty_Zmian {

	const LINIE    = array( 'L1', 'L2' );
	const TAKNIE   = array( 'TAK', 'NIE', 'nie dotyczy' );
	const MAX_PROG = 10;
	const PROG_ROW = 19; // pierwszy wiersz „NAZWA PROGRAMU” w arkuszu
	const PROG_STEP = 13; // co tyle wierszy zaczyna się kolejny blok programu

	/** Pola programu: klucz => [etykieta (jak w arkuszu), przesunięcie wiersza, typ]. */
	public static function prog_fields() {
		return array(
			'nazwa'       => array( 'Nazwa programu', 0, 'txt' ),
			'zadana'      => array( 'Ilość zadana', 1, 'num' ),
			'dobre'       => array( 'Ilość wykonana – detale dobre', 2, 'num' ),
			'zle'         => array( 'Ilość wykonana – detale złe/zniszczone', 3, 'num' ),
			'wyjasnienie' => array( 'Wyjaśnienie rozbieżności', 4, 'txt' ),
			'gatunek'     => array( 'Materiał – gatunek', 5, 'txt' ),
			'format'      => array( 'Materiał – format', 6, 'txt' ),
			'zmierzone'   => array( 'Ilość zmierzonych detali', 7, 'num' ),
			'arkusze'     => array( 'Ilość zużytych arkuszy', 8, 'num' ),
			'stos'        => array( 'Wielkość stosu wyciętego', 9, 'mix' ),
			'ulozone'     => array( 'Wszystkie detale ułożone', 10, 'taknie' ),
			'uwagi'       => array( 'Uwagi', 11, 'txt' ),
		);
	}

	/** Pola nagłówka: klucz => wiersz w kolumnie C. */
	const HEAD_ROWS = array(
		'wypelnil' => 5, 'data' => 6, 'zmiana' => 7, 'godzina' => 8,
		'operator1' => 9, 'operator2' => 10, 'pomocnik1' => 11, 'pomocnik2' => 12, 'pomocnik3' => 13,
		'porzadek' => 14, 'przyrzady' => 15, 'problemy' => 16, 'uwagi_poprz' => 17,
	);

	public static function T() {
		global $wpdb;
		return $wpdb->prefix . 'msm_karty_zmian';
	}

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
	}

	public static function create_tables() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$T = self::T();
		$c = $wpdb->get_charset_collate();
		dbDelta( "CREATE TABLE $T (
id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
data date NOT NULL,
linia varchar(4) NOT NULL DEFAULT '',
zmiana tinyint(3) unsigned NOT NULL DEFAULT 1,
wypelnil varchar(120) NOT NULL DEFAULT '',
zlecenia varchar(255) NOT NULL DEFAULT '',
dane longtext NOT NULL,
created_by bigint(20) unsigned NOT NULL DEFAULT 0,
created_at datetime NOT NULL,
updated_by bigint(20) unsigned NOT NULL DEFAULT 0,
updated_at datetime NULL,
PRIMARY KEY  (id),
KEY data (data),
KEY linia (linia),
KEY zlecenia (zlecenia(40))
) $c;" );
		self::fill_zlecenia();
	}

	/** Numer zlecenia z nazwy programu: „B02516_v3_942_2670_KB_4k” → „B02516”. */
	public static function zlec_of( $nazwa ) {
		return preg_match( '/^\s*([A-Za-z]\d{4,6})(?=[_\-\s.]|$)/', (string) $nazwa, $m ) ? strtoupper( $m[1] ) : '';
	}

	/** Lista zleceń karty do wyszukiwania: „,B02516,B02517,”. */
	public static function zlec_key( array $programy ) {
		$z = array();
		foreach ( $programy as $p ) {
			$n = self::zlec_of( $p['nazwa'] ?? '' );
			if ( $n && ! in_array( $n, $z, true ) ) {
				$z[] = $n;
			}
		}
		return $z ? mb_substr( ',' . implode( ',', $z ) . ',', 0, 255 ) : '';
	}

	/** 2.0.0: numery zleceń dla kart zapisanych wcześniej (jednorazowo). */
	public static function fill_zlecenia() {
		global $wpdb;
		if ( get_option( 'msm_kz_zlec_filled' ) ) {
			return;
		}
		foreach ( (array) $wpdb->get_results( 'SELECT id, dane FROM `' . self::T() . '`', ARRAY_A ) as $r ) { // phpcs:ignore
			$d = json_decode( (string) $r['dane'], true );
			$wpdb->update( self::T(), array( 'zlecenia' => self::zlec_key( (array) ( $d['programy'] ?? array() ) ) ), array( 'id' => (int) $r['id'] ) );
		}
		update_option( 'msm_kz_zlec_filled', 1 );
	}

	/* ---------------- dostęp ---------------- */

	/**
	 * Liczba kart zmian na numer zlecenia (do licznika na zakładce zlecenia).
	 *
	 * @param string[] $nrs Numery zleceń (np. B02516).
	 * @return array<string,int> NUMER => liczba kart.
	 */
	public static function counts( array $nrs ) {
		global $wpdb;
		$want = array();
		foreach ( $nrs as $n ) {
			$n = strtoupper( trim( (string) $n ) );
			if ( '' !== $n ) {
				$want[ $n ] = 0;
			}
		}
		if ( ! $want || $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', self::T() ) ) !== self::T() ) {
			return array();
		}
		foreach ( (array) $wpdb->get_col( "SELECT zlecenia FROM `" . self::T() . "` WHERE zlecenia <> ''" ) as $z ) { // phpcs:ignore
			foreach ( array_unique( array_filter( explode( ',', strtoupper( (string) $z ) ) ) ) as $n ) {
				if ( isset( $want[ $n ] ) ) {
					++$want[ $n ];
				}
			}
		}
		return array_filter( $want );
	}

	/**
	 * Pulpit: ostatnio dodane karty zmian – zlecenia z ich detalami dobrymi.
	 *
	 * @param int $n Ile kart.
	 * @return array{n:int,lista:array}
	 */
	public static function tablica( $n = 6 ) {
		global $wpdb;
		if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', self::T() ) ) !== self::T() ) {
			return array( 'n' => 0, 'lista' => array() );
		}
		$rows  = (array) $wpdb->get_results( $wpdb->prepare( 'SELECT id, data, linia, zmiana, wypelnil, dane, created_at FROM `' . self::T() . '` ORDER BY created_at DESC, id DESC LIMIT %d', max( 1, (int) $n ) ), ARRAY_A ); // phpcs:ignore
		$lista = array();
		foreach ( $rows as $r ) {
			$d   = json_decode( (string) $r['dane'], true );
			$zl  = array(); // numer zlecenia => detale dobre (programy tego samego zlecenia sumowane)
			foreach ( (array) ( $d['programy'] ?? array() ) as $p ) {
				if ( ! is_array( $p ) || ( '' === (string) ( $p['nazwa'] ?? '' ) && '' === (string) ( $p['dobre'] ?? '' ) ) ) {
					continue;
				}
				$z        = self::zlec_of( $p['nazwa'] ?? '' );
				$z        = '' !== $z ? $z : '—';
				$zl[ $z ] = ( $zl[ $z ] ?? 0 ) + (float) ( is_numeric( $p['dobre'] ?? '' ) ? $p['dobre'] : 0 );
			}
			$lista[] = array(
				'id'        => (int) $r['id'],
				'data'      => (string) $r['data'],
				'linia'     => (string) $r['linia'],
				'zmiana'    => (int) $r['zmiana'],
				'wypelnil'  => (string) $r['wypelnil'],
				'created_at' => (string) $r['created_at'],
				'zlecenia'  => array_map( function ( $k, $v ) { return array( 'nr' => (string) $k, 'dobre' => $v ); }, array_keys( $zl ), array_values( $zl ) ),
			);
		}
		return array( 'n' => (int) $wpdb->get_var( 'SELECT COUNT(*) FROM `' . self::T() . '`' ), 'lista' => $lista ); // phpcs:ignore
	}

	public static function can_view() {
		return is_user_logged_in() && ( MSM_Perms::menu_on( 'prod_karty' ) || true === MSM_Settings::can_manage() );
	}

	private static function is_admin() {
		return current_user_can( 'msm_edit' ) || true === MSM_Settings::can_manage();
	}

	public static function can_change( array $k ) {
		return self::is_admin() || (int) $k['created_by'] === get_current_user_id();
	}

	public static function routes() {
		$ns = MSM_Rest::NS;
		$p  = function () { return self::can_view() ? true : new WP_Error( 'msm_forbidden', 'Karty zmian są dla Ciebie wyłączone.', array( 'status' => 403 ) ); };
		register_rest_route( $ns, '/karty-zmian', array(
			array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'list_r' ), 'permission_callback' => $p ),
			array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'save_r' ), 'permission_callback' => $p ),
		) );
		register_rest_route( $ns, '/karty-zmian/import', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'import_r' ), 'permission_callback' => $p ) );
		register_rest_route( $ns, '/karty-zmian/(?P<id>\d+)', array(
			array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'get_r' ), 'permission_callback' => $p ),
			array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'save_r' ), 'permission_callback' => $p ),
		) );
		register_rest_route( $ns, '/karty-zmian/(?P<id>\d+)/delete', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'delete_r' ), 'permission_callback' => $p ) );
		register_rest_route( $ns, '/karty-zmian/(?P<id>\d+)/xlsx', array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'xlsx_r' ), 'permission_callback' => $p ) );
	}

	/* ---------------- dane ---------------- */

	public static function get( $id ) {
		global $wpdb;
		$r = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM `' . self::T() . '` WHERE id = %d', (int) $id ), ARRAY_A ); // phpcs:ignore
		return $r ? $r : null;
	}

	private static function name( $uid ) {
		$u = $uid ? get_userdata( (int) $uid ) : null;
		return $u ? $u->display_name : '';
	}

	public static function cast( array $r, $full = true ) {
		$d    = json_decode( (string) $r['dane'], true );
		$d    = is_array( $d ) ? $d : array();
		$prog = array_values( array_filter( (array) ( $d['programy'] ?? array() ), 'is_array' ) );
		$sum  = array( 'zadana' => 0, 'dobre' => 0, 'zle' => 0, 'arkusze' => 0 );
		foreach ( $prog as $pr ) {
			foreach ( $sum as $k => $v ) {
				$sum[ $k ] += is_numeric( $pr[ $k ] ?? null ) ? (float) $pr[ $k ] : 0;
			}
		}
		$out = array(
			'id'        => (int) $r['id'],
			'data'      => (string) $r['data'],
			'linia'     => (string) $r['linia'],
			'zmiana'    => (int) $r['zmiana'],
			'wypelnil'  => (string) $r['wypelnil'],
			'godzina'   => (string) ( $d['godzina'] ?? '' ),
			'programy_n' => count( $prog ),
			'programy_nazwy' => array_values( array_filter( array_map( function ( $p ) { return (string) ( $p['nazwa'] ?? '' ); }, $prog ) ) ),
			'suma'      => $sum,
			'prog_lista' => array_map( function ( $p ) { // do listy: wynik każdego programu osobno
				return array(
					'nazwa' => (string) ( $p['nazwa'] ?? '' ),
					'zlec'  => self::zlec_of( $p['nazwa'] ?? '' ),
					'dobre' => $p['dobre'] ?? '',
					'zle'   => $p['zle'] ?? '',
				);
			}, $prog ),
			'autor'     => self::name( $r['created_by'] ),
			'created_at' => (string) $r['created_at'],
			'zmienil'   => $r['updated_by'] ? self::name( $r['updated_by'] ) : '',
			'updated_at' => (string) $r['updated_at'],
			'moje'      => self::can_change( $r ),
			'plik'      => self::file_name( $r ),
		);
		if ( $full ) {
			foreach ( array_keys( self::HEAD_ROWS ) as $k ) {
				if ( ! isset( $out[ $k ] ) ) {
					$out[ $k ] = (string) ( $d[ $k ] ?? '' );
				}
			}
			$out['programy'] = $prog;
		}
		return $out;
	}

	/** Nazwa pliku jak u Was: 2026.11.14_L2_zm1.xlsx */
	public static function file_name( array $r ) {
		return str_replace( '-', '.', (string) $r['data'] ) . '_' . $r['linia'] . '_zm' . (int) $r['zmiana'] . '.xlsx';
	}

	public static function list_r( WP_REST_Request $r ) {
		global $wpdb;
		$T     = self::T();
		$where = '1=1';
		$args  = array();
		$mies  = (string) $r->get_param( 'miesiac' ); // RRRR-MM
		if ( preg_match( '/^\d{4}-\d{2}$/', $mies ) ) {
			$where .= ' AND data BETWEEN %s AND %s';
			$args[] = $mies . '-01';
			$args[] = gmdate( 'Y-m-t', strtotime( $mies . '-01' ) );
		}
		$zlec = strtoupper( trim( (string) $r->get_param( 'zlec' ) ) );
		if ( '' !== $zlec ) {
			$where .= ' AND zlecenia LIKE %s';
			$args[] = '%,' . $wpdb->esc_like( $zlec ) . ',%';
		}
		if ( in_array( $r->get_param( 'linia' ), self::LINIE, true ) ) {
			$where .= ' AND linia = %s';
			$args[] = $r->get_param( 'linia' );
		}
		$sql  = "SELECT * FROM `$T` WHERE $where ORDER BY data DESC, zmiana DESC, id DESC LIMIT 500";
		$rows = (array) $wpdb->get_results( $args ? $wpdb->prepare( $sql, $args ) : $sql, ARRAY_A ); // phpcs:ignore
		$mies_list = (array) $wpdb->get_col( "SELECT DISTINCT DATE_FORMAT(data, '%Y-%m') m FROM `$T` ORDER BY m DESC" ); // phpcs:ignore
		return rest_ensure_response( array(
			'karty'      => array_map( function ( $x ) use ( $zlec ) {
				$o = self::cast( $x, false );
				if ( '' !== $zlec ) { // programy tego zlecenia (do zakładki zlecenia w Produkcji)
					$d          = json_decode( (string) $x['dane'], true );
					$o['progs'] = array_values( array_filter( (array) ( $d['programy'] ?? array() ), function ( $p ) use ( $zlec ) { return self::zlec_of( $p['nazwa'] ?? '' ) === $zlec; } ) );
				}
				return $o;
			}, $rows ),
			'miesiace'   => $mies_list,
			'pracownicy' => self::pracownicy(),
			'linie'      => self::LINIE,
		) );
	}

	public static function get_r( WP_REST_Request $r ) {
		$k = self::get( (int) $r['id'] );
		if ( ! $k ) {
			return new WP_Error( 'msm_404', 'Karta zmiany nie istnieje (mogła zostać usunięta).', array( 'status' => 404 ) );
		}
		return rest_ensure_response( array( 'karta' => self::cast( $k ), 'pracownicy' => self::pracownicy(), 'linie' => self::LINIE ) );
	}

	public static function pracownicy() {
		return array_values( array_filter( array_map( 'trim', (array) MSM_Settings::get( 'pracownicy_zmian' ) ), 'strlen' ) );
	}

	/** Liczba z pola („768”, „16*48”, „1 250,5”) – proste działania jak w Excelu. */
	public static function num( $v ) {
		$s = str_replace( array( ' ', "\xc2\xa0", ',', 'x', 'X', '×' ), array( '', '', '.', '*', '*', '*' ), trim( (string) $v ) );
		if ( '' === $s ) {
			return '';
		}
		if ( is_numeric( $s ) ) {
			return $s + 0;
		}
		if ( preg_match( '/^\d+(\.\d+)?([*+\-]\d+(\.\d+)?){1,6}$/', $s ) ) {
			preg_match_all( '/([*+\-]?)(\d+(?:\.\d+)?)/', $s, $m, PREG_SET_ORDER );
			$terms = array();
			foreach ( $m as $i => $t ) {
				$n = (float) $t[2];
				if ( '*' === $t[1] ) {
					$terms[ count( $terms ) - 1 ] *= $n;
				} else {
					$terms[] = '-' === $t[1] ? -$n : $n;
				}
			}
			return array_sum( $terms );
		}
		return null; // niepoprawne
	}

	private static function clean( array $p ) {
		$t   = function ( $v, $len = 200 ) { return mb_substr( trim( sanitize_text_field( (string) $v ) ), 0, $len ); };
		$ta  = function ( $v ) { return mb_substr( trim( sanitize_textarea_field( (string) $v ) ), 0, 2000 ); };
		$tn  = function ( $v ) { $v = trim( (string) $v ); return in_array( $v, self::TAKNIE, true ) ? $v : ''; };
		$err = array();
		$d   = array();
		$d['data'] = preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) ( $p['data'] ?? '' ) ) ? $p['data'] : '';
		if ( ! $d['data'] ) {
			$err['data'] = 'Podaj datę';
		}
		$d['linia'] = in_array( $p['linia'] ?? '', self::LINIE, true ) ? $p['linia'] : '';
		if ( ! $d['linia'] ) {
			$err['linia'] = 'Wybierz linię';
		}
		$d['zmiana'] = in_array( (int) ( $p['zmiana'] ?? 0 ), array( 1, 2, 3 ), true ) ? (int) $p['zmiana'] : 0;
		if ( ! $d['zmiana'] ) {
			$err['zmiana'] = 'Wybierz zmianę';
		}
		$d['godzina'] = preg_match( '/^([01]\d|2[0-3]):[0-5]\d$/', (string) ( $p['godzina'] ?? '' ) ) ? $p['godzina'] : '';
		foreach ( array( 'wypelnil', 'operator1', 'operator2', 'pomocnik1', 'pomocnik2', 'pomocnik3' ) as $k ) {
			$d[ $k ] = $t( $p[ $k ] ?? '', 120 );
		}
		if ( '' === $d['wypelnil'] ) {
			$err['wypelnil'] = 'Kto wypełnia kartę?';
		}
		$d['porzadek']    = $tn( $p['porzadek'] ?? '' );
		$d['przyrzady']   = $tn( $p['przyrzady'] ?? '' );
		$d['problemy']    = $ta( $p['problemy'] ?? '' );
		$d['uwagi_poprz'] = $ta( $p['uwagi_poprz'] ?? '' );
		$d['programy']    = array();
		foreach ( array_slice( array_values( (array) ( $p['programy'] ?? array() ) ), 0, self::MAX_PROG ) as $i => $pr ) {
			if ( ! is_array( $pr ) ) {
				continue;
			}
			$o = array();
			foreach ( self::prog_fields() as $k => $f ) {
				$v = $pr[ $k ] ?? '';
				if ( 'num' === $f[2] ) {
					$n = self::num( $v );
					if ( null === $n ) {
						$err[ 'programy.' . $i . '.' . $k ] = 'Wpisz liczbę';
						$n = '';
					}
					$o[ $k ] = $n;
				} elseif ( 'taknie' === $f[2] ) {
					$o[ $k ] = $tn( $v );
				} elseif ( 'mix' === $f[2] ) {
					$o[ $k ] = $t( $v, 60 );
				} else {
					$o[ $k ] = in_array( $k, array( 'wyjasnienie', 'uwagi' ), true ) ? $ta( $v ) : $t( $v );
				}
			}
			if ( implode( '', array_map( 'strval', $o ) ) !== '' ) {
				$d['programy'][] = $o;
			}
		}
		return $err ? new WP_Error( 'msm_400', 'Uzupełnij zaznaczone pola.', array( 'status' => 400, 'fields' => $err ) ) : $d;
	}

	public static function save_r( WP_REST_Request $r ) {
		global $wpdb;
		$id  = (int) $r['id'];
		$old = $id ? self::get( $id ) : null;
		if ( $id && ! $old ) {
			return new WP_Error( 'msm_404', 'Karta zmiany nie istnieje.', array( 'status' => 404 ) );
		}
		if ( $old && ! self::can_change( $old ) ) {
			return new WP_Error( 'msm_forbidden', 'Kartę może poprawić tylko jej autor albo administrator.', array( 'status' => 403 ) );
		}
		$d = self::clean( (array) $r->get_json_params() );
		if ( is_wp_error( $d ) ) {
			return $d;
		}
		$row = array(
			'data'     => $d['data'],
			'linia'    => $d['linia'],
			'zmiana'   => $d['zmiana'],
			'wypelnil' => $d['wypelnil'],
			'zlecenia' => self::zlec_key( $d['programy'] ),
			'dane'     => wp_json_encode( $d, JSON_UNESCAPED_UNICODE ),
		);
		if ( $old ) {
			$row['updated_by'] = get_current_user_id();
			$row['updated_at'] = current_time( 'mysql' );
			$wpdb->update( self::T(), $row, array( 'id' => $id ) );
		} else {
			$row['created_by'] = get_current_user_id();
			$row['created_at'] = current_time( 'mysql' );
			$wpdb->insert( self::T(), $row );
			$id = (int) $wpdb->insert_id;
		}
		$k = self::get( $id );
		MSM_Repo::log( 'Produkcja: karta zmiany', 'karty_zmian', $id, ( $old ? 'Poprawiono' : 'Dodano' ) . ' kartę zmiany ' . self::label( $k ) . ' (' . count( $d['programy'] ) . ' progr.)' );
		$dup = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM `' . self::T() . '` WHERE data = %s AND linia = %s AND zmiana = %d AND id <> %d', $k['data'], $k['linia'], $k['zmiana'], $id ) ); // phpcs:ignore
		return rest_ensure_response( array( 'karta' => self::cast( $k ), 'duplikat' => $dup ) );
	}

	public static function label( array $k ) {
		return mysql2date( 'd.m.Y', $k['data'] ) . ' ' . $k['linia'] . ' zm. ' . (int) $k['zmiana'];
	}

	public static function delete_r( WP_REST_Request $r ) {
		global $wpdb;
		$k = self::get( (int) $r['id'] );
		if ( ! $k ) {
			return rest_ensure_response( array( 'ok' => true ) );
		}
		if ( ! self::can_change( $k ) ) {
			return new WP_Error( 'msm_forbidden', 'Kartę może usunąć tylko jej autor albo administrator.', array( 'status' => 403 ) );
		}
		$wpdb->delete( self::T(), array( 'id' => (int) $k['id'] ) );
		MSM_Repo::log( 'Produkcja: karta zmiany', 'karty_zmian', (int) $k['id'], 'Usunięto kartę zmiany ' . self::label( $k ) . ' (wypełnił: ' . $k['wypelnil'] . ')' );
		return rest_ensure_response( array( 'ok' => true ) );
	}

	/* ---------------- import z Excela (ten sam wzór) ---------------- */

	/**
	 * Podgląd importu: odczyt wgranych arkuszy (karta zmiany w układzie wzoru) → dane kart do zapisu.
	 * Zapis robi przeglądarka zwykłym POST /karty-zmian (te same zasady i walidacja co w formularzu).
	 */
	public static function import_r( WP_REST_Request $r ) {
		global $wpdb;
		if ( ! class_exists( 'ZipArchive' ) || ! class_exists( 'DOMDocument' ) ) {
			return new WP_Error( 'msm_500', 'Serwer nie ma rozszerzeń PHP „zip” / „xml” – import z Excela jest niemożliwy.', array( 'status' => 500 ) );
		}
		$files = $r->get_file_params();
		$f     = $files['pliki'] ?? null;
		if ( ! $f || empty( $f['name'] ) ) {
			return new WP_Error( 'msm_400', 'Wybierz pliki Excela (.xlsx) z kartami zmian.', array( 'status' => 400 ) );
		}
		$list = array();
		foreach ( (array) $f['name'] as $i => $name ) {
			$list[] = array( 'name' => (string) $name, 'tmp' => is_array( $f['tmp_name'] ) ? $f['tmp_name'][ $i ] : $f['tmp_name'], 'size' => (int) ( is_array( $f['size'] ) ? $f['size'][ $i ] : $f['size'] ), 'err' => (int) ( is_array( $f['error'] ) ? $f['error'][ $i ] : $f['error'] ) );
		}
		$out = array();
		foreach ( array_slice( $list, 0, 62 ) as $x ) {
			$row = array( 'plik' => sanitize_file_name( $x['name'] ), 'blad' => '', 'karta' => null, 'duplikat' => 0 );
			if ( $x['err'] || ! is_uploaded_file( $x['tmp'] ) ) {
				$row['blad'] = 'Nie udało się wgrać pliku.';
			} elseif ( ! preg_match( '/\.xlsx$/i', $x['name'] ) ) {
				$row['blad'] = 'To nie jest plik .xlsx (stary format .xls zapisz w Excelu jako .xlsx).';
			} elseif ( $x['size'] > 10 * 1024 * 1024 ) {
				$row['blad'] = 'Plik jest za duży (ponad 10 MB).';
			} else {
				$k = self::read_xlsx( $x['tmp'], $x['name'] );
				if ( is_wp_error( $k ) ) {
					$row['blad'] = $k->get_error_message();
				} else {
					$row['karta'] = $k;
					if ( $k['data'] && $k['linia'] && $k['zmiana'] ) {
						$row['duplikat'] = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM `' . self::T() . '` WHERE data = %s AND linia = %s AND zmiana = %d ORDER BY id LIMIT 1', $k['data'], $k['linia'], $k['zmiana'] ) ); // phpcs:ignore
					}
				}
			}
			$out[] = $row;
		}
		return rest_ensure_response( array( 'pliki' => $out, 'linie' => self::LINIE ) );
	}

	/** Wartości kolumny C (wiersz => tekst/liczba) z arkusza „karta zmiany”. */
	public static function read_cells( $path ) {
		$z = new ZipArchive();
		if ( true !== $z->open( $path ) ) {
			return new WP_Error( 'msm_400', 'Plik nie jest poprawnym arkuszem Excela (.xlsx).' );
		}
		// Ochrona przed „bombą zip”: suma rozmiarów po rozpakowaniu – najwyżej 30 MB (karta zmiany ma kilkadziesiąt kB).
		$total = 0;
		for ( $i = 0; $i < $z->numFiles; $i++ ) {
			$st     = $z->statIndex( $i );
			$total += $st ? (int) $st['size'] : 0;
		}
		if ( $total > 30 * MB_IN_BYTES || $z->numFiles > 500 ) {
			$z->close();
			return new WP_Error( 'msm_400', 'Plik po rozpakowaniu jest za duży jak na kartę zmiany.' );
		}
		$NS   = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main';
		$load = function ( $xml ) {
			if ( false === $xml || '' === $xml ) {
				return null;
			}
			$d = new DOMDocument();
			return @$d->loadXML( $xml, LIBXML_NONET ) ? $d : null; // phpcs:ignore
		};
		// Arkusz „karta zmiany” (albo pierwszy) – przez workbook.xml i jego relacje.
		$sheet = 'xl/worksheets/sheet1.xml';
		$wb    = $load( $z->getFromName( 'xl/workbook.xml' ) );
		$rels  = $load( $z->getFromName( 'xl/_rels/workbook.xml.rels' ) );
		if ( $wb && $rels ) {
			$rid = '';
			foreach ( $wb->getElementsByTagNameNS( $NS, 'sheet' ) as $s ) {
				$id = $s->getAttributeNS( 'http://schemas.openxmlformats.org/officeDocument/2006/relationships', 'id' );
				if ( '' === $rid ) {
					$rid = $id; // domyślnie pierwszy arkusz
				}
				if ( false !== mb_stripos( $s->getAttribute( 'name' ), 'karta' ) ) {
					$rid = $id;
					break;
				}
			}
			foreach ( $rels->getElementsByTagName( 'Relationship' ) as $rel ) {
				if ( $rel->getAttribute( 'Id' ) === $rid ) {
					$t     = ltrim( $rel->getAttribute( 'Target' ), '/' );
					$sheet = 0 === strpos( $t, 'xl/' ) ? $t : 'xl/' . $t;
				}
			}
		}
		$ss  = array();
		$sst = $load( $z->getFromName( 'xl/sharedStrings.xml' ) );
		if ( $sst ) {
			foreach ( $sst->getElementsByTagNameNS( $NS, 'si' ) as $si ) {
				$t = '';
				foreach ( $si->getElementsByTagNameNS( $NS, 't' ) as $tt ) {
					$t .= $tt->textContent;
				}
				$ss[] = $t;
			}
		}
		$doc = $load( $z->getFromName( $sheet ) );
		$z->close();
		if ( ! $doc ) {
			return new WP_Error( 'msm_400', 'W pliku nie ma arkusza karty zmiany.' );
		}
		$out = array( 'B' => array(), 'C' => array() );
		foreach ( $doc->getElementsByTagNameNS( $NS, 'c' ) as $c ) {
			if ( ! preg_match( '/^([BC])(\d+)$/', $c->getAttribute( 'r' ), $m ) || (int) $m[2] > 200 ) {
				continue;
			}
			$t = $c->getAttribute( 't' );
			$v = $c->getElementsByTagNameNS( $NS, 'v' )->item( 0 );
			if ( 'inlineStr' === $t ) {
				$val = '';
				foreach ( $c->getElementsByTagNameNS( $NS, 't' ) as $tt ) {
					$val .= $tt->textContent;
				}
			} elseif ( ! $v ) {
				continue;
			} elseif ( 's' === $t ) {
				$val = $ss[ (int) $v->textContent ] ?? '';
			} elseif ( 'str' === $t || 'e' === $t ) {
				$val = (string) $v->textContent;
			} elseif ( 'b' === $t ) {
				$val = '1' === $v->textContent ? 'TAK' : 'NIE';
			} else {
				$val = 0 + $v->textContent; // liczba (także data/godzina zapisana jako liczba)
			}
			$out[ $m[1] ][ (int) $m[2] ] = is_string( $val ) ? trim( $val ) : $val;
		}
		return $out;
	}

	/** Arkusz → dane karty (jak z formularza). Linia, data i zmiana mogą pochodzić z nazwy pliku. */
	public static function read_xlsx( $path, $file_name = '' ) {
		$cells = self::read_cells( $path );
		if ( is_wp_error( $cells ) ) {
			return $cells;
		}
		$B = $cells['B'];
		$C = $cells['C'];
		// Kontrola układu: etykiety z kolumny B jak we wzorze.
		$lbl = function ( $row ) use ( $B ) { return mb_strtolower( trim( (string) ( $B[ $row ] ?? '' ) ) ); };
		if ( 0 !== strpos( $lbl( 5 ), 'wype' ) || 0 !== strpos( $lbl( 6 ), 'data' ) || false === strpos( $lbl( self::PROG_ROW ), 'nazwa programu' ) ) {
			return new WP_Error( 'msm_400', 'Układ arkusza nie pasuje do karty zmiany (oczekiwane: Wypełnił w B5, Data w B6, NAZWA PROGRAMU w B19).' );
		}
		$fn = array( 'data' => '', 'linia' => '', 'zmiana' => 0 );
		if ( preg_match( '/(\d{4})[.\-_](\d{2})[.\-_](\d{2})/', $file_name, $m ) ) {
			$fn['data'] = $m[1] . '-' . $m[2] . '-' . $m[3];
		}
		if ( preg_match( '/(?:^|[_\s\-.])(L\d)(?=[_\s\-.]|$)/i', $file_name, $m ) && in_array( strtoupper( $m[1] ), self::LINIE, true ) ) {
			$fn['linia'] = strtoupper( $m[1] );
		}
		if ( preg_match( '/zm\.?\s*([123])/i', $file_name, $m ) ) {
			$fn['zmiana'] = (int) $m[1];
		}
		$k = array();
		foreach ( self::HEAD_ROWS as $key => $row ) {
			$k[ $key ] = $C[ $row ] ?? '';
		}
		$k['data']    = self::cell_date( $k['data'] ) ?: $fn['data'];
		$k['zmiana']  = in_array( (int) $k['zmiana'], array( 1, 2, 3 ), true ) ? (int) $k['zmiana'] : $fn['zmiana'];
		$k['godzina'] = self::cell_time( $k['godzina'] );
		$k['linia']   = $fn['linia'];
		foreach ( array( 'wypelnil', 'operator1', 'operator2', 'pomocnik1', 'pomocnik2', 'pomocnik3', 'problemy', 'uwagi_poprz' ) as $key ) {
			$k[ $key ] = trim( preg_replace( '/[ \t]+/', ' ', (string) $k[ $key ] ) );
		}
		$k['porzadek']  = self::cell_taknie( $k['porzadek'] );
		$k['przyrzady'] = self::cell_taknie( $k['przyrzady'] );
		$k['programy']  = array();
		for ( $i = 0; $i < self::MAX_PROG; $i++ ) {
			$base = self::PROG_ROW + $i * self::PROG_STEP;
			$p    = array();
			foreach ( self::prog_fields() as $key => $f ) {
				$v = $C[ $base + $f[1] ] ?? '';
				if ( 'num' === $f[2] ) {
					$v = is_numeric( $v ) ? 0 + $v : ( '' === $v ? '' : ( null === self::num( $v ) ? (string) $v : self::num( $v ) ) );
				} elseif ( 'taknie' === $f[2] ) {
					$v = self::cell_taknie( $v );
				} else {
					$v = trim( is_float( $v ) ? rtrim( rtrim( sprintf( '%.6F', $v ), '0' ), '.' ) : (string) $v );
				}
				$p[ $key ] = $v;
			}
			if ( '' !== implode( '', array_map( 'strval', $p ) ) ) {
				$k['programy'][] = $p;
			}
		}
		return $k;
	}

	/** Data z komórki: tekst „14.11.2026”, „2026-11-14”, „2026/11/14” albo liczba (data Excela). */
	private static function cell_date( $v ) {
		if ( is_int( $v ) || is_float( $v ) ) {
			return $v > 20000 && $v < 80000 ? gmdate( 'Y-m-d', (int) round( ( $v - 25569 ) * 86400 ) ) : '';
		}
		$v = trim( (string) $v );
		if ( preg_match( '/^(\d{1,2})[.\/\-](\d{1,2})[.\/\-](\d{4})/', $v, $m ) ) {
			return checkdate( (int) $m[2], (int) $m[1], (int) $m[3] ) ? sprintf( '%04d-%02d-%02d', $m[3], $m[2], $m[1] ) : '';
		}
		if ( preg_match( '/^(\d{4})[.\/\-](\d{1,2})[.\/\-](\d{1,2})/', $v, $m ) ) {
			return checkdate( (int) $m[2], (int) $m[3], (int) $m[1] ) ? sprintf( '%04d-%02d-%02d', $m[1], $m[2], $m[3] ) : '';
		}
		return '';
	}

	/** Godzina: ułamek doby (format h:mm) albo tekst „13:48”. */
	private static function cell_time( $v ) {
		if ( is_int( $v ) || is_float( $v ) ) {
			$min = (int) round( fmod( (float) $v, 1 ) * 1440 ) % 1440;
			return sprintf( '%02d:%02d', intdiv( $min, 60 ), $min % 60 );
		}
		return preg_match( '/^(\d{1,2})[:.](\d{2})/', trim( (string) $v ), $m ) && (int) $m[1] < 24 && (int) $m[2] < 60 ? sprintf( '%02d:%02d', $m[1], $m[2] ) : '';
	}

	private static function cell_taknie( $v ) {
		$f = mb_strtolower( trim( (string) $v ) );
		if ( in_array( $f, array( 'tak', 't', 'yes', '1' ), true ) ) {
			return 'TAK';
		}
		if ( in_array( $f, array( 'nie', 'n', 'no', '0' ), true ) ) {
			return 'NIE';
		}
		return 0 === strpos( $f, 'nie dot' ) ? 'nie dotyczy' : '';
	}

	/* ---------------- eksport do Excela (wzór firmy) ---------------- */

	public static function xlsx_r( WP_REST_Request $r ) {
		$k = self::get( (int) $r['id'] );
		if ( ! $k ) {
			return new WP_Error( 'msm_404', 'Karta zmiany nie istnieje.', array( 'status' => 404 ) );
		}
		try {
			$bin = self::xlsx( self::cast( $k ) );
		} catch ( Throwable $e ) {
			$bin = new WP_Error( 'msm_500', 'Nie udało się przygotować arkusza: ' . $e->getMessage(), array( 'status' => 500 ) );
		}
		if ( is_wp_error( $bin ) ) {
			return $bin;
		}
		nocache_headers();
		header( 'Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' );
		header( 'Content-Disposition: attachment; filename="' . self::file_name( $k ) . '"' );
		header( 'Content-Length: ' . strlen( $bin ) );
		echo $bin; // phpcs:ignore
		exit;
	}

	/** Wartości komórek C<wiersz> dla karty. */
	public static function cells( array $k ) {
		$c = array();
		foreach ( self::HEAD_ROWS as $key => $row ) {
			$v = $k[ $key ] ?? '';
			if ( 'data' === $key ) {
				$v = $v ? mysql2date( 'd.m.Y', $v ) : ''; // jak we wzorze: tekst 14.11.2026
			} elseif ( 'zmiana' === $key ) {
				$v = (int) $v;
			} elseif ( 'godzina' === $key && preg_match( '/^(\d{2}):(\d{2})$/', (string) $v, $m ) ) {
				$v = array( 'n' => ( (int) $m[1] * 60 + (int) $m[2] ) / 1440 ); // ułamek doby (format h:mm)
			}
			$c[ $row ] = $v;
		}
		foreach ( array_slice( (array) ( $k['programy'] ?? array() ), 0, self::MAX_PROG ) as $i => $p ) {
			$base = self::PROG_ROW + $i * self::PROG_STEP;
			foreach ( self::prog_fields() as $key => $f ) {
				$v = $p[ $key ] ?? '';
				if ( ( 'num' === $f[2] || 'mix' === $f[2] ) && '' !== $v && is_numeric( str_replace( ',', '.', (string) $v ) ) ) {
					$v = array( 'n' => (float) str_replace( ',', '.', (string) $v ) );
				}
				$c[ $base + $f[1] ] = $v;
			}
		}
		return $c;
	}

	/** Wypełnia wzór i zwraca zawartość pliku .xlsx (albo WP_Error). */
	public static function xlsx( array $k ) {
		if ( ! class_exists( 'ZipArchive' ) ) {
			return new WP_Error( 'msm_500', 'Serwer nie ma rozszerzenia PHP „zip” – eksport do Excela jest niemożliwy.', array( 'status' => 500 ) );
		}
		if ( ! class_exists( 'DOMDocument' ) ) {
			return new WP_Error( 'msm_500', 'Serwer nie ma rozszerzenia PHP „xml” (DOM) – eksport do Excela jest niemożliwy.', array( 'status' => 500 ) );
		}
		if ( ! function_exists( 'wp_tempnam' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php'; // w zapytaniach REST nie jest wczytany
		}
		$tpl = MSM_DIR . 'data/karta-zmiany.xlsx';
		if ( ! is_readable( $tpl ) ) {
			return new WP_Error( 'msm_500', 'Brak wzoru karty zmiany (data/karta-zmiany.xlsx) – wgraj wtyczkę ponownie.', array( 'status' => 500 ) );
		}
		$tmp = wp_tempnam( 'karta-zmiany.xlsx' );
		if ( ! $tmp || ! copy( $tpl, $tmp ) ) {
			return new WP_Error( 'msm_500', 'Nie udało się przygotować pliku.', array( 'status' => 500 ) );
		}
		$z = new ZipArchive();
		if ( true !== $z->open( $tmp ) ) {
			wp_delete_file( $tmp );
			return new WP_Error( 'msm_500', 'Nie udało się otworzyć wzoru karty.', array( 'status' => 500 ) );
		}
		// Arkusz 1: wartości w kolumnie C.
		$s1 = self::fill_sheet( $z->getFromName( 'xl/worksheets/sheet1.xml' ), 'C', self::cells( $k ) );
		// Lista pracowników (lista wyboru w Excelu) – aktualna z Ustawień.
		$names = self::pracownicy();
		$last  = max( 24, count( $names ) + 1 );
		$s1    = str_replace( "'zakładka techniczna'!\$A\$2:\$A\$24", "'zakładka techniczna'!\$A\$2:\$A\$" . $last, $s1 );
		$col   = array();
		for ( $i = 2; $i <= $last; $i++ ) {
			$col[ $i ] = $names[ $i - 2 ] ?? '';
		}
		$s2 = self::fill_sheet( $z->getFromName( 'xl/worksheets/sheet2.xml' ), 'A', $col );
		$z->addFromString( 'xl/worksheets/sheet1.xml', $s1 );
		$z->addFromString( 'xl/worksheets/sheet2.xml', $s2 );
		$z->close();
		$bin = file_get_contents( $tmp ); // phpcs:ignore
		wp_delete_file( $tmp );
		return $bin;
	}

	/**
	 * Wpisuje wartości do komórek jednej kolumny, zachowując styl komórki (atrybut s).
	 * Tekst jako „inlineStr”, liczba jako <v>. Brakujące wiersze/komórki są dodawane we właściwej kolejności.
	 *
	 * @param array $vals wiersz => string | ['n' => liczba] | ''
	 */
	public static function fill_sheet( $xml, $col, array $vals ) {
		$NS  = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main';
		$doc = new DOMDocument();
		$doc->preserveWhiteSpace = true;
		$doc->loadXML( $xml );
		$xp = new DOMXPath( $doc );
		$xp->registerNamespace( 'm', $NS );
		$sd = $xp->query( '//m:sheetData' )->item( 0 );
		foreach ( $vals as $rn => $v ) {
			$rn  = (int) $rn;
			$row = $xp->query( "m:row[@r='$rn']", $sd )->item( 0 );
			if ( ! $row ) {
				if ( '' === $v || null === $v ) {
					continue;
				}
				$row = $doc->createElementNS( $NS, 'row' );
				$row->setAttribute( 'r', (string) $rn );
				$after = null;
				foreach ( $xp->query( 'm:row', $sd ) as $rr ) {
					if ( (int) $rr->getAttribute( 'r' ) > $rn ) {
						$after = $rr;
						break;
					}
				}
				$sd->insertBefore( $row, $after );
			}
			$ref  = $col . $rn;
			$cell = $xp->query( "m:c[@r='$ref']", $row )->item( 0 );
			if ( ! $cell ) {
				if ( '' === $v || null === $v ) {
					continue;
				}
				$cell = $doc->createElementNS( $NS, 'c' );
				$cell->setAttribute( 'r', $ref );
				$next = null;
				foreach ( $xp->query( 'm:c', $row ) as $cc ) {
					if ( strcmp( preg_replace( '/\d+/', '', $cc->getAttribute( 'r' ) ), $col ) > 0 ) {
						$next = $cc;
						break;
					}
				}
				$row->insertBefore( $cell, $next );
			}
			while ( $cell->firstChild ) {
				$cell->removeChild( $cell->firstChild );
			}
			$cell->removeAttribute( 't' );
			if ( is_array( $v ) && isset( $v['n'] ) ) {
				$cell->appendChild( $doc->createElementNS( $NS, 'v', (string) ( 0 + $v['n'] ) ) );
			} elseif ( is_int( $v ) || is_float( $v ) ) {
				$cell->appendChild( $doc->createElementNS( $NS, 'v', (string) $v ) );
			} elseif ( '' !== (string) $v ) {
				$cell->setAttribute( 't', 'inlineStr' );
				$is = $doc->createElementNS( $NS, 'is' );
				$t  = $doc->createElementNS( $NS, 't' );
				$t->setAttribute( 'xml:space', 'preserve' );
				$t->appendChild( $doc->createTextNode( (string) $v ) );
				$is->appendChild( $t );
				$cell->appendChild( $is );
			}
		}
		return $doc->saveXML();
	}
}
