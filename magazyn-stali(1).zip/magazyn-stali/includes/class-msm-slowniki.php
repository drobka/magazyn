<?php
/**
 * Słowniki dla WZ: odbiorcy, przeznaczenie, środek transportu (z wartością domyślną dla nowej WZ).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MSM_Slowniki {

	const TYPES = array(
		'odbiorca'      => 'Odbiorcy',
		'przeznaczenie' => 'Przeznaczenie',
		'transport'     => 'Środek transportu',
	);

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
	}

	public static function T() {
		global $wpdb;
		return $wpdb->prefix . 'msm_slowniki';
	}

	public static function create_table() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$T = self::T();
		dbDelta( "CREATE TABLE $T (
id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
typ varchar(30) NOT NULL,
nazwa varchar(255) NOT NULL,
domyslny tinyint(1) NOT NULL DEFAULT 0,
created_at datetime NULL,
PRIMARY KEY  (id),
KEY typ (typ)
) ENGINE=InnoDB " . $wpdb->get_charset_collate() . ';' );
	}

	/** Przy aktualizacji: przenosi do słowników wartości użyte już na WZ. */
	public static function seed_from_wz() {
		global $wpdb;
		$W = msm_table( 'wz' );
		if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $W ) ) !== $W ) {
			return;
		}
		foreach ( array_keys( self::TYPES ) as $typ ) {
			foreach ( $wpdb->get_col( "SELECT DISTINCT `$typ` FROM `$W` WHERE `$typ` IS NOT NULL AND `$typ` <> ''" ) as $v ) { // phpcs:ignore
				self::ensure( $typ, $v );
			}
		}
	}

	/** Dodaje wartość, jeśli jej jeszcze nie ma (bez rozróżniania wielkości liter). */
	public static function ensure( $typ, $nazwa ) {
		global $wpdb;
		$nazwa = trim( (string) $nazwa );
		if ( '' === $nazwa || ! isset( self::TYPES[ $typ ] ) ) {
			return 0;
		}
		$id = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM `' . self::T() . '` WHERE typ = %s AND LOWER(nazwa) = LOWER(%s)', $typ, $nazwa ) ); // phpcs:ignore
		if ( $id ) {
			return $id;
		}
		$wpdb->insert( self::T(), array( 'typ' => $typ, 'nazwa' => mb_substr( $nazwa, 0, 255 ), 'domyslny' => 0, 'created_at' => current_time( 'mysql' ) ) );
		return (int) $wpdb->insert_id;
	}

	public static function all() {
		global $wpdb;
		$W    = msm_table( 'wz' );
		$rows = $wpdb->get_results( 'SELECT * FROM `' . self::T() . '` ORDER BY domyslny DESC, nazwa ASC', ARRAY_A ); // phpcs:ignore
		$use  = array();
		foreach ( array_keys( self::TYPES ) as $typ ) {
			foreach ( $wpdb->get_results( "SELECT LOWER(`$typ`) v, COUNT(*) n FROM `$W` WHERE status <> 'anulowana' GROUP BY LOWER(`$typ`)", ARRAY_A ) as $u ) { // phpcs:ignore
				$use[ $typ ][ (string) $u['v'] ] = (int) $u['n'];
			}
		}
		$out = array_fill_keys( array_keys( self::TYPES ), array() );
		foreach ( $rows as $r ) {
			if ( ! isset( $out[ $r['typ'] ] ) ) {
				continue;
			}
			$out[ $r['typ'] ][] = array(
				'id'       => (int) $r['id'],
				'nazwa'    => $r['nazwa'],
				'domyslny' => (bool) $r['domyslny'],
				'uzyto'    => $use[ $r['typ'] ][ mb_strtolower( $r['nazwa'], 'UTF-8' ) ] ?? 0,
			);
		}
		return $out;
	}

	public static function defaults() {
		global $wpdb;
		$out = array_fill_keys( array_keys( self::TYPES ), '' );
		foreach ( $wpdb->get_results( 'SELECT typ, nazwa FROM `' . self::T() . '` WHERE domyslny = 1', ARRAY_A ) as $r ) { // phpcs:ignore
			$out[ $r['typ'] ] = $r['nazwa'];
		}
		return $out;
	}

	private static function set_default( $typ, $id ) {
		global $wpdb;
		$wpdb->query( $wpdb->prepare( 'UPDATE `' . self::T() . '` SET domyslny = IF(id = %d, 1, 0) WHERE typ = %s', $id, $typ ) ); // phpcs:ignore
	}

	public static function create( array $in ) {
		$typ   = (string) ( $in['typ'] ?? '' );
		$nazwa = trim( sanitize_text_field( wp_unslash( (string) ( $in['nazwa'] ?? '' ) ) ) );
		if ( ! isset( self::TYPES[ $typ ] ) ) {
			return new WP_Error( 'msm_invalid', 'Nieznany słownik.', array( 'status' => 400 ) );
		}
		if ( '' === $nazwa ) {
			return new WP_Error( 'msm_invalid', 'Podaj nazwę.', array( 'status' => 400, 'fields' => array( 'nazwa' => 'Podaj nazwę' ) ) );
		}
		global $wpdb;
		if ( $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM `' . self::T() . '` WHERE typ = %s AND LOWER(nazwa) = LOWER(%s)', $typ, $nazwa ) ) ) { // phpcs:ignore
			return new WP_Error( 'msm_invalid', 'Taka pozycja już jest na liście.', array( 'status' => 400, 'fields' => array( 'nazwa' => 'Już istnieje' ) ) );
		}
		$id = self::ensure( $typ, $nazwa );
		if ( ! current_user_can( 'msm_edit' ) ) {
			$in['domyslny'] = false; // domyślną pozycję ustawia tylko administrator magazynu
		}
		if ( ! empty( $in['domyslny'] ) ) {
			self::set_default( $typ, $id );
		}
		MSM_Repo::log( 'słownik: dodanie', 'wz', 0, self::TYPES[ $typ ] . ': „' . $nazwa . '”' . ( ! empty( $in['domyslny'] ) ? ' (domyślny)' : '' ) );
		return array( 'ok' => true, 'id' => $id, 'all' => self::all() );
	}

	public static function update( $id, array $in ) {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM `' . self::T() . '` WHERE id = %d', $id ), ARRAY_A ); // phpcs:ignore
		if ( ! $row ) {
			return new WP_Error( 'msm_not_found', 'Pozycja nie istnieje.', array( 'status' => 404 ) );
		}
		if ( array_key_exists( 'nazwa', $in ) ) {
			$nazwa = trim( sanitize_text_field( wp_unslash( (string) $in['nazwa'] ) ) );
			if ( '' === $nazwa ) {
				return new WP_Error( 'msm_invalid', 'Podaj nazwę.', array( 'status' => 400 ) );
			}
			$dup = $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM `' . self::T() . '` WHERE typ = %s AND LOWER(nazwa) = LOWER(%s) AND id <> %d', $row['typ'], $nazwa, $id ) ); // phpcs:ignore
			if ( $dup ) {
				return new WP_Error( 'msm_invalid', 'Taka pozycja już jest na liście.', array( 'status' => 400 ) );
			}
			$wpdb->update( self::T(), array( 'nazwa' => mb_substr( $nazwa, 0, 255 ) ), array( 'id' => $id ) );
			if ( $nazwa !== $row['nazwa'] ) {
				MSM_Repo::log( 'słownik: zmiana', 'wz', 0, self::TYPES[ $row['typ'] ] . ': „' . $row['nazwa'] . '” → „' . $nazwa . '”' );
			}
		}
		if ( array_key_exists( 'domyslny', $in ) ) {
			if ( $in['domyslny'] ) {
				self::set_default( $row['typ'], $id );
			} else {
				$wpdb->update( self::T(), array( 'domyslny' => 0 ), array( 'id' => $id ) );
			}
		}
		return array( 'ok' => true, 'all' => self::all() );
	}

	public static function delete( $id ) {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM `' . self::T() . '` WHERE id = %d', $id ), ARRAY_A ); // phpcs:ignore
		if ( ! $row ) {
			return new WP_Error( 'msm_not_found', 'Pozycja nie istnieje.', array( 'status' => 404 ) );
		}
		$wpdb->delete( self::T(), array( 'id' => $id ) );
		MSM_Repo::log( 'słownik: usunięcie', 'wz', 0, self::TYPES[ $row['typ'] ] . ': „' . $row['nazwa'] . '”' );
		return array( 'ok' => true, 'all' => self::all() );
	}

	/** Sekcja menu odpowiadająca słownikowi. */
	const SECTIONS = array( 'odbiorca' => 'wz_odbiorcy', 'przeznaczenie' => 'wz_przeznaczenie', 'transport' => 'wz_transport' );

	/** 1.84.0: dodawanie – osoba z włączoną zakładką danego słownika. */
	public static function can_add( WP_REST_Request $r ) {
		$v = MSM_Rest::can_view();
		if ( is_wp_error( $v ) ) {
			return $v;
		}
		$typ = (string) ( ( (array) $r->get_json_params() )['typ'] ?? '' );
		$sec = self::SECTIONS[ $typ ] ?? 'wz';
		return MSM_Perms::is_wp_admin() || MSM_Perms::menu_on( $sec ) ? true : new WP_Error( 'msm_forbidden', 'Ta lista jest dla Ciebie wyłączona.', array( 'status' => 403 ) );
	}

	/** 1.84.0: zmiana nazwy, domyślnej pozycji i usuwanie – tylko administrator magazynu. */
	public static function can_change() {
		return current_user_can( 'msm_edit' ) ? true : new WP_Error( 'msm_forbidden', 'Zmieniać i usuwać pozycje słowników może tylko administrator magazynu. Możesz dodać nową pozycję.', array( 'status' => 403 ) );
	}

	public static function routes() {
		$ns   = MSM_Rest::NS;
		$view = array( 'MSM_Rest', 'can_view' );
		$add  = array( __CLASS__, 'can_add' );
		$chg  = array( __CLASS__, 'can_change' );
		register_rest_route( $ns, '/slowniki', array(
			array( 'methods' => 'GET', 'permission_callback' => $view, 'callback' => function () { return rest_ensure_response( array( 'all' => MSM_Slowniki::all(), 'labels' => MSM_Slowniki::TYPES ) ); } ),
			array( 'methods' => 'POST', 'permission_callback' => $add, 'callback' => function ( WP_REST_Request $r ) { return rest_ensure_response( MSM_Slowniki::create( (array) $r->get_json_params() ) ); } ),
		) );
		register_rest_route( $ns, '/slowniki/(?P<id>\d+)', array(
			array( 'methods' => 'POST', 'permission_callback' => $chg, 'callback' => function ( WP_REST_Request $r ) { return rest_ensure_response( MSM_Slowniki::update( (int) $r['id'], (array) $r->get_json_params() ) ); } ),
			array( 'methods' => 'DELETE', 'permission_callback' => $chg, 'callback' => function ( WP_REST_Request $r ) { return rest_ensure_response( MSM_Slowniki::delete( (int) $r['id'] ) ); } ),
		) );
	}
}
