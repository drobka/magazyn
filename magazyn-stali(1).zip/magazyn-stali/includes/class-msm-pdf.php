<?php
/**
 * Prosty generator PDF (A4) bez zewnętrznych bibliotek – do dokumentów wysyłanych e-mailem (np. zamówienia do dostawców).
 * Czcionki standardowe Helvetica / Helvetica-Bold z kodowaniem Windows-1250 (polskie znaki), tekst, linie, prostokąty
 * i obraz JPEG (logo). Współrzędne w punktach, liczone od lewego górnego rogu strony.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MSM_Pdf {

	const W = 595.28;
	const H = 841.89;

	/** Szerokości znaków (1/1000 em) dla bajtów Windows-1250: n – zwykła, b – pogrubiona. */
	private static $wn = array( 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,278,278,355,556,556,889,667,191,333,333,389,584,278,333,278,278,556,556,556,556,556,556,556,556,556,556,278,278,584,584,584,556,1015,667,667,722,722,667,611,778,722,278,500,667,556,833,722,778,667,778,722,667,611,722,667,944,667,667,611,278,278,278,469,556,333,556,556,500,556,556,278,556,556,222,222,500,222,833,556,556,556,556,333,500,278,556,500,722,500,500,500,334,260,334,584,500,556,500,222,500,333,1000,556,556,500,1000,667,333,667,611,611,611,500,222,222,333,333,350,556,1000,500,1000,500,333,500,375,500,500,278,333,333,556,556,667,260,556,333,737,667,556,584,333,737,611,400,549,333,222,333,576,537,333,333,556,500,556,556,333,292,500,722,667,667,667,667,556,722,722,722,667,667,667,667,278,278,722,722,722,722,778,778,778,778,584,722,722,722,722,722,667,611,611,333,556,556,556,556,222,500,500,500,556,556,556,556,278,278,615,556,556,556,556,556,556,556,549,333,556,556,556,556,500,278,333 );
	private static $wb = array( 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,278,333,474,556,556,889,722,238,333,333,389,584,278,333,278,278,556,556,556,556,556,556,556,556,556,556,333,333,584,584,584,611,975,722,722,722,722,667,611,778,722,278,556,722,611,833,722,778,667,778,722,667,611,722,667,944,667,667,611,333,278,333,584,556,333,556,611,556,611,556,333,611,611,278,278,556,278,889,611,611,611,611,389,556,333,611,556,778,556,556,500,389,280,389,584,500,556,500,278,500,500,1000,556,556,500,1000,667,333,667,611,611,611,500,278,278,500,500,350,556,1000,500,1000,556,333,556,479,500,500,278,333,333,611,556,722,280,556,333,737,667,556,584,333,737,611,400,549,333,278,333,576,556,333,333,556,556,556,611,333,385,500,722,722,722,722,722,611,722,722,722,667,667,667,667,278,278,722,722,722,722,778,778,778,778,584,722,722,722,722,722,667,611,611,389,556,556,556,556,278,556,556,556,556,556,556,556,278,278,719,611,611,611,611,611,611,611,549,389,611,611,611,611,556,333,333 );
	/** Kody Unicode znaków 128–255 w Windows-1250 (0 = brak). */
	private static $uni = array( 8364,0,8218,0,8222,8230,8224,8225,0,8240,352,8249,346,356,381,377,0,8216,8217,8220,8221,8226,8211,8212,0,8482,353,8250,347,357,382,378,160,711,728,321,164,260,166,167,168,169,350,171,172,173,174,379,176,177,731,322,180,181,182,183,184,261,351,187,317,733,318,380,340,193,194,258,196,313,262,199,268,201,280,203,282,205,206,270,272,323,327,211,212,336,214,215,344,366,218,368,220,221,354,223,341,225,226,259,228,314,263,231,269,233,281,235,283,237,238,271,273,324,328,243,244,337,246,247,345,367,250,369,252,253,355,729 );
	const DIFF = '/Euro /.notdef /quotesinglbase /.notdef /quotedblbase /ellipsis /dagger /daggerdbl /.notdef /perthousand /Scaron /guilsinglleft /Sacute /Tcaron /Zcaron /Zacute /.notdef /quoteleft /quoteright /quotedblleft /quotedblright /bullet /endash /emdash /.notdef /trademark /scaron /guilsinglright /sacute /tcaron /zcaron /zacute /uni00A0 /caron /breve /Lslash /currency /Aogonek /brokenbar /section /dieresis /copyright /Scedilla /guillemotleft /logicalnot /uni00AD /registered /Zdotaccent /degree /plusminus /ogonek /lslash /acute /mu /paragraph /periodcentered /cedilla /aogonek /scedilla /guillemotright /Lcaron /hungarumlaut /lcaron /zdotaccent /Racute /Aacute /Acircumflex /Abreve /Adieresis /Lacute /Cacute /Ccedilla /Ccaron /Eacute /Eogonek /Edieresis /Ecaron /Iacute /Icircumflex /Dcaron /Dcroat /Nacute /Ncaron /Oacute /Ocircumflex /Ohungarumlaut /Odieresis /multiply /Rcaron /Uring /Uacute /Uhungarumlaut /Udieresis /Yacute /uni0162 /germandbls /racute /aacute /acircumflex /abreve /adieresis /lacute /cacute /ccedilla /ccaron /eacute /eogonek /edieresis /ecaron /iacute /icircumflex /dcaron /dcroat /nacute /ncaron /oacute /ocircumflex /ohungarumlaut /odieresis /divide /rcaron /uring /uacute /uhungarumlaut /udieresis /yacute /uni0163 /dotaccent';

	private $pages = array();
	private $cur   = '';
	private $font  = 'n';
	private $size  = 10;
	private $img   = null;
	private $map   = null;

	public function add_page() {
		if ( '' !== $this->cur || $this->pages ) {
			$this->pages[] = $this->cur;
		}
		$this->cur = '';
		return $this;
	}

	public function font( $style, $size ) {
		$this->font = 'b' === $style ? 'b' : 'n';
		$this->size = (float) $size;
		return $this;
	}

	/** UTF-8 → Windows-1250 (znaki spoza strony kodowej zastępowane „?”). */
	public function enc( $s ) {
		if ( null === $this->map ) {
			$this->map = array();
			foreach ( self::$uni as $i => $cp ) {
				if ( $cp ) {
					$this->map[ $cp ] = chr( 128 + $i );
				}
			}
		}
		$out = '';
		foreach ( preg_split( '//u', (string) $s, -1, PREG_SPLIT_NO_EMPTY ) as $ch ) {
			$cp = mb_ord( $ch, 'UTF-8' );
			if ( $cp < 128 ) {
				$out .= $cp < 32 ? ' ' : $ch;
			} elseif ( isset( $this->map[ $cp ] ) ) {
				$out .= $this->map[ $cp ];
			} elseif ( in_array( $cp, array( 0x2212, 0x2010, 0x2011, 0x2012 ), true ) ) {
				$out .= '-';
			} elseif ( 0x00D7 === $cp ) {
				$out .= chr( 0xD7 );
			} else {
				$out .= '?';
			}
		}
		return $out;
	}

	public function width( $s, $style = null, $size = null ) {
		$w   = 'b' === ( $style ?? $this->font ) ? self::$wb : self::$wn;
		$sum = 0;
		$e   = $this->enc( $s );
		for ( $i = 0, $n = strlen( $e ); $i < $n; $i++ ) {
			$sum += $w[ ord( $e[ $i ] ) ];
		}
		return $sum * ( $size ?? $this->size ) / 1000;
	}

	private static function esc( $e ) {
		return str_replace( array( '\\', '(', ')', "\r" ), array( '\\\\', '\\(', '\\)', '' ), $e );
	}

	private static function n( $v ) {
		return rtrim( rtrim( sprintf( '%.2F', $v ), '0' ), '.' );
	}

	private static function rgb( $c ) {
		$c = ltrim( (string) $c, '#' );
		return array( hexdec( substr( $c, 0, 2 ) ) / 255, hexdec( substr( $c, 2, 2 ) ) / 255, hexdec( substr( $c, 4, 2 ) ) / 255 );
	}

	/** Tekst; $y = linia bazowa od góry strony; $align: L, R (x = prawa krawędź), C (x = środek). */
	public function text( $x, $y, $s, $color = '1a2233', $align = 'L' ) {
		if ( 'R' === $align ) {
			$x -= $this->width( $s );
		} elseif ( 'C' === $align ) {
			$x -= $this->width( $s ) / 2;
		}
		list( $r, $g, $b ) = self::rgb( $color );
		$this->cur .= sprintf( "BT /F%s %s Tf %s %s %s rg %s %s Td (%s) Tj ET\n", $this->font, self::n( $this->size ), self::n( $r ), self::n( $g ), self::n( $b ), self::n( $x ), self::n( self::H - $y ), self::esc( $this->enc( $s ) ) );
		return $this;
	}

	/** Podział tekstu na wiersze o szerokości $w (słowa zbyt długie są dzielone na znaki). */
	public function wrap( $s, $w ) {
		$out = array();
		foreach ( preg_split( '/\r\n|\r|\n/', (string) $s ) as $para ) {
			$line = '';
			foreach ( preg_split( '/\s+/u', trim( $para ), -1, PREG_SPLIT_NO_EMPTY ) as $word ) {
				$try = '' === $line ? $word : $line . ' ' . $word;
				if ( $this->width( $try ) <= $w ) {
					$line = $try;
					continue;
				}
				if ( '' !== $line ) {
					$out[] = $line;
				}
				while ( $this->width( $word ) > $w && mb_strlen( $word ) > 1 ) {
					$cut = mb_strlen( $word );
					while ( $cut > 1 && $this->width( mb_substr( $word, 0, $cut ) ) > $w ) {
						$cut--;
					}
					$out[] = mb_substr( $word, 0, $cut );
					$word  = mb_substr( $word, $cut );
				}
				$line = $word;
			}
			$out[] = $line;
		}
		return $out;
	}

	public function line( $x1, $y1, $x2, $y2, $color = 'd6dbe5', $w = 0.6 ) {
		list( $r, $g, $b ) = self::rgb( $color );
		$this->cur .= sprintf( "%s %s %s RG %s w %s %s m %s %s l S\n", self::n( $r ), self::n( $g ), self::n( $b ), self::n( $w ), self::n( $x1 ), self::n( self::H - $y1 ), self::n( $x2 ), self::n( self::H - $y2 ) );
		return $this;
	}

	public function rect( $x, $y, $w, $h, $fill = 'f4f6fa', $stroke = null ) {
		list( $r, $g, $b ) = self::rgb( $fill );
		$op = 'f';
		$s  = sprintf( '%s %s %s rg ', self::n( $r ), self::n( $g ), self::n( $b ) );
		if ( $stroke ) {
			list( $r2, $g2, $b2 ) = self::rgb( $stroke );
			$s .= sprintf( '%s %s %s RG 0.6 w ', self::n( $r2 ), self::n( $g2 ), self::n( $b2 ) );
			$op = 'B';
		}
		$this->cur .= $s . sprintf( "%s %s %s %s re %s\n", self::n( $x ), self::n( self::H - $y - $h ), self::n( $w ), self::n( $h ), $op );
		return $this;
	}

	/** Obraz PNG/JPEG (przez GD → JPEG na białym tle); jeden obraz na dokument (logo). */
	public function image( $path, $x, $y, $w ) {
		if ( ! is_readable( $path ) || ! function_exists( 'imagecreatefromstring' ) ) {
			return $this;
		}
		if ( null === $this->img ) {
			$src = @imagecreatefromstring( (string) file_get_contents( $path ) ); // phpcs:ignore
			if ( ! $src ) {
				return $this;
			}
			$iw = imagesx( $src );
			$ih = imagesy( $src );
			$bg = imagecreatetruecolor( $iw, $ih );
			imagefill( $bg, 0, 0, imagecolorallocate( $bg, 255, 255, 255 ) );
			imagecopy( $bg, $src, 0, 0, 0, 0, $iw, $ih );
			ob_start();
			imagejpeg( $bg, null, 92 );
			$this->img = array( 'data' => ob_get_clean(), 'w' => $iw, 'h' => $ih );
		}
		$h = $w * $this->img['h'] / $this->img['w'];
		$this->cur .= sprintf( "q %s 0 0 %s %s %s cm /Im1 Do Q\n", self::n( $w ), self::n( $h ), self::n( $x ), self::n( self::H - $y - $h ) );
		return $h;
	}

	/** Gotowy plik PDF jako tekst. */
	public function output( $title = '' ) {
		$pages   = array_merge( $this->pages, array( $this->cur ) );
		$objs    = array();
		$objs[1] = '<< /Type /Catalog /Pages 2 0 R >>';
		$objs[3] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding 5 0 R >>';
		$objs[4] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding 5 0 R >>';
		$objs[5] = '<< /Type /Encoding /BaseEncoding /WinAnsiEncoding /Differences [128 ' . self::DIFF . '] >>';
		$next    = 6;
		$img     = '';
		if ( $this->img ) {
			$objs[ $next ] = array( '<< /Type /XObject /Subtype /Image /Width ' . $this->img['w'] . ' /Height ' . $this->img['h'] . ' /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ' . strlen( $this->img['data'] ) . ' >>', $this->img['data'] );
			$img           = ' /XObject << /Im1 ' . $next . ' 0 R >>';
			$next++;
		}
		$kids = array();
		foreach ( $pages as $content ) {
			$z             = function_exists( 'gzcompress' ) ? gzcompress( $content ) : $content;
			$objs[ $next ] = array( '<< ' . ( function_exists( 'gzcompress' ) ? '/Filter /FlateDecode ' : '' ) . '/Length ' . strlen( $z ) . ' >>', $z );
			$objs[ $next + 1 ] = '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ' . self::n( self::W ) . ' ' . self::n( self::H ) . '] /Resources << /Font << /Fn 3 0 R /Fb 4 0 R >>' . $img . ' >> /Contents ' . $next . ' 0 R >>';
			$kids[]            = ( $next + 1 ) . ' 0 R';
			$next             += 2;
		}
		$objs[2]       = '<< /Type /Pages /Kids [' . implode( ' ', $kids ) . '] /Count ' . count( $kids ) . ' >>';
		$objs[ $next ] = '<< /Title (' . self::esc( $this->enc( $title ) ) . ') /Producer (System K-ERP) /CreationDate (D:' . gmdate( 'YmdHis' ) . 'Z) >>';
		$info          = $next;
		ksort( $objs );
		$pdf = "%PDF-1.4\n%\xE2\xE3\xCF\xD3\n";
		$off = array();
		foreach ( $objs as $i => $o ) {
			$off[ $i ] = strlen( $pdf );
			$pdf      .= $i . " 0 obj\n" . ( is_array( $o ) ? $o[0] . "\nstream\n" . $o[1] . "\nendstream" : $o ) . "\nendobj\n";
		}
		$xref = strlen( $pdf );
		$pdf .= "xref\n0 " . ( $info + 1 ) . "\n0000000000 65535 f \n";
		for ( $i = 1; $i <= $info; $i++ ) {
			$pdf .= sprintf( "%010d 00000 n \n", $off[ $i ] ?? 0 );
		}
		$pdf .= 'trailer << /Size ' . ( $info + 1 ) . ' /Root 1 0 R /Info ' . $info . " 0 R >>\nstartxref\n" . $xref . "\n%%EOF";
		return $pdf;
	}
}
