<?php
/**
 * Produkcja – import zleceń z arkusza Excela (ten sam układ co „Produkcja” 2026: kolumny A–O, scalone komórki zleceń).
 *
 * Dodaje TYLKO nowe zlecenia – istniejących nie zmienia. Zlecenie jest „istniejące”, gdy na liście danego roku
 * jest już zlecenie o tym samym numerze (przy powtórzonych numerach liczy się ich liczba: w pliku 2× B02485,
 * w systemie 2× → oba pominięte; w pliku 3× → nowe tylko trzecie).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MSM_Prod_Import {

	/* Kolumny arkusza (od 0): A uwagi … O zostało. */
	const C_UWAGI = 0, C_NR = 1, C_START = 2, C_KONIEC = 3, C_DOST = 4, C_WERSJA = 5, C_CZAS = 6, C_KLIENT = 7, C_NRKL = 8, C_NAZWA = 9, C_RYS = 10, C_ILOSC = 11, C_WYK = 12;
	const DET_COLS = array( 0, 4, 5, 6, 9, 10, 11, 12 );

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
	}

	public static function routes() {
		$p = array( 'MSM_Prod', 'can_manage' ); // import nadpisuje dane – od 1.84.0 tylko z uprawnieniem „Produkcja – … import”
		register_rest_route( MSM_Rest::NS, '/prod/import/parse', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'parse_r' ), 'permission_callback' => $p ) );
		register_rest_route( MSM_Rest::NS, '/prod/import/commit', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'commit_r' ), 'permission_callback' => $p ) );
	}

	/* ---------------- odczyt arkusza ---------------- */

	private static function str( $v ) {
		if ( null === $v || is_bool( $v ) ) {
			return '';
		}
		if ( is_float( $v ) && floor( $v ) === $v && abs( $v ) < 1e15 ) {
			return (string) (int) $v;
		}
		return trim( str_replace( "\r\n", "\n", (string) $v ) );
	}

	private static function date( $v ) {
		if ( is_numeric( $v ) ) {
			return MSM_Karta::date( $v );
		}
		return self::str( $v );
	}

	/**
	 * Zlecenia z arkusza: [ {nr_zlec, start_zlec, koniec_zlec, klient, nr_zlec_klienta, det: [ … ]} ].
	 * Zlecenie zaczyna się w wierszu z numerem w kolumnie B; kończy wierszem „Wykon.”, pustym wierszem albo następnym numerem.
	 * Wartości scalonych komórek obowiązują w całym zakresie (np. dostępność wspólna dla kilku detali).
	 */
	public static function parse_sheet( array $rows, array $merges, array $dates = array() ) {
		foreach ( $dates as $r => $cols ) { // liczby sformatowane w Excelu jako data → „dd.mm.rrrr” (np. nr zlecenia klienta)
			foreach ( $cols as $c => $_ ) {
				if ( isset( $rows[ $r ][ $c ] ) && is_numeric( $rows[ $r ][ $c ] ) && self::C_ILOSC !== $c && self::C_WYK !== $c ) {
					$rows[ $r ][ $c ] = MSM_Karta::date( $rows[ $r ][ $c ] );
				}
			}
		}
		$fill = array(); // [r][c] => wartość z lewego górnego rogu scalenia
		$own  = array(); // [r][c] => true – komórka z własną wartością (nie kontynuacja scalenia)
		foreach ( $merges as $m ) {
			list( $r1, $c1, $r2, $c2 ) = $m;
			if ( $c1 > 15 ) {
				continue;
			}
			$v = $rows[ $r1 ][ $c1 ] ?? null;
			for ( $r = $r1; $r <= $r2; $r++ ) {
				for ( $c = $c1; $c <= min( $c2, 15 ); $c++ ) {
					if ( $r !== $r1 || $c !== $c1 ) {
						$fill[ $r ][ $c ] = $v;
					}
				}
			}
		}
		$val = function ( $r, $c ) use ( $rows, $fill ) {
			return array_key_exists( $c, $fill[ $r ] ?? array() ) ? $fill[ $r ][ $c ] : ( $rows[ $r ][ $c ] ?? null );
		};
		$has_own = function ( $r, $c ) use ( $rows, $fill ) {
			return ! array_key_exists( $c, $fill[ $r ] ?? array() ) && '' !== self::str( $rows[ $r ][ $c ] ?? null );
		};
		$orders = array();
		$cur    = null;
		$max    = $rows ? max( array_keys( $rows ) ) : -1;
		for ( $r = 2; $r <= $max; $r++ ) { // od 3. wiersza (1–2: nagłówki)
			$m = mb_strtolower( self::str( $val( $r, self::C_WYK ) ) );
			if ( 0 === mb_strpos( $m, 'wykon' ) ) {
				$cur = null;
				continue;
			}
			$any = false;
			for ( $c = 0; $c <= 12; $c++ ) {
				if ( '' !== self::str( $val( $r, $c ) ) ) {
					$any = true;
					break;
				}
			}
			if ( ! $any ) {
				$cur = null;
				continue;
			}
			if ( $has_own( $r, self::C_NR ) ) {
				$orders[] = array(
					'nr_zlec'         => self::str( $val( $r, self::C_NR ) ),
					'start_zlec'      => self::date( $val( $r, self::C_START ) ),
					'koniec_zlec'     => self::date( $val( $r, self::C_KONIEC ) ),
					'klient'          => self::str( $val( $r, self::C_KLIENT ) ),
					'nr_zlec_klienta' => self::str( $val( $r, self::C_NRKL ) ),
					'det'             => array(),
					'wiersz'          => $r + 1,
				);
				$cur = count( $orders ) - 1;
			}
			if ( null === $cur ) {
				continue; // luźny wiersz poza zleceniem
			}
			$det_row = false;
			foreach ( self::DET_COLS as $c ) {
				if ( $has_own( $r, $c ) ) {
					$det_row = true;
					break;
				}
			}
			if ( ! $det_row ) {
				continue; // tylko kontynuacja scalonych komórek
			}
			$il = $val( $r, self::C_ILOSC );
			$wy = $val( $r, self::C_WYK );
			$orders[ $cur ]['det'][] = array(
				'uwagi'        => self::str( $val( $r, self::C_UWAGI ) ),
				'dostepnosc'   => self::str( $val( $r, self::C_DOST ) ),
				'wersja'       => self::str( $val( $r, self::C_WERSJA ) ),
				'czas_ciecia'  => self::str( $val( $r, self::C_CZAS ) ),
				'nazwa_detalu' => self::str( $val( $r, self::C_NAZWA ) ),
				'nr_rysunku'   => self::str( $val( $r, self::C_RYS ) ),
				'ilosc_zam'    => is_numeric( $il ) ? (int) round( $il ) : 0,
				'wykonano'     => is_numeric( $wy ) ? (int) round( $wy ) : 0,
			);
		}
		return $orders;
	}

	/** Które zlecenia z pliku są nowe (porównanie z listą roku po numerze zlecenia, z uwzględnieniem powtórzeń). */
	public static function plan( array $orders, array $existing_nrs ) {
		$left = array_count_values( array_map( 'strval', $existing_nrs ) );
		$new  = array();
		$skip = array();
		foreach ( $orders as $o ) {
			$k = (string) $o['nr_zlec'];
			if ( ! empty( $left[ $k ] ) ) {
				$left[ $k ]--;
				$skip[] = $k;
			} else {
				$new[] = $o;
			}
		}
		return array( 'nowe' => $new, 'pominiete' => $skip );
	}

	/** Numery, które przybyły w bazie od chwili podglądu (wielozbiór: teraz − wtedy). */
	public static function diff_multi( array $now, array $then ) {
		$left = array_count_values( array_map( 'strval', $then ) );
		$out  = array();
		foreach ( $now as $n ) {
			$n = (string) $n;
			if ( ! empty( $left[ $n ] ) ) {
				$left[ $n ]--;
			} else {
				$out[] = $n;
			}
		}
		return $out;
	}

	/* ---------------- REST ---------------- */

	private static function token_key() {
		return 'msm_prod_imp_' . get_current_user_id();
	}

	/** POST /prod/import/parse (plik, rok, arkusz?) – podgląd: nowe zlecenia i pominięte. Nic nie zapisuje. */
	public static function parse_r( WP_REST_Request $r ) {
		global $wpdb;
		$files = $r->get_file_params();
		if ( empty( $files['file']['tmp_name'] ) || ! is_uploaded_file( $files['file']['tmp_name'] ) ) {
			return new WP_Error( 'msm_400', 'Nie przesłano pliku.', array( 'status' => 400 ) );
		}
		if ( ! preg_match( '/\.xlsx$/i', (string) $files['file']['name'] ) ) {
			return new WP_Error( 'msm_400', 'Wybierz plik .xlsx z arkuszem Produkcji.', array( 'status' => 400 ) );
		}
		if ( function_exists( 'wp_raise_memory_limit' ) ) {
			wp_raise_memory_limit( 'admin' );
		}
		$book = MSM_Xlsx::read( $files['file']['tmp_name'] );
		if ( is_wp_error( $book ) ) {
			$book->add_data( array( 'status' => 400 ) );
			return $book;
		}
		$names = array_keys( $book );
		$rok   = MSM_Prod::valid_year( $r->get_param( 'rok' ) ) ?: MSM_Prod::current_year();
		$sheet = (string) $r->get_param( 'arkusz' );
		if ( '' === $sheet || ! isset( $book[ $sheet ] ) ) {
			$sheet = isset( $book[ $rok ] ) ? $rok : '';
		}
		if ( '' === $sheet ) {
			return rest_ensure_response( array( 'arkusze' => $names, 'arkusz' => '', 'rok' => $rok, 'brak' => 'W pliku nie ma arkusza „' . $rok . '”. Wybierz arkusz do importu.' ) );
		}
		if ( MSM_Prod::valid_year( $sheet ) ) {
			$rok = $sheet; // arkusz „2026” → lista 2026
		}
		$orders = self::parse_sheet( $book[ $sheet ], MSM_Xlsx::$merges[ $sheet ] ?? array(), MSM_Xlsx::$dates[ $sheet ] ?? array() );
		$have   = (array) $wpdb->get_col( $wpdb->prepare( 'SELECT nr_zlec FROM `' . MSM_Prod::TZ() . '` WHERE arkusz = %s', $rok ) ); // phpcs:ignore
		$plan   = self::plan( $orders, $have );
		set_transient( self::token_key(), array( 'rok' => $rok, 'arkusz' => $sheet, 'nowe' => $plan['nowe'], 'had' => $have ), 30 * MINUTE_IN_SECONDS );
		return rest_ensure_response( array(
			'arkusze'   => $names,
			'arkusz'    => $sheet,
			'rok'       => $rok,
			'w_pliku'   => count( $orders ),
			'pominiete' => count( $plan['pominiete'] ),
			'nowe'      => array_map( function ( $o ) {
				return array(
					'nr_zlec'  => $o['nr_zlec'],
					'klient'   => $o['klient'],
					'start'    => $o['start_zlec'],
					'koniec'   => $o['koniec_zlec'],
					'pozycji'  => count( $o['det'] ),
					'detale'   => implode( ', ', array_slice( array_filter( wp_list_pluck( $o['det'], 'nazwa_detalu' ) ), 0, 3 ) ),
					'wiersz'   => $o['wiersz'],
				);
			}, $plan['nowe'] ),
			'plik'      => sanitize_file_name( (string) $files['file']['name'] ),
		) );
	}

	/** POST /prod/import/commit – dopisuje nowe zlecenia z ostatniego podglądu na końcu listy roku. */
	public static function commit_r( WP_REST_Request $r ) {
		global $wpdb;
		$t = get_transient( self::token_key() );
		if ( ! is_array( $t ) || empty( $t['nowe'] ) ) {
			return new WP_Error( 'msm_400', 'Podgląd importu wygasł albo nie ma nic do dodania – wczytaj plik jeszcze raz.', array( 'status' => 400 ) );
		}
		delete_transient( self::token_key() );
		// Ponowne sprawdzenie – ktoś mógł w międzyczasie dodać te same zlecenia.
		$have = (array) $wpdb->get_col( $wpdb->prepare( 'SELECT nr_zlec FROM `' . MSM_Prod::TZ() . '` WHERE arkusz = %s', $t['rok'] ) ); // phpcs:ignore
		$plan = self::plan( $t['nowe'], self::diff_multi( $have, (array) ( $t['had'] ?? array() ) ) );
		$poz  = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT MAX(poz) FROM `' . MSM_Prod::TZ() . '` WHERE arkusz = %s', $t['rok'] ) ); // phpcs:ignore
		$nrs  = array();
		foreach ( $plan['nowe'] as $o ) {
			MSM_Prod::insert_order( $o, $t['rok'], ++$poz );
			$nrs[] = '' !== $o['nr_zlec'] ? $o['nr_zlec'] : '(bez numeru)';
		}
		if ( ! $nrs ) {
			return new WP_Error( 'msm_409', 'Te zlecenia zostały już dodane w międzyczasie – nic nie zaimportowano.', array( 'status' => 409 ) );
		}
		MSM_Repo::log( 'Produkcja: import z Excela', 'produkcja', 0, 'Arkusz „' . $t['arkusz'] . '” → lista ' . $t['rok'] . ': dodano ' . count( $nrs ) . ' zleceń (' . implode( ', ', array_slice( $nrs, 0, 30 ) ) . ( count( $nrs ) > 30 ? ', …' : '' ) . ')' );
		return rest_ensure_response( array( 'dodane' => count( $nrs ), 'rok' => $t['rok'], 'numery' => $nrs ) );
	}
}
