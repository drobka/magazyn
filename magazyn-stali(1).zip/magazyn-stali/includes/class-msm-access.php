<?php
/**
 * Logowanie, blokada rejestracji, odcięcie kokpitu WP dla ról magazynowych.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MSM_Access {

	/** Ochrona logowania (1.84.0): po tylu nieudanych próbach w oknie czasowym logowanie jest blokowane. */
	const FAIL_IP     = 5;
	const FAIL_USER   = 10;
	const FAIL_WINDOW = 900; // 15 minut

	/** Czy bieżące żądanie zostało zablokowane limitem prób. */
	private static $locked = false;

	public static function init() {
		// Rejestracja zawsze wyłączona.
		add_filter( 'pre_option_users_can_register', '__return_zero' );
		add_action( 'login_init', array( __CLASS__, 'block_register' ) );
		add_filter( 'register_url', array( __CLASS__, 'app_url_filter' ) );

		// Brak paska admina i kokpitu dla użytkowników bez manage_options.
		add_filter( 'show_admin_bar', array( __CLASS__, 'admin_bar' ) );
		add_action( 'admin_init', array( __CLASS__, 'block_admin' ), 1 );

		// Przekierowania logowania / wylogowania.
		add_filter( 'login_redirect', array( __CLASS__, 'login_redirect' ), 20, 3 );
		add_filter( 'logout_redirect', array( __CLASS__, 'logout_redirect' ), 20, 3 );
		add_action( 'wp_login_failed', array( __CLASS__, 'count_failure' ), 1 );
		add_action( 'wp_login_failed', array( __CLASS__, 'login_failed' ) );
		add_filter( 'authenticate', array( __CLASS__, 'throttle' ), 30, 3 );
		add_action( 'wp_login', array( __CLASS__, 'clear_failures' ), 10, 2 );

		// XML-RPC i hasła aplikacji to dodatkowe drogi logowania z pominięciem formularza – domyślnie wyłączone.
		add_filter( 'xmlrpc_enabled', function ( $on ) { return (bool) apply_filters( 'msm_xmlrpc_enabled', false ); } );
		add_filter( 'wp_is_application_passwords_available_for_user', array( __CLASS__, 'app_passwords' ), 10, 2 );
		add_action( 'wp_authenticate', array( __CLASS__, 'login_empty' ), 1, 2 );

		// Zmiana „Przedstawiaj mnie jako” w profilu → aktualizacja nazw w historii i pobraniach.
		add_action( 'profile_update', array( 'MSM_Install', 'sync_user_names' ) );

		// Nie ujawniaj listy użytkowników niezalogowanym.
		add_filter( 'rest_endpoints', array( __CLASS__, 'hide_users_endpoint' ) );
	}

	public static function app_url() {
		$id = (int) get_option( 'msm_page_id' );
		return $id ? get_permalink( $id ) : home_url( '/' );
	}

	public static function app_url_filter() {
		return self::app_url();
	}

	public static function block_register() {
		$action = isset( $_REQUEST['action'] ) ? sanitize_key( wp_unslash( $_REQUEST['action'] ) ) : ''; // phpcs:ignore
		if ( 'register' === $action ) {
			wp_safe_redirect( self::app_url() );
			exit;
		}
	}

	public static function admin_bar( $show ) {
		return current_user_can( 'manage_options' ) ? $show : false;
	}

	public static function block_admin() {
		if ( current_user_can( 'manage_options' ) || wp_doing_ajax() || ( defined( 'DOING_CRON' ) && DOING_CRON ) ) {
			return;
		}
		$script = isset( $_SERVER['SCRIPT_NAME'] ) ? basename( sanitize_text_field( wp_unslash( $_SERVER['SCRIPT_NAME'] ) ) ) : '';
		if ( in_array( $script, array( 'admin-post.php', 'async-upload.php' ), true ) ) {
			return;
		}
		$u = wp_get_current_user();
		if ( array_intersect( array( MSM_Install::ROLE_ADMIN, MSM_Install::ROLE_VIEWER ), (array) $u->roles ) || ! current_user_can( 'edit_posts' ) ) {
			// Profil edytuje się w aplikacji.
			wp_safe_redirect( self::app_url() . ( 'profile.php' === $script ? '#profil' : '' ) );
			exit;
		}
	}

	public static function login_redirect( $redirect_to, $requested, $user ) {
		if ( $user instanceof WP_User && $user->has_cap( 'msm_view' ) && ! $user->has_cap( 'manage_options' ) ) {
			// Zostaw adres aplikacji z kotwicą (np. link z e-maila #wyslij-12), w innym wypadku – start aplikacji.
			$app = self::app_url();
			return ( $requested && 0 === strpos( $requested, strtok( $app, '#' ) ) ) ? $requested : $app;
		}
		return $redirect_to;
	}

	public static function logout_redirect( $redirect_to, $requested, $user ) {
		return self::app_url();
	}

	private static function from_app() {
		$ref = wp_get_referer();
		if ( ! $ref ) {
			return false;
		}
		$app = self::app_url();
		return 0 === strpos( strtok( $ref, '?' ), strtok( $app, '?' ) );
	}

	/* ---------- limit prób logowania ---------- */

	private static function client_ip() {
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
		return (string) apply_filters( 'msm_client_ip', $ip ); // za proxy/CDN: podłącz filtr zwracający prawdziwy adres
	}

	private static function keys( $username ) {
		return array(
			'ip'   => 'msm_lf_ip_' . md5( self::client_ip() ),
			'user' => 'msm_lf_u_' . md5( strtolower( trim( (string) $username ) ) ),
		);
	}

	public static function is_locked( $username ) {
		$k = self::keys( $username );
		return (int) get_transient( $k['ip'] ) >= self::FAIL_IP
			|| ( '' !== trim( (string) $username ) && (int) get_transient( $k['user'] ) >= self::FAIL_USER );
	}

	/** Blokada przed sprawdzeniem wyniku – także przy poprawnym haśle, dopóki trwa blokada. */
	public static function throttle( $user, $username, $password ) {
		if ( '' === trim( (string) $username ) ) {
			return $user;
		}
		if ( self::is_locked( $username ) ) {
			self::$locked = true;
			return new WP_Error( 'msm_locked', '<strong>Błąd:</strong> zbyt wiele nieudanych prób logowania. Spróbuj ponownie za 15 minut.' );
		}
		return $user;
	}

	public static function count_failure( $username ) {
		$k = self::keys( $username );
		set_transient( $k['ip'], (int) get_transient( $k['ip'] ) + 1, self::FAIL_WINDOW );
		if ( '' !== trim( (string) $username ) ) {
			set_transient( $k['user'], (int) get_transient( $k['user'] ) + 1, self::FAIL_WINDOW );
		}
	}

	public static function clear_failures( $user_login, $user ) {
		$k = self::keys( $user_login );
		delete_transient( $k['ip'] );
		delete_transient( $k['user'] );
	}

	/** Hasła aplikacji (logowanie API bez formularza) – niedostępne dla kont magazynu. */
	public static function app_passwords( $available, $user ) {
		if ( $user instanceof WP_User && ! user_can( $user, 'manage_options' ) && array_intersect( array( MSM_Install::ROLE_ADMIN, MSM_Install::ROLE_VIEWER ), (array) $user->roles ) ) {
			return false;
		}
		return $available;
	}

	public static function login_failed() {
		if ( self::from_app() ) {
			wp_safe_redirect( add_query_arg( 'msm_login', self::$locked ? 'locked' : 'failed', self::app_url() ) );
			exit;
		}
	}

	public static function login_empty( $username, $password ) {
		if ( isset( $_POST['msm_login_form'] ) && ( '' === trim( (string) $username ) || '' === (string) $password ) ) { // phpcs:ignore
			wp_safe_redirect( add_query_arg( 'msm_login', 'empty', self::app_url() ) );
			exit;
		}
	}

	public static function hide_users_endpoint( $endpoints ) {
		if ( ! is_user_logged_in() ) {
			foreach ( array_keys( $endpoints ) as $route ) {
				if ( 0 === strpos( $route, '/wp/v2/users' ) ) {
					unset( $endpoints[ $route ] );
				}
			}
		}
		return $endpoints;
	}
}
