<?php
/**
 * Uprawnienia per-użytkownik: co widzi w menu i z których akcji może korzystać.
 * Rola (Administrator / Przeglądający) daje domyślny zestaw; per-osoba można sekcje/akcje WYŁĄCZYĆ.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MSM_Perms {

	const META = 'msm_perms';

	/**
	 * Drzewo menu – dokładnie jak w aplikacji: grupa => [klucz => etykieta | [etykieta, [dzieci]]].
	 * Wyłączenie pozycji nadrzędnej (np. „Wydania (WZ)”) ukrywa wszystkie jej podpozycje.
	 */
	public static function menu_tree() {
		return array(
			'Pulpit' => array(
				'tablica' => 'Pulpit (tablica kierownika)',
			),
			'Magazyn' => array(
				'stany'      => array( 'Stany', array( 'stal' => 'Stal', 'blachy_pelne' => 'Blachy pełne', 'blachy_niepelne' => 'Blachy niepełne', 'kregi' => 'Kręgi' ) ),
				'rezerwacje' => 'Rezerwacje',
				'pobrania'   => 'Pobrania',
				'wnioski'    => 'Wnioski',
				'zlecenie'   => 'Karta zlecenia',
				'zamowienia' => 'Do zamówienia',
			),
			'Dokumenty' => array(
				'pz'        => 'Przyjęcia (PZ)',
				'wz'        => array( 'Wydania (WZ)', array( 'wz_dok' => 'Dokumenty WZ', 'wz_odbiorcy' => 'Odbiorcy', 'wz_przeznaczenie' => 'Przeznaczenie', 'wz_transport' => 'Środek transportu' ) ),
				'przesylki' => 'Przesyłki',
				'zam_dost'  => 'Zamówienia do dostawców',
			),
			'Magazyn BHP' => array(
				'bhp' => array( 'Magazyn BHP', array( 'bhp_stan' => 'Stan BHP', 'bhp_wyd' => 'Wydania', 'bhp_util' => 'Utylizacje', 'bhp_osoby' => 'Osoby', 'bhp_normy' => 'Normy', 'bhp_wymiana' => 'Do wymiany' ) ),
			),
			'Produkcja' => array(
				'produkcja' => array( 'Produkcja', array( 'prod_zlecenia' => 'Zlecenia', 'prod_palety' => 'Paletówki', 'prod_notatki' => 'Notatki', 'prod_karty' => 'Karty zmian (włączane osobno)' ) ),
			),
			'Narzędziownia' => array(
				'narzedzia' => array( 'Narzędziownia', array( 'spr_prost' => 'Sprawdziany prost.', 'prz_prost' => 'Przyrządy prost.', 'spr_okr' => 'Sprawdziany okrągłe', 'prz_okr' => 'Przyrządy okrągłe', 'narz_pomiarowe' => 'Przyrządy pomiarowe', 'narz_elektro' => 'Elektronarzędzia' ) ),
			),
			'Techniczne' => array(
				'historia'    => 'Historia zmian',
				'uzytkownicy' => 'Użytkownicy',
				'kopia'       => 'Kopia danych',
				'szablony'    => 'Szablony e-maili',
				'import'      => 'Import',
				'logowania'   => 'Dziennik logowań',
				'ustawienia'  => 'Ustawienia (tylko super administrator)',
				'zmiany'      => 'Historia wersji',
				'grafik'      => 'Grafik pracy (strona /grafik/)',
			),
		);
	}

	/** Płaska lista kluczy menu (klucz => etykieta). */
	public static function menu_keys() {
		$out = array();
		foreach ( self::menu_tree() as $items ) {
			foreach ( $items as $k => $v ) {
				$out[ $k ] = is_array( $v ) ? $v[0] : $v;
				if ( is_array( $v ) ) {
					foreach ( $v[1] as $ck => $cl ) {
						$out[ $ck ] = $cl;
					}
				}
			}
		}
		return $out;
	}

	/** Podpozycja => pozycja nadrzędna. */
	public static function menu_parents() {
		$out = array();
		foreach ( self::menu_tree() as $items ) {
			foreach ( $items as $k => $v ) {
				if ( is_array( $v ) ) {
					foreach ( array_keys( $v[1] ) as $ck ) {
						$out[ $ck ] = $k;
					}
				}
			}
		}
		return $out;
	}

	/** Drzewo dla formularza uprawnień: [{group, items:[{k,l,children:[{k,l}]}]}]. */
	public static function menu_tree_payload() {
		$out = array();
		foreach ( self::menu_tree() as $g => $items ) {
			$list = array();
			foreach ( $items as $k => $v ) {
				$row = array( 'k' => $k, 'l' => is_array( $v ) ? $v[0] : $v, 'children' => array() );
				if ( is_array( $v ) ) {
					foreach ( $v[1] as $ck => $cl ) {
						$row['children'][] = array( 'k' => $ck, 'l' => $cl );
					}
				}
				$list[] = $row;
			}
			$out[] = array( 'group' => $g, 'items' => $list );
		}
		return $out;
	}

	/** Sekcje widoczne domyślnie tylko dla administratora magazynu. */
	const ADMIN_ONLY = array( 'grafik', 'tablica', 'zamowienia', 'zam_dost', 'pz', 'import', 'logowania', 'uzytkownicy', 'kopia', 'szablony' );

	// Akcje (klucz => etykieta).
	public static function cap_keys() {
		return array(
			'edit'      => 'Dodawanie / edycja / usuwanie i pobrania bezpośrednie',
			'wz'        => 'Wystawianie WZ',
			'pz'        => 'Przyjęcia (PZ)',
			'import'    => 'Import danych',
			'inwentarz' => 'Szybki inwentarz',
			'przesylki' => 'Przesyłki – poprawianie i usuwanie wpisów',
			'produkcja' => 'Produkcja – usuwanie zleceń, detali i palet oraz import arkuszy',
			'elektro'   => 'Elektronarzędzia – dodawanie, edycja i sprawdzenia',
			'pomiar'    => 'Przyrządy pomiarowe – dodawanie, edycja i wzorcowania',
			'zamowienia' => 'Zamówienia do dostawców – tworzenie, wysyłka i zamykanie',
		);
	}

	/** Czy bieżąca osoba ma daną akcję (rola + nadpisania). */
	public static function cap_on( $key, $user = null ) {
		$user = $user ? $user : wp_get_current_user();
		$eff  = self::effective( $user );
		return ! empty( $eff['caps'][ $key ] );
	}

	/** Czy użytkownik ma rolę administratora magazynu (pełne domyślne uprawnienia). */
	private static function is_admin_user( $user ) {
		return $user && ( user_can( $user, 'msm_edit' ) || user_can( $user, 'manage_options' ) );
	}

	/** Domyślne uprawnienia wynikające z roli. */
	public static function defaults( $user ) {
		$admin = self::is_admin_user( $user );
		$menu  = array();
		foreach ( array_keys( self::menu_keys() ) as $k ) {
			// Przeglądający nie widzi sekcji administracyjnych.
			$admin_only = in_array( $k, self::ADMIN_ONLY, true );
			$menu[ $k ] = $admin ? true : ! $admin_only;
		}
		$menu['prod_karty'] = false; // Karty zmian: tylko dla wskazanych osób (włączane w Użytkownikach)
		$caps = array();
		foreach ( array_keys( self::cap_keys() ) as $k ) {
			$caps[ $k ] = $admin; // domyślnie tylko administrator
		}
		return array( 'menu' => $menu, 'caps' => $caps );
	}

	/** Efektywne uprawnienia (rola + zapisane nadpisania per-osoba). */
	public static function effective( $user ) {
		$user = is_numeric( $user ) ? get_user_by( 'id', (int) $user ) : $user;
		$def  = self::defaults( $user );
		$stored = $user ? get_user_meta( $user->ID, self::META, true ) : '';
		if ( is_array( $stored ) ) {
			foreach ( array( 'menu', 'caps' ) as $grp ) {
				if ( isset( $stored[ $grp ] ) && is_array( $stored[ $grp ] ) ) {
					foreach ( $stored[ $grp ] as $k => $v ) {
						if ( isset( $def[ $grp ][ $k ] ) ) {
							$def[ $grp ][ $k ] = (bool) $v;
						}
					}
				}
			}
		}
		return $def;
	}

	/** Zapis nadpisań (tylko znane klucze, wartości bool). */
	public static function save( $user_id, array $perms ) {
		$clean = array( 'menu' => array(), 'caps' => array() );
		foreach ( self::menu_keys() as $k => $_ ) {
			if ( isset( $perms['menu'][ $k ] ) ) {
				$clean['menu'][ $k ] = (bool) $perms['menu'][ $k ];
			}
		}
		foreach ( self::cap_keys() as $k => $_ ) {
			if ( isset( $perms['caps'][ $k ] ) ) {
				$clean['caps'][ $k ] = (bool) $perms['caps'][ $k ];
			}
		}
		update_user_meta( (int) $user_id, self::META, $clean );
	}

	/** Czy bieżący (lub wskazany) użytkownik może korzystać z akcji. */
	public static function user_can( $cap, $user = null ) {
		$user = $user ? $user : wp_get_current_user();
		$eff  = self::effective( $user );
		return ! empty( $eff['caps'][ $cap ] );
	}

	/** Czy bieżący (lub wskazany) użytkownik ma włączoną sekcję menu. */
	public static function menu_on( $key, $user = null ) {
		$user   = $user ? $user : wp_get_current_user();
		$eff    = self::effective( $user );
		$parent = self::menu_parents()[ $key ] ?? null;
		return ! empty( $eff['menu'][ $key ] ) && ( ! $parent || ! empty( $eff['menu'][ $parent ] ) );
	}

	/** Administrator WordPressa – jedyny, kogo nie ograniczają uprawnienia per-osoba. */
	public static function is_wp_admin( $user = null ) {
		$user = $user ? $user : wp_get_current_user();
		return $user && user_can( $user, 'manage_options' );
	}

	/**
	 * Przycina żądane uprawnienia do tych, które ma osoba nadająca
	 * (nie można dać komuś więcej, niż ma się samemu). Zwraca pełny zestaw kluczy.
	 */
	public static function clamp( array $perms, $actor = null ) {
		$actor = $actor ? $actor : wp_get_current_user();
		$own   = self::effective( $actor );
		$wp    = self::is_wp_admin( $actor );
		$out   = array( 'menu' => array(), 'caps' => array() );
		foreach ( array( 'menu' => self::menu_keys(), 'caps' => self::cap_keys() ) as $grp => $keys ) {
			foreach ( array_keys( $keys ) as $k ) {
				$want             = ! empty( $perms[ $grp ][ $k ] );
				$out[ $grp ][ $k ] = $want && ( $wp || ! empty( $own[ $grp ][ $k ] ) );
			}
		}
		return $out;
	}

	/** Czy osoba $actor ma co najmniej wszystkie uprawnienia osoby $target (warunek zarządzania jej kontem). */
	public static function covers( $actor, $target ) {
		if ( self::is_wp_admin( $actor ) ) {
			return true;
		}
		$a = self::effective( $actor );
		$t = self::effective( $target );
		foreach ( array( 'menu', 'caps' ) as $grp ) {
			foreach ( $t[ $grp ] as $k => $v ) {
				if ( $v && empty( $a[ $grp ][ $k ] ) ) {
					return false;
				}
			}
		}
		return true;
	}

	/** Payload dla front-endu (bieżący użytkownik). */
	public static function payload( $user = null ) {
		$eff = self::effective( $user ? $user : wp_get_current_user() );
		return $eff;
	}
}
