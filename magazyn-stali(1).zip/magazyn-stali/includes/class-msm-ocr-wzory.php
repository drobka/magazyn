<?php
/**
 * Zapamiętane układy dokumentów dostawców (OCR PZ/WZ): kolumny tabeli wskazane raz
 * dla dostawcy (klucz = NIP albo uproszczona nazwa). Używane w przeglądarce przy odczycie
 * kolejnych dokumentów tego dostawcy.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MSM_Ocr_Wzory {

	const OPT   = 'msm_ocr_wzory';
	const ROLES = array( 'lp', 'kod', 'nazwa', 'ilosc', 'jm', 'ilosc2', 'jm2' );

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
	}

	public static function routes() {
		$ns   = MSM_Rest::NS;
		$view = function () { return current_user_can( 'msm_view' ) ? true : new WP_Error( 'msm_forbidden', 'Brak dostępu.', array( 'status' => 403 ) ); };
		$edit = array( 'MSM_Rest', 'can_edit' );
		register_rest_route( $ns, '/ocr-wzory', array(
			array( 'methods' => 'GET', 'callback' => function () { return rest_ensure_response( array( 'wzory' => self::all() ) ); }, 'permission_callback' => $view ),
			array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'save_r' ), 'permission_callback' => $edit ),
		) );
		register_rest_route( $ns, '/ocr-wzory/delete', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'delete_r' ), 'permission_callback' => $edit ) );
	}

	public static function all() {
		$v = get_option( self::OPT, array() );
		return is_array( $v ) ? $v : array();
	}

	/** Klucz: 10 cyfr NIP albo „n:” + nazwa (małe litery, cyfry, spacje). */
	public static function key( $k ) {
		$k = strtolower( trim( (string) $k ) );
		if ( preg_match( '/^\d{10}$/', $k ) ) {
			return $k;
		}
		if ( 0 === strpos( $k, 'n:' ) ) {
			$n = trim( preg_replace( '/[^a-z0-9 ]+/', ' ', remove_accents( substr( $k, 2 ) ) ) );
			$n = preg_replace( '/\s+/', ' ', $n );
			return '' !== $n ? 'n:' . substr( $n, 0, 60 ) : '';
		}
		return '';
	}

	/** Kolumny: [{x 0–1000, t rola}] – co najmniej nazwa (lub kod) i ilość. */
	public static function clean_cols( $cols ) {
		$out = array();
		foreach ( (array) $cols as $c ) {
			$t = isset( $c['t'] ) ? (string) $c['t'] : '';
			$x = isset( $c['x'] ) ? (int) round( (float) $c['x'] ) : -1;
			if ( in_array( $t, self::ROLES, true ) && $x >= 0 && $x <= 1000 ) {
				$out[] = array( 'x' => $x, 't' => $t );
			}
		}
		usort( $out, function ( $a, $b ) { return $a['x'] - $b['x']; } );
		$types = wp_list_pluck( $out, 't' );
		if ( ! in_array( 'ilosc', $types, true ) || ( ! in_array( 'nazwa', $types, true ) && ! in_array( 'kod', $types, true ) ) ) {
			return new WP_Error( 'msm_400', 'Wskaż co najmniej kolumny Nazwa (albo Kod) i Ilość.', array( 'status' => 400 ) );
		}
		return array_slice( $out, 0, 12 );
	}

	public static function save_r( WP_REST_Request $r ) {
		$p    = (array) $r->get_json_params();
		$key  = self::key( $p['key'] ?? '' );
		$cols = self::clean_cols( $p['cols'] ?? array() );
		if ( '' === $key ) {
			return new WP_Error( 'msm_400', 'Brak NIP i nazwy dostawcy – podaj nazwę dostawcy.', array( 'status' => 400 ) );
		}
		if ( is_wp_error( $cols ) ) {
			return $cols;
		}
		$all         = self::all();
		$nowy        = ! isset( $all[ $key ] );
		$all[ $key ] = array(
			'nazwa' => mb_substr( sanitize_text_field( (string) ( $p['nazwa'] ?? '' ) ), 0, 180 ),
			'nip'   => preg_match( '/^\d{10}$/', (string) ( $p['nip'] ?? '' ) ) ? (string) $p['nip'] : '',
			'cols'  => $cols,
			'kto'   => wp_get_current_user()->display_name,
			'data'  => current_time( 'mysql' ),
		);
		if ( count( $all ) > 300 ) {
			uasort( $all, function ( $a, $b ) { return strcmp( $b['data'], $a['data'] ); } );
			$all = array_slice( $all, 0, 300, true );
		}
		update_option( self::OPT, $all, false );
		MSM_Repo::log( 'OCR: układ dostawcy', 'pz', 0, ( $nowy ? 'Zapamiętano' : 'Zmieniono' ) . ' układ dokumentów dostawcy ' . ( $all[ $key ]['nazwa'] ?: $key ) . ( $all[ $key ]['nip'] ? ' (NIP ' . $all[ $key ]['nip'] . ')' : '' ) );
		return rest_ensure_response( array( 'wzory' => $all ) );
	}

	public static function delete_r( WP_REST_Request $r ) {
		$key = self::key( ( (array) $r->get_json_params() )['key'] ?? '' );
		$all = self::all();
		if ( '' !== $key && isset( $all[ $key ] ) ) {
			$name = $all[ $key ]['nazwa'] ?: $key;
			unset( $all[ $key ] );
			update_option( self::OPT, $all, false );
			MSM_Repo::log( 'OCR: układ dostawcy', 'pz', 0, 'Usunięto zapamiętany układ dokumentów dostawcy ' . $name );
		}
		return rest_ensure_response( array( 'wzory' => $all ) );
	}
}
