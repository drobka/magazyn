<?php
/**
 * Produkcja – Karta projektu.
 * Dane z „Karty Informacyjnej projektu” (Excel) przechowywane przy zleceniu (JSON w msm_prod_zlec.karta),
 * odczyt karty z pliku .xlsx oraz tworzenie zlecenia na jej podstawie.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MSM_Karta {

	/** Pola tekstowe karty: klucz => [etykieta, maks. długość]. */
	const FIELDS = array(
		'nazwa_projektu' => array( 'Nazwa projektu', 255 ),
		'data_karty'     => array( 'Data karty', 20 ),
		'teczka'         => array( 'Teczka projektu', 190 ),
		'uwagi_kr'       => array( 'Uwagi (nagłówek)', 1000 ),
		'handlowy'       => array( 'Dział handlowy', 190 ),
		'kierownik'      => array( 'Kierownik projektu', 190 ),
		'inzynier'       => array( 'Inżynier projektu', 190 ),
		'platnosc'       => array( 'Warunki płatności', 190 ),
		'dostawa'        => array( 'Warunki dostawy (Incoterms 2020)', 20 ),
		'poza_ue'        => array( 'Wysyłka poza UE', 1 ),
		'eur1'           => array( 'EUR1', 1 ),
		'nabywca'        => array( 'Nabywca', 2000 ),
		'odbiorca'       => array( 'Odbiorca', 2000 ),
		'windykacja'     => array( 'Dane do windykacji', 2000 ),
	);

	/** Tabele karty: klucz => [etykieta, kolumny]. */
	const TABLES = array(
		'wymagania'  => array( 'Wymagania techniczne', array( 'lp', 'nazwa', 'rysunek', 'ilosc', 'material', 'grubosc', 'masa', 'pkwiu', 'cad' ) ),
		'dodatkowe'  => array( 'Wymagania dodatkowe', array( 'lp', 'kto', 'wymagania' ) ),
		'zmiany'     => array( 'Historia zmian karty', array( 'nr', 'data', 'powod', 'opis', 'wprowadzil', 'zatwierdzil' ) ),
	);

	/** Pola karty z prostym edytorem. */
	const RICH = array( 'nabywca', 'odbiorca' );

	const INCOTERMS = array( 'EXW', 'FCA', 'CPT', 'CIP', 'DPU', 'DAP', 'DDP', 'FAS', 'FOB', 'CFR', 'CIF' );

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
	}

	public static function routes() {
		$ns = MSM_Rest::NS;
		$p  = array( 'MSM_Prod', 'can' );
		register_rest_route( $ns, '/prod/karta/parse', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'parse_upload' ), 'permission_callback' => $p ) );
		register_rest_route( $ns, '/prod/order/(?P<id>\d+)/karta', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'save' ), 'permission_callback' => $p ) );
	}

	/* ------------------------------------------------------------------ *
	 * Model
	 * ------------------------------------------------------------------ */

	public static function blank() {
		$k = array();
		foreach ( self::FIELDS as $f => $_ ) {
			$k[ $f ] = '';
		}
		foreach ( self::TABLES as $t => $_ ) {
			$k[ $t ] = array();
		}
		return $k;
	}

	/** Oczyszczenie karty: tylko znane pola, teksty przycięte, tabele z ustalonymi kolumnami. */
	public static function clean( $in ) {
		$in  = is_array( $in ) ? $in : array();
		$out = self::blank();
		foreach ( self::FIELDS as $f => $def ) {
			$v = isset( $in[ $f ] ) && is_scalar( $in[ $f ] ) ? (string) $in[ $f ] : '';
			$v = trim( str_replace( "\r\n", "\n", wp_check_invalid_utf8( $v ) ) );
			if ( in_array( $f, array( 'poza_ue', 'eur1' ), true ) ) {
				$v = in_array( strtoupper( $v ), array( 'T', 'N' ), true ) ? strtoupper( $v ) : '';
			}
			if ( 'dostawa' === $f ) {
				$v = strtoupper( $v );
			}
			if ( in_array( $f, self::RICH, true ) ) {
				$v = MSM_Rich::clean( $v );
			}
			$out[ $f ] = mb_substr( $v, 0, $def[1] );
		}
		foreach ( self::TABLES as $t => $def ) {
			$rows = isset( $in[ $t ] ) && is_array( $in[ $t ] ) ? array_slice( array_values( $in[ $t ] ), 0, 200 ) : array();
			foreach ( $rows as $row ) {
				if ( ! is_array( $row ) ) {
					continue;
				}
				$r = array();
				foreach ( $def[1] as $c ) {
					$r[ $c ] = isset( $row[ $c ] ) && is_scalar( $row[ $c ] ) ? mb_substr( trim( str_replace( "\r\n", "\n", wp_check_invalid_utf8( (string) $row[ $c ] ) ) ), 0, 2000 ) : '';
				}
				$out[ $t ][] = $r;
			}
		}
		return $out;
	}

	public static function decode( $json ) {
		$d = json_decode( (string) $json, true );
		return self::clean( is_array( $d ) ? $d : array() );
	}

	public static function encode( array $karta ) {
		return wp_json_encode( self::clean( $karta ), JSON_UNESCAPED_UNICODE );
	}

	/* ------------------------------------------------------------------ *
	 * REST
	 * ------------------------------------------------------------------ */

	/** Zapis karty zlecenia (autozapis z zakładki „Karta projektu”). */
	public static function save( WP_REST_Request $r ) {
		global $wpdb;
		$id  = (int) $r['id'];
		$row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM `' . MSM_Prod::TZ() . '` WHERE id = %d', $id ), ARRAY_A ); // phpcs:ignore
		if ( ! $row ) {
			return new WP_Error( 'msm_404', 'Nie ma takiego zlecenia.', array( 'status' => 404 ) );
		}
		$p    = (array) $r->get_json_params();
		$old  = self::decode( $row['karta'] ?? '' );
		$new  = self::clean( $p['karta'] ?? array() );
		$upd  = array();
		if ( wp_json_encode( $old ) !== wp_json_encode( $new ) ) {
			$upd['karta'] = wp_json_encode( $new, JSON_UNESCAPED_UNICODE );
		}
		// Przy wczytaniu karty z Excela – także dane zlecenia (nr klienta, klient, daty, uwagi ogólne).
		$zf = isset( $p['z'] ) && is_array( $p['z'] ) ? $p['z'] : array();
		foreach ( array( 'nr_zlec_klienta', 'klient', 'start_zlec', 'koniec_zlec', 'uwagi_ogolne' ) as $f ) {
			if ( isset( $zf[ $f ] ) && is_scalar( $zf[ $f ] ) ) {
				$v = mb_substr( trim( wp_check_invalid_utf8( (string) $zf[ $f ] ) ), 0, 'uwagi_ogolne' === $f ? 5000 : 190 );
				if ( 'uwagi_ogolne' === $f ) {
					$v = MSM_Rich::clean( $v );
				}
				if ( (string) $row[ $f ] !== $v ) {
					$upd[ $f ] = $v;
				}
			}
		}
		if ( $upd ) {
			$upd['updated_at'] = current_time( 'mysql' );
			$upd['updated_by'] = get_current_user_id();
			$wpdb->update( MSM_Prod::TZ(), $upd, array( 'id' => $id ) );
			MSM_Repo::log( 'Produkcja: karta projektu', 'produkcja', $id, 'Zlecenie ' . ( '' !== $row['nr_zlec'] ? $row['nr_zlec'] : '#' . $id ) . ' – zmieniono kartę projektu: ' . implode( ', ', self::diff_labels( $old, $new, $upd ) ) );
		}
		return rest_ensure_response( array( 'order' => MSM_Prod::get_order_public( $id ) ) );
	}

	private static function diff_labels( array $old, array $new, array $upd ) {
		$l = array();
		foreach ( self::FIELDS as $f => $def ) {
			if ( $old[ $f ] !== $new[ $f ] ) {
				$l[] = $def[0];
			}
		}
		foreach ( self::TABLES as $t => $def ) {
			if ( wp_json_encode( $old[ $t ] ) !== wp_json_encode( $new[ $t ] ) ) {
				$l[] = $def[0];
			}
		}
		$zl = array( 'nr_zlec_klienta' => 'Nr zlec. klienta', 'klient' => 'Nazwa klienta', 'start_zlec' => 'Start', 'koniec_zlec' => 'Zakończenie', 'uwagi_ogolne' => 'Uwagi ogólne' );
		foreach ( $zl as $f => $lbl ) {
			if ( isset( $upd[ $f ] ) ) {
				$l[] = $lbl;
			}
		}
		return $l ? $l : array( 'drobne zmiany' );
	}

	/** Odczyt karty z przesłanego .xlsx – bez zapisu; zwraca podgląd do potwierdzenia. */
	public static function parse_upload( WP_REST_Request $r ) {
		global $wpdb;
		$files = $r->get_file_params();
		if ( empty( $files['file']['tmp_name'] ) || ! is_uploaded_file( $files['file']['tmp_name'] ) ) {
			return new WP_Error( 'msm_400', 'Nie przesłano pliku.', array( 'status' => 400 ) );
		}
		if ( ! preg_match( '/\.xlsx$/i', (string) $files['file']['name'] ) ) {
			return new WP_Error( 'msm_400', 'Wybierz plik .xlsx z kartą projektu (Excel 2007 lub nowszy).', array( 'status' => 400 ) );
		}
		$book = MSM_Xlsx::read( $files['file']['tmp_name'] );
		if ( is_wp_error( $book ) ) {
			$book->add_data( array( 'status' => 400 ) );
			return $book;
		}
		$res = self::from_book( $book );
		if ( is_wp_error( $res ) ) {
			$res->add_data( array( 'status' => 400 ) );
			return $res;
		}
		$res['exists'] = null;
		if ( '' !== $res['z']['nr_zlec'] ) {
			$e = $wpdb->get_row( $wpdb->prepare( 'SELECT id, nr_zlec, arkusz FROM `' . MSM_Prod::TZ() . '` WHERE nr_zlec = %s ORDER BY id DESC LIMIT 1', $res['z']['nr_zlec'] ), ARRAY_A ); // phpcs:ignore
			if ( $e ) {
				$res['exists'] = array( 'id' => (int) $e['id'], 'nr_zlec' => $e['nr_zlec'], 'rok' => $e['arkusz'] );
			}
		}
		$res['file'] = sanitize_file_name( (string) $files['file']['name'] );
		return rest_ensure_response( $res );
	}

	/* ------------------------------------------------------------------ *
	 * Odczyt karty z arkuszy (po etykietach, nie po sztywnych adresach komórek)
	 * ------------------------------------------------------------------ */

	/**
	 * @param array $book [ nazwa => [ wiersze ] ] z MSM_Xlsx::read
	 * @return array|WP_Error { z, karta, det, warnings }
	 */
	public static function from_book( array $book ) {
		$karta_ws = null;
		$lista_ws = null;
		foreach ( $book as $name => $rows ) {
			$n = mb_strtolower( (string) $name );
			if ( null === $karta_ws && ( false !== mb_strpos( $n, 'karta' ) || self::find( $rows, 'karta informacyjna' ) ) ) {
				$karta_ws = $rows;
			} elseif ( null === $lista_ws && ( false !== mb_strpos( $n, 'lista kontrolna' ) || self::find( $rows, 'lista kontrolna' ) ) ) {
				$lista_ws = $rows;
			}
		}
		if ( null === $karta_ws ) {
			return new WP_Error( 'msm_karta', 'W pliku nie ma arkusza „Karta projektu” (Karta Informacyjna projektu).' );
		}
		$S    = $karta_ws;
		$k    = self::blank();
		$warn = array();

		$z = array(
			'nr_zlec'         => self::label_val( $S, 'nr zlecenia', false ),
			'nr_zlec_klienta' => self::label_val( $S, 'nr zlecenia klienta', true ),
			'start_zlec'      => self::date( self::label_val( $S, 'początek projektu', false, true ) ),
			'koniec_zlec'     => self::date( self::label_val( $S, 'koniec projektu', false, true ) ),
			'klient'          => '',
			'uwagi_ogolne'    => '',
		);
		$k['nazwa_projektu'] = self::label_val( $S, 'nazwa projektu', false );
		$k['uwagi_kr']       = self::label_val( $S, 'uwagi', true );
		$k['handlowy']       = self::label_val( $S, 'dział handlowy', true );
		if ( '' === $k['handlowy'] ) {
			$k['handlowy'] = self::label_val( $S, 'dzial handlowy', true );
		}
		$k['kierownik'] = self::label_val( $S, 'kierownik projektu', true );
		$k['inzynier']  = self::label_val( $S, 'inżynier projektu', true );
		$pos = self::find( $S, 'data:' );
		if ( $pos ) {
			$k['data_karty'] = self::date( self::cell( $S, $pos[0] + 1, $pos[1] ) );
		}
		$pos = self::find( $S, 'karta informacyjna' );
		if ( $pos ) {
			$k['teczka'] = self::str( self::cell( $S, $pos[0] + 2, $pos[1] ) );
			if ( '' === $k['teczka'] ) {
				$k['teczka'] = self::str( self::cell( $S, $pos[0] + 1, $pos[1] ) );
			}
		}

		// Historia zmian: nagłówek „Zmiana | Data | Powód zmiany | Opis zmiany | Wprowadził | Zatwierdził”.
		$h = self::header( $S, array( 'zmiana' => 'nr', 'data' => 'data', 'powód' => 'powod', 'opis' => 'opis', 'wprowadził' => 'wprowadzil', 'zatwierdził' => 'zatwierdzil' ), 'powód' );
		if ( $h ) {
			for ( $r = $h['row'] + 1; $r < $h['row'] + 40; $r++ ) {
				if ( self::row_starts( $S, $r, array( 'wymagania' ) ) ) {
					break;
				}
				$row = self::take( $S, $r, $h['cols'], array( 'data' ) );
				if ( '' === $row['data'] && '' === $row['powod'] && '' === $row['opis'] ) {
					continue;
				}
				$k['zmiany'][] = $row;
			}
		}

		// Wymagania techniczne.
		$h = self::header( $S, array( 'lp' => 'lp', 'nazwa' => 'nazwa', 'rysunek cad' => 'cad', 'rysunek' => 'rysunek', 'ilość' => 'ilosc', 'materiał' => 'material', 'grubość' => 'grubosc', 'masa' => 'masa', 'pkwiu' => 'pkwiu' ), 'nazwa' );
		if ( $h ) {
			for ( $r = $h['row'] + 1; $r < $h['row'] + 200; $r++ ) {
				if ( self::row_starts( $S, $r, array( 'wymagania dodatkowe', 'uwagi' ) ) ) {
					break;
				}
				$row = self::take( $S, $r, $h['cols'] );
				if ( '' === $row['nazwa'] && '' === $row['rysunek'] && '' === $row['ilosc'] ) {
					continue;
				}
				$k['wymagania'][] = $row;
			}
		}
		if ( ! $k['wymagania'] ) {
			$warn[] = 'Karta nie ma pozycji w „Wymaganiach technicznych” – zlecenie dostanie jedną pustą pozycję.';
		}

		// Wymagania dodatkowe: „Lp. | Kto dostarcza materiał | Wymagania”.
		$h = self::header( $S, array( 'lp' => 'lp', 'kto dostarcza' => 'kto', 'wymagania' => 'wymagania' ), 'kto dostarcza' );
		if ( $h ) {
			for ( $r = $h['row'] + 1; $r < $h['row'] + 30; $r++ ) {
				if ( self::row_starts( $S, $r, array( 'uwagi' ) ) ) {
					break;
				}
				$row = self::take( $S, $r, $h['cols'] );
				if ( '' === $row['kto'] && '' === $row['wymagania'] ) {
					continue;
				}
				$k['dodatkowe'][] = $row;
			}
		}

		// UWAGI: numerowana lista → uwagi ogólne zlecenia.
		$pos = self::find( $S, 'uwagi:' );
		if ( $pos ) {
			$lines = array();
			for ( $r = $pos[0] + 1; $r <= $pos[0] + 60; $r++ ) {
				$txt = '';
				foreach ( (array) ( $S[ $r ] ?? array() ) as $ci => $v ) {
					$s = self::str( $v );
					if ( '' !== $s && ! is_numeric( $s ) ) {
						$txt = $s;
						break;
					}
				}
				if ( '' !== $txt ) {
					$lines[] = ( count( $lines ) + 1 ) . '. ' . $txt;
				}
			}
			$z['uwagi_ogolne'] = implode( "\n", $lines );
		}

		// Lista kontrolna: warunki handlowe, nabywca / odbiorca.
		if ( $lista_ws ) {
			$L               = $lista_ws;
			$k['platnosc']   = self::label_val( $L, 'warunki płatności', false );
			$k['dostawa']    = strtoupper( self::label_val( $L, 'warunki dostawy', false ) );
			$k['poza_ue']    = self::tn( $L, 'wysyłka poza' );
			$k['eur1']       = self::tn( $L, 'eur1' );
			$k['nabywca']    = self::block( $L, 'nabywca' );
			$k['odbiorca']   = self::block( $L, 'odbiorca' );
			$k['windykacja'] = self::block( $L, 'dane oraz e-mail do windykacji', 1 );
			$z['klient']     = trim( strtok( MSM_Rich::text( $k['nabywca'] ) . "\n", "\n" ) );
		} else {
			$warn[] = 'Brak arkusza „Lista kontrolna” – nazwę klienta i warunki handlowe uzupełnij ręcznie.';
		}
		if ( '' === $z['nr_zlec'] ) {
			$warn[] = 'Karta nie ma numeru zlecenia.';
		}

		$k = self::clean( $k );

		// Pozycje zlecenia z wymagań technicznych.
		$kl  = false;
		foreach ( $k['dodatkowe'] as $d ) {
			if ( false !== mb_stripos( $d['kto'], 'klient' ) ) {
				$kl = true;
			}
		}
		$det = array();
		foreach ( $k['wymagania'] as $w ) {
			$ilosc = MSM_Prod::to_int_public( $w['ilosc'] );
			$det[] = array(
				'nazwa_detalu' => $w['nazwa'],
				'nr_rysunku'   => $w['rysunek'],
				'ilosc_zam'    => null === $ilosc ? 0 : $ilosc,
				'material'     => self::material( $w['material'], $w['grubosc'] ),
				'mat_klienta'  => $kl ? 1 : 0,
			);
		}
		return array( 'z' => $z, 'karta' => $k, 'det' => $det, 'warnings' => $warn );
	}

	/** Materiał do pozycji: grubość dopisywana, chyba że to blacha elektrotechniczna (M250-50 = 0,5 mm w nazwie gatunku). */
	public static function material( $mat, $g ) {
		$mat = trim( preg_replace( '/\s+/u', ' ', (string) $mat ) );
		$g   = trim( str_replace( '.', ',', (string) $g ) );
		if ( '' === $g || preg_match( '/^M\d{3}-\d{2}/i', $mat ) || preg_match( '/\d\s*mm\b/i', $mat ) ) {
			return $mat;
		}
		return trim( $mat . ' ' . $g . 'mm' );
	}

	/* ---- pomocnicze ---- */

	private static function str( $v ) {
		if ( null === $v || is_bool( $v ) ) {
			return '';
		}
		if ( is_float( $v ) && floor( $v ) === $v && abs( $v ) < 1e15 ) {
			$v = (string) (int) $v;
		} elseif ( is_float( $v ) ) {
			$v = str_replace( '.', ',', (string) round( $v, 6 ) ); // 0.5 → „0,5”
		}
		return trim( str_replace( "\r\n", "\n", (string) $v ) );
	}

	private static function cell( array $S, $r, $c ) {
		return $S[ $r ][ $c ] ?? null;
	}

	/** Pierwsza komórka, której tekst zaczyna się od $text (bez wielkości liter). @return array|null [wiersz, kolumna] */
	private static function find( array $S, $text, $from = 0 ) {
		$text = mb_strtolower( $text );
		foreach ( $S as $ri => $row ) {
			if ( $ri < $from ) {
				continue;
			}
			foreach ( (array) $row as $ci => $v ) {
				if ( is_string( $v ) && 0 === mb_strpos( mb_strtolower( trim( $v ) ), $text ) ) {
					return array( $ri, $ci );
				}
			}
		}
		return null;
	}

	/** Etykieta o dokładnej treści i pierwsza niepusta wartość na prawo od niej (w obrębie swojej połowy formularza). */
	private static function label_val( array $S, $label, $right_half, $raw = false ) {
		$label = mb_strtolower( $label );
		foreach ( $S as $ri => $row ) {
			foreach ( (array) $row as $ci => $v ) {
				if ( ! is_string( $v ) || mb_strtolower( trim( $v ) ) !== $label ) {
					continue;
				}
				if ( $right_half !== ( $ci >= 15 ) ) {
					continue;
				}
				$end = $right_half ? $ci + 30 : 18;
				for ( $c = $ci + 1; $c <= $end; $c++ ) {
					$x = $row[ $c ] ?? null;
					if ( null !== $x && '' !== self::str( $x ) ) {
						return $raw ? $x : self::str( $x );
					}
				}
				return '';
			}
		}
		return '';
	}

	/** Wiersz nagłówka tabeli: [row, cols => [klucz => kolumna]]. $must – fragment, który musi być w nagłówku. */
	private static function header( array $S, array $map, $must ) {
		foreach ( $S as $ri => $row ) {
			$cols = array();
			$has  = false;
			foreach ( (array) $row as $ci => $v ) {
				if ( ! is_string( $v ) ) {
					continue;
				}
				$t = mb_strtolower( trim( preg_replace( '/\s+/u', ' ', $v ) ) );
				if ( false !== mb_strpos( $t, $must ) ) {
					$has = true;
				}
				foreach ( $map as $needle => $key ) {
					if ( ! isset( $cols[ $key ] ) && 0 === mb_strpos( $t, $needle ) ) {
						$cols[ $key ] = $ci;
						break;
					}
				}
			}
			if ( $has && count( $cols ) >= 3 ) {
				foreach ( $map as $key ) {
					if ( ! isset( $cols[ $key ] ) ) {
						$cols[ $key ] = -1;
					}
				}
				return array( 'row' => $ri, 'cols' => $cols );
			}
		}
		return null;
	}

	private static function take( array $S, $r, array $cols, array $dates = array() ) {
		$out = array();
		foreach ( $cols as $key => $ci ) {
			$v           = $ci >= 0 ? self::cell( $S, $r, $ci ) : null;
			$out[ $key ] = in_array( $key, $dates, true ) ? self::date( $v ) : self::str( $v );
		}
		return $out;
	}

	private static function row_starts( array $S, $r, array $prefixes ) {
		foreach ( (array) ( $S[ $r ] ?? array() ) as $v ) {
			if ( is_string( $v ) && '' !== trim( $v ) ) {
				$t = mb_strtolower( trim( $v ) );
				foreach ( $prefixes as $p ) {
					if ( 0 === mb_strpos( $t, $p ) ) {
						return true;
					}
				}
				return false;
			}
		}
		return false;
	}

	/** Pole „T / N” zaznaczone krzyżykiem w wierszu pod etykietami T i N. */
	private static function tn( array $S, $label ) {
		$pos = self::find( $S, $label );
		if ( ! $pos ) {
			return '';
		}
		list( $r, $c ) = $pos;
		for ( $cc = $c + 1; $cc <= $c + 12; $cc++ ) {
			$h = mb_strtoupper( self::str( self::cell( $S, $r, $cc ) ) );
			if ( 'T' === $h || 'N' === $h ) {
				if ( '' !== self::str( self::cell( $S, $r + 1, $cc ) ) ) {
					return $h;
				}
			} elseif ( '' !== $h && $cc > $c + 1 ) {
				break; // następne pole
			}
		}
		return '';
	}

	/** Blok adresowy pod etykietą (np. NABYWCA): kolejne niepuste komórki w tej samej kolumnie. */
	private static function block( array $S, $label, $skip = 0 ) {
		$pos = self::find( $S, $label );
		if ( ! $pos ) {
			return '';
		}
		list( $r, $c ) = $pos;
		$out   = array();
		$empty = 0;
		for ( $rr = $r + 1 + $skip; $rr <= $r + 12; $rr++ ) {
			$v = self::str( self::cell( $S, $rr, $c ) );
			if ( '' === $v ) {
				if ( $out && ++$empty >= 2 ) {
					break;
				}
				continue;
			}
			if ( preg_match( '/^(dane|adres)\b.*:$/iu', $v ) ) {
				if ( $out ) {
					break;
				}
				continue; // podpis pola, nie treść
			}
			if ( preg_match( '/^(lp\.|dane oraz)/iu', $v ) ) {
				break;
			}
			$empty = 0;
			$out[] = $v;
		}
		return trim( preg_replace( "/\n{2,}/", "\n", implode( "\n", $out ) ) );
	}

	/** Data z Excela (liczba seryjna albo tekst) → dd.mm.rrrr. */
	public static function date( $v ) {
		if ( null === $v || '' === $v ) {
			return '';
		}
		if ( is_numeric( $v ) && $v > 20000 && $v < 80000 ) {
			$ts = (int) round( ( (float) $v - 25569 ) * 86400 );
			return gmdate( 'd.m.Y', $ts );
		}
		$s = trim( (string) $v );
		if ( preg_match( '/^(\d{4})-(\d{2})-(\d{2})/', $s, $m ) ) {
			return $m[3] . '.' . $m[2] . '.' . $m[1];
		}
		return $s;
	}
}
