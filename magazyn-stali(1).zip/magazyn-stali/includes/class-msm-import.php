<?php
/**
 * Import zestawień z plików Excel (.xlsx). Rozpoznaje arkusze po nagłówkach kolumn.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MSM_Import {

	public static function hnorm( $s ) {
		$s = mb_strtoupper( (string) $s, 'UTF-8' );
		$s = preg_replace( '/\[[^\]]*\]/u', '', $s );
		return preg_replace( '/[^\p{L}\p{N}]+/u', '', $s );
	}

	/** Rozpoznaje typ arkusza na podstawie zestawu nagłówków. */
	private static function detect( array $h ) {
		$has = function ( $k ) use ( $h ) {
			return in_array( $k, $h, true );
		};
		if ( $has( 'OZNACZENIEBLACHY' ) || $has( 'OZNACZENIE' ) ) {
			return 'kregi';
		}
		if ( $has( 'OPIS' ) && ( $has( 'DŁUGOŚĆMB' ) || $has( 'DŁUGOŚĆ' ) ) ) {
			return 'stal';
		}
		if ( $has( 'DATA' ) || $has( 'KIEDY' ) ) {
			return 'skip';
		}
		if ( $has( 'MATERIAŁ' ) && ( $has( 'WYMIAR' ) || $has( 'WYMIARA' ) ) && $has( 'GRUBOŚĆ' ) ) {
			return 'blachy_pelne';
		}
		if ( ( $has( 'WYMIARA' ) || $has( 'WYMIARAŚR' ) ) && $has( 'GRUBOŚĆ' ) ) {
			return 'blachy_niepelne';
		}
		return null;
	}

	/**
	 * Analizuje plik i przygotowuje wiersze (bez zapisu).
	 *
	 * @return array|WP_Error
	 */
	public static function parse( $path ) {
		$book = MSM_Xlsx::read( $path );
		if ( is_wp_error( $book ) ) {
			return $book;
		}
		$schema = msm_schema();
		$report = array();

		foreach ( $book as $sheet_name => $rows ) {
			$entry = array( 'sheet' => $sheet_name, 'table' => null, 'rows' => array(), 'errors' => array(), 'skipped' => 0, 'note' => '' );

			// Szukamy wiersza nagłówków w pierwszych 20 wierszach.
			$table   = null;
			$hdr_row = null;
			$hdrs    = array();
			foreach ( $rows as $ri => $row ) {
				if ( $ri > 20 ) {
					break;
				}
				$h = array_map( array( __CLASS__, 'hnorm' ), $row );
				$t = self::detect( $h );
				if ( $t ) {
					$table   = $t;
					$hdr_row = $ri;
					$hdrs    = $h;
					break;
				}
			}

			if ( ! $table ) {
				$entry['note'] = 'Nie rozpoznano układu kolumn – arkusz pominięty.';
				$report[]      = $entry;
				continue;
			}
			if ( 'skip' === $table ) {
				$entry['note'] = 'Rejestr pobrań / historia – nie jest importowany (pobrania wprowadza się w aplikacji).';
				$report[]      = $entry;
				continue;
			}
			$entry['table'] = $table;
			$entry['label'] = $schema[ $table ]['label'];

			// Mapowanie kolumn arkusza → pola.
			$map = array();
			foreach ( $hdrs as $ci => $h ) {
				if ( '' === $h ) {
					continue;
				}
				if ( 'WYMIAR' === $h && 'blachy_pelne' === $table ) {
					$map[ $ci ] = '__wymiar';
					continue;
				}
				foreach ( $schema[ $table ]['cols'] as $c ) {
					if ( ! empty( $c['computed'] ) || empty( $c['aliases'] ) ) {
						continue;
					}
					if ( in_array( $h, $c['aliases'], true ) && ! in_array( $c['key'], $map, true ) ) {
						$map[ $ci ] = $c['key'];
						break;
					}
				}
			}

			foreach ( $rows as $ri => $row ) {
				if ( $ri <= $hdr_row ) {
					continue;
				}
				$in    = array();
				$empty = true;
				foreach ( $map as $ci => $key ) {
					$v = array_key_exists( $ci, $row ) ? $row[ $ci ] : null;
					if ( is_string( $v ) ) {
						$v = trim( $v );
					}
					if ( null !== $v && '' !== $v ) {
						$empty = false;
					}
					$in[ $key ] = $v;
				}
				if ( $empty ) {
					continue;
				}

				// Wymiar "1250x2500" → A, B.
				if ( array_key_exists( '__wymiar', $in ) ) {
					$w = (string) $in['__wymiar'];
					unset( $in['__wymiar'] );
					if ( preg_match( '/([\d.,]+)\s*[xX×*]\s*([\d.,]+)/u', $w, $m ) ) {
						$in['wymiar_a'] = $m[1];
						$in['wymiar_b'] = $m[2];
					} elseif ( '' !== $w ) {
						$in['wymiar_a'] = $w;
					}
				}
				// "FI 450" → koło Ø450.
				if ( 'blachy_niepelne' === $table && isset( $in['wymiar_a'] ) && is_string( $in['wymiar_a'] ) && preg_match( '/^(FI|Ø|FI\.|ŚR\.?)\s*([\d.,]+)$/iu', $in['wymiar_a'], $m ) ) {
					$in['ksztalt']  = 'koło';
					$in['wymiar_a'] = $m[2];
				}

				$clean = MSM_Repo::sanitize( $table, $in );
				// Nieczytelna liczba (np. "./") → puste pole + notatka w uwagach, zamiast gubić wiersz.
				if ( is_wp_error( $clean ) ) {
					$fields = (array) ( $clean->get_error_data()['fields'] ?? array() );
					$fixed  = false;
					foreach ( $fields as $k => $msg ) {
						$col = msm_col( $table, $k );
						if ( $col && in_array( $col['type'], array( 'num', 'int' ), true ) && empty( $col['required'] ) && isset( $in[ $k ] ) && is_string( $in[ $k ] ) ) {
							$in['uwagi'] = trim( ( isset( $in['uwagi'] ) ? $in['uwagi'] . ' | ' : '' ) . 'import: ' . $col['label'] . ' = „' . $in[ $k ] . '”' );
							$in[ $k ]    = null;
							$fixed       = true;
						}
					}
					if ( $fixed ) {
						$clean = MSM_Repo::sanitize( $table, $in );
						if ( ! is_wp_error( $clean ) ) {
							$entry['errors'][] = 'Wiersz ' . ( $ri + 1 ) . ' – nieczytelna liczba, pole pozostawiono puste (opis w uwagach).';
						}
					}
				}
				if ( is_wp_error( $clean ) ) {
					$data = $clean->get_error_data();
					$msgs = array();
					foreach ( (array) ( $data['fields'] ?? array() ) as $k => $msg ) {
						$col    = msm_col( $table, $k );
						$msgs[] = ( $col ? $col['label'] : $k ) . ': ' . $msg;
					}
					$entry['errors'][] = 'Wiersz ' . ( $ri + 1 ) . ' – ' . implode( '; ', $msgs );
					$entry['skipped']++;
					continue;
				}
				$entry['rows'][] = $clean;
			}
			$report[] = $entry;
		}
		return $report;
	}

	/**
	 * Zapisuje przeanalizowane dane.
	 *
	 * @param string $mode append|replace
	 */
	public static function apply( array $report, $mode = 'append', $source = '' ) {
		global $wpdb;
		$summary = array();
		$by      = array();
		foreach ( $report as $e ) {
			if ( ! empty( $e['table'] ) && $e['rows'] ) {
				$by[ $e['table'] ][] = $e;
			}
		}
		foreach ( $by as $table => $entries ) {
			$wpdb->query( 'START TRANSACTION' );
			$removed = 0;
			if ( 'replace' === $mode ) {
				$removed = (int) $wpdb->query( 'DELETE FROM `' . msm_table( $table ) . '`' ); // phpcs:ignore
			}
			$added = 0;
			foreach ( $entries as $e ) {
				foreach ( $e['rows'] as $row ) {
					if ( MSM_Repo::insert_raw( $table, $row ) ) {
						$added++;
					}
				}
			}
			$wpdb->query( 'COMMIT' );
			$txt = 'Import' . ( $source ? ' z pliku ' . $source : '' ) . ': dodano ' . $added . ' poz.' . ( 'replace' === $mode ? ', usunięto poprzednie ' . $removed . ' poz.' : '' );
			MSM_Repo::log( 'import', $table, 0, $txt );
			$summary[ $table ] = array( 'added' => $added, 'removed' => $removed );
		}
		return $summary;
	}

	/** Raport bez danych wierszy – do wyświetlenia. */
	public static function public_report( array $report ) {
		return array_map( function ( $e ) {
			$e['count'] = count( $e['rows'] );
			unset( $e['rows'] );
			$e['errors'] = array_slice( $e['errors'], 0, 50 );
			return $e;
		}, $report );
	}
}
