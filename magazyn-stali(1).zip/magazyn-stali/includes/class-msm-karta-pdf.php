<?php
/**
 * Karta zlecenia – wydruk PDF (A4): dane projektu z Produkcji, podsumowanie i tabele
 * pobrań, wniosków, pozycji WZ, rezerwacji i przesyłek przychodzących do zlecenia.
 * Styl jak PDF zamówienia do dostawcy (MSM_Pdf).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MSM_Karta_Pdf {

	const L   = 36;
	const TOP = 40;
	const BOT = 58; // miejsce na stopkę

	/** @var MSM_Pdf */
	private $pdf;
	private $y    = 0;
	private $page = 1;
	private $nr   = '';

	public static function init() {
		add_action( 'rest_api_init', function () {
			register_rest_route( MSM_Rest::NS, '/zlecenie/(?P<nr>[^/]+)/pdf', array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'pdf_r' ),
				'permission_callback' => MSM_Rest::view_section( 'zlecenie' ),
			) );
		} );
	}

	public static function file_name( $nr ) {
		return 'karta-zlecenia-' . sanitize_file_name( str_replace( array( ' ', '/' ), '-', $nr ) ) . '.pdf';
	}

	public static function pdf_r( WP_REST_Request $r ) {
		$nr = trim( urldecode( (string) $r['nr'] ) );
		$d  = MSM_Reports::zlecenie( $nr );
		$k  = new self();
		$bin = $k->build( $d );
		nocache_headers();
		header( 'Content-Type: application/pdf' );
		header( 'Content-Disposition: ' . ( $r->get_param( 'pobierz' ) ? 'attachment' : 'inline' ) . '; filename="' . self::file_name( $d['nr'] ? $d['nr'] : $nr ) . '"' );
		header( 'Content-Length: ' . strlen( $bin ) );
		echo $bin; // phpcs:ignore
		exit;
	}

	private function R() {
		return MSM_Pdf::W - self::L;
	}

	/* ---------------- budowa dokumentu ---------------- */

	public function build( array $d ) {
		$this->nr  = (string) $d['nr'];
		$this->pdf = new MSM_Pdf();
		$this->pdf->add_page();
		$p = $this->pdf;
		$L = self::L;
		$R = $this->R();
		$y = 34;

		// Nagłówek: logo + firma, tytuł, data wydruku.
		$h = $p->image( MSM_DIR . 'assets/logo-mail.png', $L, $y, 140 );
		$p->font( 'n', 9 )->text( $R, $y + 10, msm_opt( 'firma_nazwa' ), '1a2233', 'R' )->text( $R, $y + 22, msm_opt( 'firma_adres' ), '6b7285', 'R' );
		$y += max( 44, is_numeric( $h ) ? $h + 12 : 44 );
		$P  = $d['projekt'] ?? null;
		$p->font( 'b', 8 )->text( $L, $y + 2, 'KARTA ZLECENIA', '6b7285' );
		$p->font( 'b', 20 )->text( $L, $y + 22, 'Zlecenie ' . $this->nr );
		$p->font( 'n', 9 )->text( $R, $y + 22, 'Wydrukowano ' . current_time( 'd.m.Y H:i' ), '6b7285', 'R' );
		$y += 30;
		if ( $P && '' !== trim( $P['nazwa'] ) ) {
			foreach ( $p->font( 'n', 11 )->wrap( $P['nazwa'], $R - $L ) as $t ) {
				$p->text( $L, $y + 10, $t, '3a4256' );
				$y += 14;
			}
		}
		$y += 10;

		// Dane projektu – 4 pola w ramce.
		if ( $P ) {
			$f  = array(
				array( 'Klient', $P['klient'] ),
				array( 'Nr zlecenia klienta', $P['nr_zlec_klienta'] ),
				array( 'Start projektu', $P['start'] ),
				array( 'Koniec projektu', $P['koniec'] ),
			);
			$cw = ( $R - $L ) / 4;
			$bh = 40;
			foreach ( $f as $i => $v ) {
				$lines = $p->font( 'b', 10 )->wrap( '' !== trim( (string) $v[1] ) ? (string) $v[1] : '—', $cw - 20 );
				$bh    = max( $bh, 26 + count( $lines ) * 12 );
			}
			$p->rect( $L, $y, $R - $L, $bh, 'f6f7f9', 'e3e6ec' );
			foreach ( $f as $i => $v ) {
				$x = $L + $i * $cw;
				if ( $i ) {
					$p->line( $x, $y + 6, $x, $y + $bh - 6, 'e3e6ec' );
				}
				$p->font( 'b', 7.5 )->text( $x + 10, $y + 14, mb_strtoupper( $v[0] ), '6b7285' );
				$val = '' !== trim( (string) $v[1] ) ? (string) $v[1] : '—';
				foreach ( $p->font( 'b', 10 )->wrap( $val, $cw - 20 ) as $j => $t ) {
					$p->text( $x + 10, $y + 28 + $j * 12, $t, '' !== trim( (string) $v[1] ) ? '1a2233' : '9aa0ad' );
				}
			}
			$y += $bh + 12;
		}

		// Podsumowanie (liczby pozycji) – „pigułki”.
		$prz   = is_array( $d['przesylki'] ?? null ) ? $d['przesylki'] : null;
		$chips = array( 'Pobrania' => count( $d['pobrania'] ), 'Wnioski' => count( $d['wnioski'] ), 'Pozycje WZ' => count( $d['wz'] ), 'Rezerwacje' => count( $d['rezerwacje'] ?? array() ) );
		if ( null !== $prz ) {
			$chips['Przesyłki'] = count( $prz );
		}
		$x = $L;
		foreach ( $chips as $lbl => $n ) {
			$t = $lbl . ': ' . $n;
			$w = $p->font( 'b', 8.5 )->width( $t ) + 18;
			$p->rect( $x, $y, $w, 17, $n ? 'eef3fc' : 'f4f5f7', $n ? 'd5e1f7' : 'e6e8ec' )->text( $x + 9, $y + 11.8, $t, $n ? '1f3f8f' : '8a90a0' );
			$x += $w + 6;
		}
		$s = $d['sumy'] ?? array();
		$sum = array();
		if ( ! empty( $s['kg'] ) ) {
			$sum[] = MSM_Calc::fmt( $s['kg'] ) . ' kg';
		}
		if ( ! empty( $s['mb'] ) ) {
			$sum[] = MSM_Calc::fmt( $s['mb'] ) . ' mb';
		}
		if ( ! empty( $s['szt'] ) ) {
			$sum[] = MSM_Calc::fmt( $s['szt'] ) . ' szt.';
		}
		if ( $sum ) {
			$st = 'Pobrano razem: ' . implode( ' · ', $sum );
			if ( $x + $p->font( 'n', 8.5 )->width( $st ) + 10 > $R ) { // nie mieści się obok – w kolejnej linii
				$y += 22;
				$p->font( 'n', 8.5 )->text( $L, $y + 11.8, $st, '4a5263' );
			} else {
				$p->font( 'n', 8.5 )->text( $R, $y + 11.8, $st, '4a5263', 'R' );
			}
		}
		$this->y = $y + 30;

		$empty = ! $d['pobrania'] && ! $d['wnioski'] && ! $d['wz'] && empty( $d['rezerwacje'] ) && empty( $prz );
		if ( $empty ) {
			$p->font( 'n', 10 )->text( $L, $this->y + 10, 'Brak pobrań, wniosków, pozycji WZ, rezerwacji i przesyłek dla tego zlecenia.', '6b7285' );
		}
		$this->sections( $d, $prz );
		$this->footer();
		return $p->output( 'Karta zlecenia ' . $this->nr );
	}

	private function sections( array $d, $prz ) {
		$ilo = function ( $r ) {
			$j = (string) ( $r['jednostka'] ?? '' );
			return MSM_Calc::fmt( $r['ilosc'] ) . ' ' . ( 'szt' === $j ? 'szt.' : $j );
		};
		$dt  = function ( $v ) { return $v ? mysql2date( 'd.m.Y', $v ) : '—'; };
		$sch = msm_schema();
		$mag = function ( $t ) use ( $sch ) { return $sch[ $t ]['label'] ?? (string) $t; };

		$this->table( 'Pobrania', $d['pobrania'], array(
			array( 'Data', 58, function ( $r ) use ( $dt ) { return $dt( $r['data'] ); } ),
			array( 'Magazyn', 70, function ( $r ) use ( $mag ) { return $mag( $r['tabela'] ); } ),
			array( 'Materiał', 0, function ( $r ) {
				$o = 'odcinek' === ( $r['tryb'] ?? '' ) && ! empty( $r['odc_szt'] ) ? ' (' . (int) $r['odc_szt'] . ' szt. × ' . MSM_Calc::fmt( $r['odc_dl'] ) . ' m)' : '';
				return (string) $r['material'] . $o;
			}, 'b' ),
			array( 'Ilość', 58, $ilo, 'b', 'R' ),
			array( 'Dla kogo', 78, function ( $r ) { return (string) $r['odbiorca']; } ),
			array( 'Wprowadził', 74, function ( $r ) { return (string) $r['user_name']; } ),
		), function ( $r ) { return (string) $r['uwagi']; } );

		$wl = MSM_Wnioski::labels();
		$this->table( 'Wnioski', $d['wnioski'], array(
			array( 'Data', 58, function ( $r ) use ( $dt ) { return $dt( $r['data'] ); } ),
			array( 'Wnioskujący', 74, function ( $r ) { return (string) $r['user_name']; } ),
			array( 'Materiał', 0, function ( $r ) { return (string) $r['material'] . ( 'sprawdzenie' === $r['typ'] ? ' (sprawdzenie stanu)' : '' ) . ( $r['rysunek'] ? ' · rys. ' . $r['rysunek'] : '' ); }, 'b' ),
			array( 'Ilość', 54, $ilo, 'b', 'R' ),
			array( 'Status', 78, function ( $r ) use ( $wl ) { return $wl[ $r['status'] ] ?? (string) $r['status']; }, 'st' ),
			array( 'Rozpatrzył', 74, function ( $r ) { return (string) $r['decided_name']; } ),
		), function ( $r ) { return trim( ( $r['admin_note'] ? 'Odpowiedź: ' . $r['admin_note'] : '' ) . ( $r['uwagi'] ? ( $r['admin_note'] ? ' · ' : '' ) . 'Cel: ' . $r['uwagi'] : '' ) ); } );

		$zl = MSM_WZ::labels();
		$this->table( 'Pozycje WZ', $d['wz'], array(
			array( 'WZ', 70, function ( $r ) { return $r['numer'] ? ( preg_match( '/^WZ\b/', $r['numer'] ) ? $r['numer'] : 'WZ ' . $r['numer'] ) : 'szkic'; }, 'b' ),
			array( 'Data', 58, function ( $r ) use ( $dt ) { return $dt( $r['data_wysylki'] ); } ),
			array( 'Odbiorca', 92, function ( $r ) { return (string) $r['odbiorca']; } ),
			array( 'Materiał', 0, function ( $r ) { return trim( ( $r['indeks'] ? $r['indeks'] . ' · ' : '' ) . $r['material'] . ( $r['rysunek'] ? ' · rys. ' . $r['rysunek'] : '' ) . ( 'magazyn' === $r['src'] ? ' (z magazynu)' : '' ) ); } ),
			array( 'Ilość', 54, $ilo, 'b', 'R' ),
			array( 'Status', 70, function ( $r ) use ( $zl ) { return $zl[ $r['status'] ] ?? (string) $r['status']; }, 'st' ),
		), function ( $r ) { return (string) $r['uwagi']; } );

		$rl = MSM_Rezerwacje::labels();
		$this->table( 'Rezerwacje', $d['rezerwacje'] ?? array(), array(
			array( 'Złożono', 58, function ( $r ) use ( $dt ) { return $dt( $r['created_at'] ); } ),
			array( 'Materiał', 0, function ( $r ) { return (string) $r['material']; }, 'b' ),
			array( 'Ilość', 54, function ( $r ) { return MSM_Calc::fmt( $r['ilosc'] ) . ( 'odcinek' === $r['tryb'] ? ' m' : ' szt.' ); }, 'b', 'R' ),
			array( 'Termin', 56, function ( $r ) use ( $dt ) { return $r['termin'] ? $dt( $r['termin'] ) : 'bez terminu'; } ),
			array( 'Status', 62, function ( $r ) use ( $rl ) { return $rl[ $r['status'] ] ?? (string) $r['status']; }, 'st' ),
			array( 'Zarezerwował', 74, function ( $r ) { return (string) $r['user_name']; } ),
			array( 'Rozpatrzył', 74, function ( $r ) { return (string) $r['decided_name']; } ),
		), function ( $r ) { return (string) $r['uwagi']; } );

		if ( is_array( $prz ) ) {
			$this->table( 'Przesyłki przychodzące', $prz, array(
				array( 'Dostawa', 66, function ( $r ) { return $r['data_spr'] ? mysql2date( 'd.m.Y H:i', $r['data_spr'] ) : '—'; } ),
				array( 'Nadawca', 96, function ( $r ) { return (string) $r['nadawca']; }, 'b' ),
				array( 'Zawartość', 0, function ( $r ) {
					$t = array();
					foreach ( (array) $r['pozycje'] as $x ) {
						$il  = null === ( $x['ilosc'] ?? null ) ? '' : MSM_Calc::fmt( $x['ilosc'] ) . ( ! empty( $x['jedn'] ) ? ' ' . $x['jedn'] : '' );
						$t[] = trim( ( $x['opis'] ? $x['opis'] : '—' ) . ( '' !== $il ? ' · ' . $il : '' ) );
					}
					return implode( '; ', $t ) . ( ! empty( $r['inne'] ) ? ' (+ ' . (int) $r['inne'] . ' poz. do innych zleceń)' : '' );
				} ),
				array( 'Faktura', 44, function ( $r ) { return $r['faktura'] ? 'tak' : 'nie'; } ),
				array( 'Stan', 58, function ( $r ) { return $r['uszkodzona'] ? 'uszkodzona' : 'bez uwag'; }, 'st' ),
				array( 'Sprawdził', 70, function ( $r ) { return (string) $r['sprawdzil']; } ),
			), function ( $r ) { return (string) $r['uwagi']; } );
		}
	}

	/* ---------------- tabela z łamaniem stron ---------------- */

	/**
	 * @param array    $cols [ etykieta, szerokość (0 = reszta), fn(row), styl ('b' pogrubiony, 'st' status), wyrównanie ]
	 * @param callable $note opcjonalna linia uwag pod wierszem
	 */
	private function table( $title, array $rows, array $cols, $note = null ) {
		if ( ! $rows ) {
			return;
		}
		$p   = $this->pdf;
		$L   = self::L;
		$R   = $this->R();
		$fix = 0;
		foreach ( $cols as $c ) {
			$fix += $c[1];
		}
		foreach ( $cols as $i => $c ) {
			if ( ! $c[1] ) {
				$cols[ $i ][1] = $R - $L - $fix;
			}
		}
		$this->need( 70 );
		$p->font( 'b', 11 )->text( $L, $this->y + 10, $title );
		$p->font( 'n', 9 )->text( $L + $p->font( 'b', 11 )->width( $title ) + 6, $this->y + 10, '(' . count( $rows ) . ')', '8a90a0' );
		$this->y += 18;
		$head = function () use ( $p, $cols, $L, $R ) {
			$p->rect( $L, $this->y, $R - $L, 18, 'f1f3f7' );
			$x = $L;
			foreach ( $cols as $c ) {
				$al = $c[4] ?? 'L';
				$p->font( 'b', 7.5 )->text( 'R' === $al ? $x + $c[1] - 5 : $x + 5, $this->y + 12, mb_strtoupper( $c[0] ), '4a5263', $al );
				$x += $c[1];
			}
			$this->y += 18;
		};
		$head();
		foreach ( $rows as $i => $r ) {
			$cells = array();
			$lines = 1;
			foreach ( $cols as $c ) {
				$v       = trim( (string) call_user_func( $c[2], $r ) );
				$v       = '' === $v ? '—' : $v;
				$st      = $c[3] ?? '';
				$wr      = $p->font( 'b' === $st ? 'b' : 'n', 8.5 )->wrap( $v, $c[1] - 10 );
				$cells[] = array( $wr, $st, $v );
				$lines   = max( $lines, count( $wr ) );
			}
			$nt  = $note ? trim( (string) call_user_func( $note, $r ) ) : '';
			$nw  = '' !== $nt ? $p->font( 'n', 7.5 )->wrap( $nt, $R - $L - $cols[0][1] - 10 ) : array();
			$rh  = $lines * 11 + 9 + ( $nw ? count( $nw ) * 9.5 + 2 : 0 );
			if ( $this->y + $rh > MSM_Pdf::H - self::BOT ) {
				$this->new_page();
				$p->font( 'b', 9 )->text( $L, $this->y + 8, $title . ' – ciąg dalszy', '6b7285' );
				$this->y += 14;
				$head();
			}
			if ( $i % 2 ) {
				$p->rect( $L, $this->y, $R - $L, $rh, 'fafbfc' );
			}
			$x  = $L;
			$by = $this->y + 13;
			foreach ( $cols as $k => $c ) {
				list( $wr, $st, $v ) = $cells[ $k ];
				$al = $c[4] ?? 'L';
				$co = '—' === $v ? '9aa0ad' : '1a2233';
				if ( 'st' === $st ) {
					$co = self::status_color( $v );
				}
				foreach ( $wr as $j => $t ) {
					$p->font( 'b' === $st || 'st' === $st ? 'b' : 'n', 8.5 )->text( 'R' === $al ? $x + $c[1] - 5 : $x + 5, $by + $j * 11, $t, $co, $al );
				}
				$x += $c[1];
			}
			foreach ( $nw as $j => $t ) {
				$p->font( 'n', 7.5 )->text( $L + $cols[0][1] + 5, $by + $lines * 11 + $j * 9.5, $t, '6b7285' );
			}
			$this->y += $rh;
			$p->line( $L, $this->y, $R, $this->y, 'e3e6ec', 0.5 );
		}
		$this->y += 18;
	}

	private static function status_color( $v ) {
		$f = mb_strtolower( $v );
		if ( preg_match( '/odrzuc|anulow|uszkodz|brak|wygas/u', $f ) ) {
			return 'b3261e';
		}
		if ( preg_match( '/wydan|wystawion|jest na stanie|bez uwag|aktywn/u', $f ) ) {
			return '1c7a43';
		}
		return '7a4d00';
	}

	private function need( $h ) {
		if ( $this->y + $h > MSM_Pdf::H - self::BOT ) {
			$this->new_page();
		}
	}

	private function new_page() {
		$this->footer();
		$this->pdf->add_page();
		$this->page++;
		$this->y = self::TOP;
		$this->pdf->font( 'b', 8 )->text( self::L, $this->y - 12, 'KARTA ZLECENIA ' . mb_strtoupper( $this->nr ), '8a90a0' );
		$this->y += 4;
	}

	private function footer() {
		$p = $this->pdf;
		$L = self::L;
		$R = $this->R();
		$p->line( $L, MSM_Pdf::H - 40, $R, MSM_Pdf::H - 40, 'e3e6ec' )
			->font( 'n', 7.5 )->text( $L, MSM_Pdf::H - 28, '© ' . msm_opt( 'firma_nazwa' ) . ' · Karta zlecenia ' . $this->nr, '8a90a0' )
			->text( $R, MSM_Pdf::H - 28, 'Strona ' . $this->page, '8a90a0', 'R' );
	}
}
