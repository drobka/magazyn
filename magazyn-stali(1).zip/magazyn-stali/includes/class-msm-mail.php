<?php
/**
 * Szablony e-maili wysyłanych przez system (prośby o wydanie, sprawdzenie, powiadomienia).
 * Treść jest w formacie HTML (edytowalna prostym edytorem). Pola w nawiasach {…} są podmieniane
 * na dane; wartości są bezpiecznie escapowane, oprócz pól oznaczonych jako „raw” (np. link {url}).
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MSM_Mail {

	const OPT = 'msm_mail_templates';

	/** Definicje szablonów: etykieta, opis, pola, pola-HTML (raw), domyślny temat i treść (HTML). */
	public static function defs() {
		return array(
			'wniosek_admin' => array(
				'label' => 'Prośba o wydanie – do magazynu',
				'desc'  => 'Trafia do administratorów magazynu, gdy pracownik złoży wniosek o pobranie materiału.',
				'vars'  => array(
					'user_name' => 'Imię i nazwisko wnioskodawcy',
					'material'  => 'Materiał',
					'ilosc'     => 'Ilość z jednostką',
					'zlecenie'  => 'Numer zlecenia',
					'cel'       => 'Cel / uwagi',
					'data'      => 'Data złożenia',
					'url'       => 'Link do wniosków w aplikacji',
				),
				'raw'     => array( 'url' ),
				'subject' => 'Nowy wniosek o pobranie od {user_name}',
				'body'    => "<p>{user_name} chce pobrać z magazynu:</p>\n<p><strong>Materiał:</strong> {material}<br>\n<strong>Ilość:</strong> {ilosc}<br>\n<strong>Zlecenie:</strong> {zlecenie}<br>\n<strong>Cel:</strong> {cel}<br>\n<strong>Złożono:</strong> {data}</p>\n<p>Zaakceptuj lub odrzuć wniosek w magazynie:<br>{url}</p>",
			),
			'sprawdzenie_admin' => array(
				'label' => 'Prośba o sprawdzenie stanu – do magazynu',
				'desc'  => 'Trafia do administratorów, gdy pracownik prosi o sprawdzenie, czy materiał jest fizycznie na stanie (bez pobierania).',
				'vars'  => array(
					'user_name' => 'Imię i nazwisko wnioskodawcy',
					'material'  => 'Materiał',
					'ilosc'     => 'Ilość z jednostką',
					'zlecenie'  => 'Numer zlecenia',
					'cel'       => 'Cel / uwagi',
					'data'      => 'Data złożenia',
					'url'       => 'Link do wniosków w aplikacji',
				),
				'raw'     => array( 'url' ),
				'subject' => 'Prośba o sprawdzenie stanu od {user_name}',
				'body'    => "<p>{user_name} prosi o sprawdzenie, czy materiał jest fizycznie na stanie (bez pobierania):</p>\n<p><strong>Materiał:</strong> {material}<br>\n<strong>Ilość:</strong> {ilosc}<br>\n<strong>Zlecenie:</strong> {zlecenie}<br>\n<strong>Cel:</strong> {cel}<br>\n<strong>Złożono:</strong> {data}</p>\n<p>Odpowiedz „Jest na stanie” albo „Brak na stanie” w magazynie:<br>{url}</p>",
			),
			'wniosek_status' => array(
				'label' => 'Odpowiedź na wniosek o wydanie – do wnioskodawcy',
				'desc'  => 'Wysyłana do wnioskodawcy, gdy zmieni się status jego wniosku o pobranie (zaakceptowany, odrzucony, wydany).',
				'vars'  => array(
					'id'           => 'Numer wniosku',
					'status'       => 'Nowy status wniosku',
					'material'     => 'Materiał',
					'ilosc'        => 'Ilość z jednostką',
					'zlecenie'     => 'Numer zlecenia',
					'decided_name' => 'Kto rozpatrzył',
					'odpowiedz'    => 'Odpowiedź/komentarz administratora (jeśli jest)',
					'url'          => 'Link / odnośnik w aplikacji',
				),
				'raw'     => array( 'url', 'odpowiedz' ),
				'subject' => 'Wniosek #{id} – {status}',
				'body'    => "<p>Twój wniosek o pobranie zmienił status: <strong>{status}</strong></p>\n<p><strong>Materiał:</strong> {material}<br>\n<strong>Ilość:</strong> {ilosc}<br>\n<strong>Zlecenie:</strong> {zlecenie}<br>\n<strong>Rozpatrzył:</strong> {decided_name}</p>\n{odpowiedz}\n<p>{url}</p>",
			),
			'sprawdzenie_status' => array(
				'label' => 'Odpowiedź na sprawdzenie stanu – do wnioskodawcy',
				'desc'  => 'Wysyłana do wnioskodawcy po sprawdzeniu stanu (jest na stanie / brak).',
				'vars'  => array(
					'id'           => 'Numer zgłoszenia',
					'status'       => 'Wynik sprawdzenia',
					'material'     => 'Materiał',
					'ilosc'        => 'Ilość z jednostką',
					'zlecenie'     => 'Numer zlecenia',
					'decided_name' => 'Kto sprawdził',
					'odpowiedz'    => 'Odpowiedź/komentarz administratora (jeśli jest)',
					'url'          => 'Link / odnośnik w aplikacji',
				),
				'raw'     => array( 'url', 'odpowiedz' ),
				'subject' => 'Sprawdzenie stanu #{id} – {status}',
				'body'    => "<p>Odpowiedź na prośbę o sprawdzenie stanu: <strong>{status}</strong></p>\n<p><strong>Materiał:</strong> {material}<br>\n<strong>Ilość:</strong> {ilosc}<br>\n<strong>Zlecenie:</strong> {zlecenie}<br>\n<strong>Sprawdził:</strong> {decided_name}</p>\n{odpowiedz}\n<p>{url}</p>",
			),
			'blacha_pelna' => array(
				'label' => 'Powiadomienie o pobraniu blachy pełnej',
				'desc'  => 'Wysyłane do wskazanych osób, gdy ze stanu pobrano blachę pełną.',
				'vars'  => array(
					'material'  => 'Materiał',
					'ilosc'     => 'Ilość z jednostką',
					'zlecenie'  => 'Numer zlecenia',
					'odbiorca'  => 'Dla kogo',
					'uwagi'     => 'Uwagi',
					'user_name' => 'Kto wprowadził',
					'data'      => 'Data',
					'stan'      => 'Ile zostało na stanie',
					'url'       => 'Link do pobrań w aplikacji',
				),
				'raw'     => array( 'url' ),
				'subject' => 'Pobrano blachę pełną – zlecenie {zlecenie}',
				'body'    => "<p>Ze stanu pobrano blachę pełną:</p>\n<p><strong>Materiał:</strong> {material}<br>\n<strong>Ilość:</strong> {ilosc}<br>\n<strong>Zlecenie:</strong> {zlecenie}<br>\n<strong>Dla kogo:</strong> {odbiorca}<br>\n<strong>Uwagi:</strong> {uwagi}<br>\n<strong>Wprowadził:</strong> {user_name}<br>\n<strong>Data:</strong> {data}<br>\n<strong>Na stanie zostało:</strong> {stan}</p>\n<p>{url}</p>",
			),
			'kopia_zapasowa' => array(
				'label' => 'Powiadomienie o kopii zapasowej',
				'desc'  => 'Wiadomość wysyłana wraz z nocną lub ręczną kopią danych – plik Excel jest w załączniku.',
				'vars'  => array(
					'data' => 'Data i godzina utworzenia kopii',
					'plik' => 'Nazwa pliku kopii',
					'site' => 'Nazwa systemu / firmy',
				),
				'raw'     => array(),
				'subject' => 'Kopia danych magazynu – {data}',
				'body'    => "<p>W załączniku kopia danych magazynu (Excel) z dnia <strong>{data}</strong>.</p>\n<p>Plik: {plik}</p>\n<p>{site}</p>",
			),
			'rez_admin' => array(
				'label' => 'Prośba o rezerwację – do magazynu',
				'desc'  => 'Trafia do administratorów, gdy pracownik poprosi o rezerwację materiału pod zlecenie (także z zapotrzebowania w Produkcji).',
				'vars'  => array(
					'user_name' => 'Kto prosi',
					'material'  => 'Materiał',
					'ilosc'     => 'Ilość z jednostką',
					'zlecenie'  => 'Numer zlecenia',
					'termin'    => 'Termin ważności rezerwacji',
					'uwagi'     => 'Uwagi',
					'url'       => 'Link do rezerwacji w aplikacji',
				),
				'raw'     => array( 'url' ),
				'subject' => 'Prośba o rezerwację od {user_name}',
				'body'    => "<p>{user_name} prosi o rezerwację materiału pod zlecenie:</p>\n<p><strong>Materiał:</strong> {material}<br>\n<strong>Ilość:</strong> {ilosc}<br>\n<strong>Zlecenie:</strong> {zlecenie}<br>\n<strong>Termin:</strong> {termin}<br>\n<strong>Uwagi:</strong> {uwagi}</p>\n<p>Zatwierdź lub odrzuć w zakładce „Rezerwacje”:<br>{url}</p>",
			),
			'rez_status' => array(
				'label' => 'Rezerwacja – do osoby proszącej',
				'desc'  => 'Wysyłana do osoby, która prosiła o rezerwację, gdy administrator ją utworzy, zatwierdzi, odrzuci lub wyda materiał.',
				'vars'  => array(
					'komunikat' => 'Co się stało (np. „Rezerwacja B71195 została zatwierdzona.”)',
					'status'    => 'Status rezerwacji',
					'material'  => 'Materiał',
					'ilosc'     => 'Ilość z jednostką',
					'zlecenie'  => 'Numer zlecenia',
					'url'       => 'Link do rezerwacji w aplikacji',
				),
				'raw'     => array( 'url' ),
				'subject' => 'Rezerwacja {zlecenie} – {status}',
				'body'    => "<p>{komunikat}</p>\n<p><strong>Materiał:</strong> {material}<br>\n<strong>Ilość:</strong> {ilosc}<br>\n<strong>Zlecenie:</strong> {zlecenie}</p>\n<p>{url}</p>",
			),
			'wz_admin' => array(
				'label' => 'WZ do zatwierdzenia – do magazynu',
				'desc'  => 'Trafia do administratorów, gdy ktoś przygotuje WZ z pozycjami z magazynu (wymaga zatwierdzenia).',
				'vars'  => array(
					'user_name' => 'Kto przygotował WZ',
					'odbiorca'  => 'Odbiorca',
					'data'      => 'Data wysyłki',
					'pozycje'   => 'Lista pozycji (tabela)',
					'url'       => 'Link do WZ w aplikacji',
				),
				'raw'     => array( 'pozycje', 'url' ),
				'subject' => 'WZ do zatwierdzenia od {user_name}',
				'body'    => "<p>{user_name} przygotował(a) WZ z pozycjami z magazynu – wymaga zatwierdzenia.</p>\n<p><strong>Odbiorca:</strong> {odbiorca}<br>\n<strong>Data wysyłki:</strong> {data}</p>\n{pozycje}\n<p>Zatwierdź w magazynie:<br>{url}</p>",
			),
			'wz_status' => array(
				'label' => 'WZ – do osoby, która ją przygotowała',
				'desc'  => 'Wysyłana do autora WZ, gdy administrator ją zatwierdzi, odrzuci albo wystawi.',
				'vars'  => array(
					'komunikat' => 'Co się stało z WZ',
					'url'       => 'Link do WZ w aplikacji',
				),
				'raw'     => array( 'url' ),
				'subject' => '{komunikat}',
				'body'    => "<p>{komunikat}</p>\n<p>{url}</p>",
			),
			'zam_dostawca' => array(
				'label' => 'Zamówienie do dostawcy',
				'desc'  => 'Wysyłane do dostawcy przyciskiem „Wyślij e-mailem” w zamówieniu – PDF zamówienia jest w załączniku, odpowiedź trafia do osoby wysyłającej.',
				'vars'  => array(
					'numer'    => 'Numer zamówienia (np. ZAM 3/2026)',
					'dostawca' => 'Nazwa dostawcy',
					'pozycje'  => 'Lista zamawianych pozycji (tabela)',
					'termin'   => 'Oczekiwany termin dostawy (jeśli podany)',
					'uwagi'    => 'Uwagi do zamówienia',
					'osoba'    => 'Imię i nazwisko wysyłającego',
					'email'    => 'E-mail wysyłającego',
					'firma'    => 'Nazwa firmy',
				),
				'raw'     => array( 'pozycje' ),
				'subject' => 'Zamówienie {numer} – {firma}',
				'body'    => "<p>Dzień dobry,</p>\n<p>w załączniku przesyłamy zamówienie <strong>{numer}</strong>:</p>\n{pozycje}\n<p><strong>Oczekiwany termin dostawy:</strong> {termin}</p>\n<p>{uwagi}</p>\n<p>Prosimy o potwierdzenie przyjęcia zamówienia i terminu dostawy oraz o podanie numeru zamówienia na dokumencie WZ.</p>\n<p>Pozdrawiamy<br>\n{osoba}<br>\n{email}<br>\n{firma}</p>",
			),
		);
	}

	private static function overrides() {
		$o = get_option( self::OPT, array() );
		return is_array( $o ) ? $o : array();
	}

	/** Pełna lista szablonów dla interfejsu. */
	public static function all() {
		$ovr = self::overrides();
		$out = array();
		foreach ( self::defs() as $key => $d ) {
			$has = isset( $ovr[ $key ] ) && is_array( $ovr[ $key ] );
			$out[] = array(
				'key'             => $key,
				'label'           => $d['label'],
				'desc'            => $d['desc'],
				'vars'            => $d['vars'],
				'subject'         => $has && isset( $ovr[ $key ]['subject'] ) ? (string) $ovr[ $key ]['subject'] : $d['subject'],
				'body'            => $has && isset( $ovr[ $key ]['body'] ) ? (string) $ovr[ $key ]['body'] : $d['body'],
				'default_subject' => $d['subject'],
				'default_body'    => $d['body'],
				'customized'      => $has,
			);
		}
		return $out;
	}

	/** Zapis jednego szablonu. Pusty temat i treść = powrót do domyślnego. */
	public static function save( $key, $subject, $body ) {
		$defs = self::defs();
		if ( ! isset( $defs[ $key ] ) ) {
			return new WP_Error( 'msm_404', 'Nieznany szablon.', array( 'status' => 404 ) );
		}
		$subject = trim( sanitize_text_field( (string) $subject ) );
		$body    = trim( (string) wp_kses_post( (string) $body ) );
		$ovr     = self::overrides();
		if ( '' === $subject && '' === $body ) {
			unset( $ovr[ $key ] );
		} else {
			$ovr[ $key ] = array(
				'subject' => '' === $subject ? $defs[ $key ]['subject'] : $subject,
				'body'    => '' === $body ? $defs[ $key ]['body'] : $body,
			);
		}
		update_option( self::OPT, $ovr );
		return self::all();
	}

	/** Zwraca temat (tekst) i treść (HTML) z podstawionymi polami {var}. */
	public static function render( $key, array $vars = array() ) {
		$defs = self::defs();
		if ( ! isset( $defs[ $key ] ) ) {
			return array( 'subject' => '', 'body' => '' );
		}
		$ovr     = self::overrides();
		$subject = isset( $ovr[ $key ]['subject'] ) ? (string) $ovr[ $key ]['subject'] : $defs[ $key ]['subject'];
		$body    = isset( $ovr[ $key ]['body'] ) ? (string) $ovr[ $key ]['body'] : $defs[ $key ]['body'];
		$raw     = isset( $defs[ $key ]['raw'] ) ? (array) $defs[ $key ]['raw'] : array();

		$smap = array();
		$bmap = array();
		foreach ( $vars as $k => $v ) {
			$smap[ '{' . $k . '}' ] = (string) $v;
			$bmap[ '{' . $k . '}' ] = in_array( $k, $raw, true ) ? (string) $v : esc_html( (string) $v );
		}
		$subject = preg_replace( '/\{[a-z_]+\}/', '', strtr( $subject, $smap ) );
		$body    = preg_replace( '/\{[a-z_]+\}/', '', strtr( $body, $bmap ) );
		// Usuń puste akapity powstałe po niewypełnionych polach.
		$body = preg_replace( '#<p>\s*</p>#u', '', $body );
		return array( 'subject' => trim( $subject ), 'body' => trim( $body ) );
	}

	const LOGO_CID = 'msm-logo@kisielewski';

	/** Nagłówek z logo (osadzony obrazek PNG – widoczny bez „pokaż obrazy”; SVG nie działa w Outlooku/Gmailu). */
	private static function logo_header() {
		return '<div style="padding:0 0 14px;margin:0 0 18px;border-bottom:1px solid #dfe3ea">'
			. '<img src="cid:' . self::LOGO_CID . '" width="170" height="45" alt="' . esc_attr( msm_opt( 'firma_skrot' ) ?: 'Kisielewski' ) . '" style="display:block;width:170px;height:45px;border:0;outline:none;text-decoration:none">'
			. '</div>';
	}

	/**
	 * Wysyłka wiadomości HTML. $opts: prefix (domyślnie „[K-ERP] ”), footer (bool), logo (bool – logo w nagłówku),
	 * attachments (lista ścieżek).
	 */
	public static function send( $to, $subject, $body_html, $opts = array() ) {
		$prefix = array_key_exists( 'prefix', $opts ) ? (string) $opts['prefix'] : '[K-ERP] ';
		$attach = isset( $opts['attachments'] ) ? (array) $opts['attachments'] : array();
		$foot   = empty( $opts['footer'] ) ? '' : '<p style="margin:20px 0 0;color:#6b7285;font-size:12px">—<br>System K-ERP · ' . esc_html( msm_opt( 'firma_nazwa' ) ) . '</p>';
		$logo   = ! empty( $opts['logo'] ) && is_readable( MSM_DIR . 'assets/logo-mail.png' );
		$html   = '<!DOCTYPE html><html lang="pl"><head><meta charset="utf-8"></head>'
			. '<body style="margin:0;padding:0;background:#f4f6fa">'
			. '<div style="max-width:640px;margin:0 auto;padding:22px;font-family:Arial,Helvetica,sans-serif;font-size:14px;line-height:1.55;color:#1a2233">'
			. ( $logo ? self::logo_header() : '' )
			. $body_html . $foot
			. '</div></body></html>';
		$embed = null;
		if ( $logo ) {
			$embed = function ( $phpmailer ) {
				$phpmailer->addEmbeddedImage( MSM_DIR . 'assets/logo-mail.png', self::LOGO_CID, 'kisielewski.png', 'base64', 'image/png' );
			};
			add_action( 'phpmailer_init', $embed );
		}
		$ok = wp_mail( $to, $prefix . $subject, $html, array_merge( array( 'Content-Type: text/html; charset=UTF-8' ), isset( $opts['headers'] ) ? (array) $opts['headers'] : array() ), $attach );
		if ( $embed ) {
			remove_action( 'phpmailer_init', $embed );
		}
		return $ok;
	}
}
