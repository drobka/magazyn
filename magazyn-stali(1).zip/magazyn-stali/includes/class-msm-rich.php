<?php
/**
 * Prosty tekst sformatowany (edytor w polach uwag, adresów): pogrubienie, pochylenie, podkreślenie, listy.
 * Wartość to HTML z małym zestawem znaczników albo zwykły tekst (stare wpisy) – oba są obsługiwane.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MSM_Rich {

	const TAGS = array( 'b' => array(), 'strong' => array(), 'i' => array(), 'em' => array(), 'u' => array(), 'ol' => array(), 'ul' => array(), 'li' => array(), 'br' => array() );

	public static function is_html( $v ) {
		return (bool) preg_match( '/<(b|strong|i|em|u|ol|ul|li|br|p|div)\b/i', (string) $v );
	}

	/** Zapis: tylko dozwolone znaczniki, bez atrybutów; zwykły tekst bez zmian. */
	public static function clean( $v ) {
		$v = str_replace( "\r\n", "\n", (string) $v );
		if ( ! self::is_html( $v ) ) {
			return trim( $v );
		}
		$v = preg_replace( '#<(p|div)\b[^>]*>#i', '', $v );
		$v = preg_replace( '#</(p|div)>#i', '<br>', $v );
		$v = wp_kses( $v, self::TAGS );
		$v = preg_replace( '#<br\s*/?>\s*(<(?:ol|ul)>)#i', '$1', $v );
		$v = preg_replace( '#(\s*<br\s*/?>\s*)+$#i', '', trim( $v ) );
		return '' === trim( wp_strip_all_tags( $v ) ) && false === stripos( $v, '<li' ) ? '' : $v;
	}

	/** Do wydruku: HTML bezpieczny; zwykły tekst – z łamaniem linii. */
	public static function html( $v ) {
		$v = (string) $v;
		if ( ! self::is_html( $v ) ) {
			return nl2br( esc_html( trim( $v ) ) );
		}
		return wp_kses( self::clean( $v ), self::TAGS );
	}

	/** Do Excela/CSV: zwykły tekst (listy jako „1.” i „•”). */
	public static function text( $v ) {
		$v = (string) $v;
		if ( ! self::is_html( $v ) ) {
			return $v;
		}
		$v = preg_replace_callback( '#<ol\b[^>]*>(.*?)</ol>#is', function ( $m ) {
			$n = 0;
			return "\n" . preg_replace_callback( '#<li\b[^>]*>(.*?)</li>#is', function ( $x ) use ( &$n ) { return ( ++$n ) . '. ' . trim( $x[1] ) . "\n"; }, $m[1] );
		}, $v );
		$v = preg_replace_callback( '#<ul\b[^>]*>(.*?)</ul>#is', function ( $m ) {
			return "\n" . preg_replace( '#<li\b[^>]*>(.*?)</li>#is', "• $1\n", $m[1] );
		}, $v );
		$v = preg_replace( '#<br\s*/?>#i', "\n", $v );
		$v = html_entity_decode( wp_strip_all_tags( $v ), ENT_QUOTES, 'UTF-8' );
		$v = preg_replace( "/\n{2,}(?=\d+\. |• )/u", "\n", $v ); // bez pustej linii przed listą
		return trim( preg_replace( "/\n{3,}/", "\n\n", $v ) );
	}
}
