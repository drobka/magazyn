<?php
/**
 * Zarządzanie kontami magazynu w aplikacji: dodawanie kont, reset haseł, role i uprawnienia per-osoba.
 * Bezpieczeństwo: operuje wyłącznie na kontach magazynu (role msm_admin / msm_viewer); nigdy na administratorach WordPressa.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MSM_Users {

	const ROLES = array( 'msm_admin' => 'Administrator', 'msm_viewer' => 'Przeglądający' );

	/** Minimalna długość hasła ustawianego z aplikacji. */
	const MIN_PASS = 10;

	/** Sprawdza hasło; zwraca WP_Error albo null. */
	public static function check_password( $pass ) {
		$pass = (string) $pass;
		if ( mb_strlen( $pass ) < self::MIN_PASS ) {
			return new WP_Error( 'msm_user', 'Hasło musi mieć co najmniej ' . self::MIN_PASS . ' znaków.', array( 'status' => 400, 'fields' => array( 'password' => 'Za krótkie hasło (min. ' . self::MIN_PASS . ').' ) ) );
		}
		if ( preg_match( '/^(.)\1+$/u', $pass ) || preg_match( '/^(0123456789|1234567890|qwertyuiop|haslo|password)/i', $pass ) ) {
			return new WP_Error( 'msm_user', 'To hasło jest zbyt łatwe do odgadnięcia.', array( 'status' => 400, 'fields' => array( 'password' => 'Zbyt proste hasło.' ) ) );
		}
		return null;
	}

	/** Czy bieżący użytkownik może zarządzać kontem $user (nie może mieć ono więcej uprawnień niż on). */
	private static function can_manage( $user ) {
		if ( ! self::manageable( $user ) ) {
			return new WP_Error( 'msm_user', 'Tego konta nie można zmieniać z aplikacji.', array( 'status' => 403 ) );
		}
		// Konto super administratora (trwałe usuwanie, ustawienia) zmienia tylko administrator WordPressa –
		// inaczej administrator magazynu mógłby np. ustawić mu nowe hasło i przejąć jego uprawnienia.
		if ( ! MSM_Perms::is_wp_admin() && MSM_Install::can_purge( $user ) && $user->ID !== get_current_user_id() ) {
			return new WP_Error( 'msm_user', 'To konto super administratora – zmienić je może tylko administrator WordPressa.', array( 'status' => 403 ) );
		}
		if ( ! MSM_Perms::covers( wp_get_current_user(), $user ) ) {
			return new WP_Error( 'msm_user', 'To konto ma uprawnienia, których Ty nie masz – zmienić je może tylko administrator WordPressa.', array( 'status' => 403 ) );
		}
		return true;
	}

	/** Wpis do Historii zmian (operacje na kontach). */
	private static function log( $akcja, $user_id, $opis, $dane = null ) {
		if ( class_exists( 'MSM_Repo' ) ) {
			MSM_Repo::log( $akcja, 'uzytkownicy', (int) $user_id, $opis, $dane );
		}
	}

	/** Czy dane konto to konto magazynu, którym wolno zarządzać (nie administrator WP). */
	private static function manageable( $user ) {
		if ( ! $user ) {
			return false;
		}
		if ( user_can( $user, 'manage_options' ) ) {
			return false; // administratora WordPressa nie ruszamy z poziomu aplikacji
		}
		$roles = (array) $user->roles;
		return (bool) array_intersect( $roles, array( 'msm_admin', 'msm_viewer' ) );
	}

	public static function listing() {
		$users = get_users( array( 'role__in' => array( 'msm_admin', 'msm_viewer' ), 'orderby' => 'display_name', 'number' => 500 ) );
		$out = array();
		foreach ( $users as $u ) {
			$role  = in_array( 'msm_admin', (array) $u->roles, true ) ? 'msm_admin' : 'msm_viewer';
			$out[] = array(
				'id'           => $u->ID,
				'login'        => $u->user_login,
				'display_name' => $u->display_name,
				'email'        => $u->user_email,
				'role'         => $role,
				'perms'        => MSM_Perms::effective( $u ),
				'self'         => $u->ID === get_current_user_id(),
				'manage'       => MSM_Perms::covers( wp_get_current_user(), $u ) && ( MSM_Perms::is_wp_admin() || ! MSM_Install::can_purge( $u ) || $u->ID === get_current_user_id() ),
			);
		}
		return array(
			'users'     => $out,
			'menu_keys' => MSM_Perms::menu_keys(),
			'menu_tree' => MSM_Perms::menu_tree_payload(),
			'cap_keys'  => MSM_Perms::cap_keys(),
			'roles'     => self::ROLES,
			'min_pass'  => self::MIN_PASS,
			'wp_admin'  => MSM_Perms::is_wp_admin(),
		);
	}

	public static function create( array $in ) {
		$login = sanitize_user( (string) ( $in['login'] ?? '' ), true );
		$name  = sanitize_text_field( (string) ( $in['display_name'] ?? '' ) );
		$email = sanitize_email( (string) ( $in['email'] ?? '' ) );
		$pass  = (string) ( $in['password'] ?? '' );
		$role  = isset( $in['role'] ) && isset( self::ROLES[ $in['role'] ] ) ? $in['role'] : 'msm_viewer';

		if ( strlen( $login ) < 3 ) {
			return new WP_Error( 'msm_user', 'Login musi mieć co najmniej 3 znaki.', array( 'status' => 400, 'fields' => array( 'login' => 'Za krótki login.' ) ) );
		}
		if ( MSM_Settings::is_super_login( $login ) ) {
			return new WP_Error( 'msm_user', 'Ten login jest zarezerwowany w Ustawieniach (lista super administratorów). Wybierz inny.', array( 'status' => 400, 'fields' => array( 'login' => 'Login zarezerwowany.' ) ) );
		}
		if ( username_exists( $login ) ) {
			return new WP_Error( 'msm_user', 'Taki login już istnieje.', array( 'status' => 400, 'fields' => array( 'login' => 'Login zajęty.' ) ) );
		}
		if ( $email && email_exists( $email ) ) {
			return new WP_Error( 'msm_user', 'Ten e-mail jest już użyty.', array( 'status' => 400, 'fields' => array( 'email' => 'E-mail zajęty.' ) ) );
		}
		$bad = self::check_password( $pass );
		if ( $bad ) {
			return $bad;
		}
		$uid = wp_insert_user( array(
			'user_login'   => $login,
			'user_pass'    => $pass,
			'user_email'   => $email,
			'display_name' => $name ? $name : $login,
			'first_name'   => $name,
			'role'         => $role,
		) );
		if ( is_wp_error( $uid ) ) {
			return new WP_Error( 'msm_user', $uid->get_error_message(), array( 'status' => 400 ) );
		}
		// Zawsze zapisujemy pełny zestaw, przycięty do uprawnień nadającego.
		$defaults = MSM_Perms::defaults( get_user_by( 'id', $uid ) );
		$perms    = MSM_Perms::clamp( isset( $in['perms'] ) && is_array( $in['perms'] ) ? $in['perms'] : $defaults );
		MSM_Perms::save( $uid, $perms );
		self::log( 'Konto: dodanie', $uid, 'Dodano konto „' . $login . '” (' . self::ROLES[ $role ] . ')', array( 'po' => array( 'role' => $role, 'perms' => $perms ) ) );
		return array( 'id' => $uid, 'message' => 'Dodano konto „' . $login . '”.' );
	}

	public static function update( $id, array $in ) {
		$user = get_user_by( 'id', (int) $id );
		$ok   = self::can_manage( $user );
		if ( is_wp_error( $ok ) ) {
			return $ok;
		}
		$self   = $user->ID === get_current_user_id();
		$before = array( 'display_name' => $user->display_name, 'email' => $user->user_email, 'role' => in_array( 'msm_admin', (array) $user->roles, true ) ? 'msm_admin' : 'msm_viewer', 'perms' => MSM_Perms::effective( $user ) );
		// Własnej roli i uprawnień nie można zmieniać z aplikacji (ochrona przed samodzielnym rozszerzeniem uprawnień).
		if ( $self && ! MSM_Perms::is_wp_admin() ) {
			$cur_role = $before['role'];
			if ( ( isset( $in['role'] ) && $in['role'] !== $cur_role ) || ( isset( $in['perms'] ) && MSM_Perms::clamp( (array) $in['perms'] ) != $before['perms'] ) ) { // phpcs:ignore
				return new WP_Error( 'msm_user', 'Nie możesz zmieniać własnej roli ani uprawnień. Poproś innego administratora.', array( 'status' => 403 ) );
			}
			unset( $in['role'], $in['perms'] );
		}
		$fields = array( 'ID' => $user->ID );
		if ( isset( $in['display_name'] ) ) {
			$fields['display_name'] = sanitize_text_field( (string) $in['display_name'] );
		}
		if ( isset( $in['email'] ) ) {
			$email = sanitize_email( (string) $in['email'] );
			if ( $email && email_exists( $email ) && (int) email_exists( $email ) !== $user->ID ) {
				return new WP_Error( 'msm_user', 'Ten e-mail jest już użyty.', array( 'status' => 400, 'fields' => array( 'email' => 'E-mail zajęty.' ) ) );
			}
			$fields['user_email'] = $email;
		}
		if ( count( $fields ) > 1 ) {
			wp_update_user( $fields );
		}
		if ( isset( $in['role'] ) && isset( self::ROLES[ $in['role'] ] ) ) {
			// Nie pozwól odebrać sobie uprawnień administratora (uniknięcie zablokowania).
			if ( $user->ID === get_current_user_id() && 'msm_viewer' === $in['role'] ) {
				return new WP_Error( 'msm_user', 'Nie możesz zmienić własnej roli na „Przeglądający”.', array( 'status' => 400 ) );
			}
			$user->set_role( $in['role'] );
		}
		if ( isset( $in['perms'] ) && is_array( $in['perms'] ) ) {
			MSM_Perms::save( $user->ID, MSM_Perms::clamp( $in['perms'] ) );
		}
		$fresh = get_user_by( 'id', $user->ID );
		$after = array( 'display_name' => $fresh->display_name, 'email' => $fresh->user_email, 'role' => in_array( 'msm_admin', (array) $fresh->roles, true ) ? 'msm_admin' : 'msm_viewer', 'perms' => MSM_Perms::effective( $fresh ) );
		if ( $after != $before ) { // phpcs:ignore
			self::log( 'Konto: edycja', $user->ID, 'Zmieniono konto „' . $user->user_login . '”', array( 'przed' => $before, 'po' => $after ) );
		}
		return array( 'id' => $user->ID, 'message' => 'Zapisano zmiany.' );
	}

	public static function reset_password( $id, $pass ) {
		$user = get_user_by( 'id', (int) $id );
		$ok   = self::can_manage( $user );
		if ( is_wp_error( $ok ) ) {
			return $ok;
		}
		$bad = self::check_password( $pass );
		if ( $bad ) {
			return $bad;
		}
		$is_self = $user->ID === get_current_user_id();
		wp_set_password( (string) $pass, $user->ID );
		self::log( 'Konto: reset hasła', $user->ID, 'Ustawiono nowe hasło dla „' . $user->user_login . '”' );
		if ( $is_self ) {
			// wp_set_password() kończy wszystkie sesje tego konta – trzeba zalogować się nowym hasłem.
			return array( 'id' => $user->ID, 'relogin' => true, 'message' => 'Hasło zmienione. Zaloguj się ponownie nowym hasłem.' );
		}
		return array( 'id' => $user->ID, 'message' => 'Hasło zmienione dla „' . $user->user_login . '”.' );
	}

	public static function delete( $id ) {
		$user = get_user_by( 'id', (int) $id );
		$ok   = self::can_manage( $user );
		if ( is_wp_error( $ok ) ) {
			return $ok;
		}
		if ( $user->ID === get_current_user_id() ) {
			return new WP_Error( 'msm_user', 'Nie możesz usunąć własnego konta.', array( 'status' => 400 ) );
		}
		require_once ABSPATH . 'wp-admin/includes/user.php';
		$login = $user->user_login;
		wp_delete_user( $user->ID );
		self::log( 'Konto: usunięcie', $user->ID, 'Usunięto konto „' . $login . '” (' . $user->display_name . ')' );
		return array( 'message' => 'Konto usunięte.' );
	}
}
