<?php
/**
 * Edycja własnego profilu w aplikacji (bez wchodzenia do kokpitu WP).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MSM_Profile {

	/** Propozycje „Przedstawiaj mnie jako” – jak w profilu WordPressa. */
	public static function display_options( WP_User $u, $first = null, $last = null, $nick = null ) {
		$first = null === $first ? $u->first_name : $first;
		$last  = null === $last ? $u->last_name : $last;
		$nick  = null === $nick ? $u->nickname : $nick;
		$opts  = array( $nick, $u->user_login );
		if ( $first ) {
			$opts[] = $first;
		}
		if ( $last ) {
			$opts[] = $last;
		}
		if ( $first && $last ) {
			$opts[] = $first . ' ' . $last;
			$opts[] = $last . ' ' . $first;
		}
		$opts[] = $u->display_name;
		$opts   = array_values( array_unique( array_filter( array_map( 'trim', $opts ), 'strlen' ) ) );
		return $opts;
	}

	public static function get() {
		$u = wp_get_current_user();
		return array(
			'login'        => $u->user_login,
			'first_name'   => $u->first_name,
			'last_name'    => $u->last_name,
			'nickname'     => $u->nickname,
			'display_name' => $u->display_name,
			'email'        => $u->user_email,
			'role'         => current_user_can( 'msm_edit' ) ? 'administrator magazynu' : 'przeglądający',
			'options'      => self::display_options( $u ),
		);
	}

	/**
	 * @return array|WP_Error
	 */
	public static function update( array $in ) {
		$u      = wp_get_current_user();
		$errors = array();

		$first   = sanitize_text_field( wp_unslash( (string) ( $in['first_name'] ?? $u->first_name ) ) );
		$last    = sanitize_text_field( wp_unslash( (string) ( $in['last_name'] ?? $u->last_name ) ) );
		$display = sanitize_text_field( wp_unslash( (string) ( $in['display_name'] ?? $u->display_name ) ) );
		$email   = sanitize_email( wp_unslash( (string) ( $in['email'] ?? $u->user_email ) ) );
		$pass1   = (string) ( $in['pass1'] ?? '' );
		$pass2   = (string) ( $in['pass2'] ?? '' );
		$current = (string) ( $in['current'] ?? '' );

		$allowed = self::display_options( $u, $first, $last );
		if ( '' === $display || ! in_array( $display, $allowed, true ) ) {
			$errors['display_name'] = 'Wybierz nazwę z listy.';
		}
		$email_changed = strtolower( $email ) !== strtolower( $u->user_email );
		if ( ! is_email( $email ) ) {
			$errors['email'] = 'Nieprawidłowy adres e-mail.';
		} elseif ( $email_changed && email_exists( $email ) ) {
			$errors['email'] = 'Ten adres jest już używany przez inne konto.';
		}
		$pass_changed = '' !== $pass1 || '' !== $pass2;
		if ( $pass_changed ) {
			$weak = MSM_Users::check_password( $pass1 ); // ta sama polityka co przy zakładaniu kont (min. 10 znaków, bez trywialnych)
			if ( $weak ) {
				$errors['pass1'] = $weak->get_error_message();
			} elseif ( $pass1 !== $pass2 ) {
				$errors['pass2'] = 'Hasła nie są takie same.';
			} elseif ( false !== strpos( $pass1, '\\' ) ) {
				$errors['pass1'] = 'Hasło nie może zawierać znaku „\\”.';
			}
		}
		if ( ( $email_changed || $pass_changed ) && ! wp_check_password( $current, $u->user_pass, $u->ID ) ) {
			$errors['current'] = 'Podaj aktualne hasło, aby zmienić e-mail lub hasło.';
		}
		if ( $errors ) {
			return new WP_Error( 'msm_invalid', 'Popraw zaznaczone pola.', array( 'status' => 400, 'fields' => $errors ) );
		}

		$data = array(
			'ID'           => $u->ID,
			'first_name'   => $first,
			'last_name'    => $last,
			'display_name' => $display,
			'user_email'   => $email,
		);
		if ( $pass_changed ) {
			$data['user_pass'] = $pass1;
		}
		$res = wp_update_user( $data );
		if ( is_wp_error( $res ) ) {
			$res->add_data( array( 'status' => 400 ) );
			return $res;
		}
		$parts = array( 'Zapisano profil.' );
		if ( $pass_changed ) {
			$parts[] = 'Hasło zostało zmienione.';
		}
		if ( $email_changed ) {
			$parts[] = 'Nowy e-mail: ' . $email . '.';
		}
		return array(
			'ok'      => true,
			'message' => implode( ' ', $parts ),
			'reload'  => true,
		);
	}
}
