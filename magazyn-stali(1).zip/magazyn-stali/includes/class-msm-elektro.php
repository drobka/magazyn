<?php
/**
 * Narzędziownia → Elektronarzędzia: lista ewidencyjna (jak arkusz „lista” z Excela) + historia sprawdzeń.
 *
 * Typy (litery symbolu): EN – elektronarzędzia, B – akumulatory, Ł – ładowarki, P – przedłużacze.
 * Następne sprawdzenie = ostatnie + 91 dni (jak w Excelu), chyba że ustawiono je ręcznie.
 * Przeglądanie: zakładka „Elektronarzędzia”; dodawanie, edycja i sprawdzenia: akcja „elektro”
 * (domyślnie administrator magazynu).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MSM_Elektro {

	const OKRES = 91; // dni między sprawdzeniami
	const TYPY  = array( 'EN' => 'Elektronarzędzia', 'B' => 'Akumulatory', 'Ł' => 'Ładowarki', 'P' => 'Przedłużacze' );
	const FIELDS = array( 'symbol', 'typ', 'nazwa', 'model', 'nr_seryjny', 'zasilanie', 'producent', 'data_spr', 'data_nast', 'data_prod', 'gwarancja', 'uwagi', 'lokalizacja' );
	const DATES  = array( 'data_spr', 'data_nast', 'data_prod', 'gwarancja' );

	public static function T() {
		global $wpdb;
		return $wpdb->prefix . 'msm_elektro';
	}

	public static function TS() {
		global $wpdb;
		return $wpdb->prefix . 'msm_elektro_spr';
	}

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
	}

	public static function create_tables() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$c = $wpdb->get_charset_collate();
		dbDelta( 'CREATE TABLE ' . self::T() . " (
id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
symbol varchar(40) NOT NULL DEFAULT '',
typ varchar(10) NOT NULL DEFAULT '',
nazwa varchar(255) NOT NULL DEFAULT '',
model varchar(190) NOT NULL DEFAULT '',
nr_seryjny varchar(190) NOT NULL DEFAULT '',
zasilanie varchar(10) NOT NULL DEFAULT '',
producent varchar(120) NOT NULL DEFAULT '',
lokalizacja varchar(60) NOT NULL DEFAULT '',
data_spr date NULL,
data_nast date NULL,
nast_recznie tinyint(1) NOT NULL DEFAULT 0,
data_prod date NULL,
gwarancja date NULL,
uwagi text NULL,
created_at datetime NULL,
updated_at datetime NULL,
updated_by bigint(20) unsigned NOT NULL DEFAULT 0,
PRIMARY KEY  (id),
KEY symbol (symbol),
KEY data_nast (data_nast),
KEY lokalizacja (lokalizacja)
) $c;" );
		dbDelta( 'CREATE TABLE ' . self::TS() . " (
id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
el_id bigint(20) unsigned NOT NULL,
data date NOT NULL,
ocena varchar(20) NOT NULL DEFAULT '',
sprawdzil varchar(190) NOT NULL DEFAULT '',
uwagi text NULL,
created_at datetime NULL,
created_by bigint(20) unsigned NOT NULL DEFAULT 0,
PRIMARY KEY  (id),
KEY el (el_id)
) $c;" );
		self::seed();
		self::fill_lokalizacja();
	}

	/** 1.95.0: istniejące elektronarzędzia dostają pierwszą lokalizację z listy (Ligota Wołczyńska). Jednorazowo. */
	public static function fill_lokalizacja() {
		global $wpdb;
		if ( get_option( 'msm_elektro_lok_filled' ) ) {
			return;
		}
		$wpdb->query( $wpdb->prepare( 'UPDATE `' . self::T() . "` SET lokalizacja = %s WHERE lokalizacja = ''", MSM_Settings::lokalizacje()[0] ) ); // phpcs:ignore
		update_option( 'msm_elektro_lok_filled', 1 );
	}

	/** Jednorazowy import listy ewidencyjnej z Excela (data/elektro.json) – tylko do pustej tabeli. */
	public static function seed() {
		global $wpdb;
		if ( get_option( 'msm_elektro_seeded' ) ) {
			return;
		}
		$f = MSM_DIR . 'data/elektro.json';
		if ( ! is_readable( $f ) || (int) $wpdb->get_var( 'SELECT COUNT(*) FROM `' . self::T() . '`' ) > 0 ) { // phpcs:ignore
			update_option( 'msm_elektro_seeded', 1 );
			return;
		}
		$data = json_decode( (string) file_get_contents( $f ), true ); // phpcs:ignore
		$now  = current_time( 'mysql' );
		foreach ( (array) ( $data['pozycje'] ?? array() ) as $x ) {
			$row = array();
			foreach ( self::FIELDS as $k ) {
				$row[ $k ] = in_array( $k, self::DATES, true ) ? ( empty( $x[ $k ] ) ? null : (string) $x[ $k ] ) : (string) ( $x[ $k ] ?? '' );
			}
			$row['nast_recznie'] = self::auto_nast( $row['data_spr'] ) === $row['data_nast'] ? 0 : 1; // np. uszkodzone – bez terminu
			$row['created_at']   = $now;
			$row['updated_at']   = $now;
			$wpdb->insert( self::T(), $row );
		}
		update_option( 'msm_elektro_seeded', 1 );
	}

	/* ---------------- uprawnienia ---------------- */

	public static function can_view() {
		if ( ! is_user_logged_in() || ! current_user_can( 'msm_view' ) ) {
			return new WP_Error( 'msm_forbidden', 'Brak dostępu.', array( 'status' => 403 ) );
		}
		return MSM_Perms::menu_on( 'narz_elektro' ) ? true : new WP_Error( 'msm_forbidden', 'Zakładka Elektronarzędzia jest dla Ciebie wyłączona.', array( 'status' => 403 ) );
	}

	public static function is_editor() {
		return MSM_Perms::is_wp_admin() || MSM_Perms::cap_on( 'elektro' );
	}

	public static function can_edit() {
		$c = self::can_view();
		if ( is_wp_error( $c ) ) {
			return $c;
		}
		return self::is_editor() ? true : new WP_Error( 'msm_forbidden', 'Nie masz uprawnienia do zmian w elektronarzędziach.', array( 'status' => 403 ) );
	}

	public static function routes() {
		$ns = MSM_Rest::NS;
		$v  = array( __CLASS__, 'can_view' );
		$e  = array( __CLASS__, 'can_edit' );
		register_rest_route( $ns, '/elektro', array(
			array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'list_r' ), 'permission_callback' => $v ),
			array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'add_r' ), 'permission_callback' => $e ),
		) );
		register_rest_route( $ns, '/elektro/(?P<id>\d+)', array(
			array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'get_r' ), 'permission_callback' => $v ),
			array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'save_r' ), 'permission_callback' => $e ),
		) );
		register_rest_route( $ns, '/elektro/(?P<id>\d+)/delete', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'delete_r' ), 'permission_callback' => $e ) );
		register_rest_route( $ns, '/elektro/(?P<id>\d+)/sprawdzenie', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'check_r' ), 'permission_callback' => $e ) );
		register_rest_route( $ns, '/elektro/spr/(?P<id>\d+)/delete', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'check_delete_r' ), 'permission_callback' => $e ) );
		register_rest_route( $ns, '/elektro/export', array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'export_r' ), 'permission_callback' => $v ) );
	}

	/* ---------------- pomocnicze ---------------- */

	/** Data + 91 dni (Y-m-d) albo null. */
	public static function auto_nast( $data_spr ) {
		if ( empty( $data_spr ) || ! ( $t = strtotime( $data_spr . ' 12:00:00' ) ) ) {
			return null;
		}
		return gmdate( 'Y-m-d', $t + self::OKRES * DAY_IN_SECONDS );
	}

	/** Litery z początku symbolu (EN0023 → EN, Ł0004 → Ł). */
	public static function prefix( $symbol ) {
		return preg_match( '/^\s*([^\d\s]+)/u', (string) $symbol, $m ) ? mb_strtoupper( $m[1] ) : '';
	}

	/** Kolejny wolny symbol dla typu (EN → EN0026): najwyższy numer + 1, 4 cyfry – jak „Kolejny nr inwentarzowy” w Excelu. */
	public static function next_symbol( $typ, array $symbols ) {
		$typ = mb_strtoupper( trim( (string) $typ ) );
		$max = 0;
		foreach ( $symbols as $s ) {
			if ( preg_match( '/^' . preg_quote( $typ, '/' ) . '(\d+)$/u', mb_strtoupper( trim( (string) $s ) ), $m ) ) {
				$max = max( $max, (int) $m[1] );
			}
		}
		return $typ . str_pad( (string) ( $max + 1 ), 4, '0', STR_PAD_LEFT );
	}

	private static function date_in( $v ) {
		$v = trim( (string) $v );
		if ( '' === $v ) {
			return null;
		}
		if ( preg_match( '/^(\d{1,2})[.\-\/](\d{1,2})[.\-\/](\d{4})$/', $v, $m ) ) {
			$v = sprintf( '%04d-%02d-%02d', $m[3], $m[2], $m[1] );
		}
		if ( ! preg_match( '/^(\d{4})-(\d{2})-(\d{2})$/', $v, $m ) || ! checkdate( (int) $m[2], (int) $m[3], (int) $m[1] ) ) {
			return false;
		}
		return $v;
	}

	public static function cast( array $r ) {
		$out = array( 'id' => (int) $r['id'] );
		foreach ( self::FIELDS as $k ) {
			$out[ $k ] = in_array( $k, self::DATES, true ) ? ( $r[ $k ] ? substr( (string) $r[ $k ], 0, 10 ) : null ) : (string) $r[ $k ];
		}
		$out['nast_recznie'] = (bool) $r['nast_recznie'];
		$out['ocena']        = (string) ( $r['ocena'] ?? '' );
		return $out;
	}

	private static function get( $id ) {
		global $wpdb;
		$r = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM `' . self::T() . '` WHERE id = %d', (int) $id ), ARRAY_A ); // phpcs:ignore
		return $r ?: null;
	}

	/** Wszystkie pozycje z oceną z ostatniego sprawdzenia. */
	public static function rows() {
		global $wpdb;
		$T  = self::T();
		$TS = self::TS();
		return array_map( array( __CLASS__, 'cast' ), (array) $wpdb->get_results( // phpcs:ignore
			"SELECT e.*, ( SELECT s.ocena FROM `$TS` s WHERE s.el_id = e.id ORDER BY s.data DESC, s.id DESC LIMIT 1 ) AS ocena FROM `$T` e ORDER BY e.typ, e.symbol, e.id",
			ARRAY_A
		) );
	}

	private static function checks( $id ) {
		global $wpdb;
		$rows = (array) $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM `' . self::TS() . '` WHERE el_id = %d ORDER BY data DESC, id DESC', (int) $id ), ARRAY_A ); // phpcs:ignore
		return array_map( function ( $s ) {
			return array( 'id' => (int) $s['id'], 'data' => (string) $s['data'], 'ocena' => (string) $s['ocena'], 'sprawdzil' => (string) $s['sprawdzil'], 'uwagi' => (string) $s['uwagi'], 'wpisano' => (string) $s['created_at'] );
		}, $rows );
	}

	private static function symbols( $except = 0 ) {
		global $wpdb;
		return (array) $wpdb->get_col( $wpdb->prepare( 'SELECT symbol FROM `' . self::T() . '` WHERE id <> %d', (int) $except ) ); // phpcs:ignore
	}

	/** Dane formularza → wiersz bazy. */
	private static function input( WP_REST_Request $r, $id = 0, $old_symbol = '' ) {
		$p   = (array) $r->get_json_params();
		$row = array();
		foreach ( array( 'nazwa' => 255, 'model' => 190, 'nr_seryjny' => 190, 'producent' => 120 ) as $k => $len ) {
			$row[ $k ] = mb_substr( sanitize_text_field( (string) ( $p[ $k ] ?? '' ) ), 0, $len );
		}
		$row['producent'] = mb_strtoupper( $row['producent'] );
		$row['uwagi']     = mb_substr( sanitize_textarea_field( (string) ( $p['uwagi'] ?? '' ) ), 0, 5000 );
		$lok              = MSM_Settings::lokalizacja_in( $p['lokalizacja'] ?? '', self::T() );
		if ( is_wp_error( $lok ) ) {
			return $lok;
		}
		$row['lokalizacja'] = $lok;
		$row['zasilanie'] = in_array( $p['zasilanie'] ?? '', array( 'AC', 'DC' ), true ) ? $p['zasilanie'] : '';
		$typ              = mb_strtoupper( trim( (string) ( $p['typ'] ?? '' ) ) );
		$row['typ']       = isset( self::TYPY[ $typ ] ) ? $typ : mb_substr( preg_replace( '/[^\p{L}]/u', '', $typ ), 0, 10 );
		$sym              = mb_strtoupper( preg_replace( '/\s+/u', '', sanitize_text_field( (string) ( $p['symbol'] ?? '' ) ) ) );
		if ( '' === $sym ) {
			return new WP_Error( 'msm_400', 'Podaj symbol.', array( 'status' => 400, 'fields' => array( 'symbol' => 'Wymagany' ) ) );
		}
		if ( '' === $row['nazwa'] ) {
			return new WP_Error( 'msm_400', 'Podaj nazwę.', array( 'status' => 400, 'fields' => array( 'nazwa' => 'Wymagana' ) ) );
		}
		$row['symbol'] = mb_substr( $sym, 0, 40 );
		if ( '' === $row['typ'] ) {
			$row['typ'] = self::prefix( $sym );
		}
		// Symbol unikalny; zaimportowany z Excela duplikat (B0015) można edytować bez zmiany symbolu.
		if ( $sym !== mb_strtoupper( (string) $old_symbol ) && in_array( $sym, array_map( 'mb_strtoupper', self::symbols( $id ) ), true ) ) {
			return new WP_Error( 'msm_dup', 'Symbol ' . $sym . ' ma już inne narzędzie. Wybierz inny (np. kolejny wolny: ' . self::next_symbol( $row['typ'] ?: self::prefix( $sym ), self::symbols( $id ) ) . ').', array( 'status' => 409, 'fields' => array( 'symbol' => 'Zajęty' ) ) );
		}
		foreach ( self::DATES as $k ) {
			$d = self::date_in( $p[ $k ] ?? '' );
			if ( false === $d ) {
				return new WP_Error( 'msm_400', 'Nieprawidłowa data.', array( 'status' => 400, 'fields' => array( $k => 'Nieprawidłowa data' ) ) );
			}
			$row[ $k ] = $d;
		}
		$row['nast_recznie'] = empty( $p['nast_recznie'] ) ? 0 : 1;
		if ( ! $row['nast_recznie'] ) {
			$row['data_nast'] = self::auto_nast( $row['data_spr'] );
		}
		return $row;
	}

	private static function label( array $r ) {
		return $r['symbol'] . ' ' . $r['nazwa'] . ( '' !== (string) $r['model'] ? ' ' . $r['model'] : '' );
	}

	private static function meta() {
		$ss  = self::symbols();
		$nxt = array();
		foreach ( array_keys( self::TYPY ) as $t ) {
			$nxt[ $t ] = self::next_symbol( $t, $ss );
		}
		return array( 'typy' => self::TYPY, 'lokalizacje' => MSM_Settings::lokalizacje_z( self::T() ), 'nastepne' => $nxt, 'okres' => self::OKRES, 'edycja' => self::is_editor(), 'ja' => wp_get_current_user()->display_name, 'dzis' => current_time( 'Y-m-d' ) );
	}

	/* ---------------- REST ---------------- */

	public static function list_r() {
		return rest_ensure_response( array_merge( array( 'pozycje' => self::rows() ), self::meta() ) );
	}

	public static function get_r( WP_REST_Request $r ) {
		$e = self::get( (int) $r['id'] );
		if ( ! $e ) {
			return new WP_Error( 'msm_404', 'Narzędzie nie istnieje (mogło zostać usunięte).', array( 'status' => 404 ) );
		}
		$ch          = self::checks( $e['id'] );
		$e['ocena']  = $ch ? $ch[0]['ocena'] : '';
		$dup         = in_array( mb_strtoupper( $e['symbol'] ), array_map( 'mb_strtoupper', self::symbols( $e['id'] ) ), true );
		$names       = array();
		foreach ( get_users( array( 'capability' => 'msm_view', 'fields' => array( 'display_name' ) ) ) as $u ) {
			$names[] = $u->display_name;
		}
		$producenci = array_values( array_unique( array_filter( wp_list_pluck( self::rows(), 'producent' ) ) ) );
		sort( $producenci );
		return rest_ensure_response( array_merge( array( 'pozycja' => self::cast( $e ), 'sprawdzenia' => $ch, 'dubel' => $dup, 'osoby' => $names, 'producenci' => $producenci ), self::meta() ) );
	}

	public static function add_r( WP_REST_Request $r ) {
		global $wpdb;
		$row = self::input( $r );
		if ( is_wp_error( $row ) ) {
			return $row;
		}
		$now = current_time( 'mysql' );
		$wpdb->insert( self::T(), $row + array( 'created_at' => $now, 'updated_at' => $now, 'updated_by' => get_current_user_id() ) );
		$id = (int) $wpdb->insert_id;
		if ( ! $id ) {
			return new WP_Error( 'msm_500', 'Nie udało się zapisać.', array( 'status' => 500 ) );
		}
		MSM_Repo::log( 'Elektronarzędzia: nowe', 'elektro', $id, 'Dodano: ' . self::label( $row ), array( 'po' => $row ) );
		return rest_ensure_response( array( 'id' => $id ) );
	}

	public static function save_r( WP_REST_Request $r ) {
		global $wpdb;
		$old = self::get( (int) $r['id'] );
		if ( ! $old ) {
			return new WP_Error( 'msm_404', 'Narzędzie nie istnieje (mogło zostać usunięte).', array( 'status' => 404 ) );
		}
		$row = self::input( $r, (int) $old['id'], $old['symbol'] );
		if ( is_wp_error( $row ) ) {
			return $row;
		}
		$diff = array();
		foreach ( $row as $k => $v ) {
			if ( (string) $v !== (string) $old[ $k ] ) {
				$diff[ $k ] = array( $old[ $k ], $v );
			}
		}
		if ( $diff ) {
			$wpdb->update( self::T(), $row + array( 'updated_at' => current_time( 'mysql' ), 'updated_by' => get_current_user_id() ), array( 'id' => (int) $old['id'] ) );
			MSM_Repo::log( 'Elektronarzędzia: edycja', 'elektro', (int) $old['id'], 'Zmieniono: ' . self::label( $row ) . ' – ' . implode( ', ', array_keys( $diff ) ), array( 'przed' => array_map( function ( $d ) { return $d[0]; }, $diff ), 'po' => array_map( function ( $d ) { return $d[1]; }, $diff ) ) );
		}
		return self::get_r( $r );
	}

	public static function delete_r( WP_REST_Request $r ) {
		global $wpdb;
		$old = self::get( (int) $r['id'] );
		if ( ! $old ) {
			return new WP_Error( 'msm_404', 'Narzędzie nie istnieje (mogło zostać usunięte).', array( 'status' => 404 ) );
		}
		$ch = self::checks( $old['id'] );
		$wpdb->delete( self::TS(), array( 'el_id' => (int) $old['id'] ) );
		$wpdb->delete( self::T(), array( 'id' => (int) $old['id'] ) );
		MSM_Repo::log( 'Elektronarzędzia: usunięcie', 'elektro', (int) $old['id'], 'Usunięto: ' . self::label( $old ) . ( $ch ? ' (z historią ' . count( $ch ) . ' sprawdzeń)' : '' ), array( 'przed' => $old, 'sprawdzenia' => $ch ) );
		return rest_ensure_response( array( 'deleted' => (int) $old['id'] ) );
	}

	/** Zapis sprawdzenia: wpis do historii + data ostatniego sprawdzenia; następne = data + 91 dni (ręczny termin zostaje zastąpiony). */
	public static function check_r( WP_REST_Request $r ) {
		global $wpdb;
		$e = self::get( (int) $r['id'] );
		if ( ! $e ) {
			return new WP_Error( 'msm_404', 'Narzędzie nie istnieje (mogło zostać usunięte).', array( 'status' => 404 ) );
		}
		$p = (array) $r->get_json_params();
		$d = self::date_in( $p['data'] ?? '' );
		if ( ! $d ) {
			return new WP_Error( 'msm_400', 'Podaj datę sprawdzenia.', array( 'status' => 400, 'fields' => array( 'data' => 'Wymagana' ) ) );
		}
		if ( $d > current_time( 'Y-m-d' ) ) {
			return new WP_Error( 'msm_400', 'Data sprawdzenia nie może być z przyszłości.', array( 'status' => 400, 'fields' => array( 'data' => 'Z przyszłości' ) ) );
		}
		$ocena = in_array( $p['ocena'] ?? '', array( 'sprawne', 'niesprawne' ), true ) ? $p['ocena'] : '';
		if ( '' === $ocena ) {
			return new WP_Error( 'msm_400', 'Wybierz ocenę: sprawne albo niesprawne.', array( 'status' => 400, 'fields' => array( 'ocena' => 'Wymagana' ) ) );
		}
		$kto = mb_substr( sanitize_text_field( (string) ( $p['sprawdzil'] ?? '' ) ), 0, 190 );
		if ( '' === $kto ) {
			return new WP_Error( 'msm_400', 'Podaj, kto sprawdził.', array( 'status' => 400, 'fields' => array( 'sprawdzil' => 'Wymagane' ) ) );
		}
		$uw = mb_substr( sanitize_textarea_field( (string) ( $p['uwagi'] ?? '' ) ), 0, 2000 );
		$wpdb->insert( self::TS(), array( 'el_id' => (int) $e['id'], 'data' => $d, 'ocena' => $ocena, 'sprawdzil' => $kto, 'uwagi' => $uw, 'created_at' => current_time( 'mysql' ), 'created_by' => get_current_user_id() ) );
		// Najnowsze sprawdzenie wyznacza daty (wpis „wstecz” starszy od ostatniego nie przesuwa terminu).
		if ( ! $e['data_spr'] || $d >= $e['data_spr'] ) {
			$wpdb->update( self::T(), array( 'data_spr' => $d, 'data_nast' => self::auto_nast( $d ), 'nast_recznie' => 0, 'updated_at' => current_time( 'mysql' ), 'updated_by' => get_current_user_id() ), array( 'id' => (int) $e['id'] ) );
		}
		MSM_Repo::log( 'Elektronarzędzia: sprawdzenie', 'elektro', (int) $e['id'], self::label( $e ) . ' – ' . mysql2date( 'd.m.Y', $d ) . ': ' . $ocena . ' (' . $kto . ')' . ( '' !== $uw ? ' – ' . $uw : '' ) );
		return self::get_r( $r );
	}

	public static function check_delete_r( WP_REST_Request $r ) {
		global $wpdb;
		$s = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM `' . self::TS() . '` WHERE id = %d', (int) $r['id'] ), ARRAY_A ); // phpcs:ignore
		if ( ! $s ) {
			return new WP_Error( 'msm_404', 'Wpis nie istnieje.', array( 'status' => 404 ) );
		}
		$e = self::get( (int) $s['el_id'] );
		$wpdb->delete( self::TS(), array( 'id' => (int) $s['id'] ) );
		MSM_Repo::log( 'Elektronarzędzia: usunięto sprawdzenie', 'elektro', (int) $s['el_id'], ( $e ? self::label( $e ) : '#' . $s['el_id'] ) . ' – wpis z ' . mysql2date( 'd.m.Y', $s['data'] ) . ' (' . $s['ocena'] . ', ' . $s['sprawdzil'] . ')', array( 'przed' => $s ) );
		$r2 = new WP_REST_Request( 'GET' );
		$r2->set_url_params( array( 'id' => (int) $s['el_id'] ) );
		return self::get_r( $r2 );
	}

	/* ---------------- eksport / Pulpit / kopia ---------------- */

	public static function export_rows() {
		$out = array( array( 'Lp.', 'Symbol', 'Nazwa', 'Model', 'Nr seryjny', 'AC/DC', 'Data os. sprawdzenia', 'Data nast. sprawdzenia', 'Data produkcji/rejestracji', 'Termin gwarancji', 'Producent', 'Uwagi', 'Typ', 'Ocena', 'Lokalizacja' ) );
		$d   = function ( $v ) { return $v ? mysql2date( 'd.m.Y', $v ) : ''; };
		foreach ( self::rows() as $i => $e ) {
			$out[] = array( $i + 1, $e['symbol'], $e['nazwa'], $e['model'], $e['nr_seryjny'], $e['zasilanie'], $d( $e['data_spr'] ), $d( $e['data_nast'] ), $d( $e['data_prod'] ), $d( $e['gwarancja'] ), $e['producent'], $e['uwagi'], $e['typ'], $e['ocena'], $e['lokalizacja'] );
		}
		return $out;
	}

	public static function export_r() {
		if ( ! function_exists( 'wp_tempnam' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		$tmp = wp_tempnam( 'msm-elektro' );
		if ( ! MSM_Xlsx::write( $tmp, 'lista', self::export_rows(), array( 5, 10, 30, 20, 14, 7, 14, 14, 14, 14, 14, 30, 6, 11, 18 ) ) ) {
			return new WP_Error( 'msm_500', 'Nie udało się utworzyć pliku.', array( 'status' => 500 ) );
		}
		nocache_headers();
		header( 'Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' );
		header( 'Content-Disposition: attachment; filename="elektronarzedzia-' . current_time( 'Y-m-d' ) . '.xlsx"' );
		header( 'Content-Length: ' . filesize( $tmp ) );
		readfile( $tmp ); // phpcs:ignore
		@unlink( $tmp ); // phpcs:ignore
		exit;
	}

	/** Pulpit: narzędzia po terminie sprawdzenia (i w ciągu 14 dni). */
	public static function tablica() {
		global $wpdb;
		$T = self::T();
		if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $T ) ) !== $T ) {
			return null;
		}
		$today = current_time( 'Y-m-d' );
		$soon  = gmdate( 'Y-m-d', strtotime( $today . ' +' . MSM_Settings::prog( 'prog_elektro' ) . ' days' ) );
		$po    = (array) $wpdb->get_results( $wpdb->prepare( "SELECT id, symbol, nazwa, model, lokalizacja, data_nast FROM `$T` WHERE data_nast IS NOT NULL AND data_nast < %s ORDER BY data_nast ASC, symbol ASC", $today ), ARRAY_A ); // phpcs:ignore
		return array(
			'po_terminie' => count( $po ),
			'wkrotce'     => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM `$T` WHERE data_nast >= %s AND data_nast <= %s", $today, $soon ) ), // phpcs:ignore
			'lista'       => array_map( function ( $x ) use ( $today ) {
				return array( 'id' => (int) $x['id'], 'symbol' => $x['symbol'], 'nazwa' => $x['nazwa'], 'model' => $x['model'], 'lokalizacja' => $x['lokalizacja'], 'data_nast' => $x['data_nast'], 'dni' => (int) round( ( strtotime( $today ) - strtotime( $x['data_nast'] ) ) / DAY_IN_SECONDS ) );
			}, array_slice( $po, 0, 8 ) ),
		);
	}
}
