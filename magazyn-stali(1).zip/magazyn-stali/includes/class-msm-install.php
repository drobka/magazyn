<?php
/**
 * Instalacja: tabele, role, strona aplikacji, dane startowe.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MSM_Install {

	const ROLE_ADMIN  = 'msm_admin';
	const ROLE_VIEWER = 'msm_viewer';

	public static function activate() {
		self::create_tables();
		self::create_roles();
		self::ensure_timezone();
		self::create_page();
		update_option( 'users_can_register', 0 );
		self::ensure_unique_numbers();
		MSM_Prod::create_tables();
		update_option( 'msm_db_version', MSM_DB_VERSION );
		MSM_Backup::schedule();
		self::migrate_super_ids();
		self::migrate_backup_names();
		self::migrate_role_names();
		self::seed();
		MSM_Prod::seed();
		MSM_Prod::migrate_split();
		MSM_Prod::migrate_sec();
		MSM_Prod_Narz::mark_existing();
		MSM_Prod_Pal::create_tables();
		MSM_Prod_Pal::purge_orphans();
		MSM_Prod_Notes::create_tables();
		MSM_Przesylki::create_tables();
		MSM_Elektro::create_tables();
		MSM_Pomiar::create_tables();
		MSM_Zam::create_tables();
		MSM_Karty_Zmian::create_tables();
	}

	public static function maybe_upgrade() {
		if ( get_option( 'msm_db_version' ) !== MSM_DB_VERSION ) {
			self::create_tables();
			self::create_roles();
			self::fix_grades();
			self::sync_user_names();
			self::fill_request_types();
			self::fill_log_refs();
			self::fill_log_uwagi();
			MSM_Slowniki::seed_from_wz();
			self::fill_kregi_location();
			self::seed_narzedzia();
			self::migrate_bhp_stany();
			self::migrate_bhp_lokacje();
			self::ensure_timezone();
			self::ensure_unique_numbers();
			MSM_Prod::create_tables();
			MSM_Prod::seed();
			MSM_Prod::migrate_split();
			MSM_Prod::migrate_sec();
			MSM_Prod_Narz::mark_existing();
			MSM_Prod_Pal::create_tables();
			MSM_Prod_Pal::purge_orphans();
			MSM_Prod_Notes::create_tables();
			MSM_Przesylki::create_tables();
			MSM_Elektro::create_tables();
			MSM_Pomiar::create_tables();
			MSM_Zam::create_tables();
			MSM_Karty_Zmian::create_tables();
			MSM_Backup::schedule();
			self::migrate_super_ids();
			self::migrate_backup_names();
			self::migrate_role_names();
			update_option( 'msm_db_version', MSM_DB_VERSION );
		}
	}

	/**
	 * Indeks UNIQUE na numeracji dokumentów (WZ, PZ, wydania i utylizacje BHP).
	 * Blokada FOR UPDATE pilnuje kolejnych numerów – indeks to bezpiecznik na poziomie bazy:
	 * dwa dokumenty nigdy nie dostaną tego samego numeru. NULL (szkice, wpisy archiwalne) jest dozwolony wielokrotnie.
	 * Gdy w danych są już duplikaty, indeksu nie zakładamy i pokazujemy listę w panelu.
	 */
	public static function ensure_unique_numbers() {
		global $wpdb;
		$tables = array(
			msm_table( 'wz' )              => 'rok,miesiac,nr_seq',
			msm_table( 'pz' )              => 'rok,miesiac,nr_seq',
			$wpdb->prefix . 'msm_bhp_wyd'  => 'rok,nr_seq',
			$wpdb->prefix . 'msm_bhp_util' => 'rok,nr_seq',
		);
		$dupes = array();
		foreach ( $tables as $T => $cols ) {
			if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $T ) ) !== $T ) {
				continue;
			}
			if ( $wpdb->get_var( "SHOW INDEX FROM `$T` WHERE Key_name = 'numer_uq'" ) ) { // phpcs:ignore
				continue;
			}
			$found = $wpdb->get_col( "SELECT MIN(numer) FROM `$T` WHERE nr_seq IS NOT NULL GROUP BY $cols HAVING COUNT(*) > 1 LIMIT 20" ); // phpcs:ignore
			if ( $found ) {
				$dupes[ $T ] = $found;
				continue;
			}
			$wpdb->query( "ALTER TABLE `$T` ADD UNIQUE KEY numer_uq ($cols)" ); // phpcs:ignore
		}
		if ( $dupes ) {
			update_option( 'msm_numer_dupes', $dupes, false );
		} else {
			delete_option( 'msm_numer_dupes' );
		}
	}

	/** Komunikat w panelu o zdublowanych numerach (wymaga ręcznej korekty). */
	public static function dupes_notice() {
		$d = get_option( 'msm_numer_dupes' );
		if ( ! $d || ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$parts = array();
		foreach ( $d as $T => $nums ) {
			$parts[] = esc_html( $T ) . ': ' . esc_html( implode( ', ', (array) $nums ) );
		}
		echo '<div class="notice notice-warning"><p><strong>System K-ERP:</strong> w bazie są dokumenty z tym samym numerem, '
			. 'dlatego nie założono zabezpieczenia przed duplikatami numerów. Popraw numery i zaktualizuj wtyczkę ponownie.<br><code>'
			. implode( '</code><br><code>', $parts ) . '</code></p></div>'; // phpcs:ignore
	}

	/**
	 * Jednorazowa migracja do podziału stanu BHP na nowy/używany.
	 * Dotychczasowy stan łączny traktujemy jako „nowy”, używany = 0.
	 * Uruchamiana raz (flaga w opcjach), nie nadpisuje już rozdzielonych stanów.
	 */
	public static function migrate_bhp_stany() {
		global $wpdb;
		if ( get_option( 'msm_bhp_stany_migrated' ) ) {
			return;
		}
		$T = msm_table( 'bhp' );
		// Kolumny muszą już istnieć (dodaje je dbDelta w create_tables powyżej).
		$col = $wpdb->get_results( "SHOW COLUMNS FROM `$T` LIKE 'ilosc_nowy'" ); // phpcs:ignore
		if ( ! $col ) {
			return; // Bezpiecznik – spróbujemy przy następnej aktualizacji.
		}
		// Całą dotychczasową ilość przypisujemy do puli „nowy”, pilnując spójności stanu łącznego.
		$wpdb->query( "UPDATE `$T` SET ilosc_nowy = ilosc, ilosc_uzywany = 0 WHERE ilosc_nowy = 0 AND ilosc_uzywany = 0 AND ilosc > 0" ); // phpcs:ignore
		$wpdb->query( "UPDATE `$T` SET ilosc = ilosc_nowy + ilosc_uzywany" ); // phpcs:ignore
		update_option( 'msm_bhp_stany_migrated', 1 );
	}

	/**
	 * Jednorazowa migracja do podziału stanu BHP na lokalizacje (magazyn / szafa BHP).
	 * Dotychczasowe pule nowy/używany trafiają do lokalizacji wynikającej z pola `lokacja`
	 * (zawiera „szaf” → szafa BHP, w przeciwnym razie magazyn). Agregaty są przeliczane.
	 */
	public static function migrate_bhp_lokacje() {
		global $wpdb;
		if ( get_option( 'msm_bhp_lok_migrated' ) ) {
			return;
		}
		$T   = msm_table( 'bhp' );
		$col = $wpdb->get_results( "SHOW COLUMNS FROM `$T` LIKE 'st_mag_nowy'" ); // phpcs:ignore
		if ( ! $col ) {
			return; // Bezpiecznik – spróbujemy przy następnej aktualizacji.
		}
		// Rozdziel dotychczasowe pule nowy/używany do lokalizacji (tylko wiersze jeszcze nierozdzielone).
		$empty = 'st_mag_nowy = 0 AND st_mag_uzywany = 0 AND st_szafa_nowy = 0 AND st_szafa_uzywany = 0';
		$wpdb->query( "UPDATE `$T` SET st_szafa_nowy = ilosc_nowy, st_szafa_uzywany = ilosc_uzywany WHERE lokacja LIKE '%szaf%' AND $empty" ); // phpcs:ignore
		$wpdb->query( "UPDATE `$T` SET st_mag_nowy = ilosc_nowy, st_mag_uzywany = ilosc_uzywany WHERE ( lokacja IS NULL OR lokacja NOT LIKE '%szaf%' ) AND $empty" ); // phpcs:ignore
		// Przelicz agregaty, aby stan był spójny do pierwszej edycji.
		$wpdb->query( "UPDATE `$T` SET ilosc_nowy = st_mag_nowy + st_szafa_nowy, ilosc_uzywany = st_mag_uzywany + st_szafa_uzywany, ilosc = st_mag_nowy + st_mag_uzywany + st_szafa_nowy + st_szafa_uzywany" ); // phpcs:ignore
		update_option( 'msm_bhp_lok_migrated', 1 );
	}

	/**
	 * System pracuje w Polsce – ustaw strefę czasową na Europe/Warsaw,
	 * jeśli WordPress ma domyślną (pustą = UTC). Nie nadpisuje ustawienia administratora.
	 */
	public static function ensure_timezone() {
		$tz  = (string) get_option( 'timezone_string' );
		$off = get_option( 'gmt_offset' );
		if ( '' === $tz && ( '' === (string) $off || 0 == $off ) ) { // phpcs:ignore
			update_option( 'timezone_string', 'Europe/Warsaw' );
			update_option( 'gmt_offset', '' );
		}
	}

	private static function col_sql( $c ) {
		switch ( $c['type'] ) {
			case 'num':
				$t = in_array( $c['key'], array( 'kg_m', 'kg_szt', 'suma_kg' ), true ) ? 'decimal(16,4)' : 'decimal(14,3)';
				return "`{$c['key']}` $t NULL";
			case 'int':
				return "`{$c['key']}` int(11) NOT NULL DEFAULT 0";
			case 'bool':
				return "`{$c['key']}` tinyint(1) NOT NULL DEFAULT 0";
			case 'date':
				return "`{$c['key']}` date NULL";
			case 'datetime':
				return "`{$c['key']}` datetime NULL";
			case 'enum':
				return "`{$c['key']}` varchar(40) NULL";
			default:
				return ! empty( $c['long'] ) ? "`{$c['key']}` text NULL" : "`{$c['key']}` varchar(190) NULL";
		}
	}

	public static function create_tables() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$charset = $wpdb->get_charset_collate();

		foreach ( msm_schema() as $key => $def ) {
			$T     = msm_table( $key );
			$lines = array( 'id bigint(20) unsigned NOT NULL AUTO_INCREMENT' );
			$keys  = array();
			foreach ( $def['cols'] as $c ) {
				$lines[] = str_replace( '`', '', self::col_sql( $c ) );
				if ( ! empty( $c['filter'] ) && empty( $c['long'] ) ) {
					$keys[] = "KEY {$c['key']} ({$c['key']})";
				}
			}
			if ( ! empty( $def['stock'] ) || ! empty( $def['edit'] ) ) {
				$lines[] = 'created_at datetime NULL';
				$lines[] = 'updated_at datetime NULL';
				$lines[] = 'updated_by bigint(20) unsigned NULL';
			}
			if ( 'pobrania' === $key ) {
				$lines[] = 'item_table varchar(30) NOT NULL';
				$lines[] = 'item_id bigint(20) unsigned NOT NULL';
				$lines[] = 'tryb varchar(10) NOT NULL DEFAULT \'szt\'';
				$lines[] = 'zmiany longtext NULL';
				$lines[] = 'odc_szt int(11) NULL';
				$lines[] = 'odc_dl decimal(14,3) NULL';
				$lines[] = 'user_id bigint(20) unsigned NULL';
				$lines[] = 'created_at datetime NULL';
				$keys[]  = 'KEY item (item_table,item_id)';
			}
			if ( 'wnioski' === $key ) {
				$lines[] = 'user_id bigint(20) unsigned NULL';
				$lines[] = 'item_table varchar(30) NOT NULL';
				$lines[] = 'item_id bigint(20) unsigned NOT NULL';
				$lines[] = 'tryb varchar(10) NOT NULL DEFAULT \'szt\'';
				$lines[] = 'decided_by bigint(20) unsigned NULL';
				$lines[] = 'decided_at datetime NULL';
				$lines[] = 'issued_at datetime NULL';
				$lines[] = 'pobranie_id bigint(20) unsigned NULL';
				$lines[] = 'next_id bigint(20) unsigned NULL';
				$lines[] = 'odc_szt int(11) NULL';
				$lines[] = 'odc_dl decimal(14,3) NULL';
				$keys[]  = 'KEY user_id (user_id)';
			}
			if ( 'rezerwacje' === $key ) {
				$lines[] = 'uwagi text NULL';
				$lines[] = 'item_table varchar(30) NOT NULL';
				$lines[] = 'item_id bigint(20) unsigned NOT NULL';
				$lines[] = 'user_id bigint(20) unsigned NULL';
				$lines[] = 'tryb varchar(10) NOT NULL DEFAULT \'szt\'';
				$lines[] = 'odc_szt int(11) NULL';
				$lines[] = 'odc_dl decimal(14,3) NULL';
				$lines[] = 'decided_by bigint(20) unsigned NULL';
				$lines[] = 'decided_at datetime NULL';
				$lines[] = 'admin_note varchar(500) NULL';
				$lines[] = 'pobranie_id bigint(20) unsigned NULL';
				$lines[] = 'prod_det_id bigint(20) unsigned NULL';
				$keys[]  = 'KEY item (item_table,item_id,status)';
				$keys[]  = 'KEY prod_det (prod_det_id)';
				$keys[]  = 'KEY user_id (user_id)';
			}
			if ( 'pz' === $key ) {
				$lines[] = 'nr_seq int(11) NULL';
				$lines[] = 'rok smallint(6) NULL';
				$lines[] = 'miesiac tinyint(4) NULL';
				$lines[] = 'uwagi text NULL';
				$lines[] = 'ocr longtext NULL';
				$lines[] = 'created_by bigint(20) unsigned NULL';
				$lines[] = 'created_at datetime NULL';
				$lines[] = 'canceled_name varchar(190) NULL';
				$lines[] = 'canceled_at datetime NULL';
				$lines[] = 'updated_name varchar(190) NULL';
				$lines[] = 'updated_at datetime NULL';
			}
			if ( 'wz' === $key ) {
				$lines[] = 'nr_seq int(11) NULL';
				$lines[] = 'rok smallint(6) NULL';
				$lines[] = 'miesiac tinyint(4) NULL';
				$lines[] = 'data_dok date NULL';
				$lines[] = 'uwagi text NULL';
				$lines[] = 'created_by bigint(20) unsigned NULL';
				$lines[] = 'created_at datetime NULL';
				$lines[] = 'updated_at datetime NULL';
				$lines[] = 'issued_by bigint(20) unsigned NULL';
				$lines[] = 'issued_name varchar(190) NULL';
				$lines[] = 'issued_at datetime NULL';
				$lines[] = 'canceled_name varchar(190) NULL';
				$lines[] = 'canceled_at datetime NULL';
				$lines[] = 'edit_count int(11) NOT NULL DEFAULT 0';
				$lines[] = 'edited_name varchar(190) NULL';
				$lines[] = 'edited_at datetime NULL';
				$lines[] = 'podpis longtext NULL';
				$keys[]  = 'KEY numer_seq (rok,miesiac,nr_seq)';
			}
			if ( 'historia' === $key ) {
				$lines[] = 'user_id bigint(20) unsigned NULL';
				$lines[] = 'tabela_key varchar(30) NULL';
				$lines[] = 'item_id bigint(20) unsigned NULL';
				$lines[] = 'dane longtext NULL';
				$lines[] = 'ref_table varchar(30) NULL';
				$lines[] = 'ref_id bigint(20) unsigned NULL';
				$keys[]  = 'KEY ref (ref_table,ref_id)';
			}
			$sql = "CREATE TABLE $T (\n" . implode( ",\n", $lines ) . ",\nPRIMARY KEY  (id)" . ( $keys ? ",\n" . implode( ",\n", $keys ) : '' ) . "\n) ENGINE=InnoDB $charset;";
			dbDelta( $sql );
		}

		// Pozycje dokumentów WZ.
		$T = $wpdb->prefix . 'msm_wz_poz';
		dbDelta( "CREATE TABLE $T (
id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
wz_id bigint(20) unsigned NOT NULL,
lp int(11) NOT NULL DEFAULT 0,
indeks varchar(190) NULL,
zlecenie varchar(190) NULL,
rysunek varchar(190) NULL,
nazwa varchar(255) NULL,
ilosc decimal(14,3) NULL,
jm varchar(20) NULL,
src varchar(20) NOT NULL DEFAULT 'reczna',
item_table varchar(30) NULL,
item_id bigint(20) unsigned NULL,
wniosek_id bigint(20) unsigned NULL,
pobranie_id bigint(20) unsigned NULL,
PRIMARY KEY  (id),
KEY wz_id (wz_id),
KEY item (item_table,item_id)
) ENGINE=InnoDB $charset;" );

		// Dokumenty wydania BHP.
		$T = $wpdb->prefix . 'msm_bhp_wyd';
		dbDelta( "CREATE TABLE $T (
id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
numer varchar(40) NULL,
nr_seq int(11) NULL,
rok smallint(6) NULL,
osoba_id bigint(20) unsigned NULL,
osoba_name varchar(190) NULL,
dzial varchar(190) NULL,
data date NULL,
uwagi text NULL,
status varchar(20) NOT NULL DEFAULT 'wydane',
wydal_id bigint(20) unsigned NULL,
wydal_name varchar(190) NULL,
canceled_name varchar(190) NULL,
canceled_at datetime NULL,
created_at datetime NULL,
PRIMARY KEY  (id),
KEY osoba_id (osoba_id),
KEY numer_seq (rok,nr_seq)
) ENGINE=InnoDB $charset;" );

		$T = $wpdb->prefix . 'msm_bhp_wyd_poz';
		dbDelta( "CREATE TABLE $T (
id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
wyd_id bigint(20) unsigned NOT NULL,
lp int(11) NOT NULL DEFAULT 0,
bhp_id bigint(20) unsigned NULL,
kategoria varchar(190) NULL,
nazwa varchar(255) NULL,
rozmiar varchar(80) NULL,
ilosc int(11) NOT NULL DEFAULT 1,
ilosc_nowy int(11) NOT NULL DEFAULT 0,
ilosc_uzywany int(11) NOT NULL DEFAULT 0,
lokacja varchar(20) NOT NULL DEFAULT 'magazyn',
jm varchar(20) NOT NULL DEFAULT 'szt',
zrodlo varchar(20) NOT NULL DEFAULT 'magazyn',
PRIMARY KEY  (id),
KEY wyd_id (wyd_id)
) ENGINE=InnoDB $charset;" );

		// Protokoły utylizacji / rozliczenia wyposażenia BHP.
		$T = $wpdb->prefix . 'msm_bhp_util';
		dbDelta( "CREATE TABLE $T (
id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
numer varchar(40) NULL,
nr_seq int(11) NULL,
rok smallint(6) NULL,
osoba_id bigint(20) unsigned NULL,
osoba_name varchar(190) NULL,
dzial varchar(190) NULL,
data date NULL,
powod varchar(60) NULL,
uwagi text NULL,
podpis longtext NULL,
status varchar(20) NOT NULL DEFAULT 'zatwierdzony',
user_id bigint(20) unsigned NULL,
user_name varchar(190) NULL,
created_at datetime NULL,
PRIMARY KEY  (id),
KEY osoba_id (osoba_id),
KEY numer_seq (rok,nr_seq)
) ENGINE=InnoDB $charset;" );

		$T = $wpdb->prefix . 'msm_bhp_util_poz';
		dbDelta( "CREATE TABLE $T (
id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
util_id bigint(20) unsigned NOT NULL,
lp int(11) NOT NULL DEFAULT 0,
typ varchar(20) NOT NULL DEFAULT 'utylizacja',
bhp_id bigint(20) unsigned NULL,
kategoria varchar(190) NULL,
nazwa varchar(255) NULL,
rozmiar varchar(80) NULL,
ilosc int(11) NOT NULL DEFAULT 1,
jm varchar(20) NOT NULL DEFAULT 'szt',
powod varchar(60) NULL,
PRIMARY KEY  (id),
KEY util_id (util_id)
) ENGINE=InnoDB $charset;" );

		MSM_Slowniki::create_table();
		MSM_PZ::create_tables();
		MSM_Logins::create_table();
		self::seed_bhp();
	}

	/** Jednorazowe wczytanie stanu magazynu BHP z data/bhp.json (gdy tabela pusta). */
	public static function seed_bhp() {
		global $wpdb;
		if ( get_option( 'msm_bhp_seeded' ) ) {
			return;
		}
		$T = msm_table( 'bhp' );
		if ( (int) $wpdb->get_var( "SELECT COUNT(*) FROM `$T`" ) > 0 ) {
			update_option( 'msm_bhp_seeded', 1 );
			return;
		}
		$file = MSM_DIR . 'data/bhp.json';
		if ( ! file_exists( $file ) ) {
			return;
		}
		$rows = json_decode( (string) file_get_contents( $file ), true );
		if ( ! is_array( $rows ) ) {
			return;
		}
		$now = current_time( 'mysql' );
		foreach ( $rows as $r ) {
			$q     = (int) ( $r['ilosc'] ?? 0 );
			$lok   = (string) ( $r['lokacja'] ?? 'magazyn' );
			$szafa = ( false !== mb_stripos( $lok, 'szaf' ) );
			$wpdb->insert( $T, array(
				'kategoria'     => (string) ( $r['kategoria'] ?? '' ),
				'nazwa'         => (string) ( $r['nazwa'] ?? '' ),
				'producent_id'  => (string) ( $r['producent_id'] ?? '' ),
				'rozmiar'       => (string) ( $r['rozmiar'] ?? '' ),
				'st_mag_nowy'   => $szafa ? 0 : $q,
				'st_szafa_nowy' => $szafa ? $q : 0,
				'ilosc_nowy'    => $q,
				'ilosc'         => $q,
				'lokacja'       => $lok,
				'created_at'    => $now,
				'updated_at'    => $now,
			) );
		}
		update_option( 'msm_bhp_seeded', 1 );
	}

	/**
	 * Uzupełnia nazwy w historii i pobraniach aktualną nazwą „Przedstawiaj mnie jako” z profilu WP.
	 * Bez argumentu – dla wszystkich użytkowników, z argumentem – dla jednego.
	 */
	public static function sync_user_names( $user_id = 0 ) {
		global $wpdb;
		$pairs = array( array( 'historia', 'user_id', 'user_name' ), array( 'pobrania', 'user_id', 'user_name' ), array( 'wnioski', 'user_id', 'user_name' ), array( 'wnioski', 'decided_by', 'decided_name' ) );
		foreach ( $pairs as $pair ) {
			list( $t, $idcol, $namecol ) = $pair;
			$T = msm_table( $t );
			if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $T ) ) !== $T ) {
				continue;
			}
			if ( $user_id ) {
				$u = get_userdata( $user_id );
				if ( $u ) {
					$wpdb->update( $T, array( $namecol => $u->display_name ), array( $idcol => (int) $user_id ) );
				}
			} else {
				$wpdb->query( "UPDATE `$T` t INNER JOIN `{$wpdb->users}` u ON u.ID = t.`$idcol` SET t.`$namecol` = u.display_name" ); // phpcs:ignore
			}
		}
	}

	/** Uzupełnia w historii odnośnik do pozycji magazynowej (dla wpisów sprzed wersji 1.8). */
	/** Jednorazowe wczytanie ewidencji sprawdzianów/przyrządów z data/narzedzia.json (gdy tabele puste). */
	public static function seed_narzedzia() {
		if ( get_option( 'msm_narz_seeded' ) ) {
			return;
		}
		$file = MSM_DIR . 'data/narzedzia.json';
		if ( ! file_exists( $file ) ) {
			return;
		}
		$data = json_decode( (string) file_get_contents( $file ), true ); // phpcs:ignore
		if ( ! is_array( $data ) ) {
			return;
		}
		global $wpdb;
		foreach ( msm_narzedzia_tables() as $t ) {
			if ( ! isset( $data[ $t ] ) || (int) $wpdb->get_var( 'SELECT COUNT(*) FROM `' . msm_table( $t ) . '`' ) > 0 ) { // phpcs:ignore
				continue;
			}
			foreach ( $data[ $t ] as $row ) {
				$clean = MSM_Repo::sanitize( $t, (array) $row );
				if ( ! is_wp_error( $clean ) ) {
					MSM_Repo::insert_raw( $t, $clean );
				}
			}
		}
		update_option( 'msm_narz_seeded', 1 );
	}

	/** Kręgi: istniejące pozycje bez lokalizacji → Magazyn Ligota. */
	public static function fill_kregi_location() {
		global $wpdb;
		$T = msm_table( 'kregi' );
		$wpdb->query( "UPDATE `$T` SET lokalizacja = 'Magazyn Ligota' WHERE lokalizacja IS NULL OR lokalizacja = ''" ); // phpcs:ignore
	}

	public static function fill_log_refs() {
		global $wpdb;
		$L = msm_table( 'historia' );
		$W = msm_table( 'wnioski' );
		$wpdb->query( "UPDATE `$L` SET ref_table = tabela_key, ref_id = item_id WHERE ref_table IS NULL AND tabela_key IN ('stal','blachy_pelne','blachy_niepelne','kregi') AND item_id > 0" ); // phpcs:ignore
		$wpdb->query( "UPDATE `$L` l INNER JOIN `$W` w ON l.tabela_key = 'wnioski' AND l.item_id = w.id SET l.ref_table = w.item_table, l.ref_id = w.item_id WHERE l.ref_table IS NULL" ); // phpcs:ignore
	}

	/** Kolumna „Uwagi” w Historii zmian dla wpisów sprzed 1.92.0 – odczyt z zapisanych danych czynności (jednorazowo). */
	public static function fill_log_uwagi() {
		global $wpdb;
		if ( get_option( 'msm_log_uwagi_filled' ) ) {
			return;
		}
		$L    = msm_table( 'historia' );
		$last = 0;
		do {
			$rows = (array) $wpdb->get_results( $wpdb->prepare( "SELECT id, dane FROM `$L` WHERE id > %d AND uwagi IS NULL AND dane LIKE %s ORDER BY id ASC LIMIT 500", $last, '%"uwagi"%' ), ARRAY_A ); // phpcs:ignore
			foreach ( $rows as $r ) {
				$last = (int) $r['id'];
				$u    = MSM_Repo::log_uwagi( json_decode( (string) $r['dane'], true ) );
				if ( null !== $u ) {
					$wpdb->update( $L, array( 'uwagi' => $u ), array( 'id' => $last ) );
				}
			}
		} while ( count( $rows ) === 500 );
		update_option( 'msm_log_uwagi_filled', 1 );
	}

	/** Wnioski sprzed wersji 1.6 to zawsze „pobranie”. */
	public static function fill_request_types() {
		global $wpdb;
		$T = msm_table( 'wnioski' );
		if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $T ) ) === $T ) {
			$wpdb->query( "UPDATE `$T` SET typ = 'pobranie' WHERE typ IS NULL OR typ = ''" ); // phpcs:ignore
		}
	}

	/** Poprawka literówek w gatunkach (S325 → S235, S255 → S355) w już wczytanych danych. */
	public static function fix_grades() {
		global $wpdb;
		$map = array( 'S325' => 'S235', 'S255' => 'S355' );
		foreach ( array( 'stal' => 'gatunek', 'blachy_pelne' => 'material', 'blachy_niepelne' => 'gatunek' ) as $t => $col ) {
			$T = msm_table( $t );
			if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $T ) ) !== $T ) {
				continue;
			}
			foreach ( $map as $from => $to ) {
				$wpdb->query( $wpdb->prepare( "UPDATE `$T` SET `$col` = %s WHERE `$col` = %s", $to, $from ) ); // phpcs:ignore
			}
		}
	}

	/**
	 * Super admin (trwałe usuwanie bez śladu i zmiana ustawień).
	 * Od 1.84.0 login z listy „super_logins” musi należeć do TEGO SAMEGO konta (ID), które było
	 * przypisane w chwili zapisu ustawień – nowe konto założone później pod tym samym loginem
	 * nie dostaje uprawnień. Zapas: capability 'msm_purge' (administrator WordPressa).
	 * Loginy dopisane wyłącznie filtrem 'msm_super_logins' (w kodzie) działają jak dotąd – wg loginu.
	 *
	 * @param WP_User|int|null $user Domyślnie bieżący użytkownik.
	 */
	public static function can_purge( $user = null ) {
		if ( null === $user ) {
			$user = wp_get_current_user();
		} elseif ( is_numeric( $user ) ) {
			$user = get_user_by( 'id', (int) $user );
		}
		if ( ! $user || ! $user->exists() ) {
			return false;
		}
		if ( user_can( $user, 'msm_purge' ) ) {
			return true;
		}
		$lower    = function ( $v ) { return strtolower( trim( (string) $v ) ); };
		$settings = array_filter( array_map( $lower, (array) MSM_Settings::get( 'super_logins' ) ) );
		$logins   = array_filter( array_map( $lower, (array) apply_filters( 'msm_super_logins', (array) MSM_Settings::get( 'super_logins' ) ) ) );
		$login    = strtolower( $user->user_login );
		if ( ! in_array( $login, $logins, true ) ) {
			return false;
		}
		if ( ! in_array( $login, $settings, true ) ) {
			return true; // dopisany filtrem w kodzie
		}
		$ids = MSM_Settings::super_ids();
		return isset( $ids[ $login ] ) && (int) $ids[ $login ] === (int) $user->ID;
	}

	/**
	 * 1.84.0: utrwalenie listy super administratorów w ustawieniach i powiązanie loginów z ID kont
	 * (wcześniej lista mogła pochodzić tylko z wartości domyślnej w kodzie).
	 */
	public static function migrate_super_ids() {
		$saved = get_option( MSM_Settings::OPT, array() );
		$saved = is_array( $saved ) ? $saved : array();
		if ( ! isset( $saved['super_logins'] ) ) {
			$saved['super_logins'] = array( '4hiv2w' ); // dotychczasowa wartość domyślna
		}
		if ( ! isset( $saved['super_ids'] ) || ! is_array( $saved['super_ids'] ) ) {
			$saved['super_ids'] = MSM_Settings::bind_ids( (array) $saved['super_logins'] );
		}
		update_option( MSM_Settings::OPT, $saved, false );
	}

	/** 1.86.0: nowe nazwy ról w WordPressie (System K-ERP). Klucze ról i uprawnienia bez zmian. */
	public static function migrate_role_names() {
		if ( ! function_exists( 'wp_roles' ) ) {
			return;
		}
		$wr    = wp_roles();
		$names = array( self::ROLE_ADMIN => 'K-ERP – administrator', self::ROLE_VIEWER => 'K-ERP – przeglądający' );
		$dirty = false;
		foreach ( $names as $k => $n ) {
			if ( isset( $wr->roles[ $k ] ) && $wr->roles[ $k ]['name'] !== $n ) {
				$wr->roles[ $k ]['name'] = $n;
				$wr->role_names[ $k ]    = $n;
				$dirty                   = true;
			}
		}
		if ( $dirty && $wr->use_db ) {
			update_option( $wr->role_key, $wr->roles );
		}
	}

	/** 1.84.0: dopisanie losowego sufiksu do nazw istniejących plików kopii (nie da się ich zgadnąć). */
	public static function migrate_backup_names() {
		if ( ! class_exists( 'MSM_Backup' ) ) {
			return;
		}
		$dir = MSM_Backup::dir();
		foreach ( (array) glob( $dir . '/kopia-*.xlsx' ) as $f ) {
			$base = basename( $f, '.xlsx' );
			if ( preg_match( '/^kopia-[\d\-]+$/', $base ) ) {
				@rename( $f, $dir . '/' . $base . '-' . strtolower( wp_generate_password( 20, false ) ) . '.xlsx' ); // phpcs:ignore
			}
		}
	}

	public static function create_roles() {
		add_role( self::ROLE_ADMIN, 'K-ERP – administrator', array( 'read' => true, 'msm_view' => true, 'msm_edit' => true ) );
		add_role( self::ROLE_VIEWER, 'K-ERP – przeglądający', array( 'read' => true, 'msm_view' => true ) );
		$r = get_role( self::ROLE_ADMIN );
		if ( $r ) {
			$r->add_cap( 'msm_view' );
			$r->add_cap( 'msm_edit' );
		}
		$r = get_role( 'administrator' );
		if ( $r ) {
			$r->add_cap( 'msm_view' );
			$r->add_cap( 'msm_edit' );
			$r->add_cap( 'msm_purge' ); // super admin: trwałe usuwanie bez śladu
		}
	}

	public static function create_page() {
		$id = (int) get_option( 'msm_page_id' );
		if ( $id && get_post( $id ) && 'trash' !== get_post_status( $id ) ) {
			return;
		}
		$id = wp_insert_post( array(
			'post_title'   => 'Magazyn',
			'post_name'    => 'magazyn',
			'post_content' => '<!-- wp:shortcode -->[magazyn]<!-- /wp:shortcode -->',
			'post_status'  => 'publish',
			'post_type'    => 'page',
		) );
		if ( $id && ! is_wp_error( $id ) ) {
			update_option( 'msm_page_id', (int) $id );
		}
	}

	/** Wczytuje dane z data/seed.json przy pierwszej aktywacji, jeśli tabele są puste. */
	public static function seed() {
		global $wpdb;
		if ( get_option( 'msm_seeded' ) ) {
			return;
		}
		$file = MSM_DIR . 'data/seed.json';
		if ( ! file_exists( $file ) ) {
			return;
		}
		foreach ( msm_stock_tables() as $t ) {
			if ( (int) $wpdb->get_var( 'SELECT COUNT(*) FROM `' . msm_table( $t ) . '`' ) > 0 ) { // phpcs:ignore
				update_option( 'msm_seeded', 1 );
				return;
			}
		}
		$data = json_decode( (string) file_get_contents( $file ), true ); // phpcs:ignore
		if ( ! is_array( $data ) ) {
			return;
		}
		foreach ( $data as $table => $rows ) {
			if ( ! in_array( $table, msm_stock_tables(), true ) ) {
				continue;
			}
			$n = 0;
			foreach ( $rows as $row ) {
				$clean = MSM_Repo::sanitize( $table, $row );
				if ( ! is_wp_error( $clean ) && MSM_Repo::insert_raw( $table, $clean ) ) {
					$n++;
				}
			}
			MSM_Repo::log( 'import', $table, 0, 'Dane startowe z zestawień Excel: ' . $n . ' poz.' );
		}
		update_option( 'msm_seeded', 1 );
	}
}
