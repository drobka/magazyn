<?php
/**
 * Magazyn BHP – utylizacja / rozliczenie wyposażenia, normy przydziału, terminy wymiany.
 *  - stan posiadania osoby (held) = wydane − (utylizacja + zwrot)
 *  - normy: maks. na wyposażeniu per asortyment (blokada przy wydaniu, z nadpisaniem admina)
 *  - utylizacja (bez wpływu na magazyn) oraz zwrot używalnego na magazyn
 *  - wydruki: protokół utylizacji + raport zbiorczy; lista „do wymiany”
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MSM_Bhp_Util {

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
		add_action( 'template_redirect', array( __CLASS__, 'maybe_print' ), 1 );
	}

	private static function TU() {
		global $wpdb; return $wpdb->prefix . 'msm_bhp_util';
	}
	private static function TUP() {
		global $wpdb; return $wpdb->prefix . 'msm_bhp_util_poz';
	}
	private static function key3( $r ) {
		return mb_strtolower( trim( (string) $r['kategoria'] ) . '|' . trim( (string) $r['nazwa'] ) . '|' . trim( (string) $r['rozmiar'] ), 'UTF-8' );
	}

	/* ------------------------------------------------------------------ *
	 * Normy przydziału
	 * ------------------------------------------------------------------ */
	public static function norms() {
		global $wpdb;
		$out = array();
		$rows = $wpdb->get_results( 'SELECT kategoria, limit_szt, wymiana_mies FROM `' . msm_table( 'bhp_normy' ) . '`', ARRAY_A ); // phpcs:ignore
		foreach ( (array) $rows as $r ) {
			$k = trim( (string) $r['kategoria'] );
			if ( '' === $k ) {
				continue;
			}
			$out[ mb_strtolower( $k, 'UTF-8' ) ] = array(
				'kategoria' => $k,
				'limit'     => (int) $r['limit_szt'],
				'wymiana'   => (int) $r['wymiana_mies'],
			);
		}
		return $out;
	}

	/* ------------------------------------------------------------------ *
	 * Stan posiadania (held) osoby
	 * ------------------------------------------------------------------ */
	public static function held_lines( $osoba_id ) {
		global $wpdb;
		$osoba_id = (int) $osoba_id;
		if ( ! $osoba_id ) {
			return array();
		}
		$BW = $wpdb->prefix . 'msm_bhp_wyd';
		$BP = $wpdb->prefix . 'msm_bhp_wyd_poz';
		$iss = $wpdb->get_results( $wpdb->prepare( "SELECT p.kategoria, p.nazwa, p.rozmiar, MAX(p.bhp_id) bhp_id, SUM(p.ilosc) q, MAX(w.data) last_data FROM `$BP` p INNER JOIN `$BW` w ON w.id = p.wyd_id WHERE w.osoba_id = %d AND w.status <> 'anulowane' GROUP BY p.kategoria, p.nazwa, p.rozmiar", $osoba_id ), ARRAY_A ); // phpcs:ignore
		$rem = $wpdb->get_results( $wpdb->prepare( "SELECT p.kategoria, p.nazwa, p.rozmiar, SUM(p.ilosc) q FROM `" . self::TUP() . "` p INNER JOIN `" . self::TU() . "` u ON u.id = p.util_id WHERE u.osoba_id = %d AND u.status <> 'anulowany' GROUP BY p.kategoria, p.nazwa, p.rozmiar", $osoba_id ), ARRAY_A ); // phpcs:ignore
		$remMap = array();
		foreach ( (array) $rem as $r ) {
			$remMap[ self::key3( $r ) ] = (int) $r['q'];
		}
		$lines = array();
		$bids  = array();
		foreach ( (array) $iss as $r ) {
			$k    = self::key3( $r );
			$held = (int) $r['q'] - ( isset( $remMap[ $k ] ) ? $remMap[ $k ] : 0 );
			if ( $held <= 0 ) {
				continue;
			}
			$bid = $r['bhp_id'] ? (int) $r['bhp_id'] : null;
			if ( $bid ) {
				$bids[] = $bid;
			}
			$lines[] = array(
				'kategoria' => (string) $r['kategoria'],
				'nazwa'     => (string) $r['nazwa'],
				'rozmiar'   => (string) $r['rozmiar'],
				'bhp_id'    => $bid,
				'held'      => $held,
				'last_data' => (string) $r['last_data'],
				'norma'     => '',
			);
		}
		// Norma przydziału z przypisania na produkcie (bhp.norma).
		if ( $bids ) {
			$in  = implode( ',', array_unique( $bids ) );
			$map = array();
			foreach ( $wpdb->get_results( "SELECT id, norma FROM `" . msm_table( 'bhp' ) . "` WHERE id IN ($in)", ARRAY_A ) as $b ) { // phpcs:ignore
				$map[ (int) $b['id'] ] = (string) $b['norma'];
			}
			foreach ( $lines as &$l ) {
				if ( $l['bhp_id'] && isset( $map[ $l['bhp_id'] ] ) ) {
					$l['norma'] = $map[ $l['bhp_id'] ];
				}
			}
			unset( $l );
		}
		return $lines;
	}

	/** Stan posiadania zgrupowany po normie przydziału (pomija pozycje bez przypisanej normy). */
	public static function held_by_norm( $osoba_id ) {
		$out = array();
		foreach ( self::held_lines( $osoba_id ) as $l ) {
			$n = mb_strtolower( trim( (string) $l['norma'] ), 'UTF-8' );
			if ( '' === $n ) {
				continue;
			}
			$out[ $n ] = ( isset( $out[ $n ] ) ? $out[ $n ] : 0 ) + (int) $l['held'];
		}
		return $out;
	}

	/** Mapa bhp_id → norma (nazwa grupy) dla wskazanych produktów. */
	private static function norma_of_products( array $bhp_ids ) {
		global $wpdb;
		$bhp_ids = array_filter( array_map( 'intval', $bhp_ids ) );
		if ( ! $bhp_ids ) {
			return array();
		}
		$in  = implode( ',', array_unique( $bhp_ids ) );
		$out = array();
		foreach ( $wpdb->get_results( "SELECT id, norma FROM `" . msm_table( 'bhp' ) . "` WHERE id IN ($in)", ARRAY_A ) as $b ) { // phpcs:ignore
			$out[ (int) $b['id'] ] = (string) $b['norma'];
		}
		return $out;
	}

	/** Zwraca listę przekroczeń normy dla planowanego wydania ($lines: pozycje z 'norma' lub 'bhp_id' i 'ilosc'). */
	public static function check_norm( $osoba_id, array $lines ) {
		$norms = self::norms();
		if ( ! $norms || ! $osoba_id ) {
			return array();
		}
		$held = self::held_by_norm( $osoba_id );
		// Uzupełnij normę po bhp_id, jeśli nie podano wprost.
		$need = array();
		foreach ( $lines as $l ) {
			if ( ( ! isset( $l['norma'] ) || '' === trim( (string) $l['norma'] ) ) && ! empty( $l['bhp_id'] ) ) {
				$need[] = (int) $l['bhp_id'];
			}
		}
		$pmap = $need ? self::norma_of_products( $need ) : array();
		$req  = array();
		foreach ( $lines as $l ) {
			$norma = isset( $l['norma'] ) ? trim( (string) $l['norma'] ) : '';
			if ( '' === $norma && ! empty( $l['bhp_id'] ) && isset( $pmap[ (int) $l['bhp_id'] ] ) ) {
				$norma = $pmap[ (int) $l['bhp_id'] ];
			}
			$n = mb_strtolower( $norma, 'UTF-8' );
			if ( '' === $n ) {
				continue;
			}
			$req[ $n ] = ( isset( $req[ $n ] ) ? $req[ $n ] : 0 ) + (int) MSM_Calc::f( $l['ilosc'] ?? 0 );
		}
		$ex = array();
		foreach ( $req as $n => $q ) {
			if ( ! isset( $norms[ $n ] ) || $norms[ $n ]['limit'] <= 0 ) {
				continue;
			}
			$have = isset( $held[ $n ] ) ? $held[ $n ] : 0;
			if ( $have + $q > $norms[ $n ]['limit'] ) {
				$ex[] = array(
					'kategoria' => $norms[ $n ]['kategoria'],
					'limit'     => $norms[ $n ]['limit'],
					'posiada'   => $have,
					'wydawane'  => $q,
					'po'        => $have + $q,
				);
			}
		}
		return $ex;
	}

	/* ------------------------------------------------------------------ *
	 * Lista „do wymiany” (termin minął)
	 * ------------------------------------------------------------------ */
	public static function do_wymiany() {
		global $wpdb;
		$norms = self::norms();
		$hasW  = false;
		foreach ( $norms as $n ) {
			if ( $n['wymiana'] > 0 ) { $hasW = true; break; }
		}
		if ( ! $hasW ) {
			return array();
		}
		$today = current_time( 'Y-m-d' );
		$out   = array();
		$osoby = $wpdb->get_results( 'SELECT id, imie_nazwisko, dzial FROM `' . msm_table( 'bhp_osoby' ) . '`', ARRAY_A ); // phpcs:ignore
		foreach ( (array) $osoby as $o ) {
			foreach ( self::held_lines( (int) $o['id'] ) as $l ) {
				$k = mb_strtolower( trim( (string) $l['norma'] ), 'UTF-8' );
				if ( '' === $k || ! isset( $norms[ $k ] ) || $norms[ $k ]['wymiana'] <= 0 || empty( $l['last_data'] ) ) {
					continue;
				}
				$due = gmdate( 'Y-m-d', strtotime( $l['last_data'] . ' +' . (int) $norms[ $k ]['wymiana'] . ' months' ) );
				if ( $due <= $today ) {
					$out[] = array(
						'osoba'     => $o['imie_nazwisko'],
						'dzial'     => $o['dzial'],
						'kategoria' => $l['kategoria'],
						'nazwa'     => $l['nazwa'],
						'rozmiar'   => $l['rozmiar'],
						'held'      => $l['held'],
						'wydano'    => $l['last_data'],
						'termin'    => $due,
					);
				}
			}
		}
		usort( $out, function ( $a, $b ) { return strcmp( $a['termin'], $b['termin'] ); } );
		return $out;
	}

	/* ------------------------------------------------------------------ *
	 * Utworzenie protokołu utylizacji / zwrotu
	 * ------------------------------------------------------------------ */
	public static function create( array $in ) {
		global $wpdb;
		if ( ! current_user_can( 'msm_edit' ) || ( class_exists( 'MSM_Perms' ) && ! MSM_Perms::user_can( 'edit' ) ) ) {
			return new WP_Error( 'msm_forbidden', 'Brak uprawnień.', array( 'status' => 403 ) );
		}
		$osoba_id = (int) ( $in['osoba_id'] ?? 0 );
		$os       = $osoba_id ? $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM `' . msm_table( 'bhp_osoby' ) . '` WHERE id = %d', $osoba_id ), ARRAY_A ) : null; // phpcs:ignore
		if ( ! $os ) {
			return new WP_Error( 'msm_400', 'Wybierz osobę z rejestru.', array( 'status' => 400, 'fields' => array( 'osoba' => 'Wybierz osobę' ) ) );
		}
		$osoba_name = (string) $os['imie_nazwisko'];
		$dzial      = trim( sanitize_text_field( wp_unslash( (string) ( $in['dzial'] ?? '' ) ) ) );
		if ( '' === $dzial ) {
			$dzial = (string) $os['dzial'];
		}
		$data  = ( isset( $in['data'] ) && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $in['data'] ) ) ? $in['data'] : current_time( 'Y-m-d' );
		$powod = trim( sanitize_text_field( wp_unslash( (string) ( $in['powod'] ?? '' ) ) ) );
		$uwagi = trim( sanitize_textarea_field( wp_unslash( (string) ( $in['uwagi'] ?? '' ) ) ) );
		$podpis = self::clean_sig( (string) ( $in['podpis'] ?? '' ) );
		$lines  = isset( $in['lines'] ) && is_array( $in['lines'] ) ? $in['lines'] : array();

		// Stan posiadania do walidacji ilości.
		$held = array();
		foreach ( self::held_lines( $osoba_id ) as $l ) {
			$held[ self::key3( $l ) ] = array( 'held' => (int) $l['held'], 'bhp_id' => $l['bhp_id'] );
		}
		$norm = array();
		$used = array();
		foreach ( $lines as $l ) {
			$ilosc = (int) MSM_Calc::f( $l['ilosc'] ?? 0 );
			if ( $ilosc < 1 ) {
				continue;
			}
			$typ   = ( 'zwrot' === ( $l['typ'] ?? '' ) ) ? 'zwrot' : 'utylizacja';
			$kat   = trim( sanitize_text_field( wp_unslash( (string) ( $l['kategoria'] ?? '' ) ) ) );
			$naz   = trim( sanitize_text_field( wp_unslash( (string) ( $l['nazwa'] ?? '' ) ) ) );
			$roz   = trim( sanitize_text_field( wp_unslash( (string) ( $l['rozmiar'] ?? '' ) ) ) );
			if ( '' === $naz ) {
				return new WP_Error( 'msm_400', 'Pozycja musi mieć nazwę.', array( 'status' => 400 ) );
			}
			$key = mb_strtolower( $kat . '|' . $naz . '|' . $roz, 'UTF-8' );
			$have = isset( $held[ $key ] ) ? $held[ $key ]['held'] : 0;
			$used[ $key ] = ( isset( $used[ $key ] ) ? $used[ $key ] : 0 ) + $ilosc;
			if ( $used[ $key ] > $have ) {
				return new WP_Error( 'msm_400', $naz . ( $roz ? ' rozm. ' . $roz : '' ) . ': osoba ma na wyposażeniu tylko ' . $have . ' szt. Nic nie zapisano.', array( 'status' => 400 ) );
			}
			$norm[] = array(
				'typ'       => $typ,
				'bhp_id'    => isset( $held[ $key ]['bhp_id'] ) ? $held[ $key ]['bhp_id'] : null,
				'kategoria' => $kat,
				'nazwa'     => $naz,
				'rozmiar'   => $roz,
				'ilosc'     => $ilosc,
				'powod'     => 'zwrot' === $typ ? '' : ( trim( sanitize_text_field( wp_unslash( (string) ( $l['powod'] ?? '' ) ) ) ) ?: $powod ),
			);
		}
		if ( ! $norm ) {
			return new WP_Error( 'msm_400', 'Zaznacz co najmniej jedną pozycję do utylizacji lub zwrotu.', array( 'status' => 400 ) );
		}

		$y = (int) current_time( 'Y' );
		$wpdb->query( 'START TRANSACTION' );
		$seq = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT MAX(nr_seq) FROM `' . self::TU() . '` WHERE rok = %d FOR UPDATE', $y ) ) + 1; // phpcs:ignore
		$nr  = 'UTYL/' . sprintf( '%04d', $seq ) . '/' . $y;

		// Zwrot używalnego → na magazyn BHP (dopisanie do stanu).
		foreach ( $norm as $l ) {
			if ( 'zwrot' !== $l['typ'] ) {
				continue;
			}
			if ( $l['bhp_id'] && (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM `' . msm_table( 'bhp' ) . '` WHERE id = %d', $l['bhp_id'] ) ) ) { // phpcs:ignore
				// Zwrócony od pracownika = używany → magazyn, pula używany.
				if ( class_exists( 'MSM_Bhp' ) ) {
					MSM_Bhp::restock( (int) $l['bhp_id'], 'magazyn', 0, (int) $l['ilosc'] );
				} else {
					$wpdb->query( $wpdb->prepare( 'UPDATE `' . msm_table( 'bhp' ) . '` SET st_mag_uzywany = st_mag_uzywany + %d, ilosc_uzywany = st_mag_uzywany + st_szafa_uzywany, ilosc = st_mag_nowy + st_mag_uzywany + st_szafa_nowy + st_szafa_uzywany, updated_at = %s WHERE id = %d', (int) $l['ilosc'], current_time( 'mysql' ), (int) $l['bhp_id'] ) ); // phpcs:ignore
				}
			} else {
				$q = (int) $l['ilosc'];
				$wpdb->insert( msm_table( 'bhp' ), array(
					'kategoria'      => $l['kategoria'],
					'nazwa'          => $l['nazwa'],
					'rozmiar'        => $l['rozmiar'],
					'st_mag_uzywany' => $q,
					'ilosc_uzywany'  => $q,
					'ilosc'          => $q,
					'lokacja'        => 'magazyn',
					'uwagi'          => 'Zwrot używalnego od: ' . $osoba_name,
					'created_at'     => current_time( 'mysql' ),
					'updated_at'     => current_time( 'mysql' ),
				) );
			}
		}
		$wpdb->insert( self::TU(), array(
			'numer'      => $nr,
			'nr_seq'     => $seq,
			'rok'        => $y,
			'osoba_id'   => $osoba_id,
			'osoba_name' => $osoba_name,
			'dzial'      => $dzial,
			'data'       => $data,
			'powod'      => $powod,
			'uwagi'      => $uwagi,
			'podpis'     => $podpis,
			'status'     => 'zatwierdzony',
			'user_id'    => get_current_user_id(),
			'user_name'  => MSM_Repo::user_name(),
			'created_at' => current_time( 'mysql' ),
		) );
		$id = (int) $wpdb->insert_id;
		if ( ! $id ) {
			$wpdb->query( 'ROLLBACK' );
			return new WP_Error( 'msm_db', 'Nie udało się zapisać protokołu.', array( 'status' => 500 ) );
		}
		$lp = 0;
		foreach ( $norm as $l ) {
			$wpdb->insert( self::TUP(), array(
				'util_id'   => $id,
				'lp'        => ++$lp,
				'typ'       => $l['typ'],
				'bhp_id'    => $l['bhp_id'],
				'kategoria' => $l['kategoria'],
				'nazwa'     => $l['nazwa'],
				'rozmiar'   => $l['rozmiar'],
				'ilosc'     => $l['ilosc'],
				'jm'        => 'szt',
				'powod'     => $l['powod'],
			) );
		}
		$wpdb->query( 'COMMIT' );

		$uty = 0; $zwr = 0;
		foreach ( $norm as $l ) { if ( 'zwrot' === $l['typ'] ) { $zwr += $l['ilosc']; } else { $uty += $l['ilosc']; } }
		MSM_Repo::log( 'BHP: utylizacja', 'bhp', $id, 'Protokół ' . $nr . ' dla: ' . $osoba_name . ' – utylizacja ' . $uty . ' szt.' . ( $zwr ? ', zwrot na magazyn ' . $zwr . ' szt' : '' ) . ( $powod ? ' (' . $powod . ')' : '' ), null, array( 'bhp_util', $id ) );
		return array( 'doc' => self::get( $id ), 'message' => 'Zapisano protokół ' . $nr . ' dla: ' . $osoba_name . '.' );
	}

	public static function listing() {
		global $wpdb;
		$rows = $wpdb->get_results( 'SELECT * FROM `' . self::TU() . '` ORDER BY id DESC LIMIT 300', ARRAY_A ); // phpcs:ignore
		$cnt  = array();
		foreach ( $wpdb->get_results( "SELECT util_id, typ, SUM(ilosc) szt FROM `" . self::TUP() . "` GROUP BY util_id, typ", ARRAY_A ) as $c ) { // phpcs:ignore
			$cnt[ (int) $c['util_id'] ][ $c['typ'] ] = (int) $c['szt'];
		}
		return array_map( function ( $r ) use ( $cnt ) {
			$c = $cnt[ (int) $r['id'] ] ?? array();
			return array(
				'id'         => (int) $r['id'],
				'numer'      => (string) $r['numer'],
				'data'       => (string) $r['data'],
				'osoba_name' => (string) $r['osoba_name'],
				'dzial'      => (string) $r['dzial'],
				'powod'      => (string) $r['powod'],
				'status'     => (string) $r['status'],
				'user_name'  => (string) $r['user_name'],
				'uty'        => isset( $c['utylizacja'] ) ? (int) $c['utylizacja'] : 0,
				'zwr'        => isset( $c['zwrot'] ) ? (int) $c['zwrot'] : 0,
			);
		}, (array) $rows );
	}

	public static function get( $id ) {
		global $wpdb;
		$r = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM `' . self::TU() . '` WHERE id = %d', (int) $id ), ARRAY_A ); // phpcs:ignore
		if ( ! $r ) {
			return null;
		}
		$r['lines'] = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM `' . self::TUP() . '` WHERE util_id = %d ORDER BY lp, id', (int) $id ), ARRAY_A ); // phpcs:ignore
		return $r;
	}

	private static function clean_sig( $v ) {
		$v = (string) $v;
		if ( '' === $v ) {
			return '';
		}
		// Only a PNG data-URI containing valid base64 characters is accepted.
		if ( ! preg_match( '#^data:image/png;base64,[A-Za-z0-9+/=\s]+$#', $v ) ) {
			return '';
		}
		if ( strlen( $v ) > 600000 ) {
			return '';
		}
		return $v;
	}

	/* ------------------------------------------------------------------ *
	 * REST
	 * ------------------------------------------------------------------ */
	public static function routes() {
		$ns   = MSM_Rest::NS;
		$view = MSM_Rest::in_section( 'bhp' );
		$edit = MSM_Rest::in_section( 'bhp', true );
		register_rest_route( $ns, '/bhp/util', array(
			array( 'methods' => 'GET', 'permission_callback' => $view, 'callback' => function () { return rest_ensure_response( self::listing() ); } ),
			array( 'methods' => 'POST', 'permission_callback' => $edit, 'callback' => function ( WP_REST_Request $r ) { return rest_ensure_response( self::create( (array) $r->get_json_params() ) ); } ),
		) );
		register_rest_route( $ns, '/bhp/util/(?P<id>\d+)', array(
			'methods' => 'GET', 'permission_callback' => $view, 'callback' => function ( WP_REST_Request $r ) { $d = self::get( (int) $r['id'] ); return $d ? rest_ensure_response( $d ) : new WP_Error( 'msm_404', 'Nie istnieje.', array( 'status' => 404 ) ); },
		) );
		register_rest_route( $ns, '/bhp/held/(?P<id>\d+)', array(
			'methods' => 'GET', 'permission_callback' => $view, 'callback' => function ( WP_REST_Request $r ) {
				return rest_ensure_response( array( 'lines' => self::held_lines( (int) $r['id'] ), 'norms' => array_values( self::norms() ) ) );
			},
		) );
		register_rest_route( $ns, '/bhp/do-wymiany', array(
			'methods' => 'GET', 'permission_callback' => $view, 'callback' => function () { return rest_ensure_response( self::do_wymiany() ); },
		) );
		register_rest_route( $ns, '/bhp/normy', array(
			'methods' => 'GET', 'permission_callback' => $view, 'callback' => function () { return rest_ensure_response( array_values( self::norms() ) ); },
		) );
	}

	/* ------------------------------------------------------------------ *
	 * Wydruki
	 * ------------------------------------------------------------------ */
	public static function maybe_print() {
		$what = isset( $_GET['msm_print'] ) ? sanitize_key( wp_unslash( $_GET['msm_print'] ) ) : ''; // phpcs:ignore
		if ( ( 'bhp_util' !== $what && 'bhp_util_rok' !== $what ) || ! is_user_logged_in() || ! current_user_can( 'msm_view' ) ) {
			return;
		}
		if ( ! MSM_Perms::is_wp_admin() && ! MSM_Perms::menu_on( 'bhp' ) ) {
			wp_die( 'Brak dostępu.', 403 );
		}
		nocache_headers();
		if ( 'bhp_util_rok' === $what ) {
			self::print_rok( (int) ( $_GET['rok'] ?? current_time( 'Y' ) ) ); // phpcs:ignore
			exit;
		}
		$u = self::get( (int) ( $_GET['id'] ?? 0 ) ); // phpcs:ignore
		if ( ! $u ) {
			wp_die( 'Protokół nie istnieje.', 404 );
		}
		self::print_doc( $u );
		exit;
	}

	private static function head() {
		$fonts = MSM_URL . 'assets/fonts/';
		$css   = '';
		foreach ( array( '400', '600', '800' ) as $w ) {
			$css .= '@font-face{font-family:PJS;font-weight:' . $w . ';src:url(' . esc_url( $fonts ) . 'plus-jakarta-sans-latin-ext-' . $w . '-normal.woff2) format("woff2");unicode-range:U+0100-02BA,U+1E00-1E9F}';
			$css .= '@font-face{font-family:PJS;font-weight:' . $w . ';src:url(' . esc_url( $fonts ) . 'plus-jakarta-sans-latin-' . $w . '-normal.woff2) format("woff2");unicode-range:U+0000-00FF,U+2000-206F}';
		}
		return $css;
	}

	private static function styles() {
		return '@page{size:A4;margin:14mm 14mm}*{box-sizing:border-box}html,body{margin:0;background:#e9ebef}body{font:10pt/1.45 PJS,sans-serif;color:#0b1020;-webkit-print-color-adjust:exact;print-color-adjust:exact}.bar{position:sticky;top:0;display:flex;gap:10px;justify-content:center;padding:10px;background:#0b1020;color:#fff;z-index:5}.bar button,.bar a{font:600 13px PJS,system-ui;padding:8px 18px;border-radius:99px;border:0;background:#3d4bff;color:#fff;cursor:pointer;text-decoration:none}.bar .g{background:transparent;border:1px solid rgba(255,255,255,.4)}.page{position:relative}@media screen{.page{width:210mm;min-height:297mm;padding:14mm;margin:16px auto;background:#fff;box-shadow:0 4px 24px rgba(0,0,0,.14)}}@media print{html,body{background:#fff}.bar{display:none}}h1{font-size:16pt;margin:0 0 1mm}.sub{color:#5a6274;font-size:8.5pt;margin:0 0 5mm}.hdr{display:flex;justify-content:space-between;align-items:flex-start;border-bottom:2px solid #0b1020;padding-bottom:3mm;margin-bottom:4mm}.meta{display:grid;grid-template-columns:1fr 1fr 1fr;gap:2mm 8mm;margin-bottom:5mm}.meta .lbl{font-size:7pt;text-transform:uppercase;letter-spacing:.06em;color:#5a6274;font-weight:600}.meta .val{font-weight:600}table{width:100%;border-collapse:collapse;margin-bottom:5mm}th,td{border:1px solid #9aa3b2;padding:1.6mm 2.2mm;text-align:left;vertical-align:top}th{background:#eef0f5;font-size:8pt;text-transform:uppercase;letter-spacing:.04em}td.num,th.num{text-align:center;width:14mm}.badge{display:inline-block;padding:.4mm 2mm;border-radius:99px;background:#eef0f5;font-size:7.5pt;font-weight:700}.badge.zwrot{background:#dff3e6;color:#1c6b43}.sign{display:grid;grid-template-columns:1fr 1fr;gap:16mm;margin-top:12mm}.sign div{border-top:1px solid #0b1020;padding-top:2mm;text-align:center;font-size:8.5pt;color:#5a6274}.sig img{max-height:22mm;display:block;margin:0 auto 2mm}.note{font-size:8.5pt;color:#444;white-space:pre-wrap}';
	}

	private static function print_doc( $u ) {
		$dt = function ( $v ) { return $v ? mysql2date( 'd.m.Y', $v ) : ''; };
		?><!DOCTYPE html>
<html lang="pl"><head><meta charset="utf-8"><meta name="robots" content="noindex,nofollow"><title>Protokół utylizacji <?php echo esc_html( $u['numer'] ); ?></title>
<style><?php echo self::head() . self::styles(); // phpcs:ignore ?></style></head>
<body>
<div class="bar"><button onclick="window.print()">Drukuj / zapisz PDF</button><a class="g" href="<?php echo esc_url( MSM_Access::app_url() ); ?>">Zamknij</a></div>
<div class="page">
	<div class="hdr">
		<div><h1>Protokół utylizacji / rozliczenia wyposażenia BHP</h1><p class="sub"><?php echo esc_html( msm_opt( 'firma_skrot' ) . ' · ' . msm_opt( 'firma_adres' ) ); ?></p></div>
		<div style="text-align:right"><div style="font-size:13pt;font-weight:800"><?php echo esc_html( $u['numer'] ); ?></div></div>
	</div>
	<div class="meta">
		<div><span class="lbl">Pracownik</span><div class="val"><?php echo esc_html( $u['osoba_name'] ); ?></div></div>
		<div><span class="lbl">Dział / brygada</span><div class="val"><?php echo esc_html( $u['dzial'] ? $u['dzial'] : '—' ); ?></div></div>
		<div><span class="lbl">Data</span><div class="val"><?php echo esc_html( $dt( $u['data'] ) ); ?></div></div>
	</div>
	<table>
		<thead><tr><th class="num">Lp.</th><th>Operacja</th><th>Asortyment</th><th>Nazwa</th><th>Rozmiar</th><th class="num">Ilość</th><th>Powód</th></tr></thead>
		<tbody>
		<?php foreach ( $u['lines'] as $l ) : ?>
			<tr>
				<td class="num"><?php echo (int) $l['lp']; ?></td>
				<td><?php echo 'zwrot' === $l['typ'] ? '<span class="badge zwrot">zwrot na magazyn</span>' : '<span class="badge">utylizacja</span>'; ?></td>
				<td><?php echo esc_html( $l['kategoria'] ); ?></td>
				<td><?php echo esc_html( $l['nazwa'] ); ?></td>
				<td><?php echo esc_html( $l['rozmiar'] ); ?></td>
				<td class="num"><?php echo (int) $l['ilosc']; ?> szt</td>
				<td><?php echo esc_html( $l['powod'] ); ?></td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table>
	<?php if ( $u['uwagi'] ) : ?><p class="note"><b>Uwagi:</b> <?php echo esc_html( $u['uwagi'] ); ?></p><?php endif; ?>
	<div class="sign">
		<div class="sig"><?php echo $u['podpis'] ? '<img src="' . esc_attr( $u['podpis'] ) . '" alt="">' : ''; ?>Podpis pracownika (<?php echo esc_html( $u['osoba_name'] ); ?>)</div>
		<div>Podpis osoby odpowiedzialnej / BHP</div>
	</div>
</div>
</body></html>
		<?php
	}

	private static function print_rok( $rok ) {
		global $wpdb;
		$rok  = (int) $rok;
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT u.numer, u.data, u.osoba_name, u.dzial, p.typ, p.kategoria, p.nazwa, p.rozmiar, p.ilosc, p.powod FROM `" . self::TUP() . "` p INNER JOIN `" . self::TU() . "` u ON u.id = p.util_id WHERE u.rok = %d AND u.status <> 'anulowany' AND p.typ = 'utylizacja' ORDER BY u.data ASC, u.id ASC", $rok ), ARRAY_A ); // phpcs:ignore
		$dt   = function ( $v ) { return $v ? mysql2date( 'd.m.Y', $v ) : ''; };
		$suma = 0;
		foreach ( $rows as $r ) { $suma += (int) $r['ilosc']; }
		?><!DOCTYPE html>
<html lang="pl"><head><meta charset="utf-8"><meta name="robots" content="noindex,nofollow"><title>Raport utylizacji <?php echo (int) $rok; ?></title>
<style><?php echo self::head() . self::styles(); // phpcs:ignore ?></style></head>
<body>
<div class="bar"><button onclick="window.print()">Drukuj / zapisz PDF</button><a class="g" href="<?php echo esc_url( MSM_Access::app_url() ); ?>">Zamknij</a></div>
<div class="page">
	<div class="hdr">
		<div><h1>Zbiorczy raport utylizacji BHP</h1><p class="sub"><?php echo esc_html( msm_opt( 'firma_skrot' ) . ' · ' . msm_opt( 'firma_adres' ) ); ?></p></div>
		<div style="text-align:right"><div style="font-size:13pt;font-weight:800">rok <?php echo (int) $rok; ?></div></div>
	</div>
	<?php if ( ! $rows ) : ?>
		<p class="note">Brak utylizacji w roku <?php echo (int) $rok; ?>.</p>
	<?php else : ?>
	<table>
		<thead><tr><th>Data</th><th>Protokół</th><th>Pracownik</th><th>Asortyment</th><th>Nazwa</th><th>Rozmiar</th><th class="num">Ilość</th><th>Powód</th></tr></thead>
		<tbody>
		<?php foreach ( $rows as $r ) : ?>
			<tr>
				<td><?php echo esc_html( $dt( $r['data'] ) ); ?></td>
				<td><?php echo esc_html( $r['numer'] ); ?></td>
				<td><?php echo esc_html( $r['osoba_name'] ); ?></td>
				<td><?php echo esc_html( $r['kategoria'] ); ?></td>
				<td><?php echo esc_html( $r['nazwa'] ); ?></td>
				<td><?php echo esc_html( $r['rozmiar'] ); ?></td>
				<td class="num"><?php echo (int) $r['ilosc']; ?> szt</td>
				<td><?php echo esc_html( $r['powod'] ); ?></td>
			</tr>
		<?php endforeach; ?>
		</tbody>
		<tfoot><tr><td colspan="6" style="text-align:right;font-weight:800">Razem zutylizowano</td><td class="num" style="font-weight:800"><?php echo (int) $suma; ?> szt</td><td></td></tr></tfoot>
	</table>
	<?php endif; ?>
</div>
</body></html>
		<?php
	}
}
