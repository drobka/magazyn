<?php
/**
 * Strona aplikacji: shortcode [magazyn], pełnoekranowy szablon, formularz logowania.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MSM_Front {

	public static function init() {
		add_shortcode( 'magazyn', array( __CLASS__, 'shortcode' ) );
		add_filter( 'template_include', array( __CLASS__, 'template' ), 99 );
		add_action( 'template_redirect', array( __CLASS__, 'no_cache' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'maybe_enqueue' ) );
	}

	public static function is_app_page() {
		$id = (int) get_option( 'msm_page_id' );
		return $id && is_page( $id );
	}

	public static function no_cache() {
		if ( self::is_app_page() ) {
			nocache_headers();
			self::security_headers();
			if ( ! defined( 'DONOTCACHEPAGE' ) ) {
				define( 'DONOTCACHEPAGE', true );
			}
		}
	}

	public static function template( $tpl ) {
		if ( self::is_app_page() && apply_filters( 'msm_fullscreen', true ) ) {
			return MSM_DIR . 'templates/app.php';
		}
		return $tpl;
	}

	public static function maybe_enqueue() {
		if ( self::is_app_page() ) {
			self::enqueue();
		}
	}

	/** Strona innej wtyczki z nagłówkiem systemu (np. 'grafik') – wtedy aplikacja rysuje tylko nagłówek z menu. */
	private static $shell = '';

	/**
	 * Nagłówek K-ERP (logo, menu, użytkownik) na stronie innej wtyczki. Wywołać w wp_enqueue_scripts.
	 *
	 * @param string $current Która pozycja menu jest bieżąca (np. 'grafik').
	 * @return bool Czy nagłówek będzie wyświetlony (zalogowany użytkownik z dostępem do systemu).
	 */
	public static function shell_enqueue( $current = '' ) {
		if ( ! is_user_logged_in() || ! current_user_can( 'msm_view' ) ) {
			return false;
		}
		self::$shell = sanitize_key( $current ) ? sanitize_key( $current ) : 'zewn';
		self::enqueue();
		return true;
	}

	/** Kontener nagłówka – wstawić na początku <body> strony wtyczki. */
	public static function shell_html() {
		return self::$shell ? '<div id="msm-app" class="msm-app msm-app--shell" data-shell="' . esc_attr( self::$shell ) . '"></div>' : '';
	}

	public static function enqueue() {
		static $done = false;
		wp_enqueue_style( 'msm-app', MSM_URL . 'assets/app.css', array(), MSM_VERSION );
		if ( $done || ! current_user_can( 'msm_view' ) ) {
			return;
		}
		$done = true;
		wp_enqueue_script( 'msm-app', MSM_URL . 'assets/app.js', array(), MSM_VERSION, true );

		$schema = array();
		foreach ( msm_schema() as $k => $def ) {
			$cols = array();
			foreach ( $def['cols'] as $c ) {
				unset( $c['aliases'] );
				$cols[] = $c;
			}
			$schema[ $k ] = array(
				'label'    => $def['label'],
				'stock'    => ! empty( $def['stock'] ),
				'narzedzia' => ! empty( $def['narzedzia'] ),
				'bhp'      => ! empty( $def['bhp'] ),
				'edit'     => ! empty( $def['edit'] ),
				'unit'     => $def['unit'] ?? null,
				'readonly' => ! empty( $def['readonly'] ),
				'editable' => $def['editable'] ?? null,
				'cols'     => $cols,
			);
		}
		$u     = wp_get_current_user();
		$perms = MSM_Perms::effective( $u );
		wp_add_inline_script( 'msm-app', 'window.MSM = ' . wp_json_encode( array(
			'rest'      => esc_url_raw( rest_url( MSM_Rest::NS ) ),
			'nonce'     => wp_create_nonce( 'wp_rest' ),
			'canEdit'   => current_user_can( 'msm_edit' ),
			'firmaNip'  => preg_replace( '/\D/', '', (string) msm_opt( 'firma_nip' ) ),
			'progi'     => array( 'zlecenia' => MSM_Settings::prog( 'prog_zlecenia' ), 'elektro' => MSM_Settings::prog( 'prog_elektro' ), 'pomiar' => MSM_Settings::prog( 'prog_pomiar' ) ),
			'caps'      => $perms['caps'],
			'menu'      => array_merge( $perms['menu'], array( 'prod_karty' => MSM_Karty_Zmian::can_view() ) ),
			'menuParent' => MSM_Perms::menu_parents(),
			'canPurge'  => MSM_Install::can_purge(),
			'canSettings' => true === MSM_Settings::can_manage(),
			'user'      => $u->display_name,
			'userId'    => (int) $u->ID,
			'vendor'    => apply_filters( 'msm_ocr_vendor_url', null ),
			'ocrOld'    => msm_ocr_outdated(),
			'inw'       => current_user_can( 'msm_edit' ) ? MSM_Inwentarz::summary() : array( 'active' => false ),
			'role'      => current_user_can( 'msm_edit' ) ? 'administrator' : 'przeglądający',
			'logout'    => html_entity_decode( wp_logout_url( MSM_Access::app_url() ) ),
			'profile'   => '#profil',
			'today'     => current_time( 'Y-m-d' ),
			'logo'      => self::logo_html(),
			'appUrl'    => MSM_Access::app_url(),
			'version'   => MSM_VERSION,
			'grafik'    => self::grafik_url(),
			'shellOnly' => self::$shell,
			'appUrl'    => MSM_Access::app_url(),
			'prod'      => class_exists( 'MSM_Prod' ),
			'sw'        => class_exists( 'MSM_Pwa' ) ? MSM_Pwa::sw_url() : '',
			'swScope'   => class_exists( 'MSM_Pwa' ) ? MSM_Pwa::scope() : '/',
			'pwaIcon'   => MSM_URL . 'assets/pwa/icon-192.png',
			'schema'    => $schema,
		) ) . ';', 'before' );
	}

	/**
	 * Nagłówki ochronne strony aplikacji (1.84.0): zakaz osadzania w ramkach obcych stron (clickjacking),
	 * brak wtyczek <object>, stała baza adresów. Pełne CSP dla skryptów wymaga usunięcia skryptów inline – planowane.
	 */
	public static function security_headers() {
		if ( headers_sent() ) {
			return;
		}
		header( 'X-Frame-Options: SAMEORIGIN' );
		header( "Content-Security-Policy: frame-ancestors 'self'; object-src 'none'; base-uri 'self'" );
		header( 'X-Content-Type-Options: nosniff' );
		header( 'Referrer-Policy: same-origin' );
	}

	public static function shortcode() {
		self::enqueue();
		if ( ! is_user_logged_in() ) {
			return self::login_form();
		}
		if ( ! current_user_can( 'msm_view' ) ) {
			return '<div class="msm-center"><div class="msm-card msm-card--narrow">' . self::logo_html() . '<h2>Brak dostępu</h2><p class="msm-muted">Twoje konto nie ma dostępu do magazynu. Skontaktuj się z administratorem.</p><a class="msm-btn" href="' . esc_url( wp_logout_url( MSM_Access::app_url() ) ) . '">Wyloguj</a></div></div>';
		}
		return '<div id="msm-app" class="msm-app"><div class="msm-loading">Ładowanie magazynu…</div></div><noscript>Aplikacja wymaga włączonego JavaScriptu.</noscript>';
	}

	private static function login_form() {
		$err = isset( $_GET['msm_login'] ) ? sanitize_key( wp_unslash( $_GET['msm_login'] ) ) : ''; // phpcs:ignore
		$msg = '';
		if ( 'failed' === $err ) {
			$msg = '<div class="msm-alert msm-alert-err msm-login-err">Nieprawidłowy login lub hasło.</div>';
		} elseif ( 'locked' === $err ) {
			$msg = '<div class="msm-alert msm-alert-err msm-login-err">Zbyt wiele nieudanych prób logowania. Spróbuj ponownie za 15 minut.</div>';
		} elseif ( 'empty' === $err ) {
			$msg = '<div class="msm-alert msm-alert-err msm-login-err">Podaj login i hasło.</div>';
		}
		$icon = function ( $path ) {
			return '<svg class="msm-ico" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $path . '</svg>';
		};
		ob_start();
		?>
		<div class="msm-auth">
			<?php echo self::hero_html(); // phpcs:ignore ?>
			<section class="msm-authpane">
				<div class="msm-authcard">
					<form method="post" action="<?php echo esc_url( site_url( 'wp-login.php', 'login_post' ) ); ?>" class="msm-form msm-authform">
						<h2>Zaloguj się</h2>
						<p class="msm-muted">Podaj login i hasło otrzymane od administratora.</p>
						<?php echo $msg; // phpcs:ignore ?>
						<label class="msm-field"><span>Login lub e-mail</span><input type="text" name="log" id="user_login" autocomplete="username" required></label>
						<label class="msm-field"><span>Hasło</span><input type="password" name="pwd" id="user_pass" autocomplete="current-password" placeholder="••••••••" required></label>
						<div class="msm-row-between">
							<label class="msm-check"><input type="checkbox" name="rememberme" value="forever"> Zapamiętaj mnie</label>
							<a class="msm-link" href="<?php echo esc_url( wp_lostpassword_url() ); ?>">Nie pamiętasz hasła?</a>
						</div>
						<?php
						$back = MSM_Access::app_url();
						if ( isset( $_GET['msm_print'] ) ) { // phpcs:ignore
							$back = add_query_arg( array_map( 'rawurlencode', wp_unslash( $_GET ) ), $back ); // phpcs:ignore
						}
						?>
						<input type="hidden" name="redirect_to" id="msm-redirect" value="<?php echo esc_url( $back ); ?>">
						<script>(function(){var h=location.hash,f=document.getElementById('msm-redirect');if(h&&f&&/^#[a-z0-9_-]+$/i.test(h)){f.value=f.value.split('#')[0]+h;}})();</script>
						<input type="hidden" name="msm_login_form" value="1">
						<button class="msm-btn msm-btn-primary msm-btn-block" type="submit" id="wp-submit">Zaloguj się <?php echo $icon( '<path d="M5 12h14M13 6l6 6-6 6"/>' ); // phpcs:ignore ?></button>
					</form>
				</div>
			</section>
		</div>
		<?php
		return ob_get_clean();
	}

	/** Funkcje systemu na stronie logowania: [ikona (ścieżki SVG), nazwa, opis w skrócie]. */
	public static function hero_features() {
		return array(
			array( '<path d="M3 9l9-5 9 5v10a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1z"/><path d="M8 20v-6h8v6"/>', 'Magazyn', 'Stal, blachy i kręgi – stany, rezerwacje, inwentaryzacja' ),
			array( '<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5M9 13h6M9 17h4"/>', 'Dokumenty', 'PZ z odczytem OCR, WZ, przesyłki i paletówki' ),
			array( '<circle cx="9" cy="20" r="1.5"/><circle cx="18" cy="20" r="1.5"/><path d="M2 3h3l2.6 11.4a1 1 0 0 0 1 .8h9.7a1 1 0 0 0 1-.8L21 7H6"/>', 'Zakupy', 'Zapotrzebowanie pod zlecenia, braki i zamówienia z PDF' ),
			array( '<path d="M3 21V10l6 4V10l6 4V6l6 4v11z"/><path d="M7 17h2M12 17h2M17 17h2"/>', 'Produkcja', 'Zlecenia, terminy i karty zleceń' ),
			array( '<path d="M14.7 6.3a4 4 0 0 0-5.4 5.4L3 18l3 3 6.3-6.3a4 4 0 0 0 5.4-5.4l-2.5 2.5-2.4-.6-.6-2.4z"/>', 'Narzędziownia', 'Przyrządy pomiarowe, wzorcowania, elektronarzędzia' ),
			array( '<path d="M12 3l8 3v6c0 4.5-3.4 8.3-8 9-4.6-.7-8-4.5-8-9V6z"/><path d="M9 12l2 2 4-4"/>', 'BHP', 'Wydania środków ochrony, stany i utylizacja' ),
		);
	}

	/** Lewy panel logowania (aplikacja i wp-login.php): nazwa, hasło, funkcje w skrócie. */
	public static function hero_html() {
		$li = '';
		foreach ( self::hero_features() as $f ) {
			$li .= '<li><svg class="msm-ico" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $f[0] . '</svg>'
				. '<div><strong>' . esc_html( $f[1] ) . '</strong><span>' . esc_html( $f[2] ) . '</span></div></li>';
		}
		return '<section class="msm-hero">' . self::logo_html( true )
			. '<div class="msm-hero__body"><p class="msm-eyebrow">System K-ERP</p>'
			. '<h1>Magazyn i produkcja&nbsp;–<br><span>System ERP</span></h1>'
			. '<ul class="msm-hero__list msm-hero__feat">' . $li . '</ul></div>'
			. '<p class="msm-hero__foot">&copy; Copyright by ' . esc_html( msm_opt( 'firma_nazwa' ) ) . '</p></section>';
	}

	public static function logo_html( $light = false ) {
		$file = $light ? 'logo-white.svg' : 'logo.svg';
		return '<a class="msm-logo' . ( $light ? ' msm-logo--light' : '' ) . '" href="' . esc_url( MSM_Access::app_url() . '#stal' ) . '" title="System K-ERP – strona główna">'
			. '<img class="msm-logo__img" src="' . esc_url( MSM_URL . 'assets/' . $file . '?v=' . MSM_VERSION ) . '" alt="Kisielewski – System K-ERP" width="153" height="40">'
			. '</a>';
	}


	/** Adres strony grafiku pracy (wtyczka „Magazyn grafik”, podstrona /grafik/) – pusty, gdy wtyczka nie jest włączona. */
	public static function grafik_url() {
		$act = array_merge( (array) get_option( 'active_plugins', array() ), array_keys( (array) get_site_option( 'active_sitewide_plugins', array() ) ) );
		foreach ( $act as $p ) {
			if ( false !== stripos( (string) $p, 'grafik' ) ) {
				return home_url( '/grafik/' );
			}
		}
		return '';
	}
}
