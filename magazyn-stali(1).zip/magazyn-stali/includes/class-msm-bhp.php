<?php
/**
 * Magazyn BHP – wydania środków ochrony / odzieży roboczej na konkretne osoby.
 * Stan magazynu BHP i rejestr osób to tabele schema ('bhp', 'bhp_osoby') – CRUD przez /t/*.
 * Ta klasa obsługuje dokumenty wydania (zdjęcie stanu + pozycje ręczne) i ich wydruk.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MSM_Bhp {

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
		add_action( 'template_redirect', array( __CLASS__, 'maybe_print' ), 1 );
	}

	private static function T_WYD() {
		global $wpdb;
		return $wpdb->prefix . 'msm_bhp_wyd';
	}
	private static function T_POZ() {
		global $wpdb;
		return $wpdb->prefix . 'msm_bhp_wyd_poz';
	}

	/* ------------------------------------------------------------------ *
	 * REST
	 * ------------------------------------------------------------------ */
	public static function routes() {
		$ns   = MSM_Rest::NS;
		$view = MSM_Rest::in_section( 'bhp' );
		$edit = MSM_Rest::in_section( 'bhp', true );

		register_rest_route( $ns, '/bhp/wydania', array(
			array( 'methods' => 'GET', 'permission_callback' => $view, 'callback' => function ( WP_REST_Request $r ) {
				return rest_ensure_response( self::listing( (array) $r->get_params() ) );
			} ),
			array( 'methods' => 'POST', 'permission_callback' => $edit, 'callback' => function ( WP_REST_Request $r ) {
				return rest_ensure_response( self::create( (array) $r->get_json_params() ) );
			} ),
		) );
		register_rest_route( $ns, '/bhp/wydania/(?P<id>\d+)', array(
			array( 'methods' => 'GET', 'permission_callback' => $view, 'callback' => function ( WP_REST_Request $r ) {
				$d = self::get( (int) $r['id'] );
				return $d ? rest_ensure_response( $d ) : new WP_Error( 'msm_404', 'Nie istnieje.', array( 'status' => 404 ) );
			} ),
		) );
		register_rest_route( $ns, '/bhp/wydania/(?P<id>\d+)/anuluj', array(
			'methods' => 'POST', 'permission_callback' => $edit, 'callback' => function ( WP_REST_Request $r ) {
				return rest_ensure_response( self::cancel( (int) $r['id'], (array) $r->get_json_params() ) );
			},
		) );
		register_rest_route( $ns, '/bhp/wydania/(?P<id>\d+)/usun', array(
			'methods' => 'POST', 'permission_callback' => function () { return MSM_Install::can_purge() ? true : new WP_Error( 'msm_forbidden', 'Brak uprawnień.', array( 'status' => 403 ) ); },
			'callback' => function ( WP_REST_Request $r ) { return rest_ensure_response( self::delete( (int) $r['id'] ) ); },
		) );
		register_rest_route( $ns, '/bhp/next-number', array(
			'methods' => 'GET', 'permission_callback' => $edit, 'callback' => function ( WP_REST_Request $r ) {
				return rest_ensure_response( self::next_number( (int) ( $r['rok'] ?? 0 ) ) );
			},
		) );
	}

	/* ------------------------------------------------------------------ *
	 * Lista / odczyt
	 * ------------------------------------------------------------------ */
	public static function listing( $args = array() ) {
		global $wpdb;
		$W     = self::T_WYD();
		$P     = self::T_POZ();
		$limit = min( 500, max( 1, (int) ( $args['per_page'] ?? 200 ) ) );
		$rows  = $wpdb->get_results( "SELECT * FROM `$W` ORDER BY id DESC LIMIT $limit", ARRAY_A ); // phpcs:ignore
		$ids   = array_map( function ( $r ) { return (int) $r['id']; }, $rows );
		$cnt   = array();
		if ( $ids ) {
			$in = implode( ',', $ids );
			foreach ( $wpdb->get_results( "SELECT wyd_id, COUNT(*) n, SUM(ilosc) szt FROM `$P` GROUP BY wyd_id", ARRAY_A ) as $c ) { // phpcs:ignore
				$cnt[ (int) $c['wyd_id'] ] = array( 'poz' => (int) $c['n'], 'szt' => (int) $c['szt'] );
			}
		}
		return array_map( function ( $r ) use ( $cnt ) {
			return self::public_head( $r, $cnt[ (int) $r['id'] ] ?? array( 'poz' => 0, 'szt' => 0 ) );
		}, $rows );
	}

	private static function public_head( $r, $counts = null ) {
		return array(
			'id'            => (int) $r['id'],
			'numer'         => (string) $r['numer'],
			'osoba_id'      => $r['osoba_id'] ? (int) $r['osoba_id'] : null,
			'osoba_name'    => (string) $r['osoba_name'],
			'dzial'         => (string) $r['dzial'],
			'data'          => (string) $r['data'],
			'uwagi'         => (string) $r['uwagi'],
			'status'        => (string) $r['status'],
			'wydal_name'    => (string) $r['wydal_name'],
			'canceled_name' => (string) $r['canceled_name'],
			'canceled_at'   => (string) $r['canceled_at'],
			'created_at'    => (string) $r['created_at'],
			'poz'           => $counts ? (int) $counts['poz'] : null,
			'szt'           => $counts ? (int) $counts['szt'] : null,
		);
	}

	public static function get( $id ) {
		global $wpdb;
		$r = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM `' . self::T_WYD() . '` WHERE id = %d', $id ), ARRAY_A ); // phpcs:ignore
		if ( ! $r ) {
			return null;
		}
		$lines = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM `' . self::T_POZ() . '` WHERE wyd_id = %d ORDER BY lp, id', $id ), ARRAY_A ); // phpcs:ignore
		$out   = self::public_head( $r );
		$out['lines'] = array_map( function ( $l ) {
			return array(
				'id'        => (int) $l['id'],
				'lp'        => (int) $l['lp'],
				'bhp_id'    => $l['bhp_id'] ? (int) $l['bhp_id'] : null,
				'kategoria' => (string) $l['kategoria'],
				'nazwa'     => (string) $l['nazwa'],
				'rozmiar'   => (string) $l['rozmiar'],
				'ilosc'     => (int) $l['ilosc'],
				'jm'        => (string) $l['jm'],
				'zrodlo'    => (string) $l['zrodlo'],
			);
		}, $lines );
		return $out;
	}

	/* ------------------------------------------------------------------ *
	 * Tworzenie wydania
	 * ------------------------------------------------------------------ */
	public static function create( array $in ) {
		global $wpdb;

		// Osoba: z rejestru (osoba_id) albo wpisana ręcznie (osoba_name).
		$osoba_id   = (int) ( $in['osoba_id'] ?? 0 );
		$osoba_name = trim( sanitize_text_field( wp_unslash( (string) ( $in['osoba_name'] ?? '' ) ) ) );
		$dzial      = trim( sanitize_text_field( wp_unslash( (string) ( $in['dzial'] ?? '' ) ) ) );
		if ( $osoba_id ) {
			$os = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM `' . msm_table( 'bhp_osoby' ) . '` WHERE id = %d', $osoba_id ), ARRAY_A ); // phpcs:ignore
			if ( ! $os ) {
				return new WP_Error( 'msm_400', 'Wybrana osoba nie istnieje.', array( 'status' => 400 ) );
			}
			$osoba_name = (string) $os['imie_nazwisko'];
			if ( '' === $dzial ) {
				$dzial = (string) $os['dzial'];
			}
		}
		if ( '' === $osoba_name ) {
			return new WP_Error( 'msm_400', 'Podaj osobę, dla której wystawiasz wydanie.', array( 'status' => 400, 'fields' => array( 'osoba' => 'Wybierz lub wpisz osobę' ) ) );
		}

		$data  = ( isset( $in['data'] ) && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $in['data'] ) ) ? $in['data'] : current_time( 'Y-m-d' );
		$uwagi = trim( sanitize_textarea_field( wp_unslash( (string) ( $in['uwagi'] ?? '' ) ) ) );
		$lines = isset( $in['lines'] ) && is_array( $in['lines'] ) ? $in['lines'] : array();
		// Wpis archiwalny: uzupełnienie historii z poprzednich lat – bez numeru i bez zmiany stanu.
		$arch = ! empty( $in['archiwalne'] );

		// Walidacja + normalizacja pozycji.
		$norm = array();
		foreach ( $lines as $l ) {
			$ilosc = (int) MSM_Calc::f( $l['ilosc'] ?? 0 );
			if ( $ilosc < 1 ) {
				continue;
			}
			$bhp_id = (int) ( $l['bhp_id'] ?? 0 );
			if ( ! $arch && $bhp_id ) {
				$item = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM `' . msm_table( 'bhp' ) . '` WHERE id = %d', $bhp_id ), ARRAY_A ); // phpcs:ignore
				if ( ! $item ) {
					return new WP_Error( 'msm_400', 'Pozycja magazynowa BHP nie istnieje.', array( 'status' => 400 ) );
				}
				$loc = ( isset( $l['lokacja'] ) && false !== mb_stripos( (string) $l['lokacja'], 'szaf' ) ) ? 'szafa' : 'magazyn';
				$norm[] = array(
					'bhp_id'    => $bhp_id,
					'kategoria' => (string) $item['kategoria'],
					'nazwa'     => trim( $item['nazwa'] . ( ! empty( $item['producent_id'] ) ? ' (' . $item['producent_id'] . ')' : '' ) ),
					'rozmiar'   => (string) $item['rozmiar'],
					'ilosc'     => $ilosc,
					'jm'        => 'szt',
					'zrodlo'    => 'magazyn',
					'lokacja'   => $loc,
					'norma'     => (string) ( $item['norma'] ?? '' ),
					'_stock'    => 'szafa' === $loc ? (int) $item['st_szafa_nowy'] + (int) $item['st_szafa_uzywany'] : (int) $item['st_mag_nowy'] + (int) $item['st_mag_uzywany'],
				);
			} else {
				$nazwa = trim( sanitize_text_field( wp_unslash( (string) ( $l['nazwa'] ?? '' ) ) ) );
				if ( '' === $nazwa ) {
					return new WP_Error( 'msm_400', 'Pozycja ręczna musi mieć nazwę.', array( 'status' => 400 ) );
				}
				$norm[] = array(
					'bhp_id'    => null,
					'kategoria' => trim( sanitize_text_field( wp_unslash( (string) ( $l['kategoria'] ?? '' ) ) ) ),
					'nazwa'     => $nazwa,
					'rozmiar'   => trim( sanitize_text_field( wp_unslash( (string) ( $l['rozmiar'] ?? '' ) ) ) ),
					'ilosc'     => $ilosc,
					'jm'        => 'szt',
					'zrodlo'    => $arch ? 'archiwum' : 'reczne',
				);
			}
		}
		if ( ! $norm ) {
			return new WP_Error( 'msm_400', 'Dodaj przynajmniej jedną pozycję do wydania.', array( 'status' => 400 ) );
		}

		// Normy przydziału (maks. na wyposażeniu) – blokada z możliwością nadpisania przez administratora.
		if ( ! $arch && $osoba_id && empty( $in['override'] ) && class_exists( 'MSM_Bhp_Util' ) ) {
			$ex = MSM_Bhp_Util::check_norm( $osoba_id, $norm );
			if ( $ex ) {
				return new WP_Error( 'msm_norm', 'Przekroczono normę przydziału.', array( 'status' => 409, 'norm' => $ex ) );
			}
		}
		if ( ! $arch && ! empty( $in['override'] ) ) {
			$po = trim( sanitize_text_field( wp_unslash( (string) ( $in['override_note'] ?? '' ) ) ) );
			$uwagi = trim( $uwagi . "\nWydano ponad normę (zgoda: " . MSM_Repo::user_name() . ( $po ? ', ' . $po : '' ) . ')' );
		}

		$wpdb->query( 'START TRANSACTION' );

		// Zdjęcie stanu dla pozycji z magazynu (z blokadą i kontrolą dostępności).
		foreach ( $norm as $i => $l ) {
			if ( 'magazyn' !== $l['zrodlo'] ) {
				continue;
			}
			$loc = 'szafa' === ( $l['lokacja'] ?? 'magazyn' ) ? 'szafa' : 'mag';
			$st  = $wpdb->get_row( $wpdb->prepare( 'SELECT st_mag_nowy, st_mag_uzywany, st_szafa_nowy, st_szafa_uzywany, ilosc FROM `' . msm_table( 'bhp' ) . '` WHERE id = %d FOR UPDATE', $l['bhp_id'] ), ARRAY_A ); // phpcs:ignore
			$cur_nowy = (int) ( $st[ 'st_' . $loc . '_nowy' ] ?? 0 );
			$cur_uzyw = (int) ( $st[ 'st_' . $loc . '_uzywany' ] ?? 0 );
			$loc_cur  = $cur_nowy + $cur_uzyw;
			if ( $l['ilosc'] > $loc_cur ) {
				$wpdb->query( 'ROLLBACK' );
				$locn = 'szafa' === $loc ? 'szafie BHP' : 'magazynie';
				return new WP_Error( 'msm_stock', $l['nazwa'] . ( $l['rozmiar'] ? ' rozm. ' . $l['rozmiar'] : '' ) . ': w ' . $locn . ' tylko ' . $loc_cur . ' szt. Nic nie zostało zapisane.', array( 'status' => 400 ) );
			}
			// Zdejmujemy najpierw ze stanu nowego, resztę ze stanu używanego – w wybranej lokalizacji.
			$take    = (int) $l['ilosc'];
			$z_nowy  = min( $take, $cur_nowy );
			$z_uzyw  = $take - $z_nowy;
			$po_nowy = $cur_nowy - $z_nowy;
			$po_uzyw = $cur_uzyw - $z_uzyw;
			// Nowy łączny stan po zdjęciu (druga lokalizacja bez zmian).
			$other     = 'szafa' === $loc ? 'mag' : 'szafa';
			$other_sum = (int) ( $st[ 'st_' . $other . '_nowy' ] ?? 0 ) + (int) ( $st[ 'st_' . $other . '_uzywany' ] ?? 0 );
			$new_total = $po_nowy + $po_uzyw + $other_sum;
			$new_nowy  = $po_nowy + (int) ( $st[ 'st_' . $other . '_nowy' ] ?? 0 );
			$new_uzyw  = $po_uzyw + (int) ( $st[ 'st_' . $other . '_uzywany' ] ?? 0 );
			$wpdb->query( $wpdb->prepare( 'UPDATE `' . msm_table( 'bhp' ) . '` SET st_' . $loc . '_nowy = %d, st_' . $loc . '_uzywany = %d, ilosc_nowy = %d, ilosc_uzywany = %d, ilosc = %d, updated_at = %s, updated_by = %d WHERE id = %d', $po_nowy, $po_uzyw, $new_nowy, $new_uzyw, $new_total, current_time( 'mysql' ), get_current_user_id(), $l['bhp_id'] ) ); // phpcs:ignore
			$norm[ $i ]['_before']       = $loc_cur;
			$norm[ $i ]['_after']        = $po_nowy + $po_uzyw;
			$norm[ $i ]['_from_nowy']    = $z_nowy;
			$norm[ $i ]['_from_uzywany'] = $z_uzyw;
		}

		if ( $arch ) {
			$y   = (int) substr( $data, 0, 4 );
			$seq = null;
			$nr  = null;
		} else {
			$y      = (int) current_time( 'Y' );
			$chosen = isset( $in['nr_seq'] ) ? (int) $in['nr_seq'] : 0;
			if ( $chosen > 0 ) {
				$taken = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM `' . self::T_WYD() . '` WHERE rok = %d AND nr_seq = %d', $y, $chosen ) ); // phpcs:ignore
				if ( $taken ) {
					$wpdb->query( 'ROLLBACK' );
					return new WP_Error( 'msm_400', 'Numer BHP/' . sprintf( '%04d', $chosen ) . '/' . $y . ' jest już zajęty. Wybierz inny.', array( 'status' => 400 ) );
				}
				$seq = $chosen;
			} else {
				$seq = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT MAX(nr_seq) FROM `' . self::T_WYD() . '` WHERE rok = %d FOR UPDATE', $y ) ) + 1; // phpcs:ignore
			}
			$nr  = 'BHP/' . sprintf( '%04d', $seq ) . '/' . $y;
		}

		$wpdb->insert( self::T_WYD(), array(
			'numer'      => $nr,
			'nr_seq'     => $seq,
			'rok'        => $y,
			'osoba_id'   => $osoba_id ? $osoba_id : null,
			'osoba_name' => $osoba_name,
			'dzial'      => $dzial,
			'data'       => $data,
			'uwagi'      => $uwagi,
			'status'     => $arch ? 'archiwalne' : 'wydane',
			'wydal_id'   => get_current_user_id(),
			'wydal_name' => MSM_Repo::user_name(),
			'created_at' => current_time( 'mysql' ),
		) );
		$id = (int) $wpdb->insert_id;
		if ( ! $id ) {
			$wpdb->query( 'ROLLBACK' );
			return new WP_Error( 'msm_db', 'Nie udało się zapisać wydania.', array( 'status' => 500 ) );
		}
		$lp = 0;
		foreach ( $norm as $l ) {
			$wpdb->insert( self::T_POZ(), array(
				'wyd_id'    => $id,
				'lp'        => ++$lp,
				'bhp_id'    => $l['bhp_id'],
				'kategoria' => $l['kategoria'],
				'nazwa'     => $l['nazwa'],
				'rozmiar'   => $l['rozmiar'],
				'ilosc'     => $l['ilosc'],
				'ilosc_nowy'    => isset( $l['_from_nowy'] ) ? (int) $l['_from_nowy'] : 0,
				'ilosc_uzywany' => isset( $l['_from_uzywany'] ) ? (int) $l['_from_uzywany'] : 0,
				'lokacja'   => isset( $l['lokacja'] ) ? $l['lokacja'] : 'magazyn',
				'jm'        => $l['jm'],
				'zrodlo'    => $l['zrodlo'],
			) );
		}
		$wpdb->query( 'COMMIT' );

		$sztuk = array_sum( array_map( function ( $l ) { return $l['ilosc']; }, $norm ) );
		if ( $arch ) {
			MSM_Repo::log( 'BHP: wpis archiwalny', 'bhp', $id, 'Wpis archiwalny (' . $data . ') dla: ' . $osoba_name . ( $dzial ? ' (' . $dzial . ')' : '' ) . ' – ' . count( $norm ) . ' poz., ' . $sztuk . ' szt. (bez zmiany stanu)', null, array( 'bhp_wyd', $id ) );
		} else {
			MSM_Repo::log( 'BHP: wydanie', 'bhp', $id, 'Wydanie ' . $nr . ' dla: ' . $osoba_name . ( $dzial ? ' (' . $dzial . ')' : '' ) . ' – ' . count( $norm ) . ' poz., ' . $sztuk . ' szt.', null, array( 'bhp_wyd', $id ) );
		}
		// Historia per pozycja magazynowa (oś czasu „stanu szafy BHP”).
		foreach ( $norm as $l ) {
			if ( 'magazyn' !== $l['zrodlo'] || empty( $l['bhp_id'] ) ) {
				continue;
			}
			MSM_Repo::log(
				'BHP: wydano',
				'bhp',
				(int) $l['bhp_id'],
				'Wydano ' . (int) $l['ilosc'] . ' szt. dla: ' . $osoba_name . ( $dzial ? ' (' . $dzial . ')' : '' ) . ' – ' . $nr,
				array(
					'przed' => array( 'ilosc' => isset( $l['_before'] ) ? (int) $l['_before'] : null ),
					'po'    => array( 'ilosc' => isset( $l['_after'] ) ? (int) $l['_after'] : null ),
					'wyd'   => array( 'id' => $id, 'numer' => $nr, 'osoba' => $osoba_name ),
				),
				array( 'bhp', (int) $l['bhp_id'] )
			);
		}

		return array( 'doc' => self::get( $id ), 'message' => ( $arch ? 'Zapisano wpis archiwalny (' . $data . ') dla: ' . $osoba_name : 'Zapisano wydanie ' . $nr . ' dla: ' . $osoba_name ) . '.' );
	}

	/**
	 * Ile sztuk zwrócić do puli nowej i używanej przy anulowaniu/usunięciu wydania.
	 * Zwraca rozbicie zapisane na pozycji wydania; dla starych wydań (bez rozbicia)
	 * całość wraca do puli „nowy”.
	 */
	private static function zwrot_pule( $l ) {
		$rn = (int) ( $l['ilosc_nowy'] ?? 0 );
		$ru = (int) ( $l['ilosc_uzywany'] ?? 0 );
		if ( $rn + $ru <= 0 ) {
			$rn = (int) ( $l['ilosc'] ?? 0 );
			$ru = 0;
		}
		return array( $rn, $ru );
	}

	/**
	 * Dopisanie sztuk na stan wybranej lokalizacji (magazyn / szafa BHP) i przeliczenie agregatów.
	 * Używane przy zwrocie wydania (anulowanie/usunięcie) oraz zwrocie z utylizacji.
	 */
	public static function restock( $bhp_id, $loc, $rn, $ru ) {
		global $wpdb;
		$loc = 'szafa' === $loc ? 'szafa' : 'mag';
		if ( (int) $rn <= 0 && (int) $ru <= 0 ) {
			return;
		}
		$wpdb->query( $wpdb->prepare(
			'UPDATE `' . msm_table( 'bhp' ) . '` SET '
			. 'st_' . $loc . '_nowy = st_' . $loc . '_nowy + %d, '
			. 'st_' . $loc . '_uzywany = st_' . $loc . '_uzywany + %d, '
			. 'ilosc_nowy = st_mag_nowy + st_szafa_nowy, '
			. 'ilosc_uzywany = st_mag_uzywany + st_szafa_uzywany, '
			. 'ilosc = st_mag_nowy + st_mag_uzywany + st_szafa_nowy + st_szafa_uzywany, '
			. 'updated_at = %s WHERE id = %d',
			(int) $rn, (int) $ru, current_time( 'mysql' ), (int) $bhp_id
		) ); // phpcs:ignore
	}

	/* ------------------------------------------------------------------ *
	 * Anulowanie – zwrot stanu pozycji magazynowych
	 * ------------------------------------------------------------------ */
	public static function cancel( $id, array $in = array() ) {
		global $wpdb;
		$w = self::get( $id );
		if ( ! $w ) {
			return new WP_Error( 'msm_404', 'Wydanie nie istnieje.', array( 'status' => 404 ) );
		}
		if ( 'anulowane' === $w['status'] ) {
			return new WP_Error( 'msm_400', 'To wydanie jest już anulowane.', array( 'status' => 400 ) );
		}
		$note = trim( sanitize_textarea_field( wp_unslash( (string) ( $in['note'] ?? '' ) ) ) );
		$wpdb->query( 'START TRANSACTION' );
		foreach ( $w['lines'] as $l ) {
			if ( 'magazyn' === $l['zrodlo'] && $l['bhp_id'] ) {
				$cur = $wpdb->get_var( $wpdb->prepare( 'SELECT ilosc FROM `' . msm_table( 'bhp' ) . '` WHERE id = %d', $l['bhp_id'] ) ); // phpcs:ignore
				if ( null !== $cur ) {
					list( $rn, $ru ) = self::zwrot_pule( $l );
					self::restock( (int) $l['bhp_id'], $l['lokacja'] ?? 'magazyn', $rn, $ru );
					MSM_Repo::log(
						'BHP: zwrot wydania',
						'bhp',
						(int) $l['bhp_id'],
						'Zwrot ' . (int) $l['ilosc'] . ' szt. na stan (anulowano ' . $w['numer'] . ') – ' . $w['osoba_name'],
						array(
							'przed' => array( 'ilosc' => (int) $cur ),
							'po'    => array( 'ilosc' => (int) $cur + (int) $l['ilosc'] ),
							'wyd'   => array( 'id' => (int) $id, 'numer' => $w['numer'], 'osoba' => $w['osoba_name'] ),
						),
						array( 'bhp', (int) $l['bhp_id'] )
					);
				}
			}
		}
		$wpdb->update( self::T_WYD(), array(
			'status'        => 'anulowane',
			'canceled_name' => MSM_Repo::user_name(),
			'canceled_at'   => current_time( 'mysql' ),
			'uwagi'         => trim( $w['uwagi'] . ( $note ? "\nAnulowano: " . $note : '' ) ),
		), array( 'id' => $id ) );
		$wpdb->query( 'COMMIT' );
		MSM_Repo::log( 'BHP: anulowanie wydania', 'bhp', (int) $id, 'Anulowano wydanie ' . $w['numer'] . ' dla: ' . $w['osoba_name'] . ' – stan pozycji magazynowych zwrócony' . ( $note ? ' (' . $note . ')' : '' ), null, array( 'bhp_wyd', (int) $id ) );
		return array( 'doc' => self::get( $id ), 'message' => 'Anulowano wydanie ' . $w['numer'] . '. Stan pozycji magazynowych został zwrócony.' );
	}

	/**
	 * Trwałe usunięcie wydania – tylko administrator główny (super admin).
	 * Numerowane wydanie: zwraca stan (jeśli nie było anulowane) i zwalnia numer.
	 * Wpis archiwalny: usuwany bez wpływu na stan.
	 */
	public static function delete( $id ) {
		global $wpdb;
		if ( ! MSM_Install::can_purge() ) {
			return new WP_Error( 'msm_forbidden', 'Tylko administrator główny może usuwać wydania BHP.', array( 'status' => 403 ) );
		}
		$w = self::get( $id );
		if ( ! $w ) {
			return new WP_Error( 'msm_404', 'Wydanie nie istnieje.', array( 'status' => 404 ) );
		}
		$wpdb->query( 'START TRANSACTION' );
		// Zwrot stanu tylko gdy wydanie nie było wcześniej anulowane (anulowane już zwróciło stan).
		if ( 'anulowane' !== $w['status'] ) {
			foreach ( $w['lines'] as $l ) {
				if ( 'magazyn' === $l['zrodlo'] && $l['bhp_id'] ) {
					$cur = $wpdb->get_var( $wpdb->prepare( 'SELECT ilosc FROM `' . msm_table( 'bhp' ) . '` WHERE id = %d', $l['bhp_id'] ) ); // phpcs:ignore
					if ( null !== $cur ) {
						list( $rn, $ru ) = self::zwrot_pule( $l );
						self::restock( (int) $l['bhp_id'], $l['lokacja'] ?? 'magazyn', $rn, $ru );
						MSM_Repo::log(
							'BHP: zwrot wydania',
							'bhp',
							(int) $l['bhp_id'],
							'Zwrot ' . (int) $l['ilosc'] . ' szt. na stan (usunięto ' . ( $w['numer'] ? $w['numer'] : 'wpis' ) . ') – ' . $w['osoba_name'],
							array(
								'przed' => array( 'ilosc' => (int) $cur ),
								'po'    => array( 'ilosc' => (int) $cur + (int) $l['ilosc'] ),
								'wyd'   => array( 'id' => (int) $id, 'numer' => $w['numer'], 'osoba' => $w['osoba_name'] ),
							),
							array( 'bhp', (int) $l['bhp_id'] )
						);
					}
				}
			}
		}
		$wpdb->delete( self::T_POZ(), array( 'wyd_id' => (int) $id ) );
		$wpdb->delete( self::T_WYD(), array( 'id' => (int) $id ) );
		$wpdb->query( 'COMMIT' );
		$arch = empty( $w['numer'] );
		MSM_Repo::log( 'BHP: usunięcie wydania', 'bhp', (int) $id, 'Usunięto ' . ( $arch ? 'wpis archiwalny' : $w['numer'] ) . ' dla: ' . $w['osoba_name'] . ( 'anulowane' === $w['status'] ? '' : ' – stan zwrócony' ) . ( $arch ? '' : ' – numer zwolniony' ), null, array( 'bhp_wyd', (int) $id ) );
		return array( 'deleted' => 1, 'message' => $arch ? 'Usunięto wpis archiwalny.' : 'Usunięto wydanie ' . $w['numer'] . '. Numer został zwolniony.' );
	}

	/** Informacja o numerze dla nowego wydania: auto (numeracja ciągła) albo wolne numery do wyboru. */
	public static function next_number( $year = 0 ) {
		global $wpdb;
		$year = $year ? (int) $year : (int) current_time( 'Y' );
		$used = array_map( 'intval', $wpdb->get_col( $wpdb->prepare( 'SELECT nr_seq FROM `' . self::T_WYD() . '` WHERE rok = %d AND nr_seq IS NOT NULL ORDER BY nr_seq ASC', $year ) ) ); // phpcs:ignore
		$max  = $used ? max( $used ) : 0;
		$fmt  = function ( $s ) use ( $year ) { return 'BHP/' . sprintf( '%04d', $s ) . '/' . $year; };
		$free = array();
		for ( $i = 1; $i <= $max; $i++ ) {
			if ( ! in_array( $i, $used, true ) ) {
				$free[] = array( 'seq' => $i, 'numer' => $fmt( $i ) );
			}
		}
		return array(
			'year'       => $year,
			'auto'       => empty( $free ),          // brak luk → nadajemy po kolei (max+1)
			'next'       => $max + 1,
			'next_numer' => $fmt( $max + 1 ),
			'free'       => $free,
		);
	}

	/* ------------------------------------------------------------------ *
	 * Wydruk (A4)
	 * ------------------------------------------------------------------ */
	public static function maybe_print() {
		$what = isset( $_GET['msm_print'] ) ? sanitize_key( wp_unslash( $_GET['msm_print'] ) ) : ''; // phpcs:ignore
		if ( ( 'bhp_wyd' !== $what && 'bhp_osoba' !== $what ) || ! is_user_logged_in() ) {
			return;
		}
		if ( ! current_user_can( 'msm_view' ) || ( ! MSM_Perms::is_wp_admin() && ! MSM_Perms::menu_on( 'bhp' ) ) ) {
			wp_die( 'Brak dostępu.', 403 );
		}
		if ( 'bhp_osoba' === $what ) {
			$rep = self::osoba_report( (int) ( $_GET['id'] ?? 0 ), (int) ( $_GET['rok'] ?? 0 ) ); // phpcs:ignore
			if ( ! $rep ) {
				wp_die( 'Osoba nie istnieje.', 404 );
			}
			nocache_headers();
			self::print_osoba_doc( $rep );
			exit;
		}
		$w = self::get( (int) ( $_GET['id'] ?? 0 ) ); // phpcs:ignore
		if ( ! $w ) {
			wp_die( 'Dokument nie istnieje.', 404 );
		}
		nocache_headers();
		self::print_doc( $w );
		exit;
	}

	/** Zestawienie wszystkiego, co wydano danej osobie (opcjonalnie w danym roku). */
	public static function osoba_report( $osoba_id, $rok = 0 ) {
		global $wpdb;
		$os = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM `' . msm_table( 'bhp_osoby' ) . '` WHERE id = %d', $osoba_id ), ARRAY_A ); // phpcs:ignore
		if ( ! $os ) {
			return null;
		}
		$BW   = self::T_WYD();
		$BP   = self::T_POZ();
		$sql  = "SELECT w.numer, w.data, w.dzial, w.wydal_name, p.kategoria, p.nazwa, p.rozmiar, p.ilosc, p.jm, p.zrodlo FROM `$BP` p INNER JOIN `$BW` w ON w.id = p.wyd_id WHERE w.osoba_id = %d AND w.status <> 'anulowane'";
		$args = array( (int) $osoba_id );
		if ( $rok ) {
			$sql   .= ' AND w.rok = %d';
			$args[] = (int) $rok;
		}
		$sql .= ' ORDER BY w.data ASC, w.id ASC, p.lp ASC';
		$rows = $wpdb->get_results( $wpdb->prepare( $sql, $args ), ARRAY_A ); // phpcs:ignore
		$lata = $wpdb->get_col( $wpdb->prepare( "SELECT DISTINCT rok FROM `$BW` WHERE osoba_id = %d AND status <> 'anulowane' AND rok IS NOT NULL ORDER BY rok DESC", (int) $osoba_id ) ); // phpcs:ignore
		$held = class_exists( 'MSM_Bhp_Util' ) ? MSM_Bhp_Util::held_lines( (int) $osoba_id ) : array();
		return array( 'osoba' => $os, 'rok' => (int) $rok, 'lines' => $rows, 'lata' => array_map( 'intval', $lata ), 'held' => $held );
	}

	private static function print_doc( $w ) {
		$fonts = MSM_URL . 'assets/fonts/';
		$dt    = function ( $v ) { return $v ? mysql2date( 'd.m.Y', $v ) : ''; };
		?><!DOCTYPE html>
<html lang="pl"><head><meta charset="utf-8"><meta name="robots" content="noindex,nofollow"><title>Wydanie BHP <?php echo esc_html( $w['numer'] ); ?></title>
<style>
@font-face{font-family:PJS;font-weight:400;src:url(<?php echo esc_url( $fonts ); ?>plus-jakarta-sans-latin-ext-400-normal.woff2) format("woff2");unicode-range:U+0100-02BA,U+1E00-1E9F}
@font-face{font-family:PJS;font-weight:400;src:url(<?php echo esc_url( $fonts ); ?>plus-jakarta-sans-latin-400-normal.woff2) format("woff2");unicode-range:U+0000-00FF,U+2000-206F}
@font-face{font-family:PJS;font-weight:600;src:url(<?php echo esc_url( $fonts ); ?>plus-jakarta-sans-latin-ext-600-normal.woff2) format("woff2");unicode-range:U+0100-02BA,U+1E00-1E9F}
@font-face{font-family:PJS;font-weight:600;src:url(<?php echo esc_url( $fonts ); ?>plus-jakarta-sans-latin-600-normal.woff2) format("woff2");unicode-range:U+0000-00FF,U+2000-206F}
@font-face{font-family:PJS;font-weight:800;src:url(<?php echo esc_url( $fonts ); ?>plus-jakarta-sans-latin-ext-800-normal.woff2) format("woff2");unicode-range:U+0100-02BA,U+1E00-1E9F}
@font-face{font-family:PJS;font-weight:800;src:url(<?php echo esc_url( $fonts ); ?>plus-jakarta-sans-latin-800-normal.woff2) format("woff2");unicode-range:U+0000-00FF,U+2000-206F}
@page{size:A4;margin:14mm 14mm}
*{box-sizing:border-box}
html,body{margin:0;background:#e9ebef}
body{font:10pt/1.45 PJS,sans-serif;color:#0b1020;-webkit-print-color-adjust:exact;print-color-adjust:exact}
.bar{position:sticky;top:0;display:flex;gap:10px;justify-content:center;padding:10px;background:#0b1020;color:#fff;z-index:5}
.bar button,.bar a{font:600 13px PJS,system-ui;padding:8px 18px;border-radius:99px;border:0;background:#3d4bff;color:#fff;cursor:pointer;text-decoration:none}
.bar .g{background:transparent;border:1px solid rgba(255,255,255,.4)}
.page{position:relative}
@media screen{.page{width:210mm;min-height:297mm;padding:14mm;margin:16px auto;background:#fff;box-shadow:0 4px 24px rgba(0,0,0,.14)}}
@media print{html,body{background:#fff}.bar{display:none}}
h1{font-size:16pt;margin:0 0 1mm}
.sub{color:#5a6274;font-size:8.5pt;margin:0 0 5mm}
.hdr{display:flex;justify-content:space-between;align-items:flex-start;border-bottom:2px solid #0b1020;padding-bottom:3mm;margin-bottom:4mm}
.meta{display:grid;grid-template-columns:1fr 1fr;gap:2mm 8mm;margin-bottom:5mm}
.meta .lbl{font-size:7pt;text-transform:uppercase;letter-spacing:.06em;color:#5a6274;font-weight:600}
.meta .val{font-weight:600}
table{width:100%;border-collapse:collapse;margin-bottom:5mm}
th,td{border:1px solid #9aa3b2;padding:2mm 2.5mm;text-align:left;vertical-align:top}
th{background:#eef0f5;font-size:8pt;text-transform:uppercase;letter-spacing:.04em}
td.num,th.num{text-align:center;width:16mm}
.badge{display:inline-block;padding:1mm 3mm;border-radius:99px;background:#eef0f5;font-size:8pt;font-weight:700}
.badge.cancel{background:#fde2e2;color:#8a1f1f}
.sign{display:grid;grid-template-columns:1fr 1fr;gap:16mm;margin-top:14mm}
.sign div{border-top:1px solid #0b1020;padding-top:2mm;text-align:center;font-size:8.5pt;color:#5a6274}
.note{font-size:8.5pt;color:#444;white-space:pre-wrap}
</style></head>
<body>
<div class="bar"><button onclick="window.print()">Drukuj / zapisz PDF</button><a class="g" href="<?php echo esc_url( MSM_Access::app_url() ); ?>">Zamknij</a></div>
<div class="page">
	<div class="hdr">
		<div>
			<h1>Wydanie środków BHP / odzieży roboczej</h1>
			<p class="sub"><?php echo esc_html( msm_opt( 'firma_skrot' ) . ' · ' . msm_opt( 'firma_adres' ) ); ?></p>
		</div>
		<div style="text-align:right">
			<div style="font-size:13pt;font-weight:800"><?php echo esc_html( $w['numer'] ? $w['numer'] : 'wpis archiwalny' ); ?></div>
			<?php if ( 'anulowane' === $w['status'] ) : ?><span class="badge cancel">ANULOWANE</span><?php elseif ( 'archiwalne' === $w['status'] ) : ?><span class="badge">ARCHIWALNE · bez numeru</span><?php endif; ?>
		</div>
	</div>
	<div class="meta">
		<div><span class="lbl">Osoba</span><div class="val"><?php echo esc_html( $w['osoba_name'] ); ?></div></div>
		<div><span class="lbl">Dział / brygada</span><div class="val"><?php echo esc_html( $w['dzial'] ? $w['dzial'] : '—' ); ?></div></div>
		<div><span class="lbl">Data wydania</span><div class="val"><?php echo esc_html( $dt( $w['data'] ) ); ?></div></div>
		<div><span class="lbl">Wydał</span><div class="val"><?php echo esc_html( $w['wydal_name'] ); ?></div></div>
	</div>
	<table>
		<thead><tr><th class="num">Lp.</th><th>Asortyment</th><th>Nazwa / producent</th><th>Rozmiar</th><th class="num">Ilość</th></tr></thead>
		<tbody>
		<?php foreach ( $w['lines'] as $l ) : ?>
			<tr>
				<td class="num"><?php echo (int) $l['lp']; ?></td>
				<td><?php echo esc_html( $l['kategoria'] ); ?></td>
				<td><?php echo esc_html( $l['nazwa'] ); ?><?php echo 'reczne' === $l['zrodlo'] ? ' <span class="badge">spoza magazynu</span>' : ''; ?></td>
				<td><?php echo esc_html( $l['rozmiar'] ); ?></td>
				<td class="num"><?php echo (int) $l['ilosc']; ?> <?php echo esc_html( $l['jm'] ); ?></td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table>
	<?php if ( $w['uwagi'] ) : ?><p class="note"><b>Uwagi:</b> <?php echo esc_html( $w['uwagi'] ); ?></p><?php endif; ?>
	<div class="sign">
		<div>Podpis wydającego</div>
		<div>Podpis odbierającego (<?php echo esc_html( $w['osoba_name'] ); ?>)</div>
	</div>
</div>
</body></html>
<?php
	}

	/** Wydruk: karta wyposażenia BHP jednej osoby – wszystko, co jej wydano (opcjonalnie w danym roku). */
	private static function print_osoba_doc( $rep ) {
		$fonts = MSM_URL . 'assets/fonts/';
		$os    = $rep['osoba'];
		$rok   = (int) $rep['rok'];
		$lines = $rep['lines'];
		$dt    = function ( $v ) { return $v ? mysql2date( 'd.m.Y', $v ) : ''; };
		$suma  = 0;
		foreach ( $lines as $l ) {
			$suma += (int) $l['ilosc'];
		}
		?><!DOCTYPE html>
<html lang="pl"><head><meta charset="utf-8"><meta name="robots" content="noindex,nofollow"><title>Karta BHP <?php echo esc_html( $os['imie_nazwisko'] ); ?></title>
<style>
@font-face{font-family:PJS;font-weight:400;src:url(<?php echo esc_url( $fonts ); ?>plus-jakarta-sans-latin-ext-400-normal.woff2) format("woff2");unicode-range:U+0100-02BA,U+1E00-1E9F}
@font-face{font-family:PJS;font-weight:400;src:url(<?php echo esc_url( $fonts ); ?>plus-jakarta-sans-latin-400-normal.woff2) format("woff2");unicode-range:U+0000-00FF,U+2000-206F}
@font-face{font-family:PJS;font-weight:600;src:url(<?php echo esc_url( $fonts ); ?>plus-jakarta-sans-latin-ext-600-normal.woff2) format("woff2");unicode-range:U+0100-02BA,U+1E00-1E9F}
@font-face{font-family:PJS;font-weight:600;src:url(<?php echo esc_url( $fonts ); ?>plus-jakarta-sans-latin-600-normal.woff2) format("woff2");unicode-range:U+0000-00FF,U+2000-206F}
@font-face{font-family:PJS;font-weight:800;src:url(<?php echo esc_url( $fonts ); ?>plus-jakarta-sans-latin-ext-800-normal.woff2) format("woff2");unicode-range:U+0100-02BA,U+1E00-1E9F}
@font-face{font-family:PJS;font-weight:800;src:url(<?php echo esc_url( $fonts ); ?>plus-jakarta-sans-latin-800-normal.woff2) format("woff2");unicode-range:U+0000-00FF,U+2000-206F}
@page{size:A4;margin:14mm 14mm}
*{box-sizing:border-box}
html,body{margin:0;background:#e9ebef}
body{font:10pt/1.45 PJS,sans-serif;color:#0b1020;-webkit-print-color-adjust:exact;print-color-adjust:exact}
.bar{position:sticky;top:0;display:flex;gap:10px;justify-content:center;padding:10px;background:#0b1020;color:#fff;z-index:5}
.bar button,.bar a{font:600 13px PJS,system-ui;padding:8px 18px;border-radius:99px;border:0;background:#3d4bff;color:#fff;cursor:pointer;text-decoration:none}
.bar .g{background:transparent;border:1px solid rgba(255,255,255,.4)}
.page{position:relative}
@media screen{.page{width:210mm;min-height:297mm;padding:14mm;margin:16px auto;background:#fff;box-shadow:0 4px 24px rgba(0,0,0,.14)}}
@media print{html,body{background:#fff}.bar{display:none}}
h1{font-size:16pt;margin:0 0 1mm}
.sub{color:#5a6274;font-size:8.5pt;margin:0 0 5mm}
.hdr{display:flex;justify-content:space-between;align-items:flex-start;border-bottom:2px solid #0b1020;padding-bottom:3mm;margin-bottom:4mm}
.meta{display:grid;grid-template-columns:1fr 1fr 1fr;gap:2mm 8mm;margin-bottom:5mm}
.meta .lbl{font-size:7pt;text-transform:uppercase;letter-spacing:.06em;color:#5a6274;font-weight:600}
.meta .val{font-weight:600}
table{width:100%;border-collapse:collapse;margin-bottom:5mm}
th,td{border:1px solid #9aa3b2;padding:1.6mm 2.2mm;text-align:left;vertical-align:top}
th{background:#eef0f5;font-size:8pt;text-transform:uppercase;letter-spacing:.04em}
td.num,th.num{text-align:center;width:14mm}
td.c,th.c{width:24mm}
tfoot td{font-weight:800;background:#f6f7fa}
.badge{display:inline-block;padding:.5mm 2mm;border-radius:99px;background:#eef0f5;font-size:7.5pt;font-weight:700}
.sign{display:grid;grid-template-columns:1fr 1fr;gap:16mm;margin-top:14mm}
.sign div{border-top:1px solid #0b1020;padding-top:2mm;text-align:center;font-size:8.5pt;color:#5a6274}
.empty{padding:8mm;text-align:center;color:#5a6274}
</style></head>
<body>
<div class="bar"><button onclick="window.print()">Drukuj / zapisz PDF</button><a class="g" href="<?php echo esc_url( MSM_Access::app_url() ); ?>">Zamknij</a></div>
<div class="page">
	<div class="hdr">
		<div>
			<h1>Karta wyposażenia BHP / odzieży roboczej</h1>
			<p class="sub"><?php echo esc_html( msm_opt( 'firma_skrot' ) . ' · ' . msm_opt( 'firma_adres' ) ); ?></p>
		</div>
		<div style="text-align:right">
			<div style="font-size:13pt;font-weight:800"><?php echo esc_html( $os['imie_nazwisko'] ); ?></div>
			<span class="badge"><?php echo $rok ? 'rok ' . (int) $rok : 'wszystkie wydania'; ?></span>
		</div>
	</div>
	<div class="meta">
		<div><span class="lbl">Pracownik</span><div class="val"><?php echo esc_html( $os['imie_nazwisko'] ); ?></div></div>
		<div><span class="lbl">Dział / brygada</span><div class="val"><?php echo esc_html( $os['dzial'] ? $os['dzial'] : '—' ); ?></div></div>
		<div><span class="lbl">Nr ewidencyjny</span><div class="val"><?php echo esc_html( $os['nr_ewid'] ? $os['nr_ewid'] : '—' ); ?></div></div>
	</div>
	<?php $held = isset( $rep['held'] ) ? $rep['held'] : array(); ?>
	<?php if ( $held ) : ?>
		<h2 style="font-size:11pt;margin:0 0 2mm">Na wyposażeniu teraz</h2>
		<table>
			<thead><tr><th>Asortyment</th><th>Nazwa</th><th>Rozmiar</th><th class="num">Ilość</th><th>Wydano</th></tr></thead>
			<tbody>
			<?php foreach ( $held as $h ) : ?>
				<tr>
					<td><?php echo esc_html( $h['kategoria'] ); ?></td>
					<td><?php echo esc_html( $h['nazwa'] ); ?></td>
					<td><?php echo esc_html( $h['rozmiar'] ); ?></td>
					<td class="num"><?php echo (int) $h['held']; ?> szt</td>
					<td><?php echo esc_html( $dt( $h['last_data'] ) ); ?></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<h2 style="font-size:11pt;margin:3mm 0 2mm">Historia wydań</h2>
	<?php endif; ?>
	<?php if ( ! $lines ) : ?>
		<p class="empty">Brak wydań<?php echo $rok ? ' w roku ' . (int) $rok : ''; ?> dla tej osoby.</p>
	<?php else : ?>
	<table>
		<thead><tr><th class="c">Data</th><th>Dokument</th><th>Asortyment</th><th>Nazwa / producent</th><th>Rozmiar</th><th class="num">Ilość</th></tr></thead>
		<tbody>
		<?php foreach ( $lines as $l ) : ?>
			<tr>
				<td class="c"><?php echo esc_html( $dt( $l['data'] ) ); ?></td>
				<td><?php echo esc_html( $l['numer'] ); ?></td>
				<td><?php echo esc_html( $l['kategoria'] ); ?></td>
				<td><?php echo esc_html( $l['nazwa'] ); ?><?php echo 'reczne' === $l['zrodlo'] ? ' <span class="badge">spoza magazynu</span>' : ''; ?></td>
				<td><?php echo esc_html( $l['rozmiar'] ); ?></td>
				<td class="num"><?php echo (int) $l['ilosc']; ?> <?php echo esc_html( $l['jm'] ); ?></td>
			</tr>
		<?php endforeach; ?>
		</tbody>
		<tfoot><tr><td colspan="5">Razem wydano</td><td class="num"><?php echo (int) $suma; ?> szt</td></tr></tfoot>
	</table>
	<?php endif; ?>
	<div class="sign">
		<div>Podpis wydającego / magazyniera</div>
		<div>Podpis pracownika (<?php echo esc_html( $os['imie_nazwisko'] ); ?>)</div>
	</div>
</div>
</body></html>
		<?php
	}

}
