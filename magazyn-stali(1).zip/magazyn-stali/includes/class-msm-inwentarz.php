<?php
/**
 * Szybki inwentarz (tylko administrator): tryb, w którym administrator szybko
 * dodaje, edytuje i usuwa pozycje magazynowe. Bez wniosków i e-maili – każda zmiana
 * trafia do historii z adnotacją „szybki inwentarz”.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MSM_Inwentarz {

	const OPT    = 'msm_inwentarz';
	const HEADER = 'x_msm_inw';

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
	}

	public static function state() {
		$s = get_option( self::OPT, array() );
		return is_array( $s ) ? $s : array();
	}

	public static function active() {
		return ! empty( self::state()['active'] );
	}

	/** Czy to żądanie z trybu szybkiego inwentarza (aktywny tryb + nagłówek z aplikacji). */
	public static function request_in_mode( WP_REST_Request $r ) {
		return self::active() && '1' === (string) $r->get_header( self::HEADER );
	}

	/** Zmiany w tabelach magazynowych – tylko administrator (także w trybie szybkiego inwentarza). */
	public static function can_edit_stock( WP_REST_Request $r ) {
		if ( ! current_user_can( 'msm_edit' ) || ( class_exists( 'MSM_Perms' ) && ! MSM_Perms::user_can( 'edit' ) ) ) {
			return new WP_Error( 'msm_forbidden', 'Brak uprawnień do zmian.', array( 'status' => 403 ) );
		}
		return true;
	}

	/** Włącza oznaczanie wpisów historii dla bieżącego żądania. */
	public static function tag( WP_REST_Request $r ) {
		if ( current_user_can( 'msm_edit' ) && self::request_in_mode( $r ) ) {
			MSM_Repo::$inw = (int) ( self::state()['nr'] ?? 0 );
		}
	}

	public static function summary() {
		global $wpdb;
		$s   = self::state();
		$out = array(
			'active'     => ! empty( $s['active'] ),
			'nr'         => (int) ( $s['nr'] ?? 0 ),
			'started_at' => $s['started_at'] ?? null,
			'started_by' => $s['started_by'] ?? '',
			'dodanie'    => 0,
			'edycja'     => 0,
			'usunięcie'  => 0,
		);
		if ( $out['nr'] ) {
			$L    = msm_table( 'historia' );
			$rows = $wpdb->get_results( $wpdb->prepare( "SELECT akcja, COUNT(*) n FROM `$L` WHERE akcja LIKE %s AND czas >= %s GROUP BY akcja", 'szybki inwentarz: %', (string) $out['started_at'] ), ARRAY_A ); // phpcs:ignore
			foreach ( $rows as $row ) {
				$k = trim( substr( $row['akcja'], strlen( 'szybki inwentarz:' ) ) );
				if ( isset( $out[ $k ] ) ) {
					$out[ $k ] = (int) $row['n'];
				}
			}
		}
		return $out;
	}

	public static function start() {
		if ( class_exists( 'MSM_Perms' ) && ! MSM_Perms::user_can( 'inwentarz' ) ) {
			return new WP_Error( 'msm_forbidden', 'Brak uprawnień do szybkiego inwentarza.', array( 'status' => 403 ) );
		}
		$s = self::state();
		if ( ! empty( $s['active'] ) ) {
			return self::summary();
		}
		$nr = (int) get_option( 'msm_inwentarz_nr', 0 ) + 1;
		update_option( 'msm_inwentarz_nr', $nr, false );
		update_option( self::OPT, array(
			'active'     => true,
			'nr'         => $nr,
			'started_at' => current_time( 'mysql' ),
			'started_by' => MSM_Repo::user_name(),
		), false );
		MSM_Repo::log( 'szybki inwentarz: start', 'inwentarz', $nr, 'Rozpoczęto szybki inwentarz nr ' . $nr );
		return self::summary();
	}

	public static function stop() {
		if ( class_exists( 'MSM_Perms' ) && ! MSM_Perms::user_can( 'inwentarz' ) ) {
			return new WP_Error( 'msm_forbidden', 'Brak uprawnień do szybkiego inwentarza.', array( 'status' => 403 ) );
		}
		$s = self::state();
		if ( empty( $s['active'] ) ) {
			return self::summary();
		}
		$sum = self::summary();
		$s['active']   = false;
		$s['ended_at'] = current_time( 'mysql' );
		update_option( self::OPT, $s, false );
		MSM_Repo::log( 'szybki inwentarz: koniec', 'inwentarz', (int) $s['nr'], 'Zakończono szybki inwentarz nr ' . (int) $s['nr'] . ' – dodano: ' . $sum['dodanie'] . ', edytowano: ' . $sum['edycja'] . ', usunięto: ' . $sum['usunięcie'] );
		$out           = self::summary();
		$out['last']   = $sum;
		return $out;
	}

	public static function routes() {
		$ns = MSM_Rest::NS;
		register_rest_route( $ns, '/inwentarz', array(
			'methods' => 'GET', 'permission_callback' => array( 'MSM_Rest', 'can_view' ),
			'callback' => function () { return rest_ensure_response( MSM_Inwentarz::summary() ); },
		) );
		register_rest_route( $ns, '/inwentarz/(?P<action>start|stop)', array(
			'methods' => 'POST', 'permission_callback' => array( 'MSM_Rest', 'can_edit' ),
			'callback' => function ( WP_REST_Request $r ) { return rest_ensure_response( 'start' === $r['action'] ? MSM_Inwentarz::start() : MSM_Inwentarz::stop() ); },
		) );
	}
}
