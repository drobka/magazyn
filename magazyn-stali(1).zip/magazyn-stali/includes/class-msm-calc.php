<?php
/**
 * Obliczenia mas i ujednolicanie nazw.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MSM_Calc {

	/** Gęstość stali konstrukcyjnej przyjęta w dotychczasowym arkuszu [kg/dm³]. */
	const STEEL = 7.86;

	/**
	 * Gęstość materiału [kg/dm³ = g/cm³] na podstawie gatunku / materiału.
	 * Można nadpisać filtrem 'msm_density'.
	 */
	public static function density( $gatunek ) {
		$g = mb_strtoupper( trim( (string) $gatunek ), 'UTF-8' );
		$d = self::STEEL;
		if ( '' !== $g ) {
			if ( preg_match( '/^(CU|MIED)/u', $g ) ) {
				$d = 8.9;
			} elseif ( preg_match( '/^(AL|ALU)/u', $g ) ) {
				$d = 2.7;
			} elseif ( preg_match( '/^(MO|MOSI|CUZN)/u', $g ) ) {
				$d = 8.5; // mosiądz (MO58 itp.)
			} elseif ( preg_match( '/^(SS|INOX|NIERDZ|304|316|1\.4)/u', $g ) ) {
				$d = 7.9;
			}
		}
		return (float) apply_filters( 'msm_density', $d, $gatunek );
	}

	/** Pole przekroju [mm²] dla pozycji stalowej lub null, gdy brakuje wymiarów. */
	public static function stal_area( $opis, $b, $c, $t ) {
		$b = self::f( $b );
		$c = self::f( $c );
		$t = self::f( $t );
		switch ( $opis ) {
			case 'PROFIL':
				if ( $b && $c && $t && $b > 2 * $t && $c > 2 * $t ) {
					return $b * $c - ( $b - 2 * $t ) * ( $c - 2 * $t );
				}
				return null;
			case 'PROFIL OTWARTY': // ceownik gięty: środnik B + 2 półki C
				if ( $b && $c && $t ) {
					return $t * ( $b + 2 * $c - 2 * $t );
				}
				return null;
			case 'KĄTOWNIK L':
				if ( $b && $t ) {
					$c = $c ? $c : $b;
					return $t * ( $b + $c - $t );
				}
				return null;
			case 'PŁASKOWNIK':
			case 'PRZYGOTÓWKA':
				if ( $b && $c ) {
					return $b * $c;
				}
				return null;
			case 'PRĘT KWADRATOWY':
				if ( $b ) {
					return $b * ( $c ? $c : $b );
				}
				return null;
			case 'PRĘT OKRĄGŁY':
			case 'PRĘT CIĄGNIONY':
				return $b ? M_PI * $b * $b / 4 : null;
			case 'PRĘT SZEŚCIOKĄTNY': // wymiar = rozmiar pod klucz
				return $b ? sqrt( 3 ) / 2 * $b * $b : null;
			case 'RURA':
				if ( $b && $t && $b > 2 * $t ) {
					return M_PI / 4 * ( $b * $b - ( $b - 2 * $t ) * ( $b - 2 * $t ) );
				}
				return null;
		}
		return null;
	}

	/** Uzupełnia pola wyliczane w wierszu danej tabeli. */
	public static function compute( $table, array $row ) {
		$ilosc = isset( $row['ilosc'] ) ? (int) $row['ilosc'] : 0;
		if ( 'stal' === $table ) {
			$len            = self::f( isset( $row['dlugosc'] ) ? $row['dlugosc'] : null );
			$row['suma_mb'] = ( null !== $len ) ? round( $len * $ilosc, 3 ) : null;
			$area           = self::stal_area( $row['opis'] ?? '', $row['szer'] ?? null, $row['wys'] ?? null, $row['scianka'] ?? null );
			if ( null !== $area ) {
				$row['kg_m']    = round( $area * self::density( $row['gatunek'] ?? '' ) / 1000, 4 );
				$row['suma_kg'] = null !== $row['suma_mb'] ? round( $row['kg_m'] * $row['suma_mb'], 3 ) : null;
			} else {
				$row['kg_m']    = null;
				$row['suma_kg'] = null;
			}
		} elseif ( 'blachy_pelne' === $table || 'blachy_niepelne' === $table ) {
			$t   = self::f( $row['grubosc'] ?? null );
			$a   = self::f( $row['wymiar_a'] ?? null );
			$b   = self::f( $row['wymiar_b'] ?? null );
			$rho = self::density( ( 'blachy_pelne' === $table && ! empty( $row['material'] ) ) ? $row['material'] : ( $row['gatunek'] ?? '' ) );
			if ( 'blachy_pelne' === $table && 'MIEDŹ' === mb_strtoupper( (string) ( $row['gatunek'] ?? '' ), 'UTF-8' ) ) {
				$rho = self::density( 'Cu' );
			}
			if ( 'blachy_pelne' === $table && 'NIERDZEWKA' === mb_strtoupper( (string) ( $row['gatunek'] ?? '' ), 'UTF-8' ) ) {
				$rho = self::density( 'SS' );
			}
			$area = null;
			if ( 'koło' === ( $row['ksztalt'] ?? '' ) ) {
				$area = $a ? M_PI * $a * $a / 4 : null;
			} elseif ( $a && $b ) {
				$area = $a * $b;
			}
			if ( $t && $area ) {
				$row['kg_szt']  = round( $area * $t * $rho / 1000000, 3 );
				$row['suma_kg'] = round( $row['kg_szt'] * $ilosc, 3 );
			} else {
				$row['kg_szt']  = null;
				$row['suma_kg'] = null;
			}
		} elseif ( 'bhp' === $table ) {
			// Cztery pule: magazyn/szafa × nowy/używany. Agregaty liczą się automatycznie.
			$mn = isset( $row['st_mag_nowy'] ) ? max( 0, (int) $row['st_mag_nowy'] ) : 0;
			$mu = isset( $row['st_mag_uzywany'] ) ? max( 0, (int) $row['st_mag_uzywany'] ) : 0;
			$sn = isset( $row['st_szafa_nowy'] ) ? max( 0, (int) $row['st_szafa_nowy'] ) : 0;
			$su = isset( $row['st_szafa_uzywany'] ) ? max( 0, (int) $row['st_szafa_uzywany'] ) : 0;
			$row['ilosc_nowy']    = $mn + $sn;
			$row['ilosc_uzywany'] = $mu + $su;
			$row['ilosc']         = $mn + $mu + $sn + $su;
		}
		return $row;
	}

	/** Parsuje liczbę (także z przecinkiem). Zwraca float lub null. */
	public static function f( $v ) {
		if ( null === $v || '' === $v ) {
			return null;
		}
		if ( is_int( $v ) || is_float( $v ) ) {
			return (float) $v;
		}
		$v = str_replace( array( ' ', "\xc2\xa0", ',' ), array( '', '', '.' ), trim( (string) $v ) );
		return is_numeric( $v ) ? (float) $v : null;
	}

	/** Ujednolicenie pisowni wartości tekstowych. */
	public static function normalize( $table, $key, $value ) {
		if ( null === $value ) {
			return null;
		}
		$v = trim( preg_replace( '/\s+/u', ' ', (string) $value ) );
		if ( '' === $v ) {
			return '';
		}
		$u = mb_strtoupper( $v, 'UTF-8' );

		if ( 'opis' === $key ) {
			$map = array(
				'PRĘT OKGĄGŁY'  => 'PRĘT OKRĄGŁY',
				'PRĘT OKRAGŁY'  => 'PRĘT OKRĄGŁY',
				'PRET OKRAGLY'  => 'PRĘT OKRĄGŁY',
				'PRĘT OKRĄGŁY'  => 'PRĘT OKRĄGŁY',
				'PRĘT ALUMINIUM' => 'PRĘT OKRĄGŁY',
				'PRĘT KW.'      => 'PRĘT KWADRATOWY',
				'PRĘT KW'       => 'PRĘT KWADRATOWY',
				'SZEŚCIOKĄT'    => 'PRĘT SZEŚCIOKĄTNY',
				'PRĘT 6-KĄTNY'  => 'PRĘT SZEŚCIOKĄTNY',
				'KĄTOWNIK'      => 'KĄTOWNIK L',
				'KATOWNIK L'    => 'KĄTOWNIK L',
				'PLASKOWNIK'    => 'PŁASKOWNIK',
			);
			return isset( $map[ $u ] ) ? $map[ $u ] : $u;
		}

		if ( in_array( $key, array( 'gatunek', 'material' ), true ) ) {
			$map = array(
				'S235'   => 'S235',
				'S355'   => 'S355',
				'S325'   => 'S235', // literówka w zestawieniu
				'S255'   => 'S355', // literówka w zestawieniu
				'MO 58'  => 'MO58',
				'MO58'   => 'MO58',
				'MO'     => 'Mo',
				'AL.'    => 'Al',
				'AL'     => 'Al',
				'CU'     => 'Cu',
				'CU MHY' => 'Cu MHY',
				'INOX'   => 'INOX',
				'SS'     => 'SS',
			);
			if ( isset( $map[ $u ] ) ) {
				return $map[ $u ];
			}
			if ( preg_match( '/^S\d{3}/u', $u ) ) {
				return $u;
			}
			return $v;
		}

		return $v;
	}

	/** Krótki opis pozycji do pobrań i historii. */
	public static function describe( $table, array $r ) {
		$n = function ( $v ) {
			return MSM_Calc::fmt( $v );
		};
		switch ( $table ) {
			case 'stal':
				$dims = $n( $r['szer'] ?? null );
				if ( ! empty( $r['wys'] ) && (float) $r['wys'] > 0 ) {
					$dims .= '×' . $n( $r['wys'] );
				}
				if ( ! empty( $r['scianka'] ) && (float) $r['scianka'] > 0 ) {
					$dims .= '×' . $n( $r['scianka'] );
				}
				$s = trim( ( $r['opis'] ?? '' ) . ' ' . $dims );
				if ( ! empty( $r['gatunek'] ) ) {
					$s .= ' ' . $r['gatunek'];
				}
				if ( isset( $r['dlugosc'] ) && '' !== $r['dlugosc'] && null !== $r['dlugosc'] ) {
					$s .= ', L=' . $n( $r['dlugosc'] ) . ' m';
				}
				return $s;
			case 'blachy_pelne':
			case 'blachy_niepelne':
				$dim = ( 'koło' === ( $r['ksztalt'] ?? '' ) ) ? 'Ø' . $n( $r['wymiar_a'] ?? null ) : $n( $r['wymiar_a'] ?? null ) . '×' . $n( $r['wymiar_b'] ?? null );
				$s   = 'Blacha ' . ( $r['gatunek'] ?? '' ) . ' gr. ' . $n( $r['grubosc'] ?? null ) . ' ' . $dim;
				if ( ! empty( $r['material'] ) ) {
					$s .= ' ' . $r['material'];
				}
				return $s;
			case 'kregi':
				return 'Krąg ' . ( $r['oznaczenie'] ?? '' ) . ' ' . ( $r['izolacja'] ?? '' ) . ' ' . $n( $r['grubosc'] ?? null ) . '×' . $n( $r['szerokosc'] ?? null ) . ( ! empty( $r['lokalizacja'] ) ? ' (' . $r['lokalizacja'] . ')' : '' );
			case 'bhp':
				$s = trim( ( $r['kategoria'] ?? '' ) . ' ' . ( $r['nazwa'] ?? '' ) );
				if ( ! empty( $r['producent_id'] ) ) {
					$s .= ' (' . $r['producent_id'] . ')';
				}
				if ( ! empty( $r['rozmiar'] ) ) {
					$s .= ', rozm. ' . $r['rozmiar'];
				}
				return '' !== $s ? $s : '#' . ( $r['id'] ?? '' );
		}
		return '#' . ( $r['id'] ?? '' );
	}

	public static function fmt( $v ) {
		if ( null === $v || '' === $v ) {
			return '';
		}
		$f = (float) $v;
		$s = rtrim( rtrim( number_format( $f, 3, ',', '' ), '0' ), ',' );
		return $s;
	}

	/**
	 * Odcinki: liczba sztuk i długość jednego odcinka z danych wejściowych.
	 * Zwraca [szt, długość jednego, razem] albo WP_Error.
	 */
	public static function odcinki( array $in ) {
		$n   = self::f( $in['odc_szt'] ?? 1 );
		$len = self::f( $in['dlugosc'] ?? null );
		if ( null === $n || $n < 1 || floor( $n ) != $n ) { // phpcs:ignore
			return new WP_Error( 'msm_invalid', 'Podaj liczbę odcinków (całe sztuki).', array( 'status' => 400, 'fields' => array( 'odc_szt' => 'Podaj liczbę' ) ) );
		}
		if ( null === $len || $len <= 0 ) {
			return new WP_Error( 'msm_invalid', 'Podaj długość odcinka w metrach.', array( 'status' => 400, 'fields' => array( 'dlugosc' => 'Podaj długość' ) ) );
		}
		$n = (int) $n;
		return array( $n, round( $len, 3 ), round( $n * $len, 3 ) );
	}

	/** Opis odcinków, np. „2 × 0,4 m = 0,8 m” (pusty dla jednego odcinka). */
	public static function odc_txt( $row ) {
		$n = isset( $row['odc_szt'] ) ? (int) $row['odc_szt'] : 0;
		if ( $n < 2 || empty( $row['odc_dl'] ) ) {
			return '';
		}
		return $n . ' × ' . self::fmt( $row['odc_dl'] ) . ' m';
	}

	/**
	 * Uwagi wpisane przy czynności (pobranie, dodanie, edycja…) – do kolumny „Uwagi” w Historii zmian.
	 * Szuka pola „uwagi” w danych wpisu: najpierw w pozycji czynności, potem na górze, potem w stanie „po”.
	 */
	public static function log_uwagi( $dane ) {
		if ( ! is_array( $dane ) ) {
			return null;
		}
		foreach ( array( $dane['poz'] ?? null, $dane, $dane['po'] ?? null ) as $src ) {
			if ( is_array( $src ) && isset( $src['uwagi'] ) && is_scalar( $src['uwagi'] ) ) {
				$u = trim( (string) $src['uwagi'] );
				if ( '' !== $u ) {
					return mb_substr( $u, 0, 2000 );
				}
			}
		}
		return null;
	}
}
