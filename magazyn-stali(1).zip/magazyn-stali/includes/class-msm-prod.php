<?php
/**
 * Produkcja – arkusz zleceń edytowany jak w Excelu (kolumny A–O arkusza „2026”).
 *
 * Model: zlecenie (pola wspólne: nr, start, zakończenie, klient, nr zlecenia klienta)
 *        + detale (uwagi, dostępność przyrządów, wersja, laser, materiał, czas cięcia,
 *          nazwa, nr rysunku, ilość zam., wykonano). „% wykon.” i „Zostało” są wyliczane.
 * Kolejność jest stała (pole poz) – bez sortowania, jak w arkuszu.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MSM_Prod {

	const SHEET = '2026'; // arkusz wczytany z Excela (seed); kolejne lata – wg daty dodania zlecenia

	/** Bieżący rok – nowe zlecenia trafiają domyślnie do listy tego roku. */
	public static function current_year() {
		return (string) current_time( 'Y' );
	}

	public static function valid_year( $y ) {
		$y = (string) (int) $y;
		return preg_match( '/^20\d\d$/', $y ) ? $y : '';
	}

	/** Lata, dla których są zlecenia, plus bieżący (najnowszy pierwszy). */
	public static function years() {
		global $wpdb;
		$ys   = (array) $wpdb->get_col( 'SELECT DISTINCT arkusz FROM `' . self::TZ() . '`' ); // phpcs:ignore
		$ys[] = self::current_year();
		$ys   = array_values( array_unique( array_filter( array_map( array( __CLASS__, 'valid_year' ), $ys ) ) ) );
		rsort( $ys );
		return $ys;
	}

	/** Pola edytowalne: zlecenie i detal (klucz => [typ, etykieta]). */
	const Z_FIELDS = array(
		'nr_zlec'         => array( 'text', 'Nr zlec.' ),
		'start_zlec'      => array( 'text', 'Start zlec.' ),
		'koniec_zlec'     => array( 'text', 'Zakończenie zlec.' ),
		'klient'          => array( 'text', 'Nazwa klienta' ),
		'nr_zlec_klienta' => array( 'text', 'Nr zlec. klienta' ),
		'uwagi_ogolne'    => array( 'long', 'Uwagi ogólne' ),
	);
	const D_FIELDS = array(
		'uwagi'        => array( 'text', 'Uwagi' ),
		'dostepnosc'   => array( 'text', 'Dostępność przyrządów/sprawdzianów' ),
		'wersja'       => array( 'text', 'Wersja' ),
		'laser'        => array( 'laser', 'Laser' ),
		'material'     => array( 'text', 'Materiał' ),
		'mat_klienta'  => array( 'bool', 'Materiał klienta' ),
		'czas_ciecia'  => array( 'sec', 'Czas cięcia [s]' ),
		'nazwa_detalu' => array( 'text', 'Nazwa detali' ),
		'nr_rysunku'   => array( 'text', 'Nr rysunku' ),
		'ilosc_zam'    => array( 'int', 'Ilość zam.' ),
		'wykonano'     => array( 'int', 'Wykon.' ),
	);

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
	}

	public static function TZ() {
		global $wpdb;
		return $wpdb->prefix . 'msm_prod_zlec';
	}

	public static function TD() {
		global $wpdb;
		return $wpdb->prefix . 'msm_prod_det';
	}

	/* ------------------------------------------------------------------ *
	 * Instalacja
	 * ------------------------------------------------------------------ */

	public static function create_tables() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$charset = $wpdb->get_charset_collate();
		dbDelta( 'CREATE TABLE ' . self::TZ() . " (
id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
arkusz varchar(20) NOT NULL DEFAULT '2026',
poz int(11) NOT NULL DEFAULT 0,
nr_zlec varchar(190) NOT NULL DEFAULT '',
start_zlec varchar(190) NOT NULL DEFAULT '',
koniec_zlec varchar(190) NOT NULL DEFAULT '',
klient varchar(255) NOT NULL DEFAULT '',
nr_zlec_klienta varchar(255) NOT NULL DEFAULT '',
uwagi_ogolne text NULL,
karta longtext NULL,
pal_odbiorca text NULL,
pal_nadawca text NULL,
updated_at datetime NULL,
updated_by bigint(20) unsigned NULL,
PRIMARY KEY  (id),
KEY arkusz_poz (arkusz,poz)
) ENGINE=InnoDB $charset;" );
		dbDelta( 'CREATE TABLE ' . self::TD() . " (
id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
zlec_id bigint(20) unsigned NOT NULL,
poz int(11) NOT NULL DEFAULT 0,
uwagi text NULL,
dostepnosc text NULL,
wersja text NULL,
laser varchar(10) NOT NULL DEFAULT '',
material text NULL,
mat_klienta tinyint(1) NOT NULL DEFAULT 0,
czas_ciecia varchar(190) NOT NULL DEFAULT '',
nazwa_detalu text NULL,
nr_rysunku varchar(255) NOT NULL DEFAULT '',
ilosc_zam int(11) NOT NULL DEFAULT 0,
wykonano int(11) NOT NULL DEFAULT 0,
updated_at datetime NULL,
updated_by bigint(20) unsigned NULL,
PRIMARY KEY  (id),
KEY zlec_poz (zlec_id,poz)
) ENGINE=InnoDB $charset;" );
	}

	/** Jednorazowe wczytanie arkusza 2026 z data/produkcja-2026.json (gdy tabele puste). */
	public static function seed() {
		global $wpdb;
		if ( get_option( 'msm_prod_seeded' ) ) {
			return;
		}
		if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', self::TZ() ) ) !== self::TZ() ) {
			return;
		}
		if ( (int) $wpdb->get_var( 'SELECT COUNT(*) FROM `' . self::TZ() . '`' ) > 0 ) { // phpcs:ignore
			update_option( 'msm_prod_seeded', 1 );
			return;
		}
		$file = MSM_DIR . 'data/produkcja-2026.json';
		$data = is_readable( $file ) ? json_decode( (string) file_get_contents( $file ), true ) : null; // phpcs:ignore
		if ( ! is_array( $data ) || empty( $data['orders'] ) ) {
			return;
		}
		$poz = 0;
		foreach ( $data['orders'] as $o ) {
			self::insert_order( $o, self::SHEET, ++$poz );
		}
		update_option( 'msm_prod_seeded', 1 );
		update_option( 'msm_prod_split', 1 ); // świeży import jest już rozdzielony
		update_option( 'msm_prod_sec', 1 );
	}

	/**
	 * Zapis zlecenia w układzie arkusza Excela (seed i import): pola zlecenia + detale,
	 * „wersja/laser/materiał” rozdzielane, czas cięcia w sekundach (nieczytelny → do Uwag).
	 *
	 * @return int id zlecenia
	 */
	public static function insert_order( array $o, $rok, $poz ) {
		global $wpdb;
		$now = current_time( 'mysql' );
		$row = array( 'arkusz' => (string) $rok, 'poz' => (int) $poz, 'updated_at' => $now, 'updated_by' => get_current_user_id() );
		foreach ( self::Z_FIELDS as $k => $_ ) {
			$row[ $k ] = mb_substr( (string) ( $o[ $k ] ?? '' ), 0, 'long' === $_[0] ? 5000 : 190 );
		}
		$wpdb->insert( self::TZ(), $row );
		$zid = (int) $wpdb->insert_id;
		$dp  = 0;
		foreach ( (array) ( $o['det'] ?? array() ) as $d ) {
			$drow = array( 'zlec_id' => $zid, 'poz' => ++$dp, 'updated_at' => $now );
			$sp = self::split_wlm( (string) ( $d['wersja'] ?? '' ) );
			$d  = array_merge( $d, array( 'wersja' => $sp['wersja'], 'laser' => $sp['laser'], 'material' => $sp['material'], 'mat_klienta' => $sp['klienta'] ) );
			if ( '' !== $sp['extra'] ) {
				$d['uwagi'] = trim( (string) ( $d['uwagi'] ?? '' ) . "\n" . $sp['extra'] );
			}
			$sec = self::parse_sec( $d['czas_ciecia'] ?? '' );
			if ( null === $sec ) {
				$d['uwagi'] = trim( (string) ( $d['uwagi'] ?? '' ) . "\nCzas cięcia: " . $d['czas_ciecia'] );
			}
			$d['czas_ciecia'] = (string) $sec;
			foreach ( self::D_FIELDS as $k => $def ) {
				$drow[ $k ] = in_array( $def[0], array( 'int', 'bool' ), true ) ? (int) ( $d[ $k ] ?? 0 ) : (string) ( $d[ $k ] ?? '' );
			}
			$wpdb->insert( self::TD(), $drow );
		}
		return $zid;
	}

	/**
	 * Czas cięcia w sekundach: „54 s.”, „12,56 sek.”, „70s”, „5min 24 sek” (→ 324), „brak” (→ pusty).
	 * Zwraca liczbę jako tekst z przecinkiem („12,56”), '' dla pustego, null gdy nie da się odczytać.
	 */
	public static function parse_sec( $v ) {
		$v = mb_strtolower( trim( str_replace( "\xc2\xa0", ' ', (string) $v ) ) );
		if ( '' === $v || in_array( $v, array( 'brak', '-', '—', '–' ), true ) ) {
			return '';
		}
		$num = '(\d+(?:[.,]\d+)?)';
		$sfx = '(?:\s*(?:s|sek|sekund[ay]?)\.?)?';
		if ( preg_match( '/^(\d+)\s*min\.?(?:\s*' . $num . $sfx . ')?$/u', $v, $m ) ) {
			$sec = 60 * (int) $m[1] + ( isset( $m[2] ) ? (float) str_replace( ',', '.', $m[2] ) : 0 );
		} elseif ( preg_match( '/^' . $num . $sfx . '$/u', $v, $m ) ) {
			$sec = (float) str_replace( ',', '.', $m[1] );
		} else {
			return null;
		}
		return str_replace( '.', ',', rtrim( rtrim( number_format( $sec, 2, '.', '' ), '0' ), '.' ) );
	}

	/** Jednorazowo: same liczby w „Czas cięcia [s]” (aktualizacja z wersji < 1.67.2). */
	public static function migrate_sec() {
		global $wpdb;
		if ( get_option( 'msm_prod_sec' ) ) {
			return;
		}
		if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', self::TD() ) ) !== self::TD() ) {
			return;
		}
		$rows = (array) $wpdb->get_results( 'SELECT id, czas_ciecia, uwagi FROM `' . self::TD() . "` WHERE czas_ciecia <> ''", ARRAY_A ); // phpcs:ignore
		foreach ( $rows as $r ) {
			$sec = self::parse_sec( $r['czas_ciecia'] );
			$upd = array( 'czas_ciecia' => (string) $sec );
			if ( null === $sec ) { // nieczytelny zapis nie ginie – trafia do Uwag
				$upd['uwagi'] = trim( (string) $r['uwagi'] . "\nCzas cięcia: " . $r['czas_ciecia'] );
			}
			if ( $upd['czas_ciecia'] !== $r['czas_ciecia'] ) {
				$wpdb->update( self::TD(), $upd, array( 'id' => (int) $r['id'] ) );
			}
		}
		update_option( 'msm_prod_sec', 1 );
	}

	/**
	 * Rozdzielenie dawnej kolumny „Zaakceptowana wersja / laser / materiał”.
	 * „V1 L2 M400-50A C5” → wersja V1, laser L2, materiał M400-50A C5.
	 * „klienta” → znacznik materiału klienta; druga wersja (np. V02) → extra (trafia do Uwag).
	 *
	 * @return array{wersja:string,laser:string,material:string,klienta:int,extra:string}
	 */
	public static function split_wlm( $s ) {
		$s   = trim( preg_replace( '/\s+/u', ' ', (string) $s ) );
		$out = array( 'wersja' => '', 'laser' => '', 'material' => '', 'klienta' => 0, 'extra' => '' );
		if ( '' === $s ) {
			return $out;
		}
		if ( preg_match( '/(?<![\p{L}\d])klienta(?![\p{L}\d])/iu', $s ) ) {
			$out['klienta'] = 1;
			$s              = preg_replace( '/(?<![\p{L}\d])klienta(?![\p{L}\d])/iu', ' ', $s );
		}
		$vers = array();
		$s    = preg_replace_callback(
			'/(?<![\p{L}\d\-])[vV](\d{1,2})(\s+mikro)?(?![\p{L}\d])/u',
			function ( $m ) use ( &$vers ) {
				$vers[] = 'V' . $m[1] . ( ! empty( $m[2] ) ? ' mikro' : '' );
				return ' ';
			},
			$s
		);
		if ( $vers ) {
			$out['wersja'] = array_shift( $vers );
			$out['extra']  = implode( ', ', $vers );
		}
		if ( preg_match( '/(?<![\p{L}\d])L([12])(?![\p{L}\d])/u', $s, $m ) ) {
			$out['laser'] = 'L' . $m[1];
			$s            = preg_replace( '/(?<![\p{L}\d])L[12](?![\p{L}\d])/u', ' ', $s );
		}
		$s = trim( preg_replace( '/\s+/u', ' ', $s ), " \t,;/" );
		$s = preg_replace( '/^m(?=\d)/u', 'M', $s ); // „m400-50A” → „M400-50A”
		$out['material'] = $s;
		return $out;
	}

	/** Jednorazowo: rozdziela zapisane już wartości (aktualizacja z wersji < 1.67). */
	public static function migrate_split() {
		global $wpdb;
		if ( get_option( 'msm_prod_split' ) ) {
			return;
		}
		if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', self::TD() ) ) !== self::TD() ) {
			return;
		}
		$rows = (array) $wpdb->get_results( 'SELECT id, wersja, uwagi FROM `' . self::TD() . "` WHERE wersja <> ''", ARRAY_A ); // phpcs:ignore
		foreach ( $rows as $r ) {
			$sp  = self::split_wlm( $r['wersja'] );
			$upd = array( 'wersja' => $sp['wersja'], 'laser' => $sp['laser'], 'material' => $sp['material'], 'mat_klienta' => $sp['klienta'] );
			if ( '' !== $sp['extra'] ) {
				$upd['uwagi'] = trim( (string) $r['uwagi'] . "\n" . $sp['extra'] );
			}
			$wpdb->update( self::TD(), $upd, array( 'id' => (int) $r['id'] ) );
		}
		update_option( 'msm_prod_split', 1 );
	}

	/* ------------------------------------------------------------------ *
	 * REST
	 * ------------------------------------------------------------------ */

	/** Dostęp: zakładka „Produkcja” włączona w uprawnieniach osoby (edytują wszyscy, którzy ją widzą). */
	public static function can() {
		if ( ! current_user_can( 'msm_view' ) ) {
			return new WP_Error( 'msm_forbidden', 'Brak dostępu – zaloguj się.', array( 'status' => is_user_logged_in() ? 403 : 401 ) );
		}
		if ( ! MSM_Perms::is_wp_admin() && ! MSM_Perms::menu_on( 'produkcja' ) ) {
			return new WP_Error( 'msm_forbidden', 'Zakładka Produkcja jest dla Ciebie wyłączona.', array( 'status' => 403 ) );
		}
		return true;
	}

	/**
	 * Operacje niszczące w Produkcji (usuwanie zleceń/detali/palet, import arkuszy) – od 1.84.0
	 * wymagają akcji „Produkcja – usuwanie… oraz import” (domyślnie: administrator magazynu).
	 */
	public static function can_manage() {
		$c = self::can();
		if ( is_wp_error( $c ) ) {
			return $c;
		}
		if ( MSM_Perms::is_wp_admin() || MSM_Perms::user_can( 'produkcja' ) ) {
			return true;
		}
		return new WP_Error( 'msm_forbidden', 'Nie masz uprawnienia do usuwania w Produkcji ani importu. Poproś administratora magazynu.', array( 'status' => 403 ) );
	}

	public static function routes() {
		$ns = MSM_Rest::NS;
		$p  = array( __CLASS__, 'can' );
		$pm = array( __CLASS__, 'can_manage' );
		register_rest_route( $ns, '/prod', array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'sheet_r' ), 'permission_callback' => $p ) );
		register_rest_route( $ns, '/prod/export', array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'export' ), 'permission_callback' => $p ) );
		register_rest_route( $ns, '/prod/cells', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'cells' ), 'permission_callback' => $p ) );
		register_rest_route( $ns, '/prod/order', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'order_add' ), 'permission_callback' => $p ) );
		register_rest_route( $ns, '/prod/order/(?P<id>\d+)/delete', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'order_delete' ), 'permission_callback' => $pm ) );
		register_rest_route( $ns, '/prod/order/(?P<id>\d+)/move', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'order_move' ), 'permission_callback' => $p ) );
		register_rest_route( $ns, '/prod/det', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'det_add' ), 'permission_callback' => $p ) );
		register_rest_route( $ns, '/prod/det/(?P<id>\d+)/magazyn', array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'det_stock' ), 'permission_callback' => $p ) );
		register_rest_route( $ns, '/prod/det/(?P<id>\d+)/delete', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'det_delete' ), 'permission_callback' => $pm ) );
	}

	public static function get_order_public( $id ) {
		return self::get_order( $id );
	}

	public static function to_int_public( $v ) {
		return self::to_int( $v );
	}

	private static function get_order( $id ) {
		global $wpdb;
		$z = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM `' . self::TZ() . '` WHERE id = %d', $id ), ARRAY_A ); // phpcs:ignore
		if ( ! $z ) {
			return null;
		}
		$z['det'] = array_map( array( __CLASS__, 'cast_det' ), (array) $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM `' . self::TD() . '` WHERE zlec_id = %d ORDER BY poz ASC, id ASC', $id ), ARRAY_A ) ); // phpcs:ignore
		$rez      = self::det_reservations( wp_list_pluck( $z['det'], 'id' ) );
		$zap      = class_exists( 'MSM_Zam' ) ? MSM_Zam::for_dets( wp_list_pluck( $z['det'], 'id' ) ) : array();
		foreach ( $z['det'] as &$d ) {
			$d['rez'] = $rez[ $d['id'] ] ?? array();
			$d['zap'] = $zap[ $d['id'] ] ?? array();
		}
		unset( $d );
		return self::cast_order( $z );
	}

	private static function cast_order( array $z ) {
		$out = array( 'id' => (int) $z['id'], 'poz' => (int) $z['poz'] );
		foreach ( self::Z_FIELDS as $k => $_ ) {
			$out[ $k ] = (string) ( $z[ $k ] ?? '' );
		}
		$out['karta'] = MSM_Karta::decode( $z['karta'] ?? '' );
		$out['pal_nadawca']  = (string) ( $z['pal_nadawca'] ?? '' );
		$out['pal_odbiorca'] = (string) ( $z['pal_odbiorca'] ?? '' );
		$out['det']   = $z['det'] ?? array();
		return $out;
	}

	private static function cast_det( array $d ) {
		$out = array( 'id' => (int) $d['id'], 'zlec_id' => (int) $d['zlec_id'] );
		foreach ( self::D_FIELDS as $k => $def ) {
			$out[ $k ] = in_array( $def[0], array( 'int', 'bool' ), true ) ? (int) ( $d[ $k ] ?? 0 ) : (string) ( $d[ $k ] ?? '' );
		}
		return $out;
	}

	/** Pola z prostym edytorem (pogrubienie, listy…). */
	const RICH = array( 'uwagi', 'uwagi_ogolne' );

	/** GET /prod?rok=2027 albo ?zlec=<id> (lista roku, w którym jest to zlecenie). Bez parametrów – bieżący rok. */
	public static function sheet_r( WP_REST_Request $r ) {
		global $wpdb;
		$rok = self::valid_year( $r->get_param( 'rok' ) );
		if ( $r->get_param( 'zlec' ) ) {
			$rok = self::valid_year( $wpdb->get_var( $wpdb->prepare( 'SELECT arkusz FROM `' . self::TZ() . '` WHERE id = %d', (int) $r->get_param( 'zlec' ) ) ) ) ?: $rok; // phpcs:ignore
		}
		$data            = self::data( '' !== $rok ? $rok : self::current_year() );
		$data['lata']    = self::years();
		$data['biezacy'] = self::current_year();
		return rest_ensure_response( $data );
	}

	public static function data( $rok ) {
		global $wpdb;
		$zs  = (array) $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM `' . self::TZ() . '` WHERE arkusz = %s ORDER BY poz ASC, id ASC', (string) $rok ), ARRAY_A ); // phpcs:ignore
		$ids = array_map( 'intval', wp_list_pluck( $zs, 'id' ) );
		$by  = array();
		if ( $ids ) {
			$ds = (array) $wpdb->get_results( 'SELECT * FROM `' . self::TD() . '` WHERE zlec_id IN (' . implode( ',', $ids ) . ') ORDER BY poz ASC, id ASC', ARRAY_A ); // phpcs:ignore
			$rez = self::det_reservations( array_map( 'intval', wp_list_pluck( $ds, 'id' ) ) );
			$zap = class_exists( 'MSM_Zam' ) ? MSM_Zam::for_dets( array_map( 'intval', wp_list_pluck( $ds, 'id' ) ) ) : array();
			foreach ( $ds as $d ) {
				$c        = self::cast_det( $d );
				$c['rez'] = $rez[ $c['id'] ] ?? array();
				$c['zap'] = $zap[ $c['id'] ] ?? array();
				$by[ (int) $d['zlec_id'] ][] = $c;
			}
		}
		// Numery palet zlecenia – do wyszukiwania na liście (np. „P00127”).
		$pal = array();
		if ( $ids && class_exists( 'MSM_Prod_Pal' ) && $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', MSM_Prod_Pal::TP() ) ) === MSM_Prod_Pal::TP() ) {
			foreach ( (array) $wpdb->get_results( 'SELECT zlec_id, rok, nr FROM `' . MSM_Prod_Pal::TP() . '` WHERE zlec_id IN (' . implode( ',', $ids ) . ')', ARRAY_A ) as $p ) { // phpcs:ignore
				$pal[ (int) $p['zlec_id'] ][] = MSM_Prod_Pal::numer( $p['rok'], $p['nr'] );
			}
		}
		$not    = class_exists( 'MSM_Prod_Notes' ) ? MSM_Prod_Notes::summary( $ids ) : array();
		$kz     = class_exists( 'MSM_Karty_Zmian' ) && MSM_Karty_Zmian::can_view() ? MSM_Karty_Zmian::counts( wp_list_pluck( $zs, 'nr_zlec' ) ) : array();
		$pb     = ( MSM_Perms::is_wp_admin() || MSM_Perms::menu_on( 'zlecenie' ) ) ? self::pobrania_n( wp_list_pluck( $zs, 'nr_zlec' ) ) : array();
		$pal    = array(); // liczba paletówek na zlecenie (licznik na zakładce „Paletówki projektu”)
		if ( class_exists( 'MSM_Prod_Pal' ) && $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', MSM_Prod_Pal::TP() ) ) === MSM_Prod_Pal::TP() ) {
			foreach ( (array) $wpdb->get_results( 'SELECT zlec_id, COUNT(*) n FROM `' . MSM_Prod_Pal::TP() . '` GROUP BY zlec_id', ARRAY_A ) as $r ) { // phpcs:ignore
				$pal[ (int) $r['zlec_id'] ] = (int) $r['n'];
			}
		}
		$orders = array();
		foreach ( $zs as $z ) {
			$z['det']       = $by[ (int) $z['id'] ] ?? array();
			$o              = self::cast_order( $z );
			$o['palety_nr'] = $pal[ (int) $z['id'] ] ?? array();
			$o['notatki_n'] = $not[ (int) $z['id'] ][0] ?? 0;
			$o['notatki_t'] = trim( $not[ (int) $z['id'] ][1] ?? '' ); // tylko do wyszukiwania
			$o['pobrania_n'] = $pb[ strtoupper( trim( (string) ( $z['nr_zlec'] ?? '' ) ) ) ] ?? 0;
			$o['palety_n']  = $pal[ (int) $z['id'] ] ?? 0;
			$o['karty_n']   = $kz[ strtoupper( trim( (string) ( $z['nr_zlec'] ?? '' ) ) ) ] ?? 0;
			$orders[]      = $o;
		}
		return array( 'sheet' => (string) $rok, 'orders' => $orders );
	}

	/* ------------------------------------------------------------------ *
	 * Materiał na magazynie dla pozycji zlecenia
	 * ------------------------------------------------------------------ */

	/** Rezerwacje powiązane z pozycjami: [det_id => [ {id, status, ilosc, jedn, material, table} ]]. */
	public static function det_reservations( array $ids ) {
		global $wpdb;
		$ids = array_values( array_filter( array_map( 'intval', $ids ) ) );
		if ( ! $ids || ! class_exists( 'MSM_Rezerwacje' ) ) {
			return array();
		}
		$T = MSM_Rezerwacje::T();
		$rows = (array) $wpdb->get_results( "SELECT id, prod_det_id, item_table, item_id, material, ilosc, tryb, status FROM `$T` WHERE prod_det_id IN (" . implode( ',', $ids ) . ") AND status IN ('nowa','aktywna','wydana') ORDER BY id", ARRAY_A ); // phpcs:ignore
		$out  = array();
		foreach ( $rows as $r ) {
			$out[ (int) $r['prod_det_id'] ][] = array(
				'id'       => (int) $r['id'],
				'status'   => $r['status'],
				'ilosc'    => (float) $r['ilosc'],
				'jedn'     => 'kg' === $r['tryb'] ? 'kg' : ( 'odcinek' === $r['tryb'] ? 'm' : 'szt' ),
				'material' => $r['material'],
				'table'    => $r['item_table'],
			);
		}
		return $out;
	}

	/**
	 * Rozbiór opisu materiału z pozycji: gatunki (np. „M250-50A”, „DC01/S235JR”), grubość w mm, izolacja (C5).
	 * Blacha elektrotechniczna M250-50 → grubość 0,50 mm z nazwy gatunku.
	 */
	public static function parse_material( $mat ) {
		$mat = trim( preg_replace( '/\s+/u', ' ', (string) $mat ) );
		$out = array( 'grades' => array(), 'grubosc' => null, 'izolacja' => '' );
		if ( '' === $mat ) {
			return $out;
		}
		if ( preg_match( '/\d\s*-\s*\d+(?:[.,]\d+)?\s*mm\b/iu', $mat ) ) {
			$out['grubosc'] = null; // zakres („4-6 mm”) – bez filtra grubości
		} elseif ( preg_match( '/(\d+(?:[.,]\d+)?)\s*mm\b/iu', $mat, $m ) ) {
			$out['grubosc'] = (float) str_replace( ',', '.', $m[1] );
		} elseif ( preg_match( '/(?<![\d.,])(\d+(?:[.,]\d+)?)\s*x\s*\d+/iu', $mat, $m ) ) {
			$out['grubosc'] = (float) str_replace( ',', '.', $m[1] ); // „10 x 500 x 500” – pierwszy wymiar to grubość
		}
		if ( preg_match( '/\b(C\d|I\d)\b/u', $mat, $m ) ) {
			$out['izolacja'] = strtoupper( $m[1] );
		}
		$first = preg_split( '/\s+/u', $mat )[0];
		foreach ( explode( '/', $first ) as $g ) {
			$g = trim( $g );
			if ( '' !== $g && ! preg_match( '/^\d+(?:[.,]\d+)?(mm)?$/i', $g ) ) {
				$out['grades'][] = $g;
			}
		}
		if ( null === $out['grubosc'] && $out['grades'] && preg_match( '/^M\d{3}-(\d{2,3})/i', $out['grades'][0], $m ) ) {
			$out['grubosc'] = (int) $m[1] / 100;
		}
		return $out;
	}

	private static function norm_grade( $g ) {
		return preg_replace( '/[^A-Z0-9]/', '', strtoupper( (string) $g ) );
	}

	/** Czy gatunek z magazynu pasuje do gatunku z pozycji (M250-50 ≈ M250-50A, S235 ≈ S235JR). */
	public static function grade_match( $stock, $want ) {
		$a = self::norm_grade( $stock );
		$b = self::norm_grade( $want );
		if ( '' === $a || '' === $b ) {
			return 0;
		}
		if ( $a === $b ) {
			return 2;
		}
		return ( 0 === strpos( $a, $b ) || 0 === strpos( $b, $a ) ) && min( strlen( $a ), strlen( $b ) ) >= 4 ? 1 : 0;
	}

	/** GET /prod/det/{id}/magazyn – pasujące blachy pełne, niepełne i kręgi (z dostępnością po rezerwacjach). */
	public static function det_stock( WP_REST_Request $r ) {
		global $wpdb;
		$d = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM `' . self::TD() . '` WHERE id = %d', (int) $r['id'] ), ARRAY_A ); // phpcs:ignore
		if ( ! $d ) {
			return new WP_Error( 'msm_404', 'Nie ma takiej pozycji.', array( 'status' => 404 ) );
		}
		$q    = (string) ( $r->get_param( 'q' ) ?? '' );
		$want = self::parse_material( '' !== trim( $q ) ? $q : (string) $d['material'] );
		$out  = array();
		if ( $want['grades'] ) {
			foreach ( array( 'blachy_pelne' => 'gatunek', 'blachy_niepelne' => 'gatunek', 'kregi' => 'oznaczenie' ) as $t => $gcol ) {
				$T = msm_table( $t );
				if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $T ) ) !== $T ) {
					continue;
				}
				$rows = (array) $wpdb->get_results( "SELECT * FROM `$T` WHERE ilosc > 0", ARRAY_A ); // phpcs:ignore
				$hit  = array();
				foreach ( $rows as $row ) {
					$g = 0;
					foreach ( $want['grades'] as $wg ) {
						$g = max( $g, self::grade_match( $row[ $gcol ] ?? '', $wg ) );
					}
					if ( ! $g ) {
						continue;
					}
					$gr = isset( $row['grubosc'] ) && '' !== $row['grubosc'] && null !== $row['grubosc'] ? (float) $row['grubosc'] : null;
					if ( null !== $want['grubosc'] && null !== $gr && abs( $gr - $want['grubosc'] ) > 0.001 ) {
						continue;
					}
					$score = $g * 10 + ( null !== $want['grubosc'] && null !== $gr ? 5 : 0 );
					if ( 'kregi' === $t && $want['izolacja'] && 0 === strcasecmp( trim( (string) $row['izolacja'] ), $want['izolacja'] ) ) {
						$score += 3;
					}
					$hit[] = array( $score, $row );
				}
				if ( ! $hit ) {
					continue;
				}
				$res = class_exists( 'MSM_Rezerwacje' ) ? MSM_Rezerwacje::reserved_map( array_map( function ( $h ) { return (int) $h[1]['id']; }, $hit ), $t ) : array();
				$kg  = 'kg' === msm_unit( $t );
				foreach ( $hit as $h ) {
					list( $score, $row ) = $h;
					$stan  = $kg ? (float) $row['ilosc'] : (int) $row['ilosc'];
					$zarez = $res[ (int) $row['id'] ] ?? 0;
					$out[] = array(
						'table'     => $t,
						'tlabel'    => msm_schema()[ $t ]['label'],
						'id'        => (int) $row['id'],
						'opis'      => MSM_Calc::describe( $t, $row ),
						'uwagi'     => (string) ( $row['uwagi'] ?? '' ),
						'stan'      => $stan,
						'zarez'     => $zarez,
						'dostepne'  => max( 0, $stan - $zarez ),
						'jedn'      => $kg ? 'kg' : 'szt',
						'score'     => $score,
						'row'       => MSM_Repo::cast_row( $t, $row ),
					);
				}
			}
		}
		usort( $out, function ( $a, $b ) { return $b['score'] <=> $a['score'] ?: $b['dostepne'] <=> $a['dostepne']; } );
		$nr = (string) $wpdb->get_var( $wpdb->prepare( 'SELECT nr_zlec FROM `' . self::TZ() . '` WHERE id = %d', (int) $d['zlec_id'] ) ); // phpcs:ignore
		return rest_ensure_response( array(
			'material' => (string) $d['material'],
			'szukane'  => $want,
			'zlecenie' => $nr,
			'wyniki'   => array_slice( $out, 0, 40 ),
			'rez'      => self::det_reservations( array( (int) $d['id'] ) )[ (int) $d['id'] ] ?? array(),
			'can_edit' => current_user_can( 'msm_edit' ),
		) );
	}

	/** Liczba całkowita z tekstu („1 984”, „1984,0”); pusty = 0; błąd = null. */
	private static function to_int( $v ) {
		$v = trim( str_replace( array( ' ', "\xc2\xa0" ), '', (string) $v ) );
		if ( '' === $v ) {
			return 0;
		}
		$v = str_replace( ',', '.', $v );
		return is_numeric( $v ) ? (int) round( (float) $v ) : null;
	}

	/**
	 * Zapis komórek (pojedyncza edycja albo wklejony blok).
	 * changes: [{k:'z'|'d', id, f, v}]. Zwraca zaktualizowane wiersze.
	 */
	public static function cells( WP_REST_Request $r ) {
		global $wpdb;
		$changes = array_slice( (array) ( $r->get_json_params()['changes'] ?? array() ), 0, 2000 );
		if ( ! $changes ) {
			return new WP_Error( 'msm_400', 'Brak zmian.', array( 'status' => 400 ) );
		}
		$now  = current_time( 'mysql' );
		$uid  = get_current_user_id();
		$outZ = array();
		$outD = array();
		$logs = array();
		foreach ( $changes as $c ) {
			$kind = ( $c['k'] ?? '' ) === 'z' ? 'z' : 'd';
			$id   = (int) ( $c['id'] ?? 0 );
			$f    = (string) ( $c['f'] ?? '' );
			$defs = 'z' === $kind ? self::Z_FIELDS : self::D_FIELDS;
			if ( ! $id || ! isset( $defs[ $f ] ) ) {
				continue;
			}
			$T   = 'z' === $kind ? self::TZ() : self::TD();
			$old = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `$T` WHERE id = %d", $id ), ARRAY_A ); // phpcs:ignore
			if ( ! $old ) {
				continue;
			}
			if ( 'int' === $defs[ $f ][0] ) {
				$val = self::to_int( $c['v'] ?? '' );
				if ( null === $val ) {
					return new WP_Error( 'msm_400', '„' . $defs[ $f ][1] . '” musi być liczbą (wpisano: ' . mb_substr( (string) $c['v'], 0, 30 ) . ').', array( 'status' => 400 ) );
				}
			} elseif ( 'bool' === $defs[ $f ][0] ) {
				$val = preg_match( '/^(1|tak|t|x|true|yes|y|✓)$/iu', trim( (string) ( $c['v'] ?? '' ) ) ) ? 1 : 0;
			} elseif ( 'sec' === $defs[ $f ][0] ) {
				$val = self::parse_sec( $c['v'] ?? '' );
				if ( null === $val ) {
					return new WP_Error( 'msm_400', '„Czas cięcia [s]” musi być liczbą sekund, np. 54 albo 12,5 (wpisano: ' . mb_substr( (string) $c['v'], 0, 30 ) . ').', array( 'status' => 400 ) );
				}
			} elseif ( 'laser' === $defs[ $f ][0] ) {
				$val = strtoupper( trim( (string) ( $c['v'] ?? '' ) ) );
				if ( ! in_array( $val, array( '', 'L1', 'L2' ), true ) ) {
					return new WP_Error( 'msm_400', '„Laser” może mieć tylko wartość L1 albo L2 (wpisano: ' . mb_substr( (string) $c['v'], 0, 30 ) . ').', array( 'status' => 400 ) );
				}
			} else {
				$val = str_replace( "\r\n", "\n", (string) ( $c['v'] ?? '' ) );
				$val = wp_check_invalid_utf8( $val );
				$val = mb_substr( $val, 0, 'z' === $kind && 'long' !== $defs[ $f ][0] ? 190 : 5000 ); // tekst 1:1 (np. „<5 mm”) – wyświetlanie zawsze escapowane
				if ( in_array( $f, self::RICH, true ) ) {
					$val = MSM_Rich::clean( $val ); // pola z edytorem: tylko b/i/u/listy
				}
			}
			if ( 'z' === $kind ) {
				$outZ[ $id ] = true;
			} else {
				$outD[ $id ] = true;
			}
			// Nowe zlecenia: w „Dostępności przyrządów” numery przyrządów dopisują się same (PO 29.93 → PO12 29.93).
			if ( 'd' === $kind && 'dostepnosc' === $f && class_exists( 'MSM_Prod_Narz' ) && MSM_Prod_Narz::is_new_order( (int) $old['zlec_id'] ) ) {
				$nrz = (string) $wpdb->get_var( $wpdb->prepare( 'SELECT nr_zlec FROM `' . self::TZ() . '` WHERE id = %d', (int) $old['zlec_id'] ) ); // phpcs:ignore
				$val = MSM_Prod_Narz::fill_numbers( $val, $nrz );
			}
			if ( (string) $old[ $f ] === (string) $val ) {
				continue;
			}
			$wpdb->update( $T, array( $f => $val, 'updated_at' => $now, 'updated_by' => $uid ), array( 'id' => $id ) );
			$logs[] = array( $kind, $id, $old, $f, $val, $defs[ $f ][1] );
		}
		self::log_changes( $logs );
		$resZ = array();
		foreach ( array_keys( $outZ ) as $id ) {
			$z = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM `' . self::TZ() . '` WHERE id = %d', $id ), ARRAY_A ); // phpcs:ignore
			if ( $z ) {
				$resZ[] = self::cast_order( $z );
			}
		}
		$resD = array();
		foreach ( array_keys( $outD ) as $id ) {
			$d = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM `' . self::TD() . '` WHERE id = %d', $id ), ARRAY_A ); // phpcs:ignore
			if ( $d ) {
				$resD[] = self::cast_det( $d );
			}
		}
		return rest_ensure_response( array( 'z' => $resZ, 'd' => $resD, 'changed' => count( $logs ) ) );
	}

	/** Opis wiersza do historii: „B02335 · stojan”. */
	private static function label( $kind, array $row ) {
		global $wpdb;
		if ( 'z' === $kind ) {
			return 'Zlecenie ' . ( '' !== $row['nr_zlec'] ? $row['nr_zlec'] : '#' . $row['id'] );
		}
		$nr = (string) $wpdb->get_var( $wpdb->prepare( 'SELECT nr_zlec FROM `' . self::TZ() . '` WHERE id = %d', $row['zlec_id'] ) ); // phpcs:ignore
		$nm = trim( preg_replace( '/\s+/', ' ', (string) $row['nazwa_detalu'] ) );
		return 'Zlecenie ' . ( '' !== $nr ? $nr : '#' . $row['zlec_id'] ) . ( '' !== $nm ? ' · ' . mb_substr( $nm, 0, 60 ) : ' · detal #' . $row['id'] );
	}

	private static function log_changes( array $logs ) {
		if ( ! $logs ) {
			return;
		}
		$short = function ( $v ) {
			$v = trim( preg_replace( '/\s+/', ' ', (string) $v ) );
			return '' === $v ? '(puste)' : ( mb_strlen( $v ) > 60 ? mb_substr( $v, 0, 57 ) . '…' : $v );
		};
		// Wklejony duży blok: jeden zbiorczy wpis zamiast setek.
		if ( count( $logs ) > 20 ) {
			MSM_Repo::log( 'Produkcja: wklejenie', 'produkcja', 0, 'Wklejono / zmieniono ' . count( $logs ) . ' komórek w Produkcji' );
			return;
		}
		foreach ( $logs as $l ) {
			list( $kind, $id, $old, $f, $val, $lbl ) = $l;
			MSM_Repo::log( 'Produkcja: edycja', 'produkcja', $id, self::label( $kind, $old ) . ' – ' . $lbl . ': ' . $short( $old[ $f ] ) . ' → ' . $short( $val ), array( 'przed' => array( $f => $old[ $f ] ), 'po' => array( $f => $val ) ) );
		}
	}

	/** Nowe zlecenie na końcu arkusza (z jednym pustym detalem). */
	public static function order_add( WP_REST_Request $r ) {
		global $wpdb;
		$now = current_time( 'mysql' );
		$rok = self::valid_year( $r->get_json_params()['rok'] ?? '' ) ?: self::current_year();
		$poz = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT MAX(poz) FROM `' . self::TZ() . '` WHERE arkusz = %s', $rok ) ) + 1; // phpcs:ignore
		$p   = (array) $r->get_json_params();
		$src = isset( $p['karta'] ) && is_array( $p['karta'] ) ? $p['karta'] : null; // { z, karta, det } z odczytu karty projektu
		$row = array( 'arkusz' => $rok, 'poz' => $poz, 'nr_zlec' => sanitize_text_field( (string) ( $p['nr_zlec'] ?? '' ) ), 'updated_at' => $now, 'updated_by' => get_current_user_id() );
		if ( $src ) {
			$zf = isset( $src['z'] ) && is_array( $src['z'] ) ? $src['z'] : array();
			foreach ( self::Z_FIELDS as $k => $def ) {
				if ( isset( $zf[ $k ] ) && is_scalar( $zf[ $k ] ) ) {
					$row[ $k ] = mb_substr( trim( wp_check_invalid_utf8( (string) $zf[ $k ] ) ), 0, 'long' === $def[0] ? 5000 : 190 );
					if ( in_array( $k, self::RICH, true ) ) {
						$row[ $k ] = MSM_Rich::clean( $row[ $k ] );
					}
				}
			}
			$row['karta'] = MSM_Karta::encode( isset( $src['karta'] ) && is_array( $src['karta'] ) ? $src['karta'] : array() );
		}
		$nr = $row['nr_zlec'];
		$wpdb->insert( self::TZ(), $row );
		$zid = (int) $wpdb->insert_id;
		if ( ! $zid ) {
			return new WP_Error( 'msm_db', 'Nie udało się dodać zlecenia.', array( 'status' => 500 ) );
		}
		$dets = $src && ! empty( $src['det'] ) && is_array( $src['det'] ) ? array_slice( array_values( $src['det'] ), 0, 200 ) : array( array() );
		foreach ( $dets as $i => $d ) {
			$d    = is_array( $d ) ? $d : array();
			$drow = array( 'zlec_id' => $zid, 'poz' => $i + 1, 'updated_at' => $now, 'updated_by' => get_current_user_id() );
			foreach ( array( 'nazwa_detalu', 'nr_rysunku', 'material' ) as $k ) {
				if ( isset( $d[ $k ] ) && is_scalar( $d[ $k ] ) ) {
					$drow[ $k ] = mb_substr( trim( wp_check_invalid_utf8( (string) $d[ $k ] ) ), 0, 'nr_rysunku' === $k ? 255 : 5000 );
				}
			}
			if ( isset( $d['ilosc_zam'] ) ) {
				$drow['ilosc_zam'] = max( 0, (int) self::to_int( $d['ilosc_zam'] ) );
			}
			if ( isset( $d['mat_klienta'] ) ) {
				$drow['mat_klienta'] = $d['mat_klienta'] ? 1 : 0;
			}
			$wpdb->insert( self::TD(), $drow );
		}
		MSM_Repo::log( 'Produkcja: nowe zlecenie', 'produkcja', $zid, 'Dodano zlecenie' . ( $nr ? ' ' . $nr : '' ) . ( $src ? ' z karty projektu (' . count( $dets ) . ' poz.)' : '' ) . ' na liście ' . $rok );
		return rest_ensure_response( array( 'order' => self::get_order( $zid ) ) );
	}

	public static function order_delete( WP_REST_Request $r ) {
		global $wpdb;
		$o = self::get_order( (int) $r['id'] );
		if ( ! $o ) {
			return new WP_Error( 'msm_404', 'Zlecenie nie istnieje.', array( 'status' => 404 ) );
		}
		$pal = class_exists( 'MSM_Prod_Pal' ) ? MSM_Prod_Pal::delete_for_order( (int) $o['id'] ) : array(); // palety zlecenia znikają razem z nim, numery wracają do puli
		if ( class_exists( 'MSM_Prod_Notes' ) ) {
			MSM_Prod_Notes::delete_for_order( (int) $o['id'] );
		}
		if ( class_exists( 'MSM_Przesylki' ) ) {
			MSM_Przesylki::unlink_order( (int) $o['id'] ); // przesyłki zostają w rejestrze, z numerem zlecenia jako tekst
		}
		$wpdb->delete( self::TD(), array( 'zlec_id' => $o['id'] ) );
		$wpdb->delete( self::TZ(), array( 'id' => $o['id'] ) );
		MSM_Repo::log( 'Produkcja: usunięcie zlecenia', 'produkcja', $o['id'], 'Usunięto zlecenie ' . ( $o['nr_zlec'] ? $o['nr_zlec'] : '#' . $o['id'] ) . ' (' . count( $o['det'] ) . ' det.' . ( $pal ? ', palety ' . implode( ', ', $pal ) : '' ) . ')', array( 'przed' => $o ) );
		return rest_ensure_response( array( 'deleted' => $o['id'] ) );
	}

	/** Przesunięcie zlecenia o jedno miejsce w górę (-1) lub w dół (+1). */
	public static function order_move( WP_REST_Request $r ) {
		global $wpdb;
		$id  = (int) $r['id'];
		$dir = (int) ( $r->get_json_params()['dir'] ?? 0 ) < 0 ? -1 : 1;
		$ark = (string) $wpdb->get_var( $wpdb->prepare( 'SELECT arkusz FROM `' . self::TZ() . '` WHERE id = %d', $id ) ); // phpcs:ignore
		$ids = array_map( 'intval', (array) $wpdb->get_col( $wpdb->prepare( 'SELECT id FROM `' . self::TZ() . '` WHERE arkusz = %s ORDER BY poz ASC, id ASC', $ark ) ) ); // phpcs:ignore
		$i   = array_search( $id, $ids, true );
		if ( false === $i ) {
			return new WP_Error( 'msm_404', 'Zlecenie nie istnieje.', array( 'status' => 404 ) );
		}
		$j = $i + $dir;
		if ( $j < 0 || $j >= count( $ids ) ) {
			return rest_ensure_response( array( 'moved' => false ) );
		}
		$tmp       = $ids[ $i ];
		$ids[ $i ] = $ids[ $j ];
		$ids[ $j ] = $tmp;
		foreach ( $ids as $n => $oid ) {
			$wpdb->update( self::TZ(), array( 'poz' => $n + 1 ), array( 'id' => $oid ) );
		}
		return rest_ensure_response( array( 'moved' => true, 'order' => $ids ) );
	}

	/** Nowy detal w zleceniu – pod wskazanym detalem (albo na końcu zlecenia). */
	public static function det_add( WP_REST_Request $r ) {
		global $wpdb;
		$p     = (array) $r->get_json_params();
		$zid   = (int) ( $p['zlec_id'] ?? 0 );
		$after = (int) ( $p['after_id'] ?? 0 );
		if ( ! self::get_order( $zid ) ) {
			return new WP_Error( 'msm_404', 'Zlecenie nie istnieje.', array( 'status' => 404 ) );
		}
		$ids = array_map( 'intval', (array) $wpdb->get_col( $wpdb->prepare( 'SELECT id FROM `' . self::TD() . '` WHERE zlec_id = %d ORDER BY poz ASC, id ASC', $zid ) ) ); // phpcs:ignore
		$wpdb->insert( self::TD(), array( 'zlec_id' => $zid, 'poz' => 0, 'updated_at' => current_time( 'mysql' ), 'updated_by' => get_current_user_id() ) );
		$new = (int) $wpdb->insert_id;
		$at  = array_search( $after, $ids, true );
		array_splice( $ids, false === $at ? count( $ids ) : $at + 1, 0, array( $new ) );
		foreach ( $ids as $n => $did ) {
			$wpdb->update( self::TD(), array( 'poz' => $n + 1 ), array( 'id' => $did ) );
		}
		MSM_Repo::log( 'Produkcja: nowy detal', 'produkcja', $new, self::label( 'z', self::get_order( $zid ) ) . ' – dodano detal' );
		return rest_ensure_response( array( 'order' => self::get_order( $zid ), 'id' => $new ) );
	}

	public static function det_delete( WP_REST_Request $r ) {
		global $wpdb;
		$d = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM `' . self::TD() . '` WHERE id = %d', (int) $r['id'] ), ARRAY_A ); // phpcs:ignore
		if ( ! $d ) {
			return new WP_Error( 'msm_404', 'Detal nie istnieje.', array( 'status' => 404 ) );
		}
		$left = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM `' . self::TD() . '` WHERE zlec_id = %d', $d['zlec_id'] ) ); // phpcs:ignore
		if ( $left <= 1 ) {
			return new WP_Error( 'msm_400', 'To jedyny detal zlecenia – usuń całe zlecenie.', array( 'status' => 400 ) );
		}
		$wpdb->delete( self::TD(), array( 'id' => $d['id'] ) );
		MSM_Repo::log( 'Produkcja: usunięcie detalu', 'produkcja', (int) $d['id'], self::label( 'd', $d ) . ' – usunięto detal', array( 'przed' => self::cast_det( $d ) ) );
		return rest_ensure_response( array( 'order' => self::get_order( (int) $d['zlec_id'] ) ) );
	}

	/** Eksport arkusza do Excela / CSV (kolumny A–O, kolejność jak w arkuszu). */
	public static function export( WP_REST_Request $r ) {
		$rok    = self::valid_year( $r->get_param( 'rok' ) ) ?: self::current_year();
		$rows   = self::export_rows( $rok );
		$format = 'csv' === $r->get_param( 'format' ) ? 'csv' : 'xlsx';
		$fname  = 'produkcja-' . $rok . '-' . current_time( 'Y-m-d' ) . '.' . $format;
		nocache_headers();
		if ( 'csv' === $format ) {
			header( 'Content-Type: text/csv; charset=UTF-8' );
			header( 'Content-Disposition: attachment; filename="' . $fname . '"' );
			$out = fopen( 'php://output', 'w' ); // phpcs:ignore
			fwrite( $out, "\xEF\xBB\xBF" ); // phpcs:ignore
			foreach ( $rows as $line ) {
				fputcsv( $out, array_map( function ( $v ) { return is_float( $v ) ? str_replace( '.', ',', (string) $v ) : msm_csv_safe( $v ); }, $line ), ';', '"', '\\' );
			}
			fclose( $out ); // phpcs:ignore
			exit;
		}
		if ( ! function_exists( 'wp_tempnam' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		$tmp = wp_tempnam( 'msm-prod' );
		if ( ! MSM_Xlsx::write( $tmp, 'Produkcja ' . $rok, $rows, array( 18, 12, 12, 14, 40, 34, 10, 26, 22, 30, 34, 10, 10, 9, 10 ) ) ) {
			return new WP_Error( 'msm_500', 'Nie udało się utworzyć pliku.', array( 'status' => 500 ) );
		}
		header( 'Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' );
		header( 'Content-Disposition: attachment; filename="' . $fname . '"' );
		header( 'Content-Length: ' . filesize( $tmp ) );
		readfile( $tmp ); // phpcs:ignore
		@unlink( $tmp ); // phpcs:ignore
		exit;
	}

	/** Arkusz do kopii zapasowej (wiersze płaskie, kolumny A–O). */
	/** Wiersze eksportu: jeden rok albo (null) wszystkie lata – z kolumną „Rok” na końcu. */
	public static function export_rows( $rok = null ) {
		$lata = null === $rok ? array_reverse( self::years() ) : array( (string) $rok );
		$data = array( 'orders' => array() );
		foreach ( $lata as $y ) {
			foreach ( self::data( $y )['orders'] as $o ) {
				$o['_rok']        = $y;
				$data['orders'][] = $o;
			}
		}
		$rows = array( array( 'Uwagi', 'Nr zlec.', 'Start zlec.', 'Zakończenie zlec.', 'Dostępność przyrządów/sprawdzianów', 'Wersja', 'Laser', 'Materiał', 'Materiał klienta', 'Czas cięcia [s]', 'Nazwa klienta', 'Nr zlec. klienta', 'Nazwa detali', 'Nr rysunku', 'Ilość zam.', 'Wykon.', '% wykon.', 'Zostało', 'Uwagi ogólne zlecenia', 'Paletówki – nadawca', 'Paletówki – odbiorca', 'Rok' ) );
		foreach ( $data['orders'] as $o ) {
			foreach ( $o['det'] as $i => $d ) {
				$first  = 0 === $i;
				$rows[] = array(
					MSM_Rich::text( $d['uwagi'] ), $first ? $o['nr_zlec'] : '', $first ? $o['start_zlec'] : '', $first ? $o['koniec_zlec'] : '',
					$d['dostepnosc'], $d['wersja'], $d['laser'], $d['material'], $d['mat_klienta'] ? 'tak' : '', $d['czas_ciecia'], $first ? $o['klient'] : '', $first ? $o['nr_zlec_klienta'] : '',
					$d['nazwa_detalu'], $d['nr_rysunku'], $d['ilosc_zam'], $d['wykonano'],
					$d['ilosc_zam'] > 0 ? round( 100 * $d['wykonano'] / $d['ilosc_zam'], 1 ) : 0, $d['ilosc_zam'] - $d['wykonano'],
					$first ? MSM_Rich::text( $o['uwagi_ogolne'] ) : '',
					$first ? MSM_Rich::text( $o['pal_nadawca'] ?? '' ) : '',
					$first ? MSM_Rich::text( $o['pal_odbiorca'] ?? '' ) : '',
					$o['_rok'],
				);
			}
		}
		return $rows;
	}

	/**
	 * Liczba pobrań materiału na numer zlecenia – jak Karta zlecenia (numer zawarty w polu „zlecenie” pobrania).
	 *
	 * @param string[] $nrs Numery zleceń.
	 * @return array<string,int>
	 */
	public static function pobrania_n( array $nrs ) {
		global $wpdb;
		$P    = msm_table( 'pobrania' );
		$rows = (array) $wpdb->get_results( "SELECT UPPER(zlecenie) z, COUNT(*) n FROM `$P` WHERE zlecenie IS NOT NULL AND zlecenie <> '' GROUP BY UPPER(zlecenie)", ARRAY_A ); // phpcs:ignore
		$out  = array();
		foreach ( $nrs as $nr ) {
			$nr = strtoupper( trim( (string) $nr ) );
			if ( '' === $nr || isset( $out[ $nr ] ) ) {
				continue;
			}
			$n = 0;
			foreach ( $rows as $r ) {
				if ( false !== strpos( (string) $r['z'], $nr ) ) {
					$n += (int) $r['n'];
				}
			}
			if ( $n ) {
				$out[ $nr ] = $n;
			}
		}
		return $out;
	}
}
