<?php
/**
 * Kopia danych do Excela (nocna i ręczna): wszystkie tabele systemu, Produkcja z kartami projektów,
 * użytkownicy z uprawnieniami i ustawienia. E-mail + kopia na serwerze.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MSM_Backup {

	const CRON   = 'msm_backup_event';

	public static function init() {
		add_action( self::CRON, array( __CLASS__, 'run_scheduled' ) );
		add_action( 'init', array( __CLASS__, 'ensure_scheduled' ) );
		add_action( 'template_redirect', array( __CLASS__, 'maybe_download' ) );
	}

	public static function schedule() {
		if ( ! wp_next_scheduled( self::CRON ) ) {
			// Najbliższa 2:00 czasu lokalnego.
			$now  = current_time( 'timestamp' );
			$next = strtotime( '02:00', $now );
			if ( $next <= $now ) {
				$next += DAY_IN_SECONDS;
			}
			$gmt = $next - ( (int) ( current_time( 'timestamp' ) - time() ) );
			wp_schedule_event( $gmt, 'daily', self::CRON );
		}
	}
	/** Harmonogram mógł zniknąć (np. czyszczenie zadań WP-Cron) – przywracamy go, gdy kopia jest włączona. */
	public static function ensure_scheduled() {
		if ( get_option( 'msm_backup_enabled', 1 ) && ! wp_next_scheduled( self::CRON ) ) {
			self::schedule();
		}
	}

	/** Kopia z harmonogramu – tylko gdy „Automatyczna kopia co noc” jest włączona. */
	public static function run_scheduled() {
		if ( ! get_option( 'msm_backup_enabled', 1 ) ) {
			return;
		}
		$res = self::run();
		if ( is_wp_error( $res ) ) {
			update_option( 'msm_backup_error', $res->get_error_message() );
		}
	}

	public static function unschedule() {
		wp_clear_scheduled_hook( self::CRON );
	}

	/* ---------- ustawienia ---------- */
	public static function settings() {
		return array(
			'enabled'      => (bool) get_option( 'msm_backup_enabled', 1 ),
			'email'        => (string) get_option( 'msm_backup_email', get_option( 'admin_email' ) ),
			'emails_extra' => (string) get_option( 'msm_backup_emails', '' ),
			'keep'         => (int) get_option( 'msm_backup_keep', 30 ),
			'last'         => (int) get_option( 'msm_backup_last', 0 ),
			'next'         => (int) wp_next_scheduled( self::CRON ),
			'error'        => (string) get_option( 'msm_backup_error', '' ),
			'sheets'       => array_values( array_merge( array_values( array_diff( self::SHEETS, array( 'Produkcja (stara tabela)' ) ) ), array( 'Produkcja (wszystkie lata)', 'Karty projektów', 'Użytkownicy i uprawnienia', 'Ustawienia systemu' ) ) ),
			'files'        => self::files(),
		);
	}
	public static function save_settings( array $in ) {
		$before = self::recipients();
		$was    = array(
			'enabled' => (bool) get_option( 'msm_backup_enabled', 1 ),
			'keep'    => (int) get_option( 'msm_backup_keep', 30 ),
		);
		$res = self::apply_settings( $in );
		$after = self::recipients();
		$now   = array( 'enabled' => (bool) get_option( 'msm_backup_enabled', 1 ), 'keep' => (int) get_option( 'msm_backup_keep', 30 ) );
		if ( $before !== $after || $was !== $now ) {
			MSM_Repo::log( 'Kopia danych: ustawienia', 'kopia', 0, 'Zmieniono ustawienia kopii danych' . ( $before !== $after ? ' – odbiorcy: ' . ( $after ? implode( ', ', $after ) : 'brak' ) : '' ),
				array( 'przed' => array( 'odbiorcy' => implode( ', ', $before ) ) + $was, 'po' => array( 'odbiorcy' => implode( ', ', $after ) ) + $now ) );
		}
		// Nowi odbiorcy pełnej kopii: powiadamiamy dotychczasowych (ochrona przed cichym przekierowaniem kopii na obcy adres).
		$added = array_values( array_diff( $after, $before ) );
		$notify = $before; // wszyscy dotychczasowi odbiorcy, także usunięci z listy
		if ( $added && $notify ) {
			$who = wp_get_current_user();
			wp_mail( $notify, '[K-ERP] Zmiana odbiorców kopii danych',
				'Użytkownik ' . $who->display_name . ' (' . $who->user_login . ') dodał odbiorców pełnej kopii danych magazynu: ' . implode( ', ', $added ) . ".\n"
				. 'Aktualna lista odbiorców: ' . implode( ', ', $after ) . ".\n\n"
				. 'Jeśli to nieoczekiwana zmiana, sprawdź ustawienia w aplikacji: ' . MSM_Access::app_url() . '#kopia' . msm_mail_footer(),
				array( 'Content-Type: text/plain; charset=UTF-8' ) );
		}
		return $res;
	}

	private static function apply_settings( array $in ) {
		if ( array_key_exists( 'enabled', $in ) ) {
			update_option( 'msm_backup_enabled', $in['enabled'] ? 1 : 0 );
		}
		if ( array_key_exists( 'email', $in ) ) {
			$e = sanitize_email( (string) $in['email'] );
			update_option( 'msm_backup_email', $e );
		}
		if ( array_key_exists( 'emails_extra', $in ) ) {
			update_option( 'msm_backup_emails', implode( ', ', self::parse_emails( (string) $in['emails_extra'] ) ) );
		}
		if ( array_key_exists( 'keep', $in ) ) {
			update_option( 'msm_backup_keep', max( 1, min( 365, (int) $in['keep'] ) ) );
		}
		return self::settings();
	}

	/** Rozbija tekst na poprawne, unikalne adresy e-mail (separatory: przecinek, średnik, spacja, nowa linia). */
	private static function parse_emails( $raw ) {
		$out = array();
		foreach ( preg_split( '/[\s,;]+/', (string) $raw, -1, PREG_SPLIT_NO_EMPTY ) as $p ) {
			$e = sanitize_email( $p );
			if ( $e && is_email( $e ) && ! in_array( $e, $out, true ) ) {
				$out[] = $e;
			}
		}
		return $out;
	}

	/** Pełna lista odbiorców kopii: adres główny + dodatkowe. */
	public static function recipients() {
		$list    = array();
		$primary = sanitize_email( (string) get_option( 'msm_backup_email', get_option( 'admin_email' ) ) );
		if ( $primary && is_email( $primary ) ) {
			$list[] = $primary;
		}
		foreach ( self::parse_emails( (string) get_option( 'msm_backup_emails', '' ) ) as $e ) {
			if ( ! in_array( $e, $list, true ) ) {
				$list[] = $e;
			}
		}
		return $list;
	}

	public static function dir() {
		$up  = wp_upload_dir();
		$dir = trailingslashit( $up['basedir'] ) . 'magazyn-stali-kopie';
		if ( ! is_dir( $dir ) ) {
			wp_mkdir_p( $dir );
		}
		// Osłony: blokada bezpośredniego dostępu z sieci do plików kopii.
		if ( ! file_exists( $dir . '/.htaccess' ) ) {
			@file_put_contents( $dir . '/.htaccess', "Require all denied\nDeny from all\n" ); // phpcs:ignore
		}
		if ( ! file_exists( $dir . '/index.php' ) ) {
			@file_put_contents( $dir . '/index.php', "<?php // Silence.\n" ); // phpcs:ignore
		}
		return $dir;
	}

	public static function files() {
		$dir = self::dir();
		$out = array();
		foreach ( (array) glob( $dir . '/kopia-*.xlsx' ) as $f ) {
			$out[] = array(
				'name' => basename( $f ),
				'size' => filesize( $f ),
				'time' => filemtime( $f ),
				'url'  => add_query_arg( 'msm_kopia', rawurlencode( basename( $f ) ), MSM_Access::app_url() ),
			);
		}
		usort( $out, function ( $a, $b ) { return $b['time'] - $a['time']; } );
		return $out;
	}

	/* ---------- budowanie arkuszy ---------- */

	/** Tabele systemu w kolejności arkuszy: sufiks tabeli (po „{prefix}msm_”) => nazwa arkusza (maks. 31 znaków). */
	const SHEETS = array(
		'stal'            => 'Stal',
		'blachy_pelne'    => 'Blachy pełne',
		'blachy_niepelne' => 'Blachy niepełne',
		'kregi'           => 'Kręgi',
		'rezerwacje'      => 'Rezerwacje',
		'pobrania'        => 'Pobrania',
		'wnioski'         => 'Wnioski',
		'pz'              => 'PZ – dokumenty',
		'pz_poz'          => 'PZ – pozycje',
		'pz_pliki'        => 'PZ – skany (lista plików)',
		'wz'              => 'WZ – dokumenty',
		'wz_poz'          => 'WZ – pozycje',
		'bhp'             => 'BHP – stan magazynu',
		'bhp_osoby'       => 'BHP – osoby',
		'bhp_normy'       => 'BHP – normy',
		'bhp_wyd'         => 'BHP – wydania',
		'bhp_wyd_poz'     => 'BHP – wydania (pozycje)',
		'bhp_util'        => 'BHP – utylizacja',
		'bhp_util_poz'    => 'BHP – utylizacja (pozycje)',
		'spr_prost'       => 'Sprawdziany prostokątne',
		'prz_prost'       => 'Przyrządy prostokątne',
		'spr_okr'         => 'Sprawdziany okrągłe',
		'prz_okr'         => 'Przyrządy okrągłe',
		'slowniki'        => 'Słowniki',
		'log'             => 'Historia zmian',
		'logins'          => 'Logowania',
		'prod_pal'        => 'Palety',
		'prod_pal_poz'    => 'Palety – pozycje',
		'prod_note'       => 'Notatki do zleceń',
		'przesylki'       => 'Przesyłki',
		'elektro'         => 'Elektronarzędzia',
		'elektro_spr'     => 'Elektronarzędzia – sprawdzenia',
		'pomiar'          => 'Przyrządy pomiarowe',
		'pomiar_wz'       => 'Przyrządy pomiarowe – wzorcowania',
		'dost'            => 'Dostawcy',
		'zap'             => 'Zapotrzebowanie zleceń',
		'zam'             => 'Zamówienia do dostawców',
		'zam_poz'         => 'Zamówienia – pozycje',
		'zam_pz'          => 'Zamówienia – dostawy (PZ)',
		'produkcja'       => 'Produkcja (stara tabela)',
	);

	/** Tabele zapisywane osobno (Produkcja – w układzie arkusza i kart projektu). */
	const SKIP = array( 'prod_zlec', 'prod_det' );

	/** Kolumny z numerem użytkownika – w kopii jako „Imię Nazwisko (#id)”. */
	const USER_COLS = array( 'user_id', 'created_by', 'updated_by', 'decided_by', 'issued_by', 'wydal_id' );

	const LABELS = array(
		'id'          => 'ID',
		'created_at'  => 'Utworzono',
		'updated_at'  => 'Zmieniono',
		'updated_by'  => 'Zmienił',
		'created_by'  => 'Utworzył',
		'user_id'     => 'Użytkownik',
		'decided_by'  => 'Decyzja – kto',
		'decided_at'  => 'Decyzja – kiedy',
		'issued_by'   => 'Wydał',
		'issued_at'   => 'Wydano',
		'item_table'  => 'Magazyn pozycji',
		'item_id'     => 'ID pozycji',
	);

	const CELL_MAX = 32000; // Excel: maks. 32 767 znaków w komórce

	private static $users = array();

	public static function build_sheets() {
		global $wpdb;
		$sheets = array( 'Informacje' => array() );
		$done   = array();
		foreach ( self::SHEETS as $suffix => $label ) {
			$done[ $suffix ] = true;
			$rows            = self::dump_table( $suffix );
			if ( null !== $rows ) {
				$sheets[ $label ] = $rows;
			}
		}
		if ( class_exists( 'MSM_Prod' ) ) {
			$sheets['Produkcja (wszystkie lata)'] = MSM_Prod::export_rows();
			foreach ( self::karta_sheets() as $label => $rows ) {
				$sheets[ $label ] = $rows;
			}
		}
		// Każda inna tabela systemu (np. dodana w przyszłości) – też trafia do kopii.
		$like = $wpdb->esc_like( $wpdb->prefix . 'msm_' ) . '%';
		foreach ( (array) $wpdb->get_col( $wpdb->prepare( 'SHOW TABLES LIKE %s', $like ) ) as $T ) {
			$suffix = substr( $T, strlen( $wpdb->prefix . 'msm_' ) );
			if ( isset( $done[ $suffix ] ) || in_array( $suffix, self::SKIP, true ) ) {
				continue;
			}
			$rows = self::dump_table( $suffix );
			if ( null !== $rows ) {
				$sheets[ 'Tabela ' . $suffix ] = $rows;
			}
		}
		$sheets['Użytkownicy i uprawnienia'] = self::users_sheet();
		$sheets['Ustawienia systemu']        = self::options_sheet();
		$sheets['Informacje']                = self::info_sheet( $sheets );
		return $sheets;
	}

	/** Cała tabela: wszystkie kolumny z bazy, nagłówki z opisu systemu, pola wyliczane dla stanów magazynowych. */
	private static function dump_table( $suffix ) {
		global $wpdb;
		$T = $wpdb->prefix . 'msm_' . $suffix;
		if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $T ) ) !== $T ) {
			return null;
		}
		$dbcols = (array) $wpdb->get_results( "SHOW COLUMNS FROM `$T`", ARRAY_A ); // phpcs:ignore
		$types  = array();
		foreach ( $dbcols as $c ) {
			$types[ $c['Field'] ] = strtolower( $c['Type'] );
		}
		$skey   = 'log' === $suffix ? 'historia' : $suffix;
		$schema = msm_schema();
		$def    = $schema[ $skey ] ?? null;
		$labels = array();
		$order  = array( 'id' );
		$calc   = array();
		if ( $def ) {
			foreach ( $def['cols'] as $c ) {
				if ( ! empty( $c['computed'] ) ) {
					$calc[ $c['key'] ] = $c['label'];
					continue;
				}
				$labels[ $c['key'] ] = $c['label'];
				$order[]             = $c['key'];
			}
		}
		foreach ( array_keys( $types ) as $f ) {
			if ( ! in_array( $f, $order, true ) ) {
				$order[] = $f;
			}
		}
		$order = array_values( array_filter( $order, function ( $f ) use ( $types ) { return isset( $types[ $f ] ); } ) );
		$head  = array();
		foreach ( $order as $f ) {
			$head[] = $labels[ $f ] ?? ( self::LABELS[ $f ] ?? $f );
		}
		$stock = $def && ! empty( $def['stock'] ) && $calc && class_exists( 'MSM_Calc' );
		if ( $stock ) {
			foreach ( $calc as $lbl ) {
				$head[] = $lbl . ' (wyliczone)';
			}
		}
		$rows = array( $head );
		$data = (array) $wpdb->get_results( "SELECT * FROM `$T` ORDER BY id ASC", ARRAY_A ); // phpcs:ignore
		foreach ( $data as $r ) {
			$line = array();
			foreach ( $order as $f ) {
				$line[] = self::cell( $f, $r[ $f ] ?? null, $types[ $f ] );
			}
			if ( $stock ) {
				$cr = MSM_Calc::compute( $skey, $r );
				foreach ( array_keys( $calc ) as $k ) {
					$line[] = isset( $cr[ $k ] ) && null !== $cr[ $k ] ? 0 + $cr[ $k ] : '';
				}
			}
			$rows[] = $line;
		}
		return $rows;
	}

	private static function cell( $field, $v, $type ) {
		if ( null === $v || '' === $v ) {
			return '';
		}
		if ( in_array( $field, self::USER_COLS, true ) && is_numeric( $v ) ) {
			return self::user_label( (int) $v );
		}
		if ( 'podpis' === $field ) {
			return '[podpis – obraz]'; // obraz podpisu zostaje w systemie (PDF dokumentu)
		}
		if ( preg_match( '/^(tinyint\(1\))/', $type ) ) {
			return (int) $v;
		}
		if ( preg_match( '/^(tinyint|smallint|mediumint|int|bigint)/', $type ) && is_numeric( $v ) ) {
			return (int) $v;
		}
		if ( preg_match( '/^(decimal|float|double)/', $type ) && is_numeric( $v ) ) {
			return (float) $v;
		}
		return self::clip( (string) $v );
	}

	private static function clip( $s ) {
		return mb_strlen( $s ) > self::CELL_MAX ? mb_substr( $s, 0, self::CELL_MAX ) . ' … [skrócono]' : $s;
	}

	private static function user_label( $id ) {
		if ( ! $id ) {
			return '';
		}
		if ( ! isset( self::$users[ $id ] ) ) {
			$u                  = get_userdata( $id );
			self::$users[ $id ] = ( $u ? $u->display_name : 'usunięty' ) . ' (#' . $id . ')';
		}
		return self::$users[ $id ];
	}

	/** Karty projektów: dane karty (1 wiersz na zlecenie) + jej tabele w osobnych arkuszach. */
	private static function karta_sheets() {
		global $wpdb;
		if ( ! class_exists( 'MSM_Karta' ) ) {
			return array();
		}
		$T = MSM_Prod::TZ();
		if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $T ) ) !== $T ) {
			return array();
		}
		$zs   = (array) $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM `' . $T . '` WHERE id > %d ORDER BY arkusz ASC, poz ASC, id ASC', 0 ), ARRAY_A ); // phpcs:ignore
		$head = array( 'Nr zlec.' );
		foreach ( MSM_Karta::FIELDS as $def ) {
			$head[] = $def[0];
		}
		$main   = array( $head );
		$tables = array();
		$tlabel = array( 'wymagania' => 'Karty – wymagania techn.', 'dodatkowe' => 'Karty – wymagania dodatk.', 'zmiany' => 'Karty – historia zmian' );
		$tcols  = array(
			'wymagania' => array( 'Lp.', 'Nazwa', 'Rysunek', 'Ilość', 'Materiał / wstawka', 'Grubość [mm]', 'Masa [kg]', 'PKWiU / CN', 'Rysunek CAD' ),
			'dodatkowe' => array( 'Lp.', 'Kto dostarcza materiał', 'Wymagania' ),
			'zmiany'    => array( 'Zmiana', 'Data', 'Powód zmiany', 'Opis zmiany', 'Wprowadził', 'Zatwierdził' ),
		);
		foreach ( $tlabel as $t => $l ) {
			$tables[ $t ] = array( array_merge( array( 'Nr zlec.' ), $tcols[ $t ] ) );
		}
		foreach ( $zs as $z ) {
			$k = MSM_Karta::decode( $z['karta'] ?? '' );
			if ( wp_json_encode( $k ) === wp_json_encode( MSM_Karta::blank() ) ) {
				continue; // zlecenie bez karty
			}
			$line = array( $z['nr_zlec'] );
			foreach ( array_keys( MSM_Karta::FIELDS ) as $f ) {
				$line[] = self::clip( in_array( $f, MSM_Karta::RICH, true ) ? MSM_Rich::text( $k[ $f ] ) : $k[ $f ] );
			}
			$main[] = $line;
			foreach ( $tlabel as $t => $_ ) {
				foreach ( $k[ $t ] as $row ) {
					$tables[ $t ][] = array_merge( array( $z['nr_zlec'] ), array_map( array( __CLASS__, 'clip' ), array_values( $row ) ) );
				}
			}
		}
		$out = array( 'Karty projektów' => $main );
		foreach ( $tlabel as $t => $l ) {
			$out[ $l ] = $tables[ $t ];
		}
		return $out;
	}

	/** Osoby z dostępem do systemu i ich uprawnienia (bez haseł). */
	private static function users_sheet() {
		$rows  = array( array( 'ID', 'Login', 'Imię i nazwisko', 'E-mail', 'Rola', 'Zarejestrowano', 'Widoczne pozycje menu', 'Ukryte pozycje menu', 'Uprawnienia do akcji' ) );
		$users = get_users( array( 'role__in' => array( 'msm_admin', 'msm_viewer', 'administrator' ), 'orderby' => 'display_name', 'number' => 1000 ) );
		$menu  = class_exists( 'MSM_Perms' ) ? MSM_Perms::menu_keys() : array();
		$caps  = class_exists( 'MSM_Perms' ) ? MSM_Perms::cap_keys() : array();
		foreach ( $users as $u ) {
			$on = array();
			$off = array();
			$ca = array();
			if ( class_exists( 'MSM_Perms' ) ) {
				$e = MSM_Perms::effective( $u );
				foreach ( $e['menu'] as $k => $v ) {
					$lbl = is_array( $menu[ $k ] ?? null ) ? ( $menu[ $k ]['label'] ?? $k ) : ( $menu[ $k ] ?? $k );
					if ( $v ) {
						$on[] = $lbl;
					} else {
						$off[] = $lbl;
					}
				}
				foreach ( $e['caps'] as $k => $v ) {
					if ( $v ) {
						$ca[] = is_array( $caps[ $k ] ?? null ) ? ( $caps[ $k ]['label'] ?? $k ) : ( $caps[ $k ] ?? $k );
					}
				}
			}
			$rows[] = array( (int) $u->ID, $u->user_login, $u->display_name, $u->user_email, implode( ', ', (array) $u->roles ), $u->user_registered, implode( ', ', $on ), implode( ', ', $off ), implode( ', ', $ca ) );
		}
		return $rows;
	}

	/** Wszystkie ustawienia systemu (opcje msm_*): firma, szablony e-maili, kopie, dziennik wersji… */
	private static function options_sheet() {
		global $wpdb;
		$rows = array( array( 'Ustawienie', 'Wartość' ) );
		$opts = (array) $wpdb->get_results( $wpdb->prepare( "SELECT option_name, option_value FROM {$wpdb->options} WHERE option_name LIKE %s ORDER BY option_name", $wpdb->esc_like( 'msm_' ) . '%' ), ARRAY_A ); // phpcs:ignore
		foreach ( $opts as $o ) {
			$v = maybe_unserialize( $o['option_value'] );
			$v = is_scalar( $v ) || null === $v ? (string) $v : wp_json_encode( $v, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT );
			$rows[] = array( $o['option_name'], self::clip( $v ) );
		}
		return $rows;
	}

	private static function info_sheet( array $sheets ) {
		$rows = array(
			array( 'Kopia danych systemu', '' ),
			array( 'Data kopii', current_time( 'd.m.Y H:i' ) ),
			array( 'Strona', get_bloginfo( 'name' ) . ' – ' . home_url( '/' ) ),
			array( 'Wersja wtyczki', defined( 'MSM_VERSION' ) ? MSM_VERSION : '' ),
			array( 'Wersja bazy danych', (string) get_option( 'msm_db_version' ) ),
			array( '', '' ),
			array( 'Arkusz', 'Liczba wierszy' ),
		);
		foreach ( $sheets as $name => $r ) {
			if ( 'Informacje' === $name ) {
				continue;
			}
			$rows[] = array( $name, max( 0, count( $r ) - 1 ) );
		}
		$rows[] = array( '', '' );
		$rows[] = array( 'Uwaga', 'Pliki skanów PZ i obrazy podpisów nie mieszczą się w Excelu – zostają na serwerze (w kopii jest ich lista). Hasła użytkowników nie są zapisywane.' );
		return $rows;
	}

	/* ---------- generowanie + wysyłka ---------- */
	public static function run() {
		$dir  = self::dir();
		// Losowy sufiks: nazwy plików nie da się zgadnąć, nawet gdy serwer (np. nginx) ignoruje .htaccess.
		$name = 'kopia-' . current_time( 'Y-m-d-Hi' ) . '-' . strtolower( wp_generate_password( 20, false ) ) . '.xlsx';
		$path = $dir . '/' . $name;

		if ( ! class_exists( 'ZipArchive' ) ) {
			update_option( 'msm_backup_error', 'Serwer nie ma rozszerzenia PHP „zip” – nie można zapisać pliku Excela.' );
			return new WP_Error( 'msm_backup', 'Serwer nie ma rozszerzenia PHP „zip” – nie można zapisać pliku Excela.' );
		}
		if ( function_exists( 'wp_raise_memory_limit' ) ) {
			wp_raise_memory_limit( 'admin' );
		}
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 300 ); // phpcs:ignore
		}
		$sheets = self::build_sheets();
		if ( ! MSM_Xlsx::write_book( $path, $sheets ) ) {
			update_option( 'msm_backup_error', 'Nie udało się zapisać pliku kopii.' );
			return new WP_Error( 'msm_backup', 'Nie udało się zapisać pliku kopii.' );
		}
		update_option( 'msm_backup_last', time() );
		delete_option( 'msm_backup_error' );
		self::prune();

		$sent = false;
		$to   = self::recipients();
		if ( $to ) {
			$vars = array(
				'data' => current_time( 'd.m.Y H:i' ),
				'plik' => $name,
				'site' => get_bloginfo( 'name' ),
			);
			if ( class_exists( 'MSM_Mail' ) ) {
				$t    = MSM_Mail::render( 'kopia_zapasowa', $vars );
				$sent = MSM_Mail::send( $to, $t['subject'], $t['body'], array( 'prefix' => '', 'attachments' => array( $path ) ) );
			} else {
				$subj = 'Kopia danych magazynu – ' . $vars['data'];
				$body = "W załączniku kopia danych magazynu (Excel) z dnia " . $vars['data'] . ".\n\n" . $vars['site'];
				$sent = wp_mail( $to, $subj, $body, array(), array( $path ) );
			}
		}
		return array( 'file' => $name, 'sent' => (bool) $sent, 'email' => implode( ', ', $to ) );
	}

	private static function prune() {
		$keep  = max( 1, (int) get_option( 'msm_backup_keep', 30 ) );
		$files = glob( self::dir() . '/kopia-*.xlsx' );
		if ( ! $files || count( $files ) <= $keep ) {
			return;
		}
		usort( $files, function ( $a, $b ) { return filemtime( $b ) - filemtime( $a ); } );
		foreach ( array_slice( $files, $keep ) as $f ) {
			@unlink( $f ); // phpcs:ignore
		}
	}

	/* ---------- pobieranie kopii przez administratora ---------- */
	public static function maybe_download() {
		if ( ! isset( $_GET['msm_kopia'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			return;
		}
		$ok = current_user_can( 'manage_options' ) || ( current_user_can( 'msm_edit' ) && ( ! class_exists( 'MSM_Perms' ) || MSM_Perms::menu_on( 'kopia' ) ) );
		if ( ! $ok ) {
			wp_die( 'Brak uprawnień do kopii danych.' );
		}
		$name = basename( sanitize_file_name( wp_unslash( $_GET['msm_kopia'] ) ) ); // phpcs:ignore
		$path = self::dir() . '/' . $name;
		if ( ! preg_match( '/^kopia-[\d\-]+(-[a-z0-9]{20})?\.xlsx$/', $name ) || ! file_exists( $path ) ) {
			wp_die( 'Nie znaleziono pliku kopii.' );
		}
		nocache_headers();
		header( 'Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' );
		header( 'Content-Disposition: attachment; filename="' . $name . '"' );
		header( 'Content-Length: ' . filesize( $path ) );
		readfile( $path ); // phpcs:ignore
		exit;
	}
}
