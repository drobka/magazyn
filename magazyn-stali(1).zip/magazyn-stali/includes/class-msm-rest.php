<?php
/**
 * REST API: /wp-json/msm/v1/...
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MSM_Rest {

	const NS = 'msm/v1';

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
	}

	public static function can_view() {
		return current_user_can( 'msm_view' ) ? true : new WP_Error( 'msm_forbidden', 'Brak dostępu – zaloguj się.', array( 'status' => is_user_logged_in() ? 403 : 401 ) );
	}

	public static function can_edit() {
		return current_user_can( 'msm_edit' ) ? true : new WP_Error( 'msm_forbidden', 'Brak uprawnień do zmian.', array( 'status' => 403 ) );
	}

	/** Dostęp do szablonów e-maili: rola z prawem edycji + uprawnienie „Szablony e-maili”. */
	public static function can_templates() {
		if ( ! current_user_can( 'msm_edit' ) ) {
			return new WP_Error( 'msm_forbidden', 'Brak uprawnień.', array( 'status' => 403 ) );
		}
		$eff = MSM_Perms::effective( wp_get_current_user() );
		return ! empty( $eff['menu']['szablony'] ) ? true : new WP_Error( 'msm_forbidden', 'Brak uprawnień do edycji szablonów e-maili.', array( 'status' => 403 ) );
	}

	/**
	 * Fabryka permission_callback: rola administratora magazynu + włączona sekcja menu.
	 * Ukrycie sekcji w uprawnieniach per-osoba blokuje też jej API (nie tylko przycisk w menu).
	 */
	/** Odczyt dla zalogowanych z włączoną zakładką (administrator WordPressa – zawsze). */
	public static function view_section( $menu_key ) {
		return function () use ( $menu_key ) {
			$c = self::can_view();
			if ( is_wp_error( $c ) ) {
				return $c;
			}
			if ( ! MSM_Perms::is_wp_admin() && ! MSM_Perms::menu_on( $menu_key ) ) {
				return new WP_Error( 'msm_forbidden', 'Ta zakładka jest dla Ciebie wyłączona.', array( 'status' => 403 ) );
			}
			return true;
		};
	}

	public static function section( $menu_key ) {
		return function () use ( $menu_key ) {
			if ( ! current_user_can( 'msm_edit' ) ) {
				return new WP_Error( 'msm_forbidden', 'Brak uprawnień.', array( 'status' => 403 ) );
			}
			if ( ! MSM_Perms::is_wp_admin() && ! MSM_Perms::menu_on( $menu_key ) ) {
				return new WP_Error( 'msm_forbidden', 'Ta sekcja jest dla Ciebie wyłączona.', array( 'status' => 403 ) );
			}
			return true;
		};
	}

	/**
	 * Fabryka permission_callback (1.84.0): dostęp do magazynu (+ prawo zmian, gdy $edit) i włączona sekcja menu.
	 */
	public static function in_section( $menu_key, $edit = false ) {
		return function () use ( $menu_key, $edit ) {
			$c = $edit ? MSM_Rest::can_edit() : MSM_Rest::can_view();
			if ( is_wp_error( $c ) ) {
				return $c;
			}
			if ( ! MSM_Perms::is_wp_admin() && ! MSM_Perms::menu_on( $menu_key ) ) {
				return new WP_Error( 'msm_forbidden', 'Ta sekcja jest dla Ciebie wyłączona.', array( 'status' => 403 ) );
			}
			return true;
		};
	}

	/**
	 * Tabele, których odczyt zależy od sekcji menu. Od 1.84.0 także pobrania, WZ i cały Magazyn BHP –
	 * wyłączenie sekcji w uprawnieniach per-osoba blokuje API i eksport, nie tylko przycisk w menu.
	 * Stany magazynowe i ewidencja narzędzi pozostają współdzielone (korzystają z nich WZ, wnioski i Produkcja).
	 */
	private static function table_section( $t ) {
		$map = array(
			'historia'   => 'historia',
			'pz'         => 'pz',
			'pobrania'   => 'pobrania',
			'wz'         => 'wz',
			'bhp'        => 'bhp',
			'bhp_osoby'  => 'bhp',
			'bhp_normy'  => 'bhp',
			'wnioski'    => 'wnioski',
			'rezerwacje' => 'rezerwacje',
		);
		return $map[ $t ] ?? null;
	}

	/** Czy bieżąca osoba może czytać tabelę (API, eksport, wydruki list). */
	public static function table_allowed( $t ) {
		return self::valid_table( $t );
	}

	private static function valid_table( $t ) {
		if ( 'pz' === $t && ! current_user_can( 'msm_edit' ) ) {
			return false;
		}
		$sec = self::table_section( $t );
		if ( $sec && ! MSM_Perms::is_wp_admin() && ! MSM_Perms::menu_on( $sec ) ) {
			return false;
		}
		return isset( msm_schema()[ $t ] );
	}

	public static function routes() {
		$t = '(?P<t>[a-z_]+)';

		register_rest_route( self::NS, "/t/$t", array(
			array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'list_rows' ), 'permission_callback' => array( __CLASS__, 'can_view' ) ),
			array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'create' ), 'permission_callback' => array( 'MSM_Inwentarz', 'can_edit_stock' ) ),
		) );
		register_rest_route( self::NS, "/t/$t/options", array(
			'methods' => 'GET', 'callback' => array( __CLASS__, 'options' ), 'permission_callback' => array( __CLASS__, 'can_view' ),
		) );
		register_rest_route( self::NS, "/t/$t/(?P<id>\d+)", array(
			array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'get_one' ), 'permission_callback' => array( __CLASS__, 'can_view' ) ),
			array( 'methods' => 'POST, PUT, PATCH', 'callback' => array( __CLASS__, 'update' ), 'permission_callback' => array( 'MSM_Inwentarz', 'can_edit_stock' ) ),
			array( 'methods' => 'DELETE', 'callback' => array( __CLASS__, 'delete' ), 'permission_callback' => array( 'MSM_Inwentarz', 'can_edit_stock' ) ),
		) );
		register_rest_route( self::NS, "/t/$t/(?P<id>\d+)/historia", array(
			'methods' => 'GET', 'permission_callback' => array( __CLASS__, 'can_view' ),
			'callback' => function ( WP_REST_Request $r ) {
				if ( ! self::valid_table( $r['t'] ) ) {
					return new WP_Error( 'msm_forbidden', 'Ta sekcja jest dla Ciebie wyłączona.', array( 'status' => 403 ) );
				}
				if ( ! in_array( $r['t'], msm_stock_tables(), true ) && 'bhp' !== $r['t'] ) {
					return new WP_Error( 'msm_400', 'Historia dostępna dla pozycji magazynowych.', array( 'status' => 400 ) );
				}
				return rest_ensure_response( MSM_Repo::item_history( $r['t'], (int) $r['id'] ) );
			},
		) );
		register_rest_route( self::NS, "/t/$t/(?P<id>\d+)/hala", array(
			'methods' => 'POST', 'callback' => array( __CLASS__, 'narz_hala' ),
			'permission_callback' => array( 'MSM_Inwentarz', 'can_edit_stock' ),
		) );
		register_rest_route( self::NS, '/ustawienia', array(
			array( 'methods' => 'GET', 'callback' => function () { return rest_ensure_response( MSM_Settings::for_admin() ); }, 'permission_callback' => array( 'MSM_Settings', 'can_manage' ) ),
			array( 'methods' => 'POST', 'callback' => function ( WP_REST_Request $r ) { return rest_ensure_response( MSM_Settings::save( (array) $r->get_json_params() ) ); }, 'permission_callback' => array( 'MSM_Settings', 'can_manage' ) ),
		) );
		register_rest_route( self::NS, "/t/$t/purge", array(
			'methods' => 'POST', 'callback' => array( __CLASS__, 'purge' ),
			'permission_callback' => function () { return MSM_Install::can_purge() ? true : new WP_Error( 'msm_forbidden', 'To konto nie ma uprawnień do trwałego usuwania.', array( 'status' => 403 ) ); },
		) );
		register_rest_route( self::NS, "/t/$t/bulk-edit", array(
			'methods' => 'POST', 'callback' => array( __CLASS__, 'bulk_edit' ), 'permission_callback' => array( 'MSM_Inwentarz', 'can_edit_stock' ),
		) );
		register_rest_route( self::NS, "/t/$t/bulk-delete", array(
			'methods' => 'POST', 'callback' => array( __CLASS__, 'bulk_delete' ), 'permission_callback' => array( 'MSM_Inwentarz', 'can_edit_stock' ),
		) );
		register_rest_route( self::NS, "/export/$t", array(
			'methods' => 'GET', 'callback' => array( __CLASS__, 'export' ), 'permission_callback' => array( __CLASS__, 'can_view' ),
		) );
		register_rest_route( self::NS, '/pobranie', array(
			'methods' => 'POST', 'callback' => array( __CLASS__, 'pobranie' ), 'permission_callback' => array( __CLASS__, 'can_edit' ),
		) );
		register_rest_route( self::NS, '/wnioski', array(
			'methods' => 'POST', 'callback' => array( __CLASS__, 'wniosek_create' ), 'permission_callback' => array( __CLASS__, 'can_view' ),
		) );
		register_rest_route( self::NS, '/wnioski/(?P<id>\d+)/zapotrzebowanie', array(
			'methods' => 'POST', 'callback' => function ( WP_REST_Request $r ) { return rest_ensure_response( MSM_Wnioski::convert( (int) $r['id'] ) ); }, 'permission_callback' => array( __CLASS__, 'can_view' ),
		) );
		register_rest_route( self::NS, '/wnioski/(?P<id>\d+)/zwrot', array(
			'methods' => 'POST', 'callback' => function ( WP_REST_Request $r ) { return rest_ensure_response( MSM_Wnioski::zwrot( (int) $r['id'], (array) $r->get_json_params() ) ); }, 'permission_callback' => array( __CLASS__, 'can_edit' ),
		) );
		register_rest_route( self::NS, '/zwrot', array(
			'methods' => 'POST', 'callback' => function ( WP_REST_Request $r ) { return rest_ensure_response( MSM_Wnioski::zwrot_pobranie( (array) $r->get_json_params() ) ); }, 'permission_callback' => array( __CLASS__, 'can_edit' ),
		) );
		register_rest_route( self::NS, '/blacha/(?P<id>\d+)/do-niepelnych', array(
			'methods' => 'POST', 'callback' => function ( WP_REST_Request $r ) { return rest_ensure_response( MSM_Repo::move_pelna_to_niepelna( (int) $r['id'] ) ); }, 'permission_callback' => array( __CLASS__, 'can_edit' ),
		) );
		register_rest_route( self::NS, '/wnioski/(?P<id>\d+)/popraw', array(
			'methods' => 'POST', 'callback' => function ( WP_REST_Request $r ) { return rest_ensure_response( MSM_Wnioski::update( (int) $r['id'], (array) $r->get_json_params() ) ); }, 'permission_callback' => array( __CLASS__, 'can_view' ),
		) );
		register_rest_route( self::NS, '/wnioski/count', array(
			'methods' => 'GET', 'callback' => array( __CLASS__, 'wnioski_count' ), 'permission_callback' => array( __CLASS__, 'can_view' ),
		) );
		register_rest_route( self::NS, '/wnioski/(?P<id>\d+)/(?P<action>akceptuj|odrzuc|wydaj|anuluj|jest|brak)', array(
			'methods' => 'POST', 'callback' => array( __CLASS__, 'wniosek_action' ), 'permission_callback' => array( __CLASS__, 'can_view' ),
		) );
		register_rest_route( self::NS, '/profil', array(
			array( 'methods' => 'GET', 'callback' => function () { return rest_ensure_response( MSM_Profile::get() ); }, 'permission_callback' => array( __CLASS__, 'can_view' ) ),
			array( 'methods' => 'POST', 'callback' => function ( WP_REST_Request $r ) { return rest_ensure_response( MSM_Profile::update( (array) $r->get_json_params() ) ); }, 'permission_callback' => array( __CLASS__, 'can_view' ) ),
		) );
		register_rest_route( self::NS, '/dashboard', array(
			'methods' => 'GET', 'callback' => function () { return rest_ensure_response( MSM_Reports::dashboard() ); }, 'permission_callback' => array( __CLASS__, 'can_view' ),
		) );
		register_rest_route( self::NS, '/zlecenie/(?P<nr>[^/]+)', array(
			'permission_callback' => self::view_section( 'zlecenie' ),
			'methods' => 'GET', 'callback' => function ( WP_REST_Request $r ) { return rest_ensure_response( MSM_Reports::zlecenie( urldecode( $r['nr'] ) ) ); }, 
		) );
		register_rest_route( self::NS, '/do-zamowienia', array(
			'methods' => 'GET', 'callback' => function () { return rest_ensure_response( MSM_Reports::low_stock() ); }, 'permission_callback' => self::view_section( 'zamowienia' ),
		) );
		register_rest_route( self::NS, '/logins', array(
			'methods' => 'GET', 'callback' => function () { return rest_ensure_response( MSM_Logins::listing() ); }, 'permission_callback' => self::section( 'logowania' ),
		) );
		// Zarządzanie użytkownikami (tylko administrator).
		register_rest_route( self::NS, '/users', array(
			array( 'methods' => 'GET', 'callback' => function () { return rest_ensure_response( MSM_Users::listing() ); }, 'permission_callback' => self::section( 'uzytkownicy' ) ),
			array( 'methods' => 'POST', 'callback' => function ( WP_REST_Request $r ) { return rest_ensure_response( MSM_Users::create( (array) $r->get_json_params() ) ); }, 'permission_callback' => self::section( 'uzytkownicy' ) ),
		) );
		register_rest_route( self::NS, '/users/(?P<id>\d+)', array(
			'methods' => 'POST', 'callback' => function ( WP_REST_Request $r ) { return rest_ensure_response( MSM_Users::update( (int) $r['id'], (array) $r->get_json_params() ) ); }, 'permission_callback' => self::section( 'uzytkownicy' ),
		) );
		register_rest_route( self::NS, '/users/(?P<id>\d+)/password', array(
			'methods' => 'POST', 'callback' => function ( WP_REST_Request $r ) { $b = (array) $r->get_json_params(); return rest_ensure_response( MSM_Users::reset_password( (int) $r['id'], (string) ( $b['password'] ?? '' ) ) ); }, 'permission_callback' => self::section( 'uzytkownicy' ),
		) );
		register_rest_route( self::NS, '/users/(?P<id>\d+)/delete', array(
			'methods' => 'POST', 'callback' => function ( WP_REST_Request $r ) { return rest_ensure_response( MSM_Users::delete( (int) $r['id'] ) ); }, 'permission_callback' => self::section( 'uzytkownicy' ),
		) );
		// Kopia danych – osobna pozycja menu „Kopia danych”.
		register_rest_route( self::NS, '/backup', array(
			array( 'methods' => 'GET', 'callback' => function () { return rest_ensure_response( MSM_Backup::settings() ); }, 'permission_callback' => self::section( 'kopia' ) ),
			array( 'methods' => 'POST', 'callback' => function ( WP_REST_Request $r ) { return rest_ensure_response( MSM_Backup::save_settings( (array) $r->get_json_params() ) ); }, 'permission_callback' => self::section( 'kopia' ) ),
		) );
		register_rest_route( self::NS, '/backup/run', array(
			'methods' => 'POST', 'callback' => function () { $res = MSM_Backup::run(); return is_wp_error( $res ) ? $res : rest_ensure_response( array_merge( (array) $res, MSM_Backup::settings() ) ); }, 'permission_callback' => self::section( 'kopia' ),
		) );
		register_rest_route( self::NS, '/import', array(
			'methods' => 'POST', 'callback' => array( __CLASS__, 'import' ), 'permission_callback' => array( __CLASS__, 'can_edit' ),
		) );
		register_rest_route( self::NS, '/mail-templates', array(
			array( 'methods' => 'GET', 'callback' => function () { return rest_ensure_response( MSM_Mail::all() ); }, 'permission_callback' => array( __CLASS__, 'can_templates' ) ),
			array( 'methods' => 'POST', 'callback' => function ( WP_REST_Request $r ) {
				$in = (array) $r->get_json_params();
				return rest_ensure_response( MSM_Mail::save( (string) ( $in['key'] ?? '' ), (string) ( $in['subject'] ?? '' ), (string) ( $in['body'] ?? '' ) ) );
			}, 'permission_callback' => array( __CLASS__, 'can_templates' ) ),
		) );
	}

	private static function params( WP_REST_Request $r ) {
		return array(
			'q'         => $r->get_param( 'q' ),
			'f'         => (array) $r->get_param( 'f' ),
			'min'       => (array) $r->get_param( 'min' ),
			'max'       => (array) $r->get_param( 'max' ),
			'orderby'   => $r->get_param( 'orderby' ) ? sanitize_key( $r->get_param( 'orderby' ) ) : null,
			'order'     => $r->get_param( 'order' ),
			'page'      => $r->get_param( 'page' ),
			'per_page'  => $r->get_param( 'per_page' ),
			'hide_zero' => $r->get_param( 'hide_zero' ),
		);
	}

	private static function clean_params( array $p, $table = '' ) {
		$p = array_filter( $p, function ( $v ) {
			return null !== $v;
		} );
		if ( in_array( $table, array( 'wnioski', 'rezerwacje' ), true ) && ! current_user_can( 'msm_edit' ) ) {
			$p['_user'] = get_current_user_id();
		}
		return $p;
	}

	public static function wniosek_create( WP_REST_Request $r ) {
		return rest_ensure_response( MSM_Wnioski::create( (array) $r->get_json_params() ) );
	}

	public static function wniosek_action( WP_REST_Request $r ) {
		$body = (array) $r->get_json_params();
		return rest_ensure_response( MSM_Wnioski::action( (int) $r['id'], $r['action'], $body['note'] ?? '' ) );
	}

	public static function wnioski_count() {
		return rest_ensure_response( MSM_Wnioski::counts() );
	}

	public static function list_rows( WP_REST_Request $r ) {
		$t = $r['t'];
		if ( ! self::valid_table( $t ) ) {
			return new WP_Error( 'msm_404', 'Nieznana tabela.', array( 'status' => 404 ) );
		}
		return rest_ensure_response( MSM_Repo::query( $t, self::clean_params( self::params( $r ), $t ) ) );
	}

	public static function options( WP_REST_Request $r ) {
		$t = $r['t'];
		if ( ! self::valid_table( $t ) ) {
			return new WP_Error( 'msm_404', 'Nieznana tabela.', array( 'status' => 404 ) );
		}
		$p = $r->get_param( 'filtered' ) ? self::clean_params( self::params( $r ), $t ) : self::clean_params( array(), $t );
		return rest_ensure_response( MSM_Repo::options( $t, $p ) );
	}

	public static function get_one( WP_REST_Request $r ) {
		$t = $r['t'];
		if ( ! self::valid_table( $t ) ) {
			return new WP_Error( 'msm_404', 'Nieznana tabela.', array( 'status' => 404 ) );
		}
		$row = MSM_Repo::get( $t, (int) $r['id'] );
		if ( $row && 'wnioski' === $t && ! current_user_can( 'msm_edit' ) && (int) $row['user_id'] !== get_current_user_id() ) {
			$row = null;
		}
		return $row ? rest_ensure_response( MSM_Repo::cast_row( $t, $row ) ) : new WP_Error( 'msm_not_found', 'Pozycja nie istnieje.', array( 'status' => 404 ) );
	}

	public static function create( WP_REST_Request $r ) {
		$t = $r['t'];
		if ( ! self::valid_table( $t ) ) { // sekcja wyłączona w uprawnieniach osoby blokuje też zapis przez API
			return new WP_Error( 'msm_forbidden', 'Ta sekcja jest dla Ciebie wyłączona.', array( 'status' => 403 ) );
		}
		if ( ! in_array( $t, msm_editable_tables(), true ) ) {
			return new WP_Error( 'msm_400', 'Tu nie można dodawać pozycji.', array( 'status' => 400 ) );
		}
		MSM_Inwentarz::tag( $r );
		return rest_ensure_response( MSM_Repo::create( $t, (array) $r->get_json_params() ) );
	}

	public static function update( WP_REST_Request $r ) {
		$t = $r['t'];
		if ( ! self::valid_table( $t ) ) { // sekcja wyłączona w uprawnieniach osoby blokuje też zapis przez API
			return new WP_Error( 'msm_forbidden', 'Ta sekcja jest dla Ciebie wyłączona.', array( 'status' => 403 ) );
		}
		if ( ! in_array( $t, array_merge( msm_editable_tables(), array( 'pobrania' ) ), true ) ) {
			return new WP_Error( 'msm_400', 'Tej tabeli nie można edytować.', array( 'status' => 400 ) );
		}
		if ( ! in_array( $t, msm_editable_tables(), true ) && ! current_user_can( 'msm_edit' ) ) {
			return new WP_Error( 'msm_forbidden', 'Brak uprawnień do zmian.', array( 'status' => 403 ) );
		}
		MSM_Inwentarz::tag( $r );
		return rest_ensure_response( MSM_Repo::update( $t, (int) $r['id'], (array) $r->get_json_params() ) );
	}

	public static function narz_hala( WP_REST_Request $r ) {
		$t = $r['t'];
		if ( ! self::valid_table( $t ) ) { // sekcja wyłączona w uprawnieniach osoby blokuje też zapis przez API
			return new WP_Error( 'msm_forbidden', 'Ta sekcja jest dla Ciebie wyłączona.', array( 'status' => 403 ) );
		}
		if ( ! in_array( $t, msm_narzedzia_tables(), true ) ) {
			return new WP_Error( 'msm_400', 'Dostępne tylko dla sprawdzianów i przyrządów.', array( 'status' => 400 ) );
		}
		$body   = (array) $r->get_json_params();
		$action = isset( $body['action'] ) ? sanitize_key( $body['action'] ) : 'hala';
		$regal  = isset( $body['regal'] ) ? (string) $body['regal'] : '';
		return rest_ensure_response( MSM_Repo::narz_hala( $t, (int) $r['id'], $action, $regal ) );
	}

	public static function delete( WP_REST_Request $r ) {
		$t = $r['t'];
		if ( ! self::valid_table( $t ) ) { // sekcja wyłączona w uprawnieniach osoby blokuje też zapis przez API
			return new WP_Error( 'msm_forbidden', 'Ta sekcja jest dla Ciebie wyłączona.', array( 'status' => 403 ) );
		}
		if ( 'pobrania' === $t ) {
			if ( ! current_user_can( 'msm_edit' ) ) {
				return new WP_Error( 'msm_forbidden', 'Brak uprawnień do zmian.', array( 'status' => 403 ) );
			}
			return rest_ensure_response( MSM_Repo::cancel_pobranie( (int) $r['id'] ) );
		}
		MSM_Inwentarz::tag( $r );
		if ( ! in_array( $t, msm_editable_tables(), true ) ) {
			return new WP_Error( 'msm_400', 'Z tej tabeli nie można usuwać.', array( 'status' => 400 ) );
		}
		$n = MSM_Repo::delete( $t, array( (int) $r['id'] ) );
		return $n ? rest_ensure_response( array( 'deleted' => $n ) ) : new WP_Error( 'msm_not_found', 'Pozycja nie istnieje.', array( 'status' => 404 ) );
	}

	public static function purge( WP_REST_Request $r ) {
		$t   = $r['t'];
		$ids = (array) ( $r->get_json_params()['ids'] ?? array() );
		$ids = array_slice( $ids, 0, 1000 );
		if ( 'historia' === $t ) {
			return rest_ensure_response( array( 'deleted' => MSM_Repo::purge_log( $ids ) ) );
		}
		if ( ! in_array( $t, msm_stock_tables(), true ) ) {
			return new WP_Error( 'msm_400', 'Z tej tabeli nie można usuwać.', array( 'status' => 400 ) );
		}
		return rest_ensure_response( array( 'deleted' => MSM_Repo::purge( $t, $ids ) ) );
	}

	public static function bulk_edit( WP_REST_Request $r ) {
		$t = $r['t'];
		if ( ! self::valid_table( $t ) ) { // sekcja wyłączona w uprawnieniach osoby blokuje też zapis przez API
			return new WP_Error( 'msm_forbidden', 'Ta sekcja jest dla Ciebie wyłączona.', array( 'status' => 403 ) );
		}
		if ( ! in_array( $t, msm_editable_tables(), true ) ) {
			return new WP_Error( 'msm_400', 'Tej tabeli nie można edytować.', array( 'status' => 400 ) );
		}
		$p     = (array) $r->get_json_params();
		$field = isset( $p['field'] ) ? (string) $p['field'] : '';
		$col   = msm_col( $t, $field );
		if ( ! $col || ! empty( $col['computed'] ) || 'id' === $field ) {
			return new WP_Error( 'msm_400', 'Tego pola nie można edytować masowo.', array( 'status' => 400 ) );
		}
		$ids = array_filter( array_map( 'intval', (array) ( $p['ids'] ?? array() ) ) );
		$ids = array_slice( array_unique( $ids ), 0, 1000 );
		if ( ! $ids ) {
			return new WP_Error( 'msm_400', 'Nie zaznaczono pozycji.', array( 'status' => 400 ) );
		}
		$value = isset( $p['value'] ) ? $p['value'] : '';
		$done  = 0;
		foreach ( $ids as $id ) {
			$res = MSM_Repo::update( $t, (int) $id, array( $field => $value ) );
			if ( ! is_wp_error( $res ) ) {
				$done++;
			}
		}
		return rest_ensure_response( array( 'updated' => $done, 'field' => $field ) );
	}

	public static function bulk_delete( WP_REST_Request $r ) {
		$t = $r['t'];
		if ( ! self::valid_table( $t ) ) { // sekcja wyłączona w uprawnieniach osoby blokuje też zapis przez API
			return new WP_Error( 'msm_forbidden', 'Ta sekcja jest dla Ciebie wyłączona.', array( 'status' => 403 ) );
		}
		if ( ! in_array( $t, msm_editable_tables(), true ) ) {
			return new WP_Error( 'msm_400', 'Z tej tabeli nie można usuwać.', array( 'status' => 400 ) );
		}
		$ids = (array) ( $r->get_json_params()['ids'] ?? array() );
		MSM_Inwentarz::tag( $r );
		return rest_ensure_response( array( 'deleted' => MSM_Repo::delete( $t, array_slice( $ids, 0, 1000 ) ) ) );
	}

	public static function pobranie( WP_REST_Request $r ) {
		if ( ! MSM_Perms::user_can( 'edit' ) ) {
			return new WP_Error( 'msm_forbidden', 'Brak uprawnień do pobrań bezpośrednich. Złóż wniosek o pobranie.', array( 'status' => 403 ) );
		}
		return rest_ensure_response( MSM_Repo::pobranie( (array) $r->get_json_params() ) );
	}

	public static function import( WP_REST_Request $r ) {
		if ( ! MSM_Perms::user_can( 'import' ) ) {
			return new WP_Error( 'msm_forbidden', 'Brak uprawnień do importu.', array( 'status' => 403 ) );
		}
		$files = $r->get_file_params();
		if ( empty( $files['file']['tmp_name'] ) || ! is_uploaded_file( $files['file']['tmp_name'] ) ) {
			return new WP_Error( 'msm_400', 'Nie przesłano pliku.', array( 'status' => 400 ) );
		}
		$name = sanitize_file_name( $files['file']['name'] );
		if ( ! preg_match( '/\.xlsx$/i', $name ) ) {
			return new WP_Error( 'msm_400', 'Obsługiwane są pliki .xlsx (Excel 2007+). Plik .xls zapisz najpierw jako .xlsx.', array( 'status' => 400 ) );
		}
		$report = MSM_Import::parse( $files['file']['tmp_name'] );
		if ( is_wp_error( $report ) ) {
			$report->add_data( array( 'status' => 400 ) );
			return $report;
		}
		$mode    = 'replace' === $r->get_param( 'mode' ) ? 'replace' : 'append';
		$dry     = (bool) $r->get_param( 'dry' );
		$summary = $dry ? array() : MSM_Import::apply( $report, $mode, $name );
		return rest_ensure_response( array(
			'dry'     => $dry,
			'mode'    => $mode,
			'sheets'  => MSM_Import::public_report( $report ),
			'summary' => $summary,
		) );
	}

	/** Eksport bieżącego (przefiltrowanego) widoku do .xlsx lub .csv. */
	public static function export( WP_REST_Request $r ) {
		$t = $r['t'];
		if ( ! self::valid_table( $t ) ) {
			return new WP_Error( 'msm_404', 'Nieznana tabela.', array( 'status' => 404 ) );
		}
		$p             = self::clean_params( self::params( $r ), $t );
		$p['per_page'] = 0;
		$p['page']     = 1;
		$res           = MSM_Repo::query( $t, $p );
		$def           = msm_schema()[ $t ];
		$format        = 'csv' === $r->get_param( 'format' ) ? 'csv' : 'xlsx';

		$head   = array( 'ID' );
		$widths = array( 7 );
		foreach ( $def['cols'] as $c ) {
			$head[]   = $c['label'];
			$widths[] = ! empty( $c['long'] ) ? 36 : max( 10, min( 30, mb_strlen( $c['label'] ) + 4 ) );
		}
		$rows = array( $head );
		foreach ( $res['rows'] as $row ) {
			$line = array( $row['id'] );
			foreach ( $def['cols'] as $c ) {
				$v = $row[ $c['key'] ];
				if ( 'bool' === $c['type'] ) {
					$v = $v ? 'tak' : 'nie';
				} elseif ( 'num' === $c['type'] && null !== $v ) {
					$v = round( (float) $v, isset( $c['decimals'] ) ? $c['decimals'] : 3 );
				}
				$line[] = $v;
			}
			$rows[] = $line;
		}

		$fname = 'magazyn-' . str_replace( '_', '-', $t ) . '-' . current_time( 'Y-m-d' ) . '.' . $format;
		nocache_headers();

		if ( 'csv' === $format ) {
			header( 'Content-Type: text/csv; charset=UTF-8' );
			header( 'Content-Disposition: attachment; filename="' . $fname . '"' );
			$out = fopen( 'php://output', 'w' ); // phpcs:ignore
			fwrite( $out, "\xEF\xBB\xBF" ); // phpcs:ignore
			foreach ( $rows as $i => $line ) {
				if ( $i > 0 ) {
					$line = array_map( function ( $v ) {
						return is_float( $v ) ? str_replace( '.', ',', (string) $v ) : $v;
					}, $line );
				}
				fputcsv( $out, array_map( 'msm_csv_safe', $line ), ';', '"', '\\' );
			}
			fclose( $out ); // phpcs:ignore
			exit;
		}

		if ( ! function_exists( 'wp_tempnam' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		$tmp = wp_tempnam( 'msm-export' );
		if ( ! MSM_Xlsx::write( $tmp, $def['label'], $rows, $widths ) ) {
			return new WP_Error( 'msm_500', 'Nie udało się utworzyć pliku.', array( 'status' => 500 ) );
		}
		header( 'Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' );
		header( 'Content-Disposition: attachment; filename="' . $fname . '"' );
		header( 'Content-Length: ' . filesize( $tmp ) );
		readfile( $tmp ); // phpcs:ignore
		@unlink( $tmp ); // phpcs:ignore
		exit;
	}
}
