<?php
/**
 * Strony WordPressa „Nie pamiętasz hasła?” i „Ustaw nowe hasło” (wp-login.php)
 * w wyglądzie ekranu logowania magazynu: ciemny panel z logo po lewej, formularz po prawej.
 *
 * Zmienia się tylko wygląd – cały proces resetu (e-mail z linkiem, klucz, siła hasła)
 * pozostaje standardowym, bezpiecznym mechanizmem WordPressa.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MSM_Loginpage {

	/** Akcje wp-login.php, które dostają wygląd magazynu. */
	const ACTIONS = array( 'lostpassword', 'retrievepassword', 'rp', 'resetpass', 'login', 'confirmaction' );

	public static function init() {
		add_action( 'login_init', array( __CLASS__, 'setup' ) );
	}

	private static function action() {
		$a = isset( $_REQUEST['action'] ) ? sanitize_key( wp_unslash( $_REQUEST['action'] ) ) : 'login'; // phpcs:ignore
		return '' === $a ? 'login' : $a;
	}

	public static function setup() {
		// Okienko ponownego logowania w kokpicie (interim-login) zostaje standardowe.
		if ( isset( $_REQUEST['interim-login'] ) || ! in_array( self::action(), self::ACTIONS, true ) ) { // phpcs:ignore
			return;
		}
		add_action( 'login_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_filter( 'login_body_class', array( __CLASS__, 'body_class' ) );
		add_action( 'login_header', array( __CLASS__, 'hero' ) );
		add_filter( 'login_message', array( __CLASS__, 'message' ) );
		add_filter( 'wp_login_errors', array( __CLASS__, 'errors' ) );
		add_filter( 'login_headerurl', array( 'MSM_Access', 'app_url' ) );
		add_filter( 'login_display_language_dropdown', '__return_false' );
		// Linki „Zaloguj się” na tych stronach prowadzą do logowania w aplikacji.
		add_filter( 'login_url', array( __CLASS__, 'login_url' ), 20 );
	}

	/** Komunikat „Sprawdź e-mail” pokazujemy we własnym nagłówku – bez dublowania przez WordPress. */
	public static function errors( $errors ) {
		if ( is_wp_error( $errors ) && isset( $_GET['checkemail'] ) && 'confirm' === $_GET['checkemail'] ) { // phpcs:ignore
			$errors->remove( 'confirm' );
		}
		return $errors;
	}

	public static function login_url() {
		return MSM_Access::app_url();
	}

	public static function assets() {
		wp_enqueue_style( 'msm-app', MSM_URL . 'assets/app.css', array(), MSM_VERSION );
		wp_enqueue_style( 'msm-loginwp', MSM_URL . 'assets/login.css', array( 'msm-app', 'login' ), MSM_VERSION );
	}

	public static function body_class( $classes ) {
		$classes[] = 'msm-auth';
		$classes[] = 'msm-loginwp';
		return $classes;
	}

	/** Lewy panel – identyczny jak na stronie logowania aplikacji. */
	public static function hero() {
		echo MSM_Front::hero_html(); // phpcs:ignore
	}

	/** Nagłówek formularza zależny od etapu resetu (zamiast szarej ramki WordPressa). */
	public static function message( $message ) {
		$a     = self::action();
		$check = isset( $_GET['checkemail'] ) ? sanitize_key( wp_unslash( $_GET['checkemail'] ) ) : ''; // phpcs:ignore
		$head  = '';
		if ( 'confirm' === $check ) {
			$head = self::head( 'Sprawdź skrzynkę e-mail', 'Wysłaliśmy wiadomość z linkiem do ustawienia nowego hasła. Link jest ważny 24 godziny – jeśli nie widzisz wiadomości, zajrzyj do folderu SPAM.', 'mail' );
			return $head; // komunikat WP mówi to samo – nie dublujemy
		}
		if ( in_array( $a, array( 'lostpassword', 'retrievepassword' ), true ) ) {
			return self::head( 'Nie pamiętasz hasła?', 'Podaj login lub adres e-mail z konta. Wyślemy link do ustawienia nowego hasła.', 'key' );
		}
		if ( 'rp' === $a ) {
			return self::head( 'Ustaw nowe hasło', 'Wpisz nowe hasło albo użyj wygenerowanego. Po zapisaniu zalogujesz się nim do magazynu.', 'lock' );
		}
		if ( 'resetpass' === $a ) {
			$link = '<p class="msm-lp-next"><a class="msm-btn msm-btn-primary msm-btn-block" href="' . esc_url( MSM_Access::app_url() ) . '">Przejdź do logowania</a></p>';
			return self::head( 'Hasło zmienione', 'Twoje nowe hasło jest zapisane. Zaloguj się nim do magazynu.', 'check' ) . $link;
		}
		if ( 'login' === $a ) {
			return self::head( 'Zaloguj się', 'Podaj login i hasło otrzymane od administratora.', 'lock' ) . $message;
		}
		return $message;
	}

	private static function head( $title, $text, $icon ) {
		$paths = array(
			'key'   => '<circle cx="7.5" cy="15.5" r="4.5"/><path d="m10.7 12.3 9.3-9.3M17 6l3 3M14 9l2 2"/>',
			'mail'  => '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/>',
			'lock'  => '<rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>',
			'check' => '<circle cx="12" cy="12" r="9"/><path d="m8 12 3 3 5-6"/>',
		);
		return '<div class="msm-lp-head"><span class="msm-lp-ico"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $paths[ $icon ] . '</svg></span>'
			. '<h2>' . esc_html( $title ) . '</h2><p class="msm-muted">' . esc_html( $text ) . '</p></div>';
	}
}
