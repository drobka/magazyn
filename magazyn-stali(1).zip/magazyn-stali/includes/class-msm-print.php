<?php
/**
 * Wydruki: pojedynczy wniosek (2 egzemplarze, każdy na osobnej stronie A4) i zestawienie wniosków (lista wg filtrów).
 * Adres: strona magazynu + ?msm_print=wniosek&id=12  lub  ?msm_print=wnioski&f[status]=zaakceptowany …
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MSM_Print {

	public static function init() {
		add_action( 'template_redirect', array( __CLASS__, 'maybe_render' ), 1 );
	}

	public static function maybe_render() {
		$what = isset( $_GET['msm_print'] ) ? sanitize_key( wp_unslash( $_GET['msm_print'] ) ) : ''; // phpcs:ignore
		if ( ! in_array( $what, array( 'wniosek', 'wnioski', 'lista', 'zamowienia' ), true ) ) {
			return; // Inne wydruki (np. WZ) obsługują własne klasy.
		}
		if ( ! is_user_logged_in() ) {
			return; // Strona magazynu pokaże logowanie i wróci tu po zalogowaniu.
		}
		if ( ! current_user_can( 'msm_view' ) ) {
			wp_die( 'Brak dostępu.', 403 );
		}
		nocache_headers();
		if ( 'wniosek' === $what ) {
			self::single( (int) ( $_GET['id'] ?? 0 ) ); // phpcs:ignore
		} elseif ( 'wnioski' === $what ) {
			if ( ! MSM_Perms::is_wp_admin() && ! MSM_Perms::menu_on( 'wnioski' ) ) {
				wp_die( 'Brak dostępu.', 403 );
			}
			self::listing();
		} elseif ( 'lista' === $what ) {
			self::stock_listing( isset( $_GET['t'] ) ? sanitize_key( wp_unslash( $_GET['t'] ) ) : '' ); // phpcs:ignore
		} elseif ( 'zamowienia' === $what ) {
			if ( ! MSM_Perms::is_wp_admin() && ! MSM_Perms::menu_on( 'zamowienia' ) ) {
				wp_die( 'Brak dostępu.', 403 );
			}
			self::zamowienia();
		}
		exit;
	}

	/* ------------------------------------------------------------------ */

	private static function doc_no( $w ) {
		$ts = strtotime( $w['data'] );
		return 'WP/' . gmdate( 'Y', $ts ) . '/' . gmdate( 'm', $ts ) . '/' . sprintf( '%04d', (int) $w['id'] );
	}

	private static function dt( $v, $fmt = 'd.m.Y, H:i' ) {
		return $v ? mysql2date( $fmt, $v ) : '';
	}

	private static function n( $v, $dec = 2 ) {
		return null === $v || '' === $v ? '' : rtrim( rtrim( number_format( (float) $v, $dec, ',', ' ' ), '0' ), ',' );
	}

	/** Dane pozycji magazynowej + masa dla ilości z wniosku. */
	private static function item_info( $w ) {
		$info = array( 'gatunek' => '', 'len' => '', 'mb' => null, 'kg' => null, 'uwagi' => '', 'exists' => false );
		if ( ! in_array( $w['item_table'], msm_stock_tables(), true ) ) {
			return $info;
		}
		$item = MSM_Repo::get( $w['item_table'], (int) $w['item_id'] );
		if ( ! $item ) {
			return $info;
		}
		$info['exists']  = true;
		$info['gatunek'] = trim( ( $item['gatunek'] ?? '' ) . ( ! empty( $item['material'] ) ? ' / ' . $item['material'] : '' ), ' /' );
		$info['uwagi']   = $item['uwagi'] ?? '';
		$qty             = (float) $w['ilosc'];
		if ( 'stal' === $w['item_table'] ) {
			$info['len'] = 'odcinek' === $w['tryb'] ? '' : self::n( $item['dlugosc'], 3 ) . ' m';
			$mb          = 'odcinek' === $w['tryb'] ? $qty : $qty * (float) $item['dlugosc'];
			$info['mb']  = $mb;
			$info['kg']  = null !== $item['kg_m'] ? $mb * (float) $item['kg_m'] : null;
		} elseif ( 'kg' === $w['jednostka'] ) {
			$info['kg'] = $qty;
		} elseif ( isset( $item['kg_szt'] ) && null !== $item['kg_szt'] ) {
			$info['kg'] = $qty * (float) $item['kg_szt'];
		}
		return $info;
	}

	private static function head( $title, $landscape = false, $note = '' ) {
		$fonts = MSM_URL . 'assets/fonts/';
		?><!DOCTYPE html>
<html lang="pl"><head><meta charset="utf-8"><meta name="robots" content="noindex,nofollow"><title><?php echo esc_html( $title ); ?></title>
<style>
@font-face{font-family:PJS;font-weight:400;src:url(<?php echo esc_url( $fonts ); ?>plus-jakarta-sans-latin-ext-400-normal.woff2) format("woff2");unicode-range:U+0100-02BA,U+02BD-02C5,U+02C7-02CC,U+02CE-02D7,U+02DD-02FF,U+1E00-1E9F,U+2113,U+2C60-2C7F}
@font-face{font-family:PJS;font-weight:400;src:url(<?php echo esc_url( $fonts ); ?>plus-jakarta-sans-latin-400-normal.woff2) format("woff2");unicode-range:U+0000-00FF,U+2000-206F,U+2212}
@font-face{font-family:PJS;font-weight:600;src:url(<?php echo esc_url( $fonts ); ?>plus-jakarta-sans-latin-ext-600-normal.woff2) format("woff2");unicode-range:U+0100-02BA,U+02BD-02C5,U+02C7-02CC,U+02CE-02D7,U+02DD-02FF,U+1E00-1E9F}
@font-face{font-family:PJS;font-weight:600;src:url(<?php echo esc_url( $fonts ); ?>plus-jakarta-sans-latin-600-normal.woff2) format("woff2");unicode-range:U+0000-00FF,U+2000-206F}
@font-face{font-family:PJS;font-weight:800;src:url(<?php echo esc_url( $fonts ); ?>plus-jakarta-sans-latin-ext-800-normal.woff2) format("woff2");unicode-range:U+0100-02BA,U+02BD-02C5,U+02C7-02CC,U+02CE-02D7,U+02DD-02FF,U+1E00-1E9F}
@font-face{font-family:PJS;font-weight:800;src:url(<?php echo esc_url( $fonts ); ?>plus-jakarta-sans-latin-800-normal.woff2) format("woff2");unicode-range:U+0000-00FF,U+2000-206F}
@page{size:A4 <?php echo $landscape ? 'landscape' : 'portrait'; ?>;margin:<?php echo $landscape ? '10mm 10mm 12mm' : '12mm 14mm'; ?>}
*{box-sizing:border-box}
html,body{margin:0;background:#e9ebef}
body{font:9pt/1.4 PJS,system-ui,sans-serif;color:#0b1020;-webkit-print-color-adjust:exact;print-color-adjust:exact}
.bar{position:sticky;top:0;display:flex;gap:10px;justify-content:center;align-items:center;padding:10px;background:#0b1020;color:#fff;font-size:13px;z-index:5}
.bar button{font:600 13px PJS,system-ui;padding:8px 18px;border-radius:99px;border:0;background:#3d4bff;color:#fff;cursor:pointer}
.bar button.g{background:transparent;border:1px solid rgba(255,255,255,.4)}
.sheet{background:#fff;margin:14px auto;box-shadow:0 4px 24px rgba(0,0,0,.12);padding:<?php echo $landscape ? '10mm' : '8mm 12mm'; ?>;width:<?php echo $landscape ? '297mm' : '210mm'; ?>}
@media print{html,body{background:#fff}.bar{display:none}.sheet{margin:0;box-shadow:none;padding:0;width:auto}}
.lbl{display:block;font-size:6.5pt;text-transform:uppercase;letter-spacing:.06em;color:#6b7285;font-weight:600}
.v{font-weight:600}
table{width:100%;border-collapse:collapse}
th{background:#f2f4f8;text-align:left;font-size:6.5pt;text-transform:uppercase;letter-spacing:.05em;color:#3a4256;padding:1.6mm 2mm;border:1px solid #d6d6cf;font-weight:600}
td{padding:1.8mm 2mm;border:1px solid #d6d6cf;vertical-align:top}
td.n,th.n{text-align:right;white-space:nowrap}
.muted{color:#6b7285}
.pill{display:inline-block;padding:.6mm 2.6mm;border-radius:99px;font-size:7pt;font-weight:600;border:1px solid #d6d6cf;margin-right:1.5mm}
.pill.st{background:#eceeff;color:#2c38e0;border-color:#d2d6ff}
</style></head><body>
<div class="bar"><span><?php echo esc_html( $title ); ?><?php echo $note ? ' · <b>' . esc_html( $note ) . '</b>' : ''; ?></span><button onclick="window.print()">Drukuj</button><button class="g" onclick="window.close()">Zamknij</button></div>
		<?php
	}

	/* ------------------------------------------------------------------ *
	 * Pojedynczy wniosek – 2 egzemplarze
	 * ------------------------------------------------------------------ */

	private static function single( $id ) {
		global $wpdb;
		$w = MSM_Repo::get( 'wnioski', $id );
		if ( ! $w || ( ! current_user_can( 'msm_edit' ) && (int) $w['user_id'] !== get_current_user_id() ) ) {
			wp_die( 'Wniosek nie istnieje.', 404 );
		}
		$labels = MSM_Wnioski::labels();
		$check  = 'sprawdzenie' === $w['typ'];
		$rej    = ! $check && MSM_Wnioski::ST_REJECTED === $w['status'];
		$can    = ! $check && MSM_Wnioski::ST_CANCELED === $w['status'];
		$info   = self::item_info( $w );
		$schema = msm_schema();
		$from   = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM `' . msm_table( 'wnioski' ) . '` WHERE next_id = %d', (int) $w['id'] ) ); // phpcs:ignore
		$no     = self::doc_no( $w );
		$title  = ( $check ? 'Prośba o sprawdzenie stanu ' : 'Wniosek o pobranie ' ) . $no;
		self::head( $title, false, 'Format A4 · drukowane są 2 kopie (dla magazynu i dla wnioskującego)' );
		?>
<style>
.half{display:flex;flex-direction:column;position:relative;font-size:10pt}
.half + .half{break-before:page;page-break-before:always}
@media print{.half{min-height:270mm}}
/* Ekran: podgląd jednej kartki A4; druga kopia pojawia się tylko na wydruku. */
@media screen{
  .sheet.single{background:transparent;box-shadow:none;padding:0;width:auto}
  .half{width:210mm;min-height:297mm;padding:12mm 14mm;margin:16px auto;background:#fff;box-shadow:0 4px 24px rgba(0,0,0,.14)}
  .half + .half{display:none}
}
.hd{display:flex;justify-content:space-between;align-items:flex-start;padding-bottom:4mm;border-bottom:2px solid #0b1020}
.hd img{height:16mm}
.hd .doc{text-align:right}
.hd h1{margin:0;font-size:15pt;font-weight:800;letter-spacing:-.02em}
.hd .no{font-size:12pt;font-weight:800;color:#0E58A4;margin-top:.5mm}
.hd .meta{font-size:8pt;color:#6b7285;margin-top:.5mm}
.copy{display:inline-block;margin-bottom:2mm;font-size:7.5pt;font-weight:800;text-transform:uppercase;letter-spacing:.08em;color:#fff;background:#0b1020;padding:.8mm 3mm;border-radius:1mm}
.row{display:flex;gap:2.5mm;margin:5mm 0 4mm}
.pill{font-size:8.5pt;padding:1mm 3.2mm}
.info{display:grid;grid-template-columns:1fr 1fr;border:1px solid #d6d6cf;border-radius:3mm;overflow:hidden}
.info>div{padding:3mm 3.5mm;border-bottom:1px solid #e6e6e0}
.info>div:nth-child(odd){border-right:1px solid #e6e6e0}
.info>div:nth-last-child(-n+2){border-bottom:0}
.info .v{font-size:11pt}
.lbl{font-size:7.5pt}
h2{font-size:9pt;text-transform:uppercase;letter-spacing:.08em;color:#3a4256;margin:7mm 0 2mm;font-weight:800}
table{font-size:9.5pt}
th{font-size:7.5pt;padding:2.2mm 2.5mm}
td{padding:3mm 2.5mm}
tfoot td{font-weight:800;background:#fafaf8}
.dec{display:grid;grid-template-columns:repeat(3,1fr);gap:3mm}
.pill.st.rej{background:#ffe2de;color:#b3261e;border-color:#f4c4bd}
.dec.rej>div{border-color:#f1c2bb;background:#fff7f6}
.dec .no-issue{color:#b3261e;font-weight:700}
.sign.two{grid-template-columns:repeat(2,1fr)}
.dec>div{border:1px solid #d6d6cf;border-radius:3mm;padding:3mm 3.5mm;min-height:18mm}
.sign{display:grid;grid-template-columns:repeat(3,1fr);gap:9mm;margin-top:auto;padding-top:20mm}
.sign div{border-top:1px solid #0b1020;padding-top:1.5mm;text-align:center;font-size:8.5pt;color:#3a4256}
.sign b{display:block;color:#0b1020;font-size:9pt}
.ft{display:flex;justify-content:space-between;font-size:7.5pt;color:#6b7285;margin-top:6mm;padding-top:2.5mm;border-top:1px solid #e6e6e0}
</style>
<div class="sheet single">
		<?php
		foreach ( array( 'Kopia 1/2 – dla magazynu', 'Kopia 2/2 – dla wnioskującego' ) as $i => $copy ) :
			?>
<div class="half">
  <div class="hd">
    <img src="<?php echo esc_url( MSM_URL . 'assets/logo.svg?v=' . MSM_VERSION ); ?>" alt="Kisielewski">
    <div class="doc">
      <span class="copy"><?php echo esc_html( $copy ); ?></span>
      <h1><?php echo $check ? 'Prośba o sprawdzenie stanu' : 'Wniosek o pobranie materiału'; ?></h1>
      <div class="no">Nr <?php echo esc_html( $no ); ?></div>
      <div class="meta">Magazyn: <?php echo esc_html( msm_opt( 'magazyn_nazwa' ) ); ?> · wydrukowano <?php echo esc_html( current_time( 'd.m.Y H:i' ) ); ?></div>
    </div>
  </div>
  <div class="row">
    <span class="pill st<?php echo $rej || $can ? ' rej' : ''; ?>">Status: <?php echo esc_html( $labels[ $w['status'] ] ?? $w['status'] ); ?></span>
    <span class="pill">Typ: <?php echo $check ? 'Sprawdzenie stanu' : 'Pobranie'; ?></span>
    <?php if ( $from ) : ?><span class="pill">Z prośby o sprawdzenie stanu #<?php echo (int) $from; ?></span><?php endif; ?>
    <?php if ( ! empty( $w['next_id'] ) ) : ?><span class="pill">Zapotrzebowanie wysłane jako #<?php echo (int) $w['next_id']; ?></span><?php endif; ?>
  </div>
  <div class="info">
    <div><span class="lbl">Wnioskujący</span><span class="v"><?php echo esc_html( $w['user_name'] ); ?></span></div>
    <div><span class="lbl">Data złożenia</span><span class="v"><?php echo esc_html( self::dt( $w['data'] ) ); ?></span></div>
    <div><span class="lbl">Numer zlecenia</span><span class="v"><?php echo esc_html( $w['zlecenie'] ? $w['zlecenie'] : '—' ); ?></span></div>
    <div><span class="lbl">Numer rysunku</span><span class="v"><?php echo esc_html( ! empty( $w['rysunek'] ) ? $w['rysunek'] : '—' ); ?></span></div>
    <div><span class="lbl">Cel / uwagi</span><span class="v"><?php echo esc_html( $w['uwagi'] ? $w['uwagi'] : '—' ); ?></span></div>
  </div>
  <h2>Materiał</h2>
  <table>
    <thead><tr><th style="width:6mm">Lp.</th><th style="width:22mm">Magazyn</th><th>Materiał</th><th style="width:22mm">Gatunek</th><th class="n" style="width:16mm">Ilość</th><th class="n" style="width:20mm"><?php echo 'stal' === $w['item_table'] ? 'Dł. sztuki' : '&nbsp;'; ?></th><th class="n" style="width:18mm">Masa ok.</th></tr></thead>
    <tbody><tr>
      <td>1</td>
      <td><?php echo esc_html( $schema[ $w['item_table'] ]['label'] ?? $w['item_table'] ); ?></td>
      <td><b><?php echo esc_html( $w['material'] ); ?></b><?php echo 'odcinek' === $w['tryb'] ? ' <span class="muted">(odcinek)</span>' : ''; ?><br><span class="muted" style="font-size:7pt">ID pozycji <?php echo (int) $w['item_id']; ?><?php echo $info['exists'] ? '' : ' · pozycja usunięta z magazynu'; ?><?php echo $info['uwagi'] ? ' · ' . esc_html( $info['uwagi'] ) : ''; ?></span></td>
      <td><?php echo esc_html( $info['gatunek'] ); ?></td>
      <td class="n"><b><?php echo esc_html( self::n( $w['ilosc'], 3 ) . ' ' . $w['jednostka'] ); ?></b><?php if ( MSM_Calc::odc_txt( $w ) ) : ?><br><small><?php echo esc_html( MSM_Calc::odc_txt( $w ) ); ?></small><?php endif; ?></td>
      <td class="n"><?php echo esc_html( $info['len'] ); ?></td>
      <td class="n"><?php echo null !== $info['kg'] ? esc_html( self::n( $info['kg'] ) . ' kg' ) : '—'; ?></td>
    </tr></tbody>
    <?php if ( null !== $info['mb'] || null !== $info['kg'] ) : ?>
    <tfoot><tr><td colspan="4">Razem</td><td class="n"><?php echo esc_html( self::n( $w['ilosc'], 3 ) . ' ' . $w['jednostka'] ); ?></td><td class="n"><?php echo null !== $info['mb'] ? esc_html( self::n( $info['mb'], 3 ) . ' mb' ) : ''; ?></td><td class="n"><?php echo null !== $info['kg'] ? esc_html( self::n( $info['kg'] ) . ' kg' ) : ''; ?></td></tr></tfoot>
    <?php endif; ?>
  </table>
  <h2><?php echo $check ? 'Odpowiedź magazyniera' : ( $rej ? 'Decyzja – wniosek odrzucony' : ( $can ? 'Decyzja – wniosek anulowany' : 'Decyzja i wydanie' ) ); ?></h2>
  <div class="dec<?php echo $rej || $can ? ' rej' : ''; ?>">
    <div><span class="lbl"><?php echo $check ? 'Sprawdził' : ( $rej ? 'Odrzucił' : ( $can ? 'Anulował' : 'Zaakceptował' ) ); ?></span><div class="v"><?php echo esc_html( $w['decided_name'] ); ?>&nbsp;</div><div class="muted" style="font-size:7pt"><?php echo esc_html( self::dt( $w['decided_at'] ) ); ?></div></div>
    <?php if ( $check ) : ?>
    <div><span class="lbl">Wynik</span><div class="v"><?php echo in_array( $w['status'], array( 'potwierdzony', 'brak' ), true ) ? esc_html( $labels[ $w['status'] ] ) : '&nbsp;'; ?></div></div>
    <?php elseif ( $rej || $can ) : ?>
    <div><span class="lbl">Wydanie</span><div class="v no-issue">Nie wydano</div><div class="muted" style="font-size:7pt">wniosek <?php echo $rej ? 'odrzucony przez magazyn' : 'anulowany'; ?></div></div>
    <?php else : ?>
    <div><span class="lbl">Wydano</span><div class="v"><?php echo esc_html( self::dt( $w['issued_at'] ) ); ?>&nbsp;</div><div class="muted" style="font-size:7pt"><?php echo $w['pobranie_id'] ? 'pobranie nr ' . (int) $w['pobranie_id'] . ' w systemie' : ''; ?></div></div>
    <?php endif; ?>
    <div><span class="lbl"><?php echo $rej ? 'Powód odrzucenia / uwagi' : 'Uwagi magazyniera'; ?></span><div><?php echo esc_html( (string) $w['admin_note'] ); ?>&nbsp;</div></div>
  </div>
  <?php if ( $rej || $can ) : ?>
  <div class="sign two">
    <div><b>Wnioskujący</b>data i podpis</div>
    <div><b><?php echo $rej ? 'Odrzucił (magazynier)' : 'Przyjął do wiadomości (magazynier)'; ?></b>data i podpis</div>
  </div>
  <?php else : ?>
  <div class="sign">
    <div><b>Wnioskujący</b>data i podpis</div>
    <div><b><?php echo $check ? 'Sprawdził (magazynier)' : 'Wydał (magazynier)'; ?></b>data i podpis</div>
    <div><b>Odebrał</b>data i podpis</div>
  </div>
  <?php endif; ?>
  <div class="ft"><span>© Copyright by <?php echo esc_html( msm_opt( 'firma_nazwa' ) ); ?></span><span>Dokument z systemu magazynowego · <?php echo esc_html( $no ); ?></span></div>
</div>
		<?php endforeach; ?>
</div>
<script>window.addEventListener('load',function(){setTimeout(function(){window.print();},300);});</script>
</body></html>
		<?php
	}

	/* ------------------------------------------------------------------ *
	 * Zestawienie wniosków wg filtrów z aplikacji
	 * ------------------------------------------------------------------ */

	private static function listing() {
		$p = array(
			'q'        => isset( $_GET['q'] ) ? sanitize_text_field( wp_unslash( $_GET['q'] ) ) : null, // phpcs:ignore
			'f'        => isset( $_GET['f'] ) ? map_deep( wp_unslash( (array) $_GET['f'] ), 'sanitize_text_field' ) : array(), // phpcs:ignore
			'min'      => isset( $_GET['min'] ) ? map_deep( wp_unslash( (array) $_GET['min'] ), 'sanitize_text_field' ) : array(), // phpcs:ignore
			'max'      => isset( $_GET['max'] ) ? map_deep( wp_unslash( (array) $_GET['max'] ), 'sanitize_text_field' ) : array(), // phpcs:ignore
			'orderby'  => isset( $_GET['orderby'] ) ? sanitize_key( wp_unslash( $_GET['orderby'] ) ) : null, // phpcs:ignore
			'order'    => isset( $_GET['order'] ) ? sanitize_key( wp_unslash( $_GET['order'] ) ) : null, // phpcs:ignore
			'per_page' => 0,
			'page'     => 1,
		);
		$p = array_filter( $p, function ( $v ) {
			return null !== $v;
		} );
		if ( ! current_user_can( 'msm_edit' ) ) {
			$p['_user'] = get_current_user_id();
		}
		$res    = MSM_Repo::query( 'wnioski', $p );
		$labels = MSM_Wnioski::labels();
		$schema = msm_schema();

		// Opis zastosowanych filtrów.
		$desc  = array();
		$names = array( 'status' => 'Status', 'typ' => 'Typ', 'user_name' => 'Wnioskujący', 'decided_name' => 'Rozpatrzył' );
		foreach ( (array) ( $p['f'] ?? array() ) as $k => $v ) {
			if ( '' === $v || ! isset( $names[ $k ] ) ) {
				continue;
			}
			$shown  = 'status' === $k ? ( $labels[ $v ] ?? $v ) : ( 'typ' === $k ? ( 'sprawdzenie' === $v ? 'Sprawdzenie stanu' : 'Pobranie' ) : $v );
			$desc[] = $names[ $k ] . ': ' . $shown;
		}
		if ( ! empty( $p['min']['data'] ) || ! empty( $p['max']['data'] ) ) {
			$desc[] = 'Złożono: ' . ( ! empty( $p['min']['data'] ) ? 'od ' . mysql2date( 'd.m.Y', $p['min']['data'] ) . ' ' : '' ) . ( ! empty( $p['max']['data'] ) ? 'do ' . mysql2date( 'd.m.Y', $p['max']['data'] ) : '' );
		}
		if ( ! empty( $p['q'] ) ) {
			$desc[] = 'Szukaj: „' . $p['q'] . '”';
		}

		$title = 'Zestawienie wniosków o pobranie';
		self::head( $title, true );
		?>
<style>
.hd{display:flex;justify-content:space-between;align-items:flex-end;padding-bottom:3mm;border-bottom:1.5px solid #0b1020;margin-bottom:3mm}
.hd img{height:12mm}
.hd h1{margin:0;font-size:14pt;font-weight:800;letter-spacing:-.02em;text-align:right}
.hd .meta{font-size:7.5pt;color:#6b7285;text-align:right}
.flt{font-size:8pt;margin-bottom:3mm}
table{font-size:8pt}
tr{page-break-inside:avoid}
thead{display:table-header-group}
.chk{width:5mm;height:5mm;border:1px solid #0b1020;border-radius:1mm;display:inline-block}
.sum{margin-top:3mm;font-size:8.5pt;font-weight:600}
.ft{display:flex;justify-content:space-between;font-size:6.5pt;color:#6b7285;margin-top:6mm}
</style>
<div class="sheet">
  <div class="hd">
    <img src="<?php echo esc_url( MSM_URL . 'assets/logo.svg?v=' . MSM_VERSION ); ?>" alt="Kisielewski">
    <div><h1><?php echo esc_html( $title ); ?></h1><div class="meta">Magazyn: <?php echo esc_html( msm_opt( 'magazyn_nazwa' ) ); ?> · wydrukował <?php echo esc_html( MSM_Repo::user_name() ); ?> · <?php echo esc_html( current_time( 'd.m.Y H:i' ) ); ?></div></div>
  </div>
  <div class="flt"><b>Filtry:</b> <?php echo $desc ? esc_html( implode( ' · ', $desc ) ) : 'brak (wszystkie wnioski)'; ?></div>
  <table>
    <thead><tr>
      <th style="width:22mm">Nr</th><th style="width:22mm">Złożono</th><th style="width:20mm">Typ</th><th style="width:28mm">Wnioskujący</th>
      <th>Materiał</th><th class="n" style="width:16mm">Ilość</th><th style="width:20mm">Zlecenie</th><th style="width:22mm">Rysunek</th><th>Cel / uwagi</th>
      <th style="width:22mm">Status</th><th style="width:26mm">Rozpatrzył</th><th style="width:15mm;text-align:center">Wydano</th>
    </tr></thead>
    <tbody>
    <?php if ( ! $res['rows'] ) : ?>
      <tr><td colspan="12" class="muted" style="text-align:center;padding:6mm">Brak wniosków spełniających kryteria.</td></tr>
    <?php endif; ?>
    <?php
    foreach ( $res['rows'] as $r ) :
        $raw = MSM_Repo::get( 'wnioski', $r['id'] );
        ?>
      <tr>
        <td><b><?php echo esc_html( self::doc_no( $raw ) ); ?></b></td>
        <td><?php echo esc_html( self::dt( $r['data'], 'd.m.Y H:i' ) ); ?></td>
        <td><?php echo 'sprawdzenie' === $r['typ'] ? 'Sprawdzenie' : 'Pobranie'; ?></td>
        <td><?php echo esc_html( $r['user_name'] ); ?></td>
        <td><?php echo esc_html( $r['material'] ); ?><br><span class="muted" style="font-size:7pt"><?php echo esc_html( $schema[ $r['item_table'] ]['label'] ?? '' ); ?></span></td>
        <td class="n"><b><?php echo esc_html( self::n( $r['ilosc'], 3 ) . ' ' . $r['jednostka'] ); ?></b><?php if ( MSM_Calc::odc_txt( $r ) ) : ?><br><small><?php echo esc_html( MSM_Calc::odc_txt( $r ) ); ?></small><?php endif; ?></td>
        <td><?php echo esc_html( (string) $r['zlecenie'] ); ?></td>
        <td><?php echo esc_html( (string) ( $r['rysunek'] ?? '' ) ); ?></td>
        <td><?php echo esc_html( (string) $r['uwagi'] ); ?></td>
        <td><?php echo esc_html( $labels[ $r['status'] ] ?? $r['status'] ); ?></td>
        <td><?php echo esc_html( (string) $r['decided_name'] ); ?><?php echo $r['decided_at'] ? '<br><span class="muted" style="font-size:7pt">' . esc_html( self::dt( $r['decided_at'], 'd.m.Y H:i' ) ) . '</span>' : ''; ?></td>
        <td style="text-align:center"><?php echo 'wydany' === $r['status'] ? '✔' : '<span class="chk"></span>'; ?></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  <div class="sum">Razem wniosków: <?php echo (int) $res['total']; ?></div>
  <div class="ft"><span>© Copyright by <?php echo esc_html( msm_opt( 'firma_nazwa' ) ); ?></span><span>Zestawienie z systemu magazynowego</span></div>
</div>
<script>window.addEventListener('load',function(){setTimeout(function(){window.print();},300);});</script>
</body></html>
		<?php
	}

	/* ------------------------------------------------------------------ *
	 * Zestawienie pozycji magazynowych (zaznaczone albo wg filtrów) – A4
	 * ------------------------------------------------------------------ */

	private static function stock_listing( $t ) {
		global $wpdb;
		if ( ! in_array( $t, msm_editable_tables(), true ) || ! MSM_Rest::table_allowed( $t ) ) {
			wp_die( 'Nieznana lista.', 400 );
		}
		$def  = msm_schema()[ $t ];
		$unit = msm_unit( $t );
		$cols = array_values( array_filter( $def['cols'], function ( $c ) {
			return empty( $c['hidden'] );
		} ) );

		$ids = array();
		if ( isset( $_GET['ids'] ) ) { // phpcs:ignore
			$ids = array_slice( array_values( array_unique( array_filter( array_map( 'intval', explode( ',', (string) wp_unslash( $_GET['ids'] ) ) ) ) ) ), 0, 3000 ); // phpcs:ignore
		}
		if ( $ids ) {
			$place = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
			$raw   = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `" . msm_table( $t ) . "` WHERE id IN ($place)", $ids ), ARRAY_A ); // phpcs:ignore
			$pos   = array_flip( $ids );
			usort( $raw, function ( $a, $b ) use ( $pos ) {
				return ( $pos[ (int) $a['id'] ] ?? 0 ) <=> ( $pos[ (int) $b['id'] ] ?? 0 );
			} );
			$rows     = array_map( function ( $r ) use ( $t ) { return MSM_Repo::cast_row( $t, $r ); }, $raw );
			$subtitle = 'Zaznaczone pozycje: ' . count( $rows );
		} else {
			$p = array(
				'q'        => isset( $_GET['q'] ) ? sanitize_text_field( wp_unslash( $_GET['q'] ) ) : null, // phpcs:ignore
				'f'        => isset( $_GET['f'] ) ? map_deep( wp_unslash( (array) $_GET['f'] ), 'sanitize_text_field' ) : array(), // phpcs:ignore
				'min'      => isset( $_GET['min'] ) ? map_deep( wp_unslash( (array) $_GET['min'] ), 'sanitize_text_field' ) : array(), // phpcs:ignore
				'max'      => isset( $_GET['max'] ) ? map_deep( wp_unslash( (array) $_GET['max'] ), 'sanitize_text_field' ) : array(), // phpcs:ignore
				'orderby'  => isset( $_GET['orderby'] ) ? sanitize_key( wp_unslash( $_GET['orderby'] ) ) : null, // phpcs:ignore
				'order'    => isset( $_GET['order'] ) ? sanitize_key( wp_unslash( $_GET['order'] ) ) : null, // phpcs:ignore
				'hide_zero' => ! empty( $_GET['hide_zero'] ) ? 1 : '', // phpcs:ignore
				'per_page' => 0,
				'page'     => 1,
			);
			$p    = array_filter( $p, function ( $v ) { return null !== $v; } );
			$res  = MSM_Repo::query( $t, $p );
			$rows = $res['rows'];
			$lbl  = array();
			foreach ( $cols as $c ) { $lbl[ $c['key'] ] = $c['label']; }
			$desc = array();
			foreach ( (array) ( $p['f'] ?? array() ) as $k => $v ) { if ( '' !== $v && isset( $lbl[ $k ] ) ) { $desc[] = $lbl[ $k ] . ': ' . $v; } }
			foreach ( (array) ( $p['min'] ?? array() ) as $k => $v ) { if ( '' !== $v && isset( $lbl[ $k ] ) ) { $desc[] = $lbl[ $k ] . ' od ' . $v . ( ! empty( $p['max'][ $k ] ) ? ' do ' . $p['max'][ $k ] : '' ); } }
			foreach ( (array) ( $p['max'] ?? array() ) as $k => $v ) { if ( '' !== $v && isset( $lbl[ $k ] ) && empty( $p['min'][ $k ] ) ) { $desc[] = $lbl[ $k ] . ' do ' . $v; } }
			if ( ! empty( $p['q'] ) ) { $desc[] = 'Szukaj: „' . $p['q'] . '”'; }
			if ( ! empty( $p['hide_zero'] ) ) { $desc[] = 'tylko dostępne (stan > 0)'; }
			$subtitle = $desc ? implode( ' · ', $desc ) : 'wszystkie pozycje';
		}

		$sums  = array();
		foreach ( $cols as $c ) {
			if ( ! empty( $c['sum'] ) ) { $sums[ $c['key'] ] = 0; }
		}
		foreach ( $rows as $r ) {
			foreach ( $sums as $k => $v ) { $sums[ $k ] += (float) ( $r[ $k ] ?? 0 ); }
		}

		$title = 'Zestawienie: ' . $def['label'];
		self::head( $title, true );
		?>
<style>
.hd{display:flex;justify-content:space-between;align-items:flex-end;padding-bottom:3mm;border-bottom:1.5px solid #0b1020;margin-bottom:3mm}
.hd img{height:12mm}
.hd h1{margin:0;font-size:14pt;font-weight:800;letter-spacing:-.02em;text-align:right}
.hd .meta{font-size:7.5pt;color:#6b7285;text-align:right}
.flt{font-size:8pt;margin-bottom:3mm}
table{font-size:8pt}
tr{page-break-inside:avoid}
thead{display:table-header-group}
tfoot td{font-weight:800;background:#f2f4f8}
.ft{display:flex;justify-content:space-between;font-size:6.5pt;color:#6b7285;margin-top:6mm}
</style>
<div class="sheet">
  <div class="hd">
    <img src="<?php echo esc_url( MSM_URL . 'assets/logo.svg?v=' . MSM_VERSION ); ?>" alt="Kisielewski">
    <div><h1><?php echo esc_html( $title ); ?></h1><div class="meta">Magazyn: <?php echo esc_html( msm_opt( 'magazyn_nazwa' ) ); ?> · wydrukował <?php echo esc_html( MSM_Repo::user_name() ); ?> · <?php echo esc_html( current_time( 'd.m.Y H:i' ) ); ?></div></div>
  </div>
  <div class="flt"><b>Zakres:</b> <?php echo esc_html( $subtitle ); ?> · pozycji: <?php echo count( $rows ); ?></div>
  <table>
    <thead><tr>
      <th class="n" style="width:9mm">Lp.</th>
      <?php foreach ( $cols as $c ) : $num = in_array( $c['type'], array( 'num', 'int' ), true ); ?>
        <th class="<?php echo $num ? 'n' : ''; ?>"><?php echo esc_html( $c['label'] ); ?></th>
      <?php endforeach; ?>
    </tr></thead>
    <tbody>
    <?php if ( ! $rows ) : ?>
      <tr><td colspan="<?php echo count( $cols ) + 1; ?>" class="muted" style="text-align:center;padding:6mm">Brak pozycji.</td></tr>
    <?php endif; ?>
    <?php $i = 0; foreach ( $rows as $r ) : $i++; ?>
      <tr>
        <td class="n"><?php echo $i; ?>.</td>
        <?php foreach ( $cols as $c ) : $num = in_array( $c['type'], array( 'num', 'int' ), true ); $v = $r[ $c['key'] ] ?? ''; ?>
          <td class="<?php echo $num ? 'n' : ''; ?>"><?php
            if ( $num && '' !== $v && null !== $v ) { $fv = self::n( $v, isset( $c['decimals'] ) ? $c['decimals'] : ( 'int' === $c['type'] ? 0 : 3 ) ); echo esc_html( '' === $fv && is_numeric( $v ) ? '0' : $fv ); }
            else { echo esc_html( (string) $v ); }
          ?></td>
        <?php endforeach; ?>
      </tr>
    <?php endforeach; ?>
    </tbody>
    <?php if ( $rows && $sums ) : ?>
    <tfoot><tr>
      <td class="n">&nbsp;</td>
      <?php foreach ( $cols as $c ) : $num = in_array( $c['type'], array( 'num', 'int' ), true ); ?>
        <td class="<?php echo $num ? 'n' : ''; ?>"><?php
          if ( 'ilosc' === $c['key'] ) { echo esc_html( 'Razem: ' . self::n( $sums['ilosc'], 'int' === $c['type'] ? 0 : 3 ) . ' ' . $unit ); }
          elseif ( isset( $sums[ $c['key'] ] ) ) { echo esc_html( self::n( $sums[ $c['key'] ], isset( $c['decimals'] ) ? $c['decimals'] : 2 ) ); }
          else { echo '&nbsp;'; }
        ?></td>
      <?php endforeach; ?>
    </tr></tfoot>
    <?php endif; ?>
  </table>
  <div class="ft"><span>© Copyright by <?php echo esc_html( msm_opt( 'firma_nazwa' ) ); ?></span><span>Dokument z systemu magazynowego</span></div>
</div>
</body></html>
		<?php
	}

	/* ------------------------------------------------------------------ *
	 * Do zamówienia – blachy pełne (grupowane, z rozbiciem na rozmiary)
	 * ------------------------------------------------------------------ */
	private static function zamowienia() {
		$gat  = isset( $_GET['gat'] ) ? explode( '|', (string) wp_unslash( $_GET['gat'] ) ) : array();   // phpcs:ignore
		$grub = isset( $_GET['grub'] ) ? explode( '|', (string) wp_unslash( $_GET['grub'] ) ) : array(); // phpcs:ignore
		$rozm = isset( $_GET['rozm'] ) ? explode( '|', (string) wp_unslash( $_GET['rozm'] ) ) : array(); // phpcs:ignore
		$mat  = isset( $_GET['mat'] ) ? array_map( 'sanitize_text_field', explode( '|', (string) wp_unslash( $_GET['mat'] ) ) ) : array(); // phpcs:ignore
		$gat  = array_map( 'sanitize_text_field', $gat );
		$grub = array_map( 'sanitize_text_field', $grub );
		$rozm = array_map( 'sanitize_text_field', $rozm );
		$ids  = isset( $_GET['ids'] ) ? array_filter( array_map( 'intval', explode( ',', (string) wp_unslash( $_GET['ids'] ) ) ) ) : array(); // phpcs:ignore

		$rows = MSM_Reports::low_stock();
		if ( $ids ) {
			// Druk tylko zaznaczonych pozycji (rozmiarów) – po id, z zachowaniem grupowania.
			$set  = array_flip( $ids );
			$rows = array_values( array_filter( array_map( function ( $r ) use ( $set ) {
				$r['sizes'] = array_values( array_filter( $r['sizes'], function ( $s ) use ( $set ) {
					return isset( $set[ (int) ( $s['id'] ?? 0 ) ] );
				} ) );
				return $r['sizes'] ? $r : null;
			}, $rows ) ) );
			$cnt      = 0;
			foreach ( $rows as $r ) { $cnt += count( $r['sizes'] ); }
			$subtitle = 'zaznaczone pozycje: ' . $cnt;
		} else {
			$rows = MSM_Reports::filter_zamowienia( $rows, $gat, $grub, $rozm, $mat );
			$desc = array();
			if ( array_filter( $gat, 'strlen' ) ) { $desc[] = 'Gatunek: ' . implode( ', ', array_filter( $gat, 'strlen' ) ); }
			if ( array_filter( $mat, 'strlen' ) ) { $desc[] = 'Materiał: ' . implode( ', ', array_filter( $mat, 'strlen' ) ); }
			if ( array_filter( $grub, 'strlen' ) ) { $desc[] = 'Grubość: ' . implode( ', ', array_filter( $grub, 'strlen' ) ) . ' mm'; }
			if ( array_filter( $rozm, 'strlen' ) ) { $desc[] = 'Rozmiar: ' . implode( ', ', array_filter( $rozm, 'strlen' ) ); }
			$subtitle = $desc ? implode( ' · ', $desc ) : 'wszystkie blachy poniżej stanu minimalnego';
		}

		$title = 'Do zamówienia – blachy pełne';
		self::head( $title );
		?>
<style>
.hd{display:flex;justify-content:space-between;align-items:flex-end;padding-bottom:3mm;border-bottom:1.5px solid #0b1020;margin-bottom:3mm}
.hd img{height:12mm}
.hd h1{margin:0;font-size:14pt;font-weight:800;letter-spacing:-.02em;text-align:right}
.hd .meta{font-size:7.5pt;color:#6b7285;text-align:right}
.flt{font-size:8pt;margin-bottom:3mm}
tr{page-break-inside:avoid}
thead{display:table-header-group}
td.brak{color:#b3261e;font-weight:800}
td.ok{color:#1c6b43;font-weight:600}
.ft{display:flex;justify-content:space-between;font-size:6.5pt;color:#6b7285;margin-top:6mm}
</style>
<div class="sheet">
  <div class="hd">
    <img src="<?php echo esc_url( MSM_URL . 'assets/logo.svg?v=' . MSM_VERSION ); ?>" alt="Kisielewski">
    <div><h1><?php echo esc_html( $title ); ?></h1><div class="meta">Magazyn: <?php echo esc_html( msm_opt( 'magazyn_nazwa' ) ); ?> · wydrukował <?php echo esc_html( MSM_Repo::user_name() ); ?> · <?php echo esc_html( current_time( 'd.m.Y H:i' ) ); ?></div></div>
  </div>
  <div class="flt"><b>Zakres:</b> <?php echo esc_html( $subtitle ); ?> · blach: <?php echo count( $rows ); ?></div>
  <table>
    <thead><tr>
      <th class="n" style="width:9mm">Lp.</th>
      <th>Blacha</th>
      <th>Rozmiar</th>
      <th class="n">Stan</th>
      <th class="n">Min.</th>
      <th class="n">Brakuje</th>
    </tr></thead>
    <tbody>
    <?php if ( ! $rows ) : ?>
      <tr><td colspan="6" class="muted" style="text-align:center;padding:6mm">Brak blach do zamówienia.</td></tr>
    <?php endif; ?>
    <?php $i = 0; foreach ( $rows as $r ) : $i++; $sizes = $r['sizes']; $n = max( 1, count( $sizes ) ); ?>
      <?php foreach ( $sizes as $j => $s ) : ?>
      <tr>
        <?php if ( 0 === $j ) : ?>
          <td class="n" rowspan="<?php echo (int) $n; ?>"><?php echo (int) $i; ?>.</td>
          <td rowspan="<?php echo (int) $n; ?>"><b><?php echo esc_html( $r['nazwa'] ); ?></b></td>
        <?php endif; ?>
        <td><?php echo esc_html( $s['rozmiar'] ); ?><?php if ( ! empty( $s['opis'] ) ) : ?> <span class="muted">(<?php echo esc_html( $s['opis'] ); ?>)</span><?php endif; ?></td>
        <td class="n"><?php echo esc_html( self::n( $s['ilosc'], 0 ) ); ?> szt</td>
        <td class="n"><?php echo $s['min_stan'] > 0 ? esc_html( self::n( $s['min_stan'], 0 ) . ' szt.' ) : '—'; ?></td>
        <?php if ( ! empty( $s['low'] ) ) : ?>
          <td class="n brak"><?php echo esc_html( self::n( $s['brak'], 0 ) ); ?> szt</td>
        <?php else : ?>
          <td class="n ok">na stanie</td>
        <?php endif; ?>
      </tr>
      <?php endforeach; ?>
    <?php endforeach; ?>
    </tbody>
  </table>
  <div class="ft"><span>© Copyright by <?php echo esc_html( msm_opt( 'firma_nazwa' ) ); ?></span><span>Lista do zamówienia – system magazynowy</span></div>
</div>
</body></html>
		<?php
	}

}
