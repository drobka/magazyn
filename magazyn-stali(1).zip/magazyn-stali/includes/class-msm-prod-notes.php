<?php
/**
 * Produkcja – Notatki do zleceń.
 *
 * Wiele notatek na zlecenie (dziennik): treść z prostym formatowaniem (MSM_Rich), autor, data dodania i ostatniej zmiany.
 * Dodawać, poprawiać i usuwać może każdy z dostępem do Produkcji. Lista „Produkcja → Notatki” pokazuje zlecenia
 * z notatkami (najnowsza notatka na górze).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MSM_Prod_Notes {

	const MAX = 20000; // znaków HTML na notatkę

	public static function TN() {
		global $wpdb;
		return $wpdb->prefix . 'msm_prod_note';
	}

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
	}

	public static function create_tables() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$c = $wpdb->get_charset_collate();
		dbDelta( 'CREATE TABLE ' . self::TN() . " (
id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
zlec_id bigint(20) unsigned NOT NULL,
tresc longtext NULL,
created_at datetime NULL,
created_by bigint(20) unsigned NOT NULL DEFAULT 0,
updated_at datetime NULL,
updated_by bigint(20) unsigned NOT NULL DEFAULT 0,
wykonano_at datetime NULL,
wykonano_by bigint(20) unsigned NOT NULL DEFAULT 0,
PRIMARY KEY  (id),
KEY zlec (zlec_id),
KEY created (created_at),
KEY wykonano (wykonano_at)
) $c;" );
	}

	private static function ready() {
		global $wpdb;
		static $ok = null;
		if ( null === $ok ) {
			$ok = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', self::TN() ) ) === self::TN();
		}
		return $ok;
	}

	public static function routes() {
		$ns = MSM_Rest::NS;
		$p  = array( 'MSM_Prod', 'can' );
		register_rest_route( $ns, '/prod/order/(?P<id>\d+)/notatki', array(
			array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'list_r' ), 'permission_callback' => $p ),
			array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'add_r' ), 'permission_callback' => $p ),
		) );
		register_rest_route( $ns, '/prod/notatka/(?P<id>\d+)', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'save_r' ), 'permission_callback' => $p ) );
		register_rest_route( $ns, '/prod/notatka/(?P<id>\d+)/wykonano', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'done_r' ), 'permission_callback' => $p ) );
		register_rest_route( $ns, '/prod/notatka/(?P<id>\d+)/delete', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'delete_r' ), 'permission_callback' => $p ) );
		register_rest_route( $ns, '/prod/notatki', array(
			'methods'             => 'GET',
			'callback'            => array( __CLASS__, 'all_r' ),
			'permission_callback' => function () {
				$c = MSM_Prod::can();
				if ( is_wp_error( $c ) ) {
					return $c;
				}
				return MSM_Perms::is_wp_admin() || MSM_Perms::menu_on( 'prod_notatki' ) ? true : new WP_Error( 'msm_forbidden', 'Lista Notatek jest dla Ciebie wyłączona.', array( 'status' => 403 ) );
			},
		) );
	}

	/* ---------------- dane ---------------- */

	private static function names( array $ids ) {
		$out = array();
		foreach ( array_unique( array_filter( array_map( 'intval', $ids ) ) ) as $id ) {
			$u          = get_userdata( $id );
			$out[ $id ] = $u ? $u->display_name : 'użytkownik #' . $id;
		}
		return $out;
	}

	private static function cast( array $n, array $names ) {
		$c = (int) $n['created_by'];
		$u = (int) $n['updated_by'];
		return array(
			'id'         => (int) $n['id'],
			'zlec_id'    => (int) $n['zlec_id'],
			'tresc'      => (string) $n['tresc'],
			'autor'      => $c ? ( $names[ $c ] ?? '' ) : 'system',
			'created_at' => (string) $n['created_at'],
			'updated_at' => $n['updated_at'] !== $n['created_at'] ? (string) $n['updated_at'] : '',
			'zmienil'    => $n['updated_at'] !== $n['created_at'] && $u ? ( $names[ $u ] ?? '' ) : '',
			'moje'       => self::can_change( $n ),
			'wykonano'   => ! empty( $n['wykonano_at'] ),
			'wykonano_at' => (string) ( $n['wykonano_at'] ?? '' ),
			'wykonal'    => ! empty( $n['wykonano_at'] ) && ! empty( $n['wykonano_by'] ) ? ( $names[ (int) $n['wykonano_by'] ] ?? '' ) : '',
		);
	}

	/** 1.84.0: poprawianie i usuwanie notatki – autor albo administrator magazynu. */
	private static function can_change( array $n ) {
		return (int) $n['created_by'] === get_current_user_id() || current_user_can( 'msm_edit' ) || MSM_Perms::is_wp_admin();
	}

	private static function get( $id ) {
		global $wpdb;
		$n = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM `' . self::TN() . '` WHERE id = %d', (int) $id ), ARRAY_A ); // phpcs:ignore
		return $n ?: null;
	}

	/** Notatki zlecenia: najpierw do wykonania (najnowsze na górze), potem wykonane (ostatnio wykonane na górze). */
	public static function for_order( $zid ) {
		global $wpdb;
		if ( ! self::ready() ) {
			return array();
		}
		$ns    = (array) $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM `' . self::TN() . '` WHERE zlec_id = %d ORDER BY wykonano_at IS NOT NULL, wykonano_at DESC, created_at DESC, id DESC', (int) $zid ), ARRAY_A ); // phpcs:ignore
		$names = self::names( array_merge( wp_list_pluck( $ns, 'created_by' ), wp_list_pluck( $ns, 'updated_by' ), wp_list_pluck( $ns, 'wykonano_by' ) ) );
		return array_map( function ( $n ) use ( $names ) { return self::cast( $n, $names ); }, $ns );
	}

	/** Liczba notatek i ich tekst (do wyszukiwania na liście zleceń): [ zlec_id => [n, tekst] ]. */
	public static function summary( array $zids ) {
		global $wpdb;
		$zids = array_filter( array_map( 'intval', $zids ) );
		if ( ! $zids || ! self::ready() ) {
			return array();
		}
		$out = array();
		foreach ( (array) $wpdb->get_results( 'SELECT zlec_id, tresc, wykonano_at FROM `' . self::TN() . '` WHERE zlec_id IN (' . implode( ',', $zids ) . ')', ARRAY_A ) as $n ) { // phpcs:ignore
			$z = (int) $n['zlec_id'];
			if ( ! isset( $out[ $z ] ) ) {
				$out[ $z ] = array( 0, '' );
			}
			if ( empty( $n['wykonano_at'] ) ) {
				$out[ $z ][0]++; // licznik na zakładce: tylko do wykonania
			}
			if ( mb_strlen( $out[ $z ][1] ) < 3000 ) {
				$out[ $z ][1] .= ' ' . MSM_Rich::text( (string) $n['tresc'] );
			}
		}
		return $out;
	}

	public static function delete_for_order( $zid ) {
		global $wpdb;
		if ( self::ready() ) {
			$wpdb->delete( self::TN(), array( 'zlec_id' => (int) $zid ) );
		}
	}

	/** Krótki opis notatki (bez formatowania) – do Historii zmian. */
	private static function short( $html, $len = 120 ) {
		$t = trim( preg_replace( '/\s+/u', ' ', MSM_Rich::text( (string) $html ) ) );
		return mb_strlen( $t ) > $len ? mb_substr( $t, 0, $len - 1 ) . '…' : $t;
	}

	private static function clean( $v ) {
		$h = MSM_Rich::clean( mb_substr( (string) $v, 0, self::MAX ) );
		return '' === trim( MSM_Rich::text( $h ) ) ? '' : $h;
	}

	private static function order_label( $zid ) {
		$o = MSM_Prod::get_order_public( (int) $zid );
		return $o ? ( '' !== (string) $o['nr_zlec'] ? $o['nr_zlec'] : '#' . $o['id'] ) : '#' . (int) $zid;
	}

	/* ---------------- REST ---------------- */

	public static function list_r( WP_REST_Request $r ) {
		if ( ! MSM_Prod::get_order_public( (int) $r['id'] ) ) {
			return new WP_Error( 'msm_404', 'Zlecenie nie istnieje.', array( 'status' => 404 ) );
		}
		return rest_ensure_response( array( 'notatki' => self::for_order( (int) $r['id'] ) ) );
	}

	public static function add_r( WP_REST_Request $r ) {
		global $wpdb;
		$zid = (int) $r['id'];
		if ( ! MSM_Prod::get_order_public( $zid ) ) {
			return new WP_Error( 'msm_404', 'Zlecenie nie istnieje.', array( 'status' => 404 ) );
		}
		$t = self::clean( $r->get_param( 'tresc' ) );
		if ( '' === $t ) {
			return new WP_Error( 'msm_400', 'Notatka jest pusta.', array( 'status' => 400 ) );
		}
		$now = current_time( 'mysql' );
		$uid = get_current_user_id();
		$wpdb->insert( self::TN(), array( 'zlec_id' => $zid, 'tresc' => $t, 'created_at' => $now, 'created_by' => $uid, 'updated_at' => $now, 'updated_by' => $uid ) );
		$id = (int) $wpdb->insert_id;
		MSM_Repo::log( 'Produkcja: notatka', 'produkcja', $zid, 'Zlecenie ' . self::order_label( $zid ) . ' – nowa notatka: ' . self::short( $t ) );
		return rest_ensure_response( array( 'id' => $id, 'notatki' => self::for_order( $zid ) ) );
	}

	public static function save_r( WP_REST_Request $r ) {
		global $wpdb;
		$n = self::get( (int) $r['id'] );
		if ( ! $n ) {
			return new WP_Error( 'msm_404', 'Notatka nie istnieje (mogła zostać usunięta).', array( 'status' => 404 ) );
		}
		if ( ! self::can_change( $n ) ) {
			return new WP_Error( 'msm_forbidden', 'Cudzą notatkę może zmienić lub usunąć tylko jej autor albo administrator magazynu.', array( 'status' => 403 ) );
		}
		$t = self::clean( $r->get_param( 'tresc' ) );
		if ( '' === $t ) {
			return new WP_Error( 'msm_400', 'Notatka jest pusta – aby ją usunąć, użyj „Usuń”.', array( 'status' => 400 ) );
		}
		if ( $t !== (string) $n['tresc'] ) {
			$wpdb->update( self::TN(), array( 'tresc' => $t, 'updated_at' => current_time( 'mysql' ), 'updated_by' => get_current_user_id() ), array( 'id' => (int) $n['id'] ) );
			MSM_Repo::log( 'Produkcja: notatka', 'produkcja', (int) $n['zlec_id'], 'Zlecenie ' . self::order_label( $n['zlec_id'] ) . ' – zmieniono notatkę: ' . self::short( $n['tresc'], 60 ) . ' → ' . self::short( $t, 60 ), array( 'przed' => array( 'tresc' => $n['tresc'] ), 'po' => array( 'tresc' => $t ) ) );
		}
		return rest_ensure_response( array( 'notatki' => self::for_order( (int) $n['zlec_id'] ) ) );
	}

	/** Oznaczenie notatki jako wykonanej (zostaje w historii, wyszarzona) albo przywrócenie do wykonania. */
	public static function done_r( WP_REST_Request $r ) {
		global $wpdb;
		$n = self::get( (int) $r['id'] );
		if ( ! $n ) {
			return new WP_Error( 'msm_404', 'Notatka nie istnieje (mogła zostać usunięta).', array( 'status' => 404 ) );
		}
		$done = (bool) $r->get_param( 'wykonano' );
		if ( $done === ! empty( $n['wykonano_at'] ) ) {
			return rest_ensure_response( array( 'notatki' => self::for_order( (int) $n['zlec_id'] ) ) );
		}
		$wpdb->update( self::TN(), $done ? array( 'wykonano_at' => current_time( 'mysql' ), 'wykonano_by' => get_current_user_id() ) : array( 'wykonano_at' => null, 'wykonano_by' => 0 ), array( 'id' => (int) $n['id'] ) );
		MSM_Repo::log( 'Produkcja: notatka', 'produkcja', (int) $n['zlec_id'], 'Zlecenie ' . self::order_label( $n['zlec_id'] ) . ' – ' . ( $done ? 'wykonano' : 'przywrócono do wykonania' ) . ': ' . self::short( $n['tresc'] ) );
		return rest_ensure_response( array( 'notatki' => self::for_order( (int) $n['zlec_id'] ) ) );
	}

	public static function delete_r( WP_REST_Request $r ) {
		global $wpdb;
		$n = self::get( (int) $r['id'] );
		if ( ! $n ) {
			return new WP_Error( 'msm_404', 'Notatka nie istnieje (mogła zostać usunięta).', array( 'status' => 404 ) );
		}
		if ( ! self::can_change( $n ) ) {
			return new WP_Error( 'msm_forbidden', 'Cudzą notatkę może zmienić lub usunąć tylko jej autor albo administrator magazynu.', array( 'status' => 403 ) );
		}
		$wpdb->delete( self::TN(), array( 'id' => (int) $n['id'] ) );
		MSM_Repo::log( 'Produkcja: notatka', 'produkcja', (int) $n['zlec_id'], 'Zlecenie ' . self::order_label( $n['zlec_id'] ) . ' – usunięto notatkę: ' . self::short( $n['tresc'] ), array( 'przed' => $n ) );
		return rest_ensure_response( array( 'notatki' => self::for_order( (int) $n['zlec_id'] ) ) );
	}

	/** GET /prod/notatki – zlecenia z notatkami (wszystkie lata), z ostatnią notatką; najświeższe na górze. */
	public static function all_r() {
		global $wpdb;
		if ( ! self::ready() ) {
			return rest_ensure_response( array( 'zlecenia' => array() ) );
		}
		$TN = self::TN();
		$TZ = MSM_Prod::TZ();
		// Ostatnia notatka każdego zlecenia + liczba notatek (tylko istniejące zlecenia).
		$rows = (array) $wpdb->get_results( // phpcs:ignore
			"SELECT n.*, z.nr_zlec, z.klient, z.arkusz, z.nr_zlec_klienta, c.ile, c.wyk
			FROM `$TN` n
			INNER JOIN `$TZ` z ON z.id = n.zlec_id
			INNER JOIN ( SELECT zlec_id, COUNT(*) AS ile, SUM(wykonano_at IS NOT NULL) AS wyk FROM `$TN` GROUP BY zlec_id ) c ON c.zlec_id = n.zlec_id
			WHERE n.id = ( SELECT n2.id FROM `$TN` n2 WHERE n2.zlec_id = n.zlec_id ORDER BY n2.wykonano_at IS NOT NULL, n2.created_at DESC, n2.id DESC LIMIT 1 )
			ORDER BY n.created_at DESC, n.id DESC",
			ARRAY_A
		);
		$names = self::names( array_merge( wp_list_pluck( $rows, 'created_by' ), wp_list_pluck( $rows, 'updated_by' ), wp_list_pluck( $rows, 'wykonano_by' ) ) );
		$out   = array();
		foreach ( $rows as $n ) {
			$c          = self::cast( $n, $names );
			$c['tekst'] = MSM_Rich::text( (string) $n['tresc'] );
			$out[]      = array(
				'zlec_id'         => (int) $n['zlec_id'],
				'nr_zlec'         => (string) $n['nr_zlec'],
				'klient'          => (string) $n['klient'],
				'nr_zlec_klienta' => (string) $n['nr_zlec_klienta'],
				'rok'             => (string) $n['arkusz'],
				'ile'             => (int) $n['ile'],
				'wyk'             => (int) $n['wyk'],
				'ostatnia'        => $c,
			);
		}
		return rest_ensure_response( array( 'zlecenia' => $out ) );
	}
}
