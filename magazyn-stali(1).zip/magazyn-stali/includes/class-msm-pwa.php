<?php
/**
 * Aplikacja na telefon (PWA): manifest, service worker, ikony.
 *
 * - Magazyn można „zainstalować” na ekranie głównym telefonu/komputera (osobne okno, bez paska przeglądarki).
 * - Service worker trzyma w pamięci tylko pliki statyczne wtyczki (CSS, JS, czcionki, ikony).
 *   Strony aplikacji (zawiera dane i klucz sesji) ani odpowiedzi API NIGDY nie są zapisywane –
 *   po wylogowaniu na wspólnym telefonie nic z magazynu nie zostaje w pamięci.
 * - Bez sieci zamiast błędu przeglądarki pokazuje się czytelny ekran „Brak połączenia”.
 * - Powiadomienia systemowe o nowych wnioskach / WZ do zatwierdzenia (gdy aplikacja jest otwarta,
 *   także zminimalizowana lub w tle).
 *
 * Service worker i manifest są serwowane z adresu głównego witryny (/?msm_sw=1), dzięki czemu
 * mogą obsługiwać stronę /magazyn/ bez dodatkowej konfiguracji serwera.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MSM_Pwa {

	const THEME = '#0E58A4';

	public static function init() {
		add_action( 'init', array( __CLASS__, 'serve' ), 1 );
		add_action( 'wp_head', array( __CLASS__, 'head' ), 2 );
	}

	public static function sw_url() {
		return add_query_arg( 'msm_sw', MSM_VERSION, home_url( '/' ) );
	}

	public static function manifest_url() {
		return add_query_arg( 'msm_manifest', MSM_VERSION, home_url( '/' ) );
	}

	/** Ścieżka (bez domeny) strony aplikacji – zakres działania service workera. */
	public static function scope() {
		$path = wp_parse_url( MSM_Access::app_url(), PHP_URL_PATH );
		return trailingslashit( $path ? $path : '/' );
	}

	public static function head() {
		if ( ! class_exists( 'MSM_Front' ) || ! MSM_Front::is_app_page() ) {
			return;
		}
		// use-credentials: część serwerów/zabezpieczeń odrzuca żądania bez ciasteczek – manifest musi dojść zawsze.
		echo '<link rel="manifest" href="' . esc_url( self::manifest_url() ) . '" crossorigin="use-credentials">' . "\n";
		echo '<meta name="theme-color" content="' . esc_attr( self::THEME ) . '">' . "\n";
		echo '<meta name="mobile-web-app-capable" content="yes">' . "\n";
		echo '<meta name="apple-mobile-web-app-capable" content="yes">' . "\n";
		echo '<meta name="apple-mobile-web-app-title" content="Magazyn">' . "\n";
		echo '<link rel="apple-touch-icon" href="' . esc_url( MSM_URL . 'assets/pwa/apple-180.png' ) . '">' . "\n";
	}

	public static function serve() {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		if ( isset( $_GET['msm_manifest'] ) ) {
			self::manifest();
		}
		if ( isset( $_GET['msm_sw'] ) ) {
			self::service_worker();
		}
		// phpcs:enable
	}

	private static function manifest() {
		$firma = class_exists( 'MSM_Settings' ) ? MSM_Settings::get( 'firma_nazwa' ) : '';
		$data  = array(
			'name'             => 'Magazyn' . ( $firma ? ' – ' . $firma : '' ),
			'short_name'       => 'Magazyn',
			'description'      => 'Stany magazynowe, pobrania, wnioski, WZ i PZ.',
			'lang'             => 'pl',
			'start_url'        => self::scope(),
			'scope'            => self::scope(),
			'id'               => self::scope(),
			'display'          => 'standalone',
			'orientation'      => 'any',
			'background_color' => '#ffffff',
			'theme_color'      => self::THEME,
			'icons'            => array(
				array( 'src' => MSM_URL . 'assets/pwa/icon-192.png', 'sizes' => '192x192', 'type' => 'image/png', 'purpose' => 'any maskable' ),
				array( 'src' => MSM_URL . 'assets/pwa/icon-512.png', 'sizes' => '512x512', 'type' => 'image/png', 'purpose' => 'any maskable' ),
			),
			'shortcuts'        => self::shortcuts(),
		);
		header( 'Content-Type: application/manifest+json; charset=utf-8' );
		header( 'Cache-Control: private, max-age=3600' ); // skróty zależą od uprawnień zalogowanej osoby
		header( 'Vary: Cookie' );
		echo wp_json_encode( $data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ); // phpcs:ignore
		exit;
	}

	/**
	 * Skróty po przytrzymaniu ikony aplikacji (Android pokazuje do 4): najpierw szybkie akcje
	 * „Przyjmij PZ” i „Nowa przesyłka”, potem Wnioski i Stal – tylko te, do których osoba ma dostęp.
	 */
	private static function shortcuts() {
		$s    = self::scope();
		$ico  = function ( $n ) { return array( array( 'src' => MSM_URL . 'assets/pwa/sc-' . $n . '.png', 'sizes' => '96x96', 'type' => 'image/png' ) ); };
		$all  = array(
			array( 'Przyjmij PZ', 'PZ – zdjęcie dokumentu', 'Nowe przyjęcie: zdjęcie dokumentu dostawy', $s . '#pz-new', 'pz', function () { return current_user_can( 'msm_edit' ) && MSM_Perms::menu_on( 'pz' ) && MSM_Perms::user_can( 'pz' ); } ),
			array( 'Nowa przesyłka', 'Przesyłka', 'Wpis do rejestru przesyłek przychodzących', $s . '#przesylki-new', 'przesylka', function () { return class_exists( 'MSM_Przesylki' ) && true === MSM_Przesylki::can_view(); } ),
			array( 'Wnioski', 'Wnioski', 'Wnioski o pobranie materiału', $s . '#wnioski', 'wnioski', function () { return MSM_Perms::menu_on( 'wnioski' ); } ),
			array( 'Stal', 'Stal', 'Stany magazynowe – stal', $s . '#stal', 'stal', function () { return MSM_Perms::menu_on( 'stany' ); } ),
		);
		$logged = is_user_logged_in() && current_user_can( 'msm_view' );
		$out    = array();
		foreach ( $all as $a ) {
			if ( $logged && ! call_user_func( $a[5] ) ) {
				continue;
			}
			$out[] = array( 'name' => $a[0], 'short_name' => $a[1], 'description' => $a[2], 'url' => $a[3], 'icons' => $ico( $a[4] ) );
		}
		return array_slice( $out, 0, 4 );
	}

	private static function service_worker() {
		$cfg = array(
			'version' => MSM_VERSION,
			'assets'  => MSM_URL . 'assets/',
			'scope'   => self::scope(),
			'icon'    => MSM_URL . 'assets/pwa/icon-192.png',
		);
		header( 'Content-Type: application/javascript; charset=utf-8' );
		header( 'Cache-Control: no-cache' ); // przeglądarka zawsze sprawdza nową wersję workera
		header( 'Service-Worker-Allowed: ' . self::scope() );
		echo 'var MSM_SW = ' . wp_json_encode( $cfg, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . ";\n"; // phpcs:ignore
		echo self::sw_js(); // phpcs:ignore
		exit;
	}

	private static function sw_js() {
		return <<<'JS'
/* System K-ERP – service worker. Buforuje WYŁĄCZNIE pliki statyczne wtyczki. */
var CACHE = 'msm-static-' + MSM_SW.version;

self.addEventListener('install', function () { self.skipWaiting(); });

self.addEventListener('activate', function (e) {
	e.waitUntil(caches.keys().then(function (keys) {
		return Promise.all(keys.filter(function (k) { return k.indexOf('msm-static-') === 0 && k !== CACHE; }).map(function (k) { return caches.delete(k); }));
	}).then(function () { return self.clients.claim(); }));
});

function offlinePage() {
	var html = '<!DOCTYPE html><html lang="pl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Brak połączenia – Magazyn</title>' +
		'<style>body{margin:0;min-height:100vh;display:grid;place-items:center;font:16px/1.5 system-ui,-apple-system,Segoe UI,sans-serif;background:#f4f6fa;color:#1b2333}' +
		'.c{max-width:340px;padding:32px 28px;background:#fff;border-radius:16px;box-shadow:0 8px 30px rgba(20,30,60,.08);text-align:center}' +
		'h1{font-size:20px;margin:16px 0 6px}p{margin:0 0 20px;color:#5a6274}button{font:inherit;font-weight:600;border:0;border-radius:10px;padding:11px 20px;background:#0E58A4;color:#fff;cursor:pointer}</style></head>' +
		'<body><div class="c"><img src="' + MSM_SW.icon + '" width="64" height="64" alt="" style="border-radius:14px"><h1>Brak połączenia</h1>' +
		'<p>Magazyn potrzebuje internetu, żeby pokazać aktualne dane. Sprawdź Wi-Fi lub dane komórkowe.</p>' +
		'<button onclick="location.reload()">Spróbuj ponownie</button></div></body></html>';
	return new Response(html, { status: 503, headers: { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' } });
}

self.addEventListener('fetch', function (e) {
	var req = e.request;
	if (req.method !== 'GET') return;
	var url = new URL(req.url);

	// Strona aplikacji: zawsze z sieci (dane + klucz sesji – nie zapisujemy), bez sieci → ekran „Brak połączenia”.
	if (req.mode === 'navigate') {
		if (url.pathname.indexOf(MSM_SW.scope) === 0) {
			e.respondWith(fetch(req).catch(offlinePage));
		}
		return;
	}

	// Pliki statyczne wtyczki (z numerem wersji w adresie): najpierw pamięć, w tle odświeżenie.
	if (req.url.indexOf(MSM_SW.assets) === 0 && /\.(css|js|woff2?|svg|png)(\?|$)/.test(req.url)) {
		e.respondWith(caches.open(CACHE).then(function (cache) {
			return cache.match(req).then(function (hit) {
				var net = fetch(req).then(function (res) {
					if (res && res.ok) cache.put(req, res.clone());
					return res;
				});
				return hit || net;
			});
		}));
	}
	// Wszystko inne (REST API, wydruki, skany) – bez udziału workera.
});

// Kliknięcie w powiadomienie: przejdź do otwartego okna magazynu albo je otwórz.
self.addEventListener('notificationclick', function (e) {
	e.notification.close();
	var target = new URL((e.notification.data && e.notification.data.url) || MSM_SW.scope, self.location.origin).href;
	e.waitUntil(self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then(function (list) {
		for (var i = 0; i < list.length; i++) {
			var c = list[i];
			if (new URL(c.url).pathname.indexOf(MSM_SW.scope) === 0 && 'focus' in c) {
				c.postMessage({ type: 'msm-goto', url: target }); // zmiana zakładki bez przeładowania
				return c.focus();
			}
		}
		return self.clients.openWindow(target);
	}));
});
JS;
	}
}
