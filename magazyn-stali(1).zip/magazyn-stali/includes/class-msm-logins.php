<?php
/**
 * Dziennik logowań: kto i kiedy się logował (oraz nieudane próby).
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MSM_Logins {

	public static function init() {
		add_action( 'wp_login', array( __CLASS__, 'on_login' ), 10, 2 );
		add_action( 'wp_login_failed', array( __CLASS__, 'on_failed' ) );
	}

	public static function table() {
		global $wpdb;
		return $wpdb->prefix . 'msm_logins';
	}

	public static function create_table() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$charset = $wpdb->get_charset_collate();
		$T = self::table();
		dbDelta( "CREATE TABLE $T (
id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
czas datetime NOT NULL,
user_id bigint(20) unsigned NULL,
user_login varchar(190) NULL,
display_name varchar(190) NULL,
rola varchar(60) NULL,
ip varchar(64) NULL,
wynik varchar(10) NOT NULL DEFAULT 'ok',
PRIMARY KEY  (id),
KEY czas (czas),
KEY wynik (wynik)
) ENGINE=InnoDB $charset;" );
	}

	private static function ip() {
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
		return mb_substr( $ip, 0, 64 );
	}

	private static function only_msm( $user ) {
		// Logujemy tylko konta mające dostęp do magazynu.
		return $user && ( user_can( $user, 'msm_view' ) || user_can( $user, 'manage_options' ) );
	}

	public static function on_login( $user_login, $user ) {
		if ( ! self::only_msm( $user ) ) {
			return;
		}
		global $wpdb;
		$roles = (array) $user->roles;
		$wpdb->insert( self::table(), array(
			'czas'         => current_time( 'mysql' ),
			'user_id'      => (int) $user->ID,
			'user_login'   => $user_login,
			'display_name' => $user->display_name,
			'rola'         => $roles ? $roles[0] : '',
			'ip'           => self::ip(),
			'wynik'        => 'ok',
		) );
	}

	public static function on_failed( $user_login ) {
		$user = get_user_by( 'login', $user_login );
		if ( ! self::only_msm( $user ) ) {
			return; // nie zaśmiecamy dziennika próbami na nieistniejące/obce konta
		}
		global $wpdb;
		$wpdb->insert( self::table(), array(
			'czas'         => current_time( 'mysql' ),
			'user_id'      => $user ? (int) $user->ID : null,
			'user_login'   => $user_login,
			'display_name' => $user ? $user->display_name : '',
			'rola'         => '',
			'ip'           => self::ip(),
			'wynik'        => 'blad',
		) );
	}

	/** Lista wpisów (dla administratora). */
	public static function listing( $limit = 300 ) {
		global $wpdb;
		$T = self::table();
		$limit = max( 1, min( 1000, (int) $limit ) );
		$rows = $wpdb->get_results( "SELECT czas, display_name, user_login, rola, ip, wynik FROM `$T` ORDER BY id DESC LIMIT $limit", ARRAY_A ); // phpcs:ignore
		return $rows ?: array();
	}
}
