<?php
/**
 * Dostęp do danych: zapytania, zapis, pobrania, historia zmian.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MSM_Repo {

	/* ------------------------------------------------------------------ *
	 * Odczyt
	 * ------------------------------------------------------------------ */

	public static function query( $table, array $p ) {
		global $wpdb;
		$schema = msm_schema();
		$def    = $schema[ $table ];
		$T      = msm_table( $table );
		$cols   = array();
		foreach ( $def['cols'] as $c ) {
			$cols[ $c['key'] ] = $c;
		}

		list( $where, $args ) = self::build_where( $table, $cols, $p );
		$where_sql            = implode( ' AND ', $where );

		// Sortowanie.
		$orderby = isset( $p['orderby'] ) ? (string) $p['orderby'] : $def['default_order'][0];
		$order   = ( isset( $p['order'] ) && 'desc' === strtolower( $p['order'] ) ) ? 'DESC' : 'ASC';
		if ( ! isset( $p['orderby'] ) ) {
			$order = $def['default_order'][1];
		}
		if ( 'id' !== $orderby && ! isset( $cols[ $orderby ] ) ) {
			$orderby = 'id';
		}
		$order_sql = "(`$orderby` IS NULL), `$orderby` $order, `id` " . ( 'id' === $orderby ? $order : 'ASC' );

		// Stronicowanie.
		$per_page = isset( $p['per_page'] ) ? (int) $p['per_page'] : 50;
		$per_page = ( $per_page <= 0 ) ? 5000 : min( 5000, $per_page );
		$page     = max( 1, isset( $p['page'] ) ? (int) $p['page'] : 1 );
		$offset   = ( $page - 1 ) * $per_page;

		// Podsumowania.
		$sum_sql = array( 'COUNT(*) AS n' );
		foreach ( $cols as $k => $c ) {
			if ( ! empty( $c['sum'] ) ) {
				$sum_sql[] = "SUM(`$k`) AS `$k`";
			}
		}
		$sql_sum = 'SELECT ' . implode( ', ', $sum_sql ) . " FROM `$T` WHERE $where_sql";
		$sums    = $wpdb->get_row( $args ? $wpdb->prepare( $sql_sum, $args ) : $sql_sum, ARRAY_A ); // phpcs:ignore
		$total   = (int) $sums['n'];
		unset( $sums['n'] );

		$sql  = "SELECT * FROM `$T` WHERE $where_sql ORDER BY $order_sql LIMIT %d OFFSET %d";
		$rows = $wpdb->get_results( $wpdb->prepare( $sql, array_merge( $args, array( $per_page, $offset ) ) ), ARRAY_A ); // phpcs:ignore

		$cast = array_map( function ( $r ) use ( $table ) {
			return MSM_Repo::cast_row( $table, $r );
		}, $rows );
		if ( ( in_array( $table, msm_stock_tables(), true ) || 'bhp' === $table ) && $cast ) {
			$with = 'bhp' === $table ? self::bhp_items_with_history( wp_list_pluck( $cast, 'id' ) ) : self::items_with_history( $table, wp_list_pluck( $cast, 'id' ) );
			$rezt = class_exists( 'MSM_Rezerwacje' ) && in_array( $table, MSM_Rezerwacje::TABLES, true );
			$rez  = $rezt ? MSM_Rezerwacje::reserved_map( wp_list_pluck( $cast, 'id' ), $table ) : array();
			foreach ( $cast as &$c ) {
				$c['_hist'] = isset( $with[ $c['id'] ] );
				if ( $rezt ) {
					$c['_rez'] = isset( $rez[ $c['id'] ] ) ? 0 + $rez[ $c['id'] ] : 0;
				}
			}
			unset( $c );
		}
		return array(
			'rows'     => $cast,
			'total'    => $total,
			'page'     => $page,
			'per_page' => $per_page,
			'sums'     => array_map( function ( $v ) {
				return null === $v ? null : (float) $v;
			}, $sums ? $sums : array() ),
		);
	}

	private static function build_where( $table, $cols, $p ) {
		$where = array( '1=1' );
		$args  = array();

		// Wyszukiwarka: każde słowo musi pasować do którejś kolumny.
		$q = isset( $p['q'] ) ? trim( (string) $p['q'] ) : '';
		if ( '' !== $q ) {
			$q      = preg_replace( '/(\d)\s*[xX×*]\s*(?=\d)/u', '$1 ', $q );
			$q      = preg_replace( '/(\d)\s*[xX×*]\s*(?=\d)/u', '$1 ', $q );
			$tokens = preg_split( '/\s+/u', $q, -1, PREG_SPLIT_NO_EMPTY );
			foreach ( array_slice( $tokens, 0, 8 ) as $tok ) {
				$or  = array();
				$num = MSM_Calc::f( $tok );
				foreach ( $cols as $k => $c ) {
					if ( in_array( $c['type'], array( 'num', 'int' ), true ) ) {
						if ( null !== $num ) {
							$or[]   = "`$k` = %f";
							$args[] = $num;
						}
					} elseif ( 'bool' !== $c['type'] ) {
						$or[]   = "`$k` LIKE %s";
						$args[] = '%' . $GLOBALS['wpdb']->esc_like( $tok ) . '%';
					}
				}
				if ( $or ) {
					$where[] = '(' . implode( ' OR ', $or ) . ')';
				}
			}
		}

		// Filtry listowe.
		if ( ! empty( $p['f'] ) && is_array( $p['f'] ) ) {
			foreach ( $p['f'] as $k => $vals ) {
				if ( ! isset( $cols[ $k ] ) ) {
					continue;
				}
				$vals = is_array( $vals ) ? $vals : explode( '||', (string) $vals );
				$vals = array_values( array_filter( array_map( 'strval', $vals ), function ( $v ) {
					return '' !== $v;
				} ) );
				if ( ! $vals ) {
					continue;
				}
				$is_text = isset( $cols[ $k ]['filter'] ) && 'text' === $cols[ $k ]['filter'];
				$or = array();
				foreach ( $vals as $v ) {
					if ( '__empty__' === $v ) {
						$or[] = "(`$k` IS NULL OR `$k` = '')";
					} elseif ( $is_text ) {
						$or[]   = "`$k` LIKE %s";
						$args[] = '%' . $GLOBALS['wpdb']->esc_like( $v ) . '%';
					} else {
						$or[]   = "`$k` = %s";
						$args[] = $v;
					}
				}
				$where[] = '(' . implode( ' OR ', $or ) . ')';
			}
		}

		// Wymiary z 'exact_single': wpisane tylko jedno pole (od albo do) = dokładnie ta wartość.
		$p_min = ( ! empty( $p['min'] ) && is_array( $p['min'] ) ) ? $p['min'] : array();
		$p_max = ( ! empty( $p['max'] ) && is_array( $p['max'] ) ) ? $p['max'] : array();
		foreach ( $cols as $k => $c ) {
			if ( empty( $c['exact_single'] ) ) {
				continue;
			}
			$lo = isset( $p_min[ $k ] ) ? MSM_Calc::f( $p_min[ $k ] ) : null;
			$hi = isset( $p_max[ $k ] ) ? MSM_Calc::f( $p_max[ $k ] ) : null;
			if ( ( null === $lo ) !== ( null === $hi ) ) {
				$where[] = "ABS(`$k` - %f) < 0.0005";
				$args[]  = null !== $lo ? $lo : $hi;
				unset( $p_min[ $k ], $p_max[ $k ] );
			}
		}
		$p['min'] = $p_min;
		$p['max'] = $p_max;

		// Zakresy od–do.
		foreach ( array( 'min' => '>=', 'max' => '<=' ) as $pk => $op ) {
			if ( empty( $p[ $pk ] ) || ! is_array( $p[ $pk ] ) ) {
				continue;
			}
			foreach ( $p[ $pk ] as $k => $v ) {
				if ( ! isset( $cols[ $k ] ) || '' === $v || null === $v ) {
					continue;
				}
				$type = $cols[ $k ]['type'];
				if ( 'date' === $type || 'datetime' === $type ) {
					if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $v ) ) {
						continue;
					}
					if ( 'datetime' === $type ) {
						$v .= ( 'min' === $pk ) ? ' 00:00:00' : ' 23:59:59';
					}
					$where[] = "`$k` $op %s";
					$args[]  = $v;
				} else {
					$n = MSM_Calc::f( $v );
					if ( null === $n ) {
						continue;
					}
					$where[] = "`$k` $op %f";
					$args[]  = $n;
				}
			}
		}

		// Przeglądający widzi tylko własne wnioski.
		if ( ! empty( $p['_user'] ) ) {
			$where[] = '`user_id` = %d';
			$args[]  = (int) $p['_user'];
		}

		if ( ! empty( $p['hide_zero'] ) && isset( $cols['ilosc'] ) ) {
			$where[] = '`ilosc` > 0';
		}

		return array( $where, $args );
	}

	/**
	 * Wartości do list wyboru (filtry) i podpowiedzi (formularze).
	 * Z $p: liczone w obrębie pozostałych aktywnych filtrów (bez filtra danej kolumny),
	 * dzięki czemu listy pokazują tylko to, co da wynik.
	 */
	public static function options( $table, array $p = array() ) {
		global $wpdb;
		$T    = msm_table( $table );
		$out  = array();
		$cols = array();
		foreach ( msm_schema()[ $table ]['cols'] as $c ) {
			$cols[ $c['key'] ] = $c;
		}
		foreach ( msm_schema()[ $table ]['cols'] as $c ) {
			if ( empty( $c['filter'] ) && empty( $c['suggest'] ) ) {
				continue;
			}
			if ( 'select' !== ( $c['filter'] ?? '' ) && empty( $c['suggest'] ) ) {
				continue;
			}
			$k  = $c['key'];
			$pp = $p;
			if ( isset( $pp['f'] ) && is_array( $pp['f'] ) ) {
				unset( $pp['f'][ $k ] );
			}
			list( $where, $args ) = self::build_where( $table, $cols, $pp );
			$sql  = "SELECT `$k` AS v, COUNT(*) AS n FROM `$T` WHERE " . implode( ' AND ', $where ) . " GROUP BY `$k` ORDER BY `$k`";
			$rows = $wpdb->get_results( $args ? $wpdb->prepare( $sql, $args ) : $sql, ARRAY_A ); // phpcs:ignore
			$list = array();
			foreach ( $rows as $r ) {
				$v = $r['v'];
				if ( null === $v || '' === $v ) {
					$list[] = array( 'v' => '__empty__', 'label' => '(puste)', 'n' => (int) $r['n'] );
				} else {
					if ( 'bool' === $c['type'] ) {
						$label = $v ? 'tak' : 'nie';
					} elseif ( in_array( $c['type'], array( 'num', 'int' ), true ) ) {
						$label = MSM_Calc::fmt( $v );
					} else {
						$label = (string) $v;
					}
					$list[] = array( 'v' => (string) $v, 'label' => $label, 'n' => (int) $r['n'] );
				}
			}
			$out[ $k ] = $list;
		}
		return $out;
	}

	public static function get( $table, $id, $lock = false ) {
		global $wpdb;
		$T = msm_table( $table );
		$r = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `$T` WHERE id = %d" . ( $lock ? ' FOR UPDATE' : '' ), $id ), ARRAY_A ); // phpcs:ignore
		return $r ? $r : null;
	}

	public static function cast_row( $table, array $r ) {
		$out = array( 'id' => (int) $r['id'] );
		foreach ( msm_schema()[ $table ]['cols'] as $c ) {
			$k = $c['key'];
			$v = isset( $r[ $k ] ) ? $r[ $k ] : null;
			if ( null !== $v ) {
				if ( 'num' === $c['type'] ) {
					$v = (float) $v;
				} elseif ( 'int' === $c['type'] ) {
					$v = (int) $v;
				} elseif ( 'bool' === $c['type'] ) {
					$v = (bool) (int) $v;
				}
			}
			$out[ $k ] = $v;
		}
		if ( 'pobrania' === $table ) {
			$out['item_table'] = $r['item_table'];
			$out['item_id']    = (int) $r['item_id'];
			$out['tryb']       = $r['tryb'];
		}
		if ( 'wnioski' === $table ) {
			foreach ( array( 'item_table', 'tryb', 'decided_at', 'issued_at' ) as $k ) {
				$out[ $k ] = $r[ $k ];
			}
			$out['typ'] = $out['typ'] ? $out['typ'] : 'pobranie';
			$out['item_id']     = (int) $r['item_id'];
			$out['user_id']     = (int) $r['user_id'];
			$out['pobranie_id'] = $r['pobranie_id'] ? (int) $r['pobranie_id'] : null;
			$out['next_id']     = ! empty( $r['next_id'] ) ? (int) $r['next_id'] : null;
		}
		if ( in_array( $table, array( 'wnioski', 'pobrania', 'rezerwacje' ), true ) ) {
			$out['odc_szt'] = isset( $r['odc_szt'] ) && null !== $r['odc_szt'] ? (int) $r['odc_szt'] : null;
			$out['odc_dl']  = isset( $r['odc_dl'] ) && null !== $r['odc_dl'] ? (float) $r['odc_dl'] : null;
			$out['odc_txt'] = MSM_Calc::odc_txt( $r );
		}
		if ( 'rezerwacje' === $table ) {
			$out['user_id'] = (int) ( $r['user_id'] ?? 0 );
			$out['item_id'] = (int) ( $r['item_id'] ?? 0 );
			$out['tryb']    = $r['tryb'] ?? 'szt';
		}
		if ( 'historia' === $table ) {
			$out['dane']    = $r['dane'] ? json_decode( $r['dane'], true ) : null;
			$out['item_id']    = (int) $r['item_id'];
			$out['tabela_key'] = $r['tabela_key'];
		}
		if ( ! empty( $r['updated_at'] ) ) {
			$out['_updated'] = $r['updated_at'];
		}
		return $out;
	}

	/* ------------------------------------------------------------------ *
	 * Walidacja
	 * ------------------------------------------------------------------ */

	/**
	 * @return array|WP_Error
	 */
	public static function sanitize( $table, array $in, $partial = false ) {
		$def    = msm_schema()[ $table ];
		$allow  = isset( $def['editable'] ) ? $def['editable'] : null;
		$out    = array();
		$errors = array();

		// "PRĘT ALUMINIUM" → pręt okrągły, gatunek Al.
		if ( 'stal' === $table && isset( $in['opis'] ) && 'PRĘT ALUMINIUM' === mb_strtoupper( trim( (string) $in['opis'] ), 'UTF-8' ) && empty( $in['gatunek'] ) ) {
			$in['gatunek'] = 'Al';
		}

		foreach ( $def['cols'] as $c ) {
			$k = $c['key'];
			if ( ! empty( $c['computed'] ) || ( null !== $allow && ! in_array( $k, $allow, true ) ) ) {
				continue;
			}
			if ( ! array_key_exists( $k, $in ) ) {
				if ( ! $partial ) {
					$out[ $k ] = array_key_exists( 'default', $c ) ? $c['default'] : ( 'int' === $c['type'] ? 0 : null );
				}
				continue;
			}
			$v = $in[ $k ];
			if ( is_string( $v ) ) {
				$v = trim( wp_unslash( $v ) );
			}
			switch ( $c['type'] ) {
				case 'text':
					$v = ! empty( $c['long'] ) ? sanitize_textarea_field( (string) $v ) : sanitize_text_field( (string) $v );
					$v = MSM_Calc::normalize( $table, $k, $v );
					$v = ( '' === $v ) ? null : mb_substr( $v, 0, ! empty( $c['long'] ) ? 2000 : 190 );
					break;
				case 'enum':
					$v = MSM_Calc::normalize( $table, $k, sanitize_text_field( (string) $v ) );
					if ( '' === $v || null === $v ) {
						$v = array_key_exists( 'default', $c ) ? $c['default'] : null;
					} elseif ( ! in_array( $v, $c['options'], true ) ) {
						$errors[ $k ] = 'Niedozwolona wartość: ' . $v;
					}
					break;
				case 'num':
					if ( null === $v || '' === $v ) {
						$v = null;
					} else {
						$n = MSM_Calc::f( $v );
						if ( null === $n || $n < 0 ) {
							$errors[ $k ] = 'Podaj liczbę ≥ 0';
						}
						$v = $n;
					}
					break;
				case 'int':
					if ( null === $v || '' === $v ) {
						$v = 0;
					} else {
						$n = MSM_Calc::f( $v );
						if ( null === $n || $n < 0 || floor( $n ) != $n ) { // phpcs:ignore
							$errors[ $k ] = 'Podaj liczbę całkowitą ≥ 0';
						}
						$v = (int) $n;
					}
					break;
				case 'bool':
					$v = ( true === $v || 1 === $v || in_array( strtolower( (string) $v ), array( '1', 'true', 'tak', 'yes', 'x' ), true ) ) ? 1 : 0;
					break;
				case 'date':
					if ( null === $v || '' === $v ) {
						$v = null;
					} elseif ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $v ) ) {
						$errors[ $k ] = 'Data w formacie RRRR-MM-DD';
					}
					break;
				default:
					$v = sanitize_text_field( (string) $v );
			}
			$out[ $k ] = $v;
		}

		foreach ( $def['cols'] as $c ) {
			if ( ! empty( $c['required'] ) && array_key_exists( $c['key'], $out ) && ( null === $out[ $c['key'] ] || '' === $out[ $c['key'] ] ) ) {
				$errors[ $c['key'] ] = 'Pole wymagane';
			}
		}

		if ( 'blachy_niepelne' === $table && isset( $out['ksztalt'] ) && 'koło' === $out['ksztalt'] ) {
			$out['wymiar_b'] = null;
		}

		if ( $errors ) {
			return new WP_Error( 'msm_invalid', 'Popraw zaznaczone pola.', array( 'status' => 400, 'fields' => $errors ) );
		}
		return $out;
	}

	/* ------------------------------------------------------------------ *
	 * Zapis
	 * ------------------------------------------------------------------ */

	public static function insert_raw( $table, array $row ) {
		global $wpdb;
		$row               = MSM_Calc::compute( $table, $row );
		$now               = current_time( 'mysql' );
		$row['created_at'] = $now;
		$row['updated_at'] = $now;
		$row['updated_by'] = get_current_user_id();
		$wpdb->insert( msm_table( $table ), $row );
		return (int) $wpdb->insert_id;
	}

	/** Numer sesji szybkiego inwentarza dla bieżącego żądania (0 = zwykła zmiana). */
	public static $inw = 0;

	/** Prefiks akcji w historii dla bieżącej operacji (np. „PZ: ”). */
	public static $prefix = '';

	private static function akcja( $a ) {
		if ( self::$prefix ) {
			return self::$prefix . $a;
		}
		return self::$inw ? 'szybki inwentarz: ' . $a : $a;
	}

	/** Przyjęcie na stan istniejącej pozycji (PZ). $ref = opis źródła, np. „PZ 01/11/2026”. */
	public static function receive( $table, $id, $qty, $ref, $dane = array() ) {
		$item = self::get( $table, (int) $id );
		if ( ! $item ) {
			return new WP_Error( 'msm_not_found', 'Pozycja #' . (int) $id . ' nie istnieje.', array( 'status' => 404 ) );
		}
		$kg    = 'kg' === msm_unit( $table );
		$qty   = $kg ? round( (float) $qty, 3 ) : (int) $qty;
		$new   = $kg ? round( (float) $item['ilosc'] + $qty, 3 ) : (int) $item['ilosc'] + $qty;
		if ( $new < 0 ) {
			return new WP_Error( 'msm_stock', 'Za mało na stanie: ' . MSM_Calc::describe( $table, $item ), array( 'status' => 400 ) );
		}
		$after = self::save_changes( $table, $item, array( 'ilosc' => $new ) );
		$unit  = $kg ? 'kg' : 'szt';
		self::log(
			$qty >= 0 ? 'PZ: przyjęcie' : 'PZ: anulowanie',
			$table,
			(int) $id,
			( $qty >= 0 ? 'Przyjęto ' : 'Cofnięto ' ) . MSM_Calc::fmt( abs( $qty ) ) . ' ' . $unit . ' (' . $ref . '): ' . MSM_Calc::describe( $table, $after ),
			array_merge( array( 'przed' => array( 'ilosc' => $item['ilosc'] ), 'po' => array( 'ilosc' => $after['ilosc'] ) ), $dane )
		);
		return $after;
	}

	const HALA = 'HALA';

	/** Sprawdziany/przyrządy: wydanie na halę (regał → HALA) lub zwrot na wskazany regał. Zapis w historii. */
	public static function narz_hala( $table, $id, $action, $regal ) {
		if ( ! in_array( $table, msm_narzedzia_tables(), true ) ) {
			return new WP_Error( 'msm_400', 'Dostępne tylko dla sprawdzianów i przyrządów.', array( 'status' => 400 ) );
		}
		$item = self::get( $table, (int) $id );
		if ( ! $item ) {
			return new WP_Error( 'msm_not_found', 'Pozycja #' . (int) $id . ' nie istnieje.', array( 'status' => 404 ) );
		}
		$cur   = trim( (string) ( $item['regal'] ?? '' ) );
		$numer = (string) ( $item['numer'] ?? ( '#' . (int) $id ) );

		if ( 'zwrot' === $action ) {
			$regal = trim( sanitize_text_field( $regal ) );
			if ( '' === $regal ) {
				return new WP_Error( 'msm_400', 'Podaj regał, na który odkładasz.', array( 'status' => 400, 'fields' => array( 'regal' => 'Podaj regał.' ) ) );
			}
			$after = self::save_changes( $table, $item, array( 'regal' => $regal ) );
			self::log( 'Narzędzie: zwrot na regał', $table, (int) $id, 'Nr ' . $numer . ' – zwrot na regał „' . $regal . '”', array( 'przed' => array( 'regal' => $cur ), 'po' => array( 'regal' => $regal ) ) );
			return self::cast_row( $table, $after );
		}

		// Wydanie na halę.
		if ( self::HALA === mb_strtoupper( $cur, 'UTF-8' ) ) {
			return self::cast_row( $table, $item );
		}
		$after = self::save_changes( $table, $item, array( 'regal' => self::HALA ) );
		self::log( 'Narzędzie: wydanie na halę', $table, (int) $id, 'Nr ' . $numer . ' – wydano na halę' . ( '' !== $cur ? ' (z regału „' . $cur . '”)' : '' ), array( 'przed' => array( 'regal' => $cur ), 'po' => array( 'regal' => self::HALA ) ) );
		return self::cast_row( $table, $after );
	}

	private static function inw_dane( $dane ) {
		if ( self::$inw ) {
			$dane        = (array) $dane;
			$dane['inw'] = self::$inw;
		}
		return $dane;
	}

	public static function create( $table, array $in ) {
		$row = self::sanitize( $table, $in );
		if ( is_wp_error( $row ) ) {
			return $row;
		}
		$id = self::insert_raw( $table, $row );
		if ( ! $id ) {
			return new WP_Error( 'msm_db', 'Nie udało się zapisać pozycji.', array( 'status' => 500 ) );
		}
		$after = self::get( $table, $id );
		self::log( self::akcja( 'dodanie' ), $table, $id, MSM_Calc::describe( $table, $after ), self::inw_dane( array( 'po' => self::plain( $table, $after ) ) ) );
		return self::cast_row( $table, $after );
	}

	public static function update( $table, $id, array $in ) {
		global $wpdb;
		$before = self::get( $table, $id );
		if ( ! $before ) {
			return new WP_Error( 'msm_not_found', 'Pozycja nie istnieje.', array( 'status' => 404 ) );
		}
		$data = self::sanitize( $table, $in, true );
		if ( is_wp_error( $data ) ) {
			return $data;
		}
		$after = self::save_changes( $table, $before, $data );
		$diff  = self::diff( $table, $before, $after );
		if ( $diff['przed'] ) {
			self::log( self::akcja( 'edycja' ), $table, $id, MSM_Calc::describe( $table, $after ), self::inw_dane( $diff ) );
		}
		return self::cast_row( $table, $after );
	}

	/** Zapisuje zmiany pól + przelicza pola wyliczane. Zwraca nowy wiersz. */
	private static function save_changes( $table, array $before, array $data ) {
		global $wpdb;
		$merged = array_merge( $before, $data );
		$merged = MSM_Calc::compute( $table, $merged );
		$upd    = array();
		foreach ( msm_schema()[ $table ]['cols'] as $c ) {
			$k = $c['key'];
			if ( array_key_exists( $k, $merged ) && ( array_key_exists( $k, $data ) || ! empty( $c['computed'] ) ) ) {
				$upd[ $k ] = $merged[ $k ];
			}
		}
		if ( isset( msm_schema()[ $table ]['stock'] ) || isset( msm_schema()[ $table ]['edit'] ) ) {
			$upd['updated_at'] = current_time( 'mysql' );
			$upd['updated_by'] = get_current_user_id();
		}
		$wpdb->update( msm_table( $table ), $upd, array( 'id' => (int) $before['id'] ) );
		return self::get( $table, (int) $before['id'] );
	}

	/**
	 * Super admin: trwałe usunięcie pozycji BEZ śladu – usuwa pozycję, jej wpisy w historii
	 * oraz powiązane pobrania (i ich wpisy). Nie zapisuje niczego w dzienniku.
	 */
	/** Super admin: trwałe usunięcie wybranych wpisów z historii zmian (bez śladu). */
	public static function purge_log( array $ids ) {
		global $wpdb;
		$ids = array_values( array_filter( array_unique( array_map( 'intval', $ids ) ) ) );
		if ( ! $ids ) {
			return 0;
		}
		$in = implode( ',', $ids );
		$L  = msm_table( 'historia' );
		return (int) $wpdb->query( "DELETE FROM `$L` WHERE id IN ($in)" ); // phpcs:ignore
	}

	public static function purge( $table, array $ids ) {
		global $wpdb;
		$ids = array_values( array_filter( array_unique( array_map( 'intval', $ids ) ) ) );
		if ( ! $ids || ! in_array( $table, msm_stock_tables(), true ) ) {
			return 0;
		}
		$in  = implode( ',', $ids );
		$L   = msm_table( 'historia' );
		$P   = msm_table( 'pobrania' );
		$pid = $wpdb->get_col( $wpdb->prepare( "SELECT id FROM `$P` WHERE item_table = %s AND item_id IN ($in)", $table ) ); // phpcs:ignore
		if ( $pid ) {
			$pin = implode( ',', array_map( 'intval', $pid ) );
			$wpdb->query( "DELETE FROM `$P` WHERE id IN ($pin)" ); // phpcs:ignore
			$wpdb->query( 'UPDATE `' . msm_table( 'wnioski' ) . "` SET pobranie_id = NULL WHERE pobranie_id IN ($pin)" ); // phpcs:ignore
			$wpdb->query( 'UPDATE `' . $wpdb->prefix . "msm_wz_poz` SET pobranie_id = NULL WHERE pobranie_id IN ($pin)" ); // phpcs:ignore
		}
		$wpdb->query( $wpdb->prepare( "DELETE FROM `$L` WHERE (tabela_key = %s AND item_id IN ($in)) OR (ref_table = %s AND ref_id IN ($in))", $table, $table ) ); // phpcs:ignore
		return (int) $wpdb->query( $wpdb->prepare( 'DELETE FROM `' . msm_table( $table ) . "` WHERE id IN ($in) AND %d = 1", 1 ) ); // phpcs:ignore
	}

	public static function delete( $table, array $ids ) {
		global $wpdb;
		$deleted = 0;
		foreach ( array_unique( array_map( 'intval', $ids ) ) as $id ) {
			$before = self::get( $table, $id );
			if ( ! $before ) {
				continue;
			}
			if ( $wpdb->delete( msm_table( $table ), array( 'id' => $id ) ) ) {
				$deleted++;
				self::log( self::akcja( 'usunięcie' ), $table, $id, MSM_Calc::describe( $table, $before ), self::inw_dane( array( 'przed' => self::plain( $table, $before ) ) ) );
			}
		}
		return $deleted;
	}

	/**
	 * Przeniesienie pozycji z „Blach pełnych" do „Blach niepełnych"
	 * (naprawa błędnego zaimportowania z Excela). Tylko administrator.
	 */
	public static function move_pelna_to_niepelna( $id ) {
		$src = self::get( 'blachy_pelne', (int) $id );
		if ( ! $src ) {
			return new WP_Error( 'msm_not_found', 'Pozycja nie istnieje.', array( 'status' => 404 ) );
		}
		$uwagi = trim( (string) ( isset( $src['uwagi'] ) ? $src['uwagi'] : '' ) );
		if ( ! empty( $src['material'] ) ) {
			$uwagi = ( $uwagi ? $uwagi . ' | ' : '' ) . 'Materiał: ' . $src['material'];
		}
		$fields = array(
			'gatunek'  => isset( $src['gatunek'] ) ? $src['gatunek'] : '',
			'grubosc'  => isset( $src['grubosc'] ) ? $src['grubosc'] : '',
			'ksztalt'  => 'prostokąt',
			'wymiar_a' => isset( $src['wymiar_a'] ) ? $src['wymiar_a'] : '',
			'wymiar_b' => isset( $src['wymiar_b'] ) ? $src['wymiar_b'] : '',
			'ilosc'    => isset( $src['ilosc'] ) ? $src['ilosc'] : '',
			'min_stan' => isset( $src['min_stan'] ) ? $src['min_stan'] : '',
			'uwagi'    => $uwagi,
		);
		$item = self::create( 'blachy_niepelne', $fields );
		if ( is_wp_error( $item ) ) {
			return $item;
		}
		self::delete( 'blachy_pelne', array( (int) $id ) );
		self::log( 'Przeniesienie do blach niepełnych', 'blachy_niepelne', (int) $item['id'], 'Z blach pełnych (#' . (int) $id . '): ' . MSM_Calc::describe( 'blachy_niepelne', $item ) );
		return array( 'item' => $item, 'message' => 'Przeniesiono do blach niepełnych: ' . MSM_Calc::describe( 'blachy_niepelne', $item ) );
	}

	/* ------------------------------------------------------------------ *
	 * Pobrania z magazynu
	 * ------------------------------------------------------------------ */

	public static function pobranie( array $in ) {
		global $wpdb;
		$table = isset( $in['tabela'] ) ? (string) $in['tabela'] : '';
		if ( ! in_array( $table, msm_stock_tables(), true ) ) {
			return new WP_Error( 'msm_invalid', 'Nieznany magazyn.', array( 'status' => 400 ) );
		}
		$id    = (int) ( $in['item_id'] ?? 0 );
		$tryb  = ( 'stal' === $table && 'odcinek' === ( $in['tryb'] ?? '' ) ) ? 'odcinek' : 'szt';
		$data  = ( isset( $in['data'] ) && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $in['data'] ) ) ? $in['data'] : current_time( 'Y-m-d' );
		$zlecenie = mb_substr( mb_strtoupper( trim( sanitize_text_field( wp_unslash( (string) ( $in['zlecenie'] ?? '' ) ) ) ), 'UTF-8' ), 0, 60 );
		if ( 'blachy_pelne' === $table && '' === $zlecenie ) {
			return new WP_Error( 'msm_invalid', 'Podaj numer zlecenia – jest wymagany przy pobraniu blachy pełnej.', array( 'status' => 400, 'fields' => array( 'zlecenie' => 'Wymagany przy blasze pełnej' ) ) );
		}
		$extra = self::sanitize( 'pobrania', array(
			'odbiorca' => $in['odbiorca'] ?? '',
			'uwagi'    => $in['uwagi'] ?? '',
			'wpisana'  => $in['wpisana'] ?? 0,
		), true );
		if ( is_wp_error( $extra ) ) {
			return $extra;
		}

		$wpdb->query( 'START TRANSACTION' );
		$item = self::get( $table, $id, true );
		if ( ! $item ) {
			$wpdb->query( 'ROLLBACK' );
			return new WP_Error( 'msm_not_found', 'Pozycja nie istnieje.', array( 'status' => 404 ) );
		}
		$kgu     = 'kg' === msm_unit( $table );
		$stock   = $kgu ? (float) $item['ilosc'] : (int) $item['ilosc'];
		$opis    = MSM_Calc::describe( $table, $item );

		// Twarda blokada: nie można pobrać materiału zarezerwowanego pod inne zlecenia.
		if ( class_exists( 'MSM_Rezerwacje' ) && in_array( $table, MSM_Rezerwacje::TABLES, true ) && empty( $in['_skip_rez'] ) ) {
			$reserved = MSM_Rezerwacje::reserved_pieces( $id, (int) ( $in['from_rezerwacja'] ?? 0 ), $table );
			if ( $reserved > 0 ) {
				$u     = $kgu ? ' kg' : ' szt.';
				$avail = max( 0, $stock - $reserved );
				$need  = 'odcinek' === $tryb ? 1 : ( $kgu ? (float) MSM_Calc::f( $in['ilosc'] ?? 0 ) : (int) MSM_Calc::f( $in['ilosc'] ?? 0 ) );
				if ( $need > $avail + 1e-9 ) {
					$wpdb->query( 'ROLLBACK' );
					return new WP_Error( 'msm_reserved', 'Nie można pobrać – ' . MSM_Calc::fmt( $reserved ) . $u . ' jest zarezerwowane pod inne zlecenia (dostępne ' . MSM_Calc::fmt( $avail ) . ' z ' . MSM_Calc::fmt( $stock ) . $u . '). Wydaj materiał przez zakładkę „Rezerwacje” albo anuluj rezerwację.', array( 'status' => 409, 'fields' => array( 'ilosc' => 'Dostępne ' . MSM_Calc::fmt( $avail ) ) ) );
				}
			}
		}
		$changes = array();
		$set     = array();

		$odc = null;
		if ( 'odcinek' === $tryb ) {
			$odc = MSM_Calc::odcinki( $in );
			if ( is_wp_error( $odc ) ) {
				$wpdb->query( 'ROLLBACK' );
				return $odc;
			}
			$cut = $odc[2];
			$len = MSM_Calc::f( $item['dlugosc'] );
			if ( $stock < 1 ) {
				$wpdb->query( 'ROLLBACK' );
				return new WP_Error( 'msm_stock', 'Brak sztuk na stanie.', array( 'status' => 400 ) );
			}
			if ( null === $cut || $cut <= 0 ) {
				$wpdb->query( 'ROLLBACK' );
				return new WP_Error( 'msm_invalid', 'Podaj długość odcinka w metrach.', array( 'status' => 400, 'fields' => array( 'dlugosc' => 'Podaj długość' ) ) );
			}
			if ( null === $len || $cut > $len + 1e-9 ) {
				$wpdb->query( 'ROLLBACK' );
				return new WP_Error( 'msm_stock', ( $odc[0] > 1 ? 'Razem ' . $odc[0] . ' × ' . MSM_Calc::fmt( $odc[1] ) . ' m = ' . MSM_Calc::fmt( $cut ) . ' m – więcej niż sztuka na stanie (' . MSM_Calc::fmt( $len ) . ' m).' : 'Odcinek dłuższy niż sztuka na stanie (' . MSM_Calc::fmt( $len ) . ' m).' ), array( 'status' => 400, 'fields' => array( 'dlugosc' => 'Za długi' ) ) );
			}
			if ( abs( $cut - $len ) < 1e-9 ) {
				$tryb        = 'szt';
				$in['ilosc'] = 1;
			} else {
				$rest = round( $len - $cut, 3 );
				if ( 1 === $stock ) {
					$set['dlugosc']     = $rest;
					$changes['dlugosc'] = $cut;
				} else {
					$set['ilosc']         = $stock - 1;
					$copy                 = $item;
					unset( $copy['id'], $copy['created_at'], $copy['updated_at'], $copy['updated_by'] );
					$copy['ilosc']        = 1;
					$copy['dlugosc']      = $rest;
					$copy['uwagi']        = trim( ( $item['uwagi'] ? $item['uwagi'] . ' | ' : '' ) . 'reszta po pobraniu' );
					$rest_id              = self::insert_raw( $table, $copy );
					self::log( 'reszta po cięciu', $table, $rest_id, 'Reszta ' . MSM_Calc::fmt( $rest ) . ' m po odcięciu ' . MSM_Calc::fmt( $cut ) . ' m z pozycji #' . (int) $id . ': ' . $opis );
					$changes['ilosc']     = 1;
					$changes['reszta_id'] = $rest_id;
					$changes['reszta_dl'] = $rest;
				}
				$qty  = $cut;
				$unit = 'm';
			}
		}

		if ( 'szt' === $tryb && $kgu ) {
			$n = MSM_Calc::f( $in['ilosc'] ?? null );
			if ( null === $n || $n <= 0 ) {
				$wpdb->query( 'ROLLBACK' );
				return new WP_Error( 'msm_invalid', 'Podaj ilość w kg.', array( 'status' => 400, 'fields' => array( 'ilosc' => 'Podaj ilość w kg' ) ) );
			}
			$n = round( $n, 3 );
			if ( $n > $stock + 1e-9 ) {
				$wpdb->query( 'ROLLBACK' );
				return new WP_Error( 'msm_stock', 'Na stanie jest tylko ' . MSM_Calc::fmt( $stock ) . ' kg.', array( 'status' => 400, 'fields' => array( 'ilosc' => 'Max ' . MSM_Calc::fmt( $stock ) ) ) );
			}
			$set['ilosc']     = round( $stock - $n, 3 );
			$changes['ilosc'] = $n;
			$qty              = $n;
			$unit             = 'kg';
		} elseif ( 'szt' === $tryb ) {
			$n = MSM_Calc::f( $in['ilosc'] ?? null );
			if ( null === $n || $n < 1 || floor( $n ) != $n ) { // phpcs:ignore
				$wpdb->query( 'ROLLBACK' );
				return new WP_Error( 'msm_invalid', 'Podaj liczbę sztuk.', array( 'status' => 400, 'fields' => array( 'ilosc' => 'Podaj liczbę sztuk' ) ) );
			}
			$n = (int) $n;
			if ( $n > $stock ) {
				$wpdb->query( 'ROLLBACK' );
				return new WP_Error( 'msm_stock', 'Na stanie jest tylko ' . $stock . ' szt.', array( 'status' => 400, 'fields' => array( 'ilosc' => 'Max ' . $stock ) ) );
			}
			$set['ilosc']     = $stock - $n;
			$changes['ilosc'] = $n;
			$qty              = $n;
			$unit             = 'szt';
		}

		$after = self::save_changes( $table, $item, $set );

		$wpdb->insert( msm_table( 'pobrania' ), array(
			'data'       => $data,
			'tabela'     => msm_schema()[ $table ]['label'],
			'item_table' => $table,
			'item_id'    => $id,
			'tryb'       => $tryb,
			'material'   => $opis,
			'ilosc'      => $qty,
			'jednostka'  => $unit,
			'zlecenie'   => '' === $zlecenie ? null : $zlecenie,
			'odbiorca'   => $extra['odbiorca'] ?? null,
			'uwagi'      => $extra['uwagi'] ?? null,
			'wpisana'    => $extra['wpisana'] ?? 0,
			'zmiany'     => wp_json_encode( $changes ),
			'odc_szt'    => $odc ? $odc[0] : null,
			'odc_dl'     => $odc ? $odc[1] : null,
			'user_id'    => get_current_user_id(),
			'user_name'  => self::user_name(),
			'created_at' => current_time( 'mysql' ),
		) );
		$pid = (int) $wpdb->insert_id;
		if ( ! $pid ) {
			$wpdb->query( 'ROLLBACK' );
			return new WP_Error( 'msm_db', 'Nie udało się zapisać pobrania.', array( 'status' => 500 ) );
		}
		$txt = 'Pobrano ' . MSM_Calc::fmt( $qty ) . ' ' . ( 'szt' === $unit ? 'szt.' : $unit ) . ( $odc && $odc[0] > 1 ? ' (' . $odc[0] . ' × ' . MSM_Calc::fmt( $odc[1] ) . ' m)' : '' ) . ': ' . $opis . ( '' !== $zlecenie ? ' [zlec. ' . $zlecenie . ']' : '' ) . ( ! empty( $extra['odbiorca'] ) ? ' → ' . $extra['odbiorca'] : '' );
		self::log( 'pobranie', $table, $id, $txt, array(
			'przed' => array( 'ilosc' => $stock, 'dlugosc' => $item['dlugosc'] ?? null ),
			'po'    => array( 'ilosc' => $kgu ? (float) $after['ilosc'] : (int) $after['ilosc'], 'dlugosc' => $after['dlugosc'] ?? null ),
			'poz'   => array(
				'zlecenie' => '' === $zlecenie ? null : $zlecenie,
				'odbiorca' => ! empty( $extra['odbiorca'] ) ? $extra['odbiorca'] : null,
				'uwagi'    => ! empty( $extra['uwagi'] ) ? $extra['uwagi'] : null,
				'tryb'     => $tryb,
				'odc_szt'  => $odc ? $odc[0] : null,
				'odc_dl'   => $odc ? $odc[1] : null,
				'data'     => $data,
			),
		) );
		$wpdb->query( 'COMMIT' );

		$prow = self::get( 'pobrania', $pid );
		if ( 'blachy_pelne' === $table ) {
			MSM_Wnioski::notify_blacha_pelna( $prow, $after );
		}

		return array(
			'pobranie' => self::cast_row( 'pobrania', $prow ),
			'item'     => self::cast_row( $table, $after ),
			'message'  => $txt . '. Na stanie: ' . ( $kgu ? MSM_Calc::fmt( (float) $after['ilosc'] ) . ' kg' : (int) $after['ilosc'] . ' szt.' ),
		);
	}

	/** Anulowanie pobrania = zwrot na stan. */
	public static function cancel_pobranie( $pid ) {
		global $wpdb;
		$wpdb->query( 'START TRANSACTION' );
		$p = self::get( 'pobrania', $pid, true );
		if ( ! $p ) {
			$wpdb->query( 'ROLLBACK' );
			return new WP_Error( 'msm_not_found', 'Pobranie nie istnieje.', array( 'status' => 404 ) );
		}
		$table   = $p['item_table'];
		$changes = json_decode( (string) $p['zmiany'], true );
		$changes = is_array( $changes ) ? $changes : array();
		$warn    = '';
		$item    = in_array( $table, msm_stock_tables(), true ) ? self::get( $table, (int) $p['item_id'], true ) : null;

		if ( ! $item ) {
			$warn = 'Pozycja magazynowa już nie istnieje – stan nie został przywrócony.';
		} else {
			$set = array();
			if ( ! empty( $changes['reszta_id'] ) ) {
				$rest = self::get( $table, (int) $changes['reszta_id'], true );
				if ( $rest && 1 === (int) $rest['ilosc'] && abs( (float) $rest['dlugosc'] - (float) $changes['reszta_dl'] ) < 1e-6 ) {
					$wpdb->delete( msm_table( $table ), array( 'id' => (int) $rest['id'] ) );
					$set['ilosc'] = (int) $item['ilosc'] + 1;
				} else {
					$warn = 'Reszta po cięciu została już zmieniona – popraw stan ręcznie.';
				}
			} else {
				if ( ! empty( $changes['ilosc'] ) ) {
					$set['ilosc'] = 'kg' === msm_unit( $table ) ? round( (float) $item['ilosc'] + (float) $changes['ilosc'], 3 ) : (int) $item['ilosc'] + (int) $changes['ilosc'];
				}
				if ( ! empty( $changes['dlugosc'] ) ) {
					$set['dlugosc'] = round( (float) $item['dlugosc'] + (float) $changes['dlugosc'], 3 );
				}
			}
			if ( $set ) {
				self::save_changes( $table, $item, $set );
			}
		}
		$wpdb->delete( msm_table( 'pobrania' ), array( 'id' => (int) $pid ) );
		// Wniosek, z którego powstało to pobranie, wraca do stanu „zaakceptowany”.
		$wpdb->query( $wpdb->prepare( 'UPDATE `' . msm_table( 'wnioski' ) . "` SET status = 'zaakceptowany', pobranie_id = NULL, issued_at = NULL WHERE pobranie_id = %d", (int) $pid ) ); // phpcs:ignore
		self::log( 'anulowanie pobrania', $table, (int) $p['item_id'], 'Zwrot ' . MSM_Calc::fmt( $p['ilosc'] ) . ' ' . $p['jednostka'] . ': ' . $p['material'] . ( $warn ? ' (' . $warn . ')' : '' ), array( 'przed' => self::plain( 'pobrania', $p ) ) );
		$wpdb->query( 'COMMIT' );
		return array( 'ok' => true, 'warning' => $warn );
	}

	/* ------------------------------------------------------------------ *
	 * Historia pojedynczej pozycji
	 * ------------------------------------------------------------------ */

	/** Które z podanych pozycji mają jakąkolwiek historię (edycje, pobrania, wnioski). */
	public static function items_with_history( $table, array $ids ) {
		global $wpdb;
		$ids = array_filter( array_map( 'intval', $ids ) );
		if ( ! $ids ) {
			return array();
		}
		$in  = implode( ',', $ids );
		$out = array();
		$a   = $wpdb->get_col( $wpdb->prepare( 'SELECT DISTINCT ref_id FROM `' . msm_table( 'historia' ) . "` WHERE ref_table = %s AND akcja <> 'dodanie' AND akcja <> 'import' AND ref_id IN ($in)", $table ) ); // phpcs:ignore
		$b   = $wpdb->get_col( $wpdb->prepare( 'SELECT DISTINCT item_id FROM `' . msm_table( 'wnioski' ) . "` WHERE item_table = %s AND item_id IN ($in)", $table ) ); // phpcs:ignore
		foreach ( array_merge( $a, $b ) as $id ) {
			$out[ (int) $id ] = true;
		}
		return $out;
	}

	/** Pozycje BHP, które mają historię: były wydane albo mają ręczne zmiany w historii. */
	public static function bhp_items_with_history( array $ids ) {
		global $wpdb;
		$ids = array_filter( array_map( 'intval', $ids ) );
		if ( ! $ids ) {
			return array();
		}
		$in  = implode( ',', $ids );
		$out = array();
		$a   = $wpdb->get_col( "SELECT DISTINCT bhp_id FROM `" . msm_table( 'bhp_wyd_poz' ) . "` WHERE bhp_id IN ($in)" ); // phpcs:ignore
		$b   = $wpdb->get_col( $wpdb->prepare( "SELECT DISTINCT ref_id FROM `" . msm_table( 'historia' ) . "` WHERE ref_table = %s AND akcja <> 'dodanie' AND akcja <> 'import' AND ref_id IN ($in)", 'bhp' ) ); // phpcs:ignore
		foreach ( array_merge( $a, $b ) as $id ) {
			$out[ (int) $id ] = true;
		}
		return $out;
	}

	/** Wszystkie działania na pozycji: zmiany, pobrania, sprawdzenia i zapotrzebowania. */
	public static function item_history( $table, $id ) {
		global $wpdb;
		$item = self::get( $table, $id );
		$L    = msm_table( 'historia' );
		$W    = msm_table( 'wnioski' );
		$P    = msm_table( 'pobrania' );

		$rows   = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `$L` WHERE ref_table = %s AND ref_id = %d ORDER BY czas DESC, id DESC LIMIT 500", $table, $id ), ARRAY_A ); // phpcs:ignore
		$wn     = array();
		$wn_ids = array_filter( array_map( function ( $r ) {
			return 'wnioski' === $r['tabela_key'] ? (int) $r['item_id'] : 0;
		}, $rows ) );
		if ( $wn_ids ) {
			foreach ( $wpdb->get_results( "SELECT * FROM `$W` WHERE id IN (" . implode( ',', array_unique( $wn_ids ) ) . ')', ARRAY_A ) as $w ) { // phpcs:ignore
				$wn[ (int) $w['id'] ] = $w;
			}
		}
		$events = array();
		foreach ( $rows as $r ) {
			$events[] = self::describe_event( $r, $wn );
		}

		// Podsumowanie i oś czasu BHP liczymy wprost z wydań (bhp_wyd_poz) – także sprzed logowania historii.
		if ( 'bhp' === $table ) {
			$BW   = msm_table( 'bhp_wyd' );
			$BP   = msm_table( 'bhp_wyd_poz' );
			$row2 = $wpdb->get_row( $wpdb->prepare( "SELECT COUNT(*) n, COALESCE(SUM(p.ilosc),0) s FROM `$BP` p INNER JOIN `$BW` w ON w.id = p.wyd_id WHERE p.bhp_id = %d AND w.status <> 'anulowane'", $id ), ARRAY_A ); // phpcs:ignore
			$wy   = $wpdb->get_results( $wpdb->prepare( "SELECT p.ilosc, p.rozmiar, w.numer, w.data, w.status, w.osoba_name, w.dzial, w.wydal_name, w.created_at FROM `$BP` p INNER JOIN `$BW` w ON w.id = p.wyd_id WHERE p.bhp_id = %d ORDER BY w.data DESC, w.id DESC", $id ), ARRAY_A ); // phpcs:ignore
			$ev2  = array();
			foreach ( $wy as $r ) {
				$anul = 'anulowane' === $r['status'];
				$arch = empty( $r['numer'] );
				$ev2[] = array(
					'czas'      => $r['data'] ? $r['data'] . ' 00:00:00' : $r['created_at'],
					'user_name' => $r['wydal_name'],
					'akcja'     => $anul ? 'Wydanie (anulowane)' : 'Wydanie',
					'kind'      => $anul ? 'zwrot' : 'pobranie',
					'group'     => 'pobrania',
					'title'     => 'Wydano ' . (int) $r['ilosc'] . ' szt. dla: ' . $r['osoba_name'] . ( $r['dzial'] ? ' (' . $r['dzial'] . ')' : '' ),
					'detail'    => ( $arch ? 'wpis archiwalny' : 'nr ' . $r['numer'] ) . ( $anul ? ' · ANULOWANE' : '' ),
					'stock'     => null,
					'diff'      => null,
				);
			}
			// Zmiany ręczne (edycje stanu) z historii – pomijamy wpisy wydań, które mamy już z wydań.
			foreach ( $events as $e ) {
				if ( 'pobrania' !== $e['group'] ) {
					$ev2[] = $e;
				}
			}
			usort( $ev2, function ( $a, $b ) { return strcmp( (string) $b['czas'], (string) $a['czas'] ); } );
			return array(
				'item'    => $item ? self::cast_row( $table, $item ) : null,
				'title'   => $item ? MSM_Calc::describe( $table, $item ) : 'Pozycja usunięta (#' . (int) $id . ')',
				'summary' => array( 'pobrania' => (int) ( $row2['n'] ?? 0 ), 'szt' => (int) ( $row2['s'] ?? 0 ), 'm' => 0, 'kg' => 0, 'sprawdzenia' => 0, 'zapotrzebowania' => 0, 'w_toku' => 0 ),
				'events'  => $ev2,
				'is_bhp'  => true,
			);
		}
		$pob = $wpdb->get_results( $wpdb->prepare( "SELECT jednostka, COUNT(*) n, SUM(ilosc) s FROM `$P` WHERE item_table = %s AND item_id = %d GROUP BY jednostka", $table, $id ), ARRAY_A ); // phpcs:ignore
		$sum = array( 'pobrania' => 0, 'szt' => 0, 'm' => 0, 'kg' => 0 );
		foreach ( $pob as $p ) {
			$sum['pobrania'] += (int) $p['n'];
			$sum[ in_array( $p['jednostka'], array( 'm', 'kg' ), true ) ? $p['jednostka'] : 'szt' ] += (float) $p['s'];
		}
		$wst = $wpdb->get_results( $wpdb->prepare( "SELECT typ, status, COUNT(*) n FROM `$W` WHERE item_table = %s AND item_id = %d GROUP BY typ, status", $table, $id ), ARRAY_A ); // phpcs:ignore
		$sum['sprawdzenia']   = 0;
		$sum['zapotrzebowania'] = 0;
		$sum['w_toku']        = 0;
		foreach ( $wst as $w ) {
			$sum[ 'sprawdzenie' === $w['typ'] ? 'sprawdzenia' : 'zapotrzebowania' ] += (int) $w['n'];
			if ( in_array( $w['status'], array( 'nowy', 'zaakceptowany' ), true ) ) {
				$sum['w_toku'] += (int) $w['n'];
			}
		}

		return array(
			'item'    => $item ? self::cast_row( $table, $item ) : null,
			'title'   => $item ? MSM_Calc::describe( $table, $item ) : 'Pozycja usunięta (#' . (int) $id . ')',
			'summary' => $sum,
			'events'  => $events,
		);
	}

	/** Zamienia wpis historii na krótki, czytelny opis do osi czasu pozycji. */
	private static function describe_event( array $r, array $wn ) {
		$dane = $r['dane'] ? json_decode( $r['dane'], true ) : null;
		$ak   = $r['akcja'];
		$inw  = 0 === strpos( $ak, 'szybki inwentarz: ' );
		if ( $inw ) {
			$ak = substr( $ak, strlen( 'szybki inwentarz: ' ) );
		}
		$opis = (string) $r['opis'];
		$ev   = array(
			'czas'      => $r['czas'],
			'user_name' => $r['user_name'],
			'akcja'     => $ak,
			'kind'      => 'inne',
			'group'     => 'zmiany',
			'title'     => $ak,
			'detail'    => '',
			'stock'     => null,
			'diff'      => null,
		);
		$stock = function () use ( $dane ) {
			if ( isset( $dane['przed']['ilosc'], $dane['po']['ilosc'] ) ) {
				return array( (float) $dane['przed']['ilosc'], (float) $dane['po']['ilosc'] );
			}
			return null;
		};

		if ( 'PZ: przyjęcie' === $ak || 'PZ: dodanie' === $ak ) {
			$ev['kind']   = 'dodanie';
			$ev['title']  = 'PZ: dodanie' === $ak ? 'Dodano z przyjęcia PZ' : 'Przyjęto na stan (PZ)';
			$ev['detail'] = $opis;
			$ev['stock']  = $stock();
			return $ev;
		}
		if ( 'PZ: anulowanie' === $ak || 'PZ: usunięcie' === $ak ) {
			$ev['kind']   = 'usuniecie';
			$ev['title']  = 'Anulowano przyjęcie PZ';
			$ev['detail'] = $opis;
			return $ev;
		}
		if ( 'pobranie' === $ak ) {
			preg_match( '/^Pobrano (.+?): (.+?)(?: \[zlec\. ([^\]]+)\])?(?: → (.+))?$/u', $opis, $m );
			$qtyS = isset( $m[1] ) ? $m[1] : '';
			$mat  = isset( $m[2] ) ? $m[2] : '';
			$poz  = ( isset( $dane['poz'] ) && is_array( $dane['poz'] ) ) ? $dane['poz'] : array();
			$zlec = ! empty( $poz['zlecenie'] ) ? $poz['zlecenie'] : ( isset( $m[3] ) ? $m[3] : '' );
			$odb  = ! empty( $poz['odbiorca'] ) ? $poz['odbiorca'] : ( isset( $m[4] ) ? $m[4] : '' );
			$parts = array();
			if ( '' !== $zlec ) {
				$parts[] = 'zlecenie ' . $zlec;
			}
			if ( '' !== $odb ) {
				$parts[] = 'dla: ' . $odb;
			}
			if ( ! empty( $poz['odc_szt'] ) && $poz['odc_szt'] > 1 ) {
				$parts[] = 'odcinki: ' . (int) $poz['odc_szt'] . ' × ' . MSM_Calc::fmt( $poz['odc_dl'] ) . ' m';
			} elseif ( isset( $poz['tryb'] ) && 'odcinek' === $poz['tryb'] ) {
				$parts[] = 'odcinek';
			}
			if ( ! empty( $poz['uwagi'] ) ) {
				$parts[] = 'cel: ' . $poz['uwagi'];
			}
			if ( ! empty( $poz['data'] ) && substr( (string) $r['czas'], 0, 10 ) !== $poz['data'] ) {
				$parts[] = 'data pobrania: ' . $poz['data'];
			}
			$ev['kind']   = 'pobranie';
			$ev['group']  = 'pobrania';
			$ev['title']  = 'Pobrano ' . $qtyS . ( '' !== $mat ? ': ' . $mat : '' );
			$ev['detail'] = implode( ' · ', $parts );
			$ev['stock']  = $stock();
		} elseif ( 'BHP: wydano' === $ak || 'BHP: zwrot wydania' === $ak ) {
			$ev['kind']  = 'BHP: zwrot wydania' === $ak ? 'zwrot' : 'pobranie';
			$ev['group'] = 'pobrania';
			$ev['title'] = $opis;
			$ev['stock'] = $stock();
		} elseif ( 'anulowanie pobrania' === $ak ) {
			preg_match( '/^Zwrot (.+?): /u', $opis, $m );
			$ev['kind']   = 'zwrot';
			$ev['group']  = 'pobrania';
			$ev['title']  = 'Zwrot na stan ' . ( $m[1] ?? '' ) . ' (anulowane pobranie)';
			$ev['detail'] = preg_match( '/\(([^()]+)\)$/u', $opis, $mm ) ? $mm[1] : '';
		} elseif ( 'wnioski' === $r['tabela_key'] ) {
			$wid   = (int) $r['item_id'];
			$w     = $wn[ $wid ] ?? null;
			$check = 0 === strpos( $ak, 'sprawdzenie' );
			$st    = trim( (string) substr( $ak, (int) strpos( $ak, ':' ) + ( false !== strpos( $ak, ':' ) ? 1 : strlen( $ak ) ) ) );
			$qty   = $w ? MSM_Calc::fmt( $w['ilosc'] ) . ' ' . $w['jednostka'] . ( MSM_Calc::odc_txt( $w ) ? ' (' . MSM_Calc::odc_txt( $w ) . ')' : '' ) : '';
			$zl    = $w && $w['zlecenie'] ? 'zlecenie ' . $w['zlecenie'] : '';
			$note  = preg_match( '/\(([^()]+)\)$/u', $opis, $mm ) && false === strpos( $mm[1], 'zlecenie' ) ? $mm[1] : '';
			$ev['group'] = 'wnioski';
			if ( $check ) {
				$ev['kind']  = 'sprawdzenie';
				$ev['title'] = '' === $st ? 'Prośba o sprawdzenie stanu #' . $wid : 'Sprawdzono #' . $wid . ': ' . $st;
				if ( 'brak na stanie' === $st ) {
					$ev['kind'] = 'brak';
				}
			} else {
				$map = array(
					''                           => array( 'zapotrzebowanie', 'Zapotrzebowanie #%d złożone' ),
					'zaakceptowany – do wydania' => array( 'akceptacja', 'Zapotrzebowanie #%d zaakceptowane – do wydania' ),
					'wydany'                     => array( 'wydanie', 'Zapotrzebowanie #%d wydane' ),
					'odrzucony'                  => array( 'odrzucenie', 'Zapotrzebowanie #%d odrzucone' ),
					'anulowany'                  => array( 'odrzucenie', 'Zapotrzebowanie #%d anulowane' ),
				);
				$x           = $map[ $st ] ?? array( 'zapotrzebowanie', 'Zapotrzebowanie #%d: ' . $st );
				$ev['kind']  = $x[0];
				$ev['title'] = sprintf( $x[1], $wid );
			}
			$ev['detail'] = implode( ' · ', array_filter( array( $qty, $zl, $w && '' === $st && $w['uwagi'] ? $w['uwagi'] : '', $note ? '„' . $note . '”' : '' ) ) );
		} elseif ( 'edycja' === $ak ) {
			$ev['kind']  = 'edycja';
			$ev['title'] = 'Zmiana danych pozycji';
			$ev['diff']  = $dane;
		} elseif ( 'dodanie' === $ak ) {
			$ev['kind']  = 'dodanie';
			$ev['title'] = 'Dodano do magazynu';
		} elseif ( 'reszta po cięciu' === $ak ) {
			$ev['kind']   = 'reszta';
			$ev['group']  = 'pobrania';
			$ev['title']  = 'Utworzono z reszty po cięciu';
			$ev['detail'] = preg_replace( '/: .*$/u', '', $opis );
		} elseif ( 'usunięcie' === $ak ) {
			$ev['kind']  = 'usuniecie';
			$ev['title'] = 'Usunięto z magazynu';
		} else {
			$ev['detail'] = $opis;
		}
		if ( $inw ) {
			$ev['title'] .= ' – szybki inwentarz';
			$ev['inw']    = true;
		}
		return $ev;
	}

	/* ------------------------------------------------------------------ *
	 * Historia
	 * ------------------------------------------------------------------ */

	/**
	 * @param array|null $ref  [tabela, id] pozycji magazynowej, której dotyczy wpis (np. wniosek → detal).
	 */
	public static function log( $akcja, $table, $item_id, $opis, $dane = null, $ref = null ) {
		global $wpdb;
		$schema = msm_schema();
		$wpdb->insert( msm_table( 'historia' ), array(
			'czas'       => current_time( 'mysql' ),
			'user_id'    => get_current_user_id(),
			'user_name'  => self::user_name(),
			'akcja'      => $akcja,
			'tabela'     => isset( $schema[ $table ] ) ? $schema[ $table ]['label'] : ( array( 'produkcja' => 'Produkcja', 'przesylki' => 'Przesyłki', 'elektro' => 'Elektronarzędzia', 'pomiar' => 'Przyrządy pomiarowe', 'zam' => 'Zamówienia', 'karty_zmian' => 'Karty zmian', 'zap' => 'Zapotrzebowanie', 'dost' => 'Dostawcy', 'uzytkownicy' => 'Użytkownicy', 'ustawienia' => 'Ustawienia', 'system' => 'System' )[ $table ] ?? (string) $table ),
			'tabela_key' => (string) $table,
			'item_id'    => (int) $item_id,
			'opis'       => mb_substr( (string) $opis, 0, 2000 ),
			'dane'       => $dane ? wp_json_encode( $dane ) : null,
			'uwagi'      => self::log_uwagi( $dane ),
			'ref_table'  => $ref ? (string) $ref[0] : ( ( in_array( $table, msm_stock_tables(), true ) || 'bhp' === $table ) ? (string) $table : null ),
			'ref_id'     => $ref ? (int) $ref[1] : ( ( in_array( $table, msm_stock_tables(), true ) || 'bhp' === $table ) ? (int) $item_id : null ),
		) );
	}

	/** Uwagi wpisane przy czynności – do kolumny „Uwagi” w Historii zmian (logika w MSM_Calc). */
	public static function log_uwagi( $dane ) {
		return MSM_Calc::log_uwagi( $dane );
	}

	public static function user_name() {
		$u = wp_get_current_user();
		return $u && $u->exists() ? $u->display_name : 'system';
	}

	private static function plain( $table, $row ) {
		$out = array();
		foreach ( msm_schema()[ $table ]['cols'] as $c ) {
			if ( empty( $c['computed'] ) && array_key_exists( $c['key'], $row ) ) {
				$out[ $c['key'] ] = $row[ $c['key'] ];
			}
		}
		return $out;
	}

	private static function diff( $table, $before, $after ) {
		$d = array( 'przed' => array(), 'po' => array() );
		foreach ( msm_schema()[ $table ]['cols'] as $c ) {
			$k = $c['key'];
			if ( ! empty( $c['computed'] ) ) {
				continue;
			}
			$a = $before[ $k ] ?? null;
			$b = $after[ $k ] ?? null;
			$same = in_array( $c['type'], array( 'num', 'int', 'bool' ), true )
				? ( ( null === $a && null === $b ) || ( null !== $a && null !== $b && abs( (float) $a - (float) $b ) < 1e-9 ) )
				: ( (string) $a === (string) $b );
			if ( ! $same ) {
				$d['przed'][ $k ] = $a;
				$d['po'][ $k ]    = $b;
			}
		}
		return $d;
	}
}
