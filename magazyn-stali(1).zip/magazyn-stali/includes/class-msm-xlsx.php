<?php
/**
 * Minimalny odczyt i zapis plików .xlsx (bez zewnętrznych bibliotek, wymaga rozszerzenia zip).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MSM_Xlsx {

	/** Scalone komórki z ostatniego odczytu: [ arkusz => [ [r1, c1, r2, c2], … ] ] (indeksy od 0). */
	public static $merges = array();

	/** Komórki liczbowe sformatowane jako data z ostatniego odczytu: [ arkusz => [ r => [ c => true ] ] ]. */
	public static $dates = array();

	/**
	 * Czyta wszystkie arkusze. Zwraca [ nazwa_arkusza => [ [wiersz], ... ] ] (wiersze indeksowane od 0, kolumny od 0).
	 *
	 * @return array|WP_Error
	 */
	public static function read( $path ) {
		if ( ! class_exists( 'ZipArchive' ) ) {
			return new WP_Error( 'msm_zip', 'Serwer nie ma rozszerzenia PHP „zip” – import .xlsx niemożliwy.' );
		}
		$zip = new ZipArchive();
		if ( true !== $zip->open( $path ) ) {
			return new WP_Error( 'msm_xlsx', 'To nie jest poprawny plik .xlsx.' );
		}
		// 1.84.0: ochrona przed „zip bomb” – limit liczby plików i rozmiaru po rozpakowaniu.
		$limit = (int) apply_filters( 'msm_xlsx_max_unpacked', 100 * MB_IN_BYTES );
		$total = 0;
		if ( $zip->numFiles > 2000 ) {
			$zip->close();
			return new WP_Error( 'msm_xlsx', 'Plik .xlsx ma nietypową budowę (zbyt wiele elementów).' );
		}
		for ( $i = 0; $i < $zip->numFiles; $i++ ) {
			$st     = $zip->statIndex( $i );
			$total += $st ? (int) $st['size'] : 0;
			if ( $total > $limit ) {
				$zip->close();
				return new WP_Error( 'msm_xlsx', 'Plik .xlsx po rozpakowaniu jest za duży (limit ' . (int) round( $limit / MB_IN_BYTES ) . ' MB).' );
			}
		}
		$prev = libxml_use_internal_errors( true );

		$shared = array();
		$ss     = $zip->getFromName( 'xl/sharedStrings.xml' );
		if ( false !== $ss ) {
			$x = simplexml_load_string( $ss, 'SimpleXMLElement', LIBXML_NONET );
			if ( $x ) {
				foreach ( $x->si as $si ) {
					$shared[] = self::si_text( $si );
				}
			}
		}

		$wb   = simplexml_load_string( (string) $zip->getFromName( 'xl/workbook.xml' ), 'SimpleXMLElement', LIBXML_NONET );
		$rels = simplexml_load_string( (string) $zip->getFromName( 'xl/_rels/workbook.xml.rels' ), 'SimpleXMLElement', LIBXML_NONET );
		if ( ! $wb || ! $rels ) {
			$zip->close();
			libxml_use_internal_errors( $prev );
			return new WP_Error( 'msm_xlsx', 'Nie można odczytać struktury skoroszytu.' );
		}
		$targets = array();
		foreach ( $rels->Relationship as $r ) {
			$targets[ (string) $r['Id'] ] = (string) $r['Target'];
		}

		$date_xf      = self::date_styles( $zip );
		$out          = array();
		self::$merges = array();
		self::$dates  = array();
		foreach ( $wb->sheets->sheet as $sheet ) {
			$rid    = (string) $sheet->attributes( 'http://schemas.openxmlformats.org/officeDocument/2006/relationships' )->id;
			$target = isset( $targets[ $rid ] ) ? $targets[ $rid ] : '';
			$target = ltrim( $target, '/' );
			if ( 0 !== strpos( $target, 'xl/' ) ) {
				$target = 'xl/' . $target;
			}
			$xml = $zip->getFromName( $target );
			if ( false === $xml ) {
				continue;
			}
			$sx = simplexml_load_string( $xml, 'SimpleXMLElement', LIBXML_NONET | LIBXML_COMPACT );
			if ( ! $sx || ! isset( $sx->sheetData ) ) {
				continue;
			}
			$rows = array();
			$dts  = array();
			foreach ( $sx->sheetData->row as $row ) {
				$ri   = (int) $row['r'] - 1;
				$vals = array();
				foreach ( $row->c as $c ) {
					$ci = self::col_index( preg_replace( '/\d+/', '', (string) $c['r'] ) );
					$t  = (string) $c['t'];
					if ( 's' === $t ) {
						$v = $shared[ (int) $c->v ] ?? '';
					} elseif ( 'inlineStr' === $t ) {
						$v = self::si_text( $c->is );
					} elseif ( 'b' === $t ) {
						$v = (string) $c->v === '1';
					} elseif ( 'e' === $t ) {
						$v = null; // #REF! itp.
					} elseif ( 'str' === $t ) {
						$v = (string) $c->v;
					} else {
						$v = isset( $c->v ) ? (string) $c->v : null;
						if ( null !== $v && is_numeric( $v ) ) {
							$v = $v + 0;
							if ( isset( $date_xf[ (int) $c['s'] ] ) ) {
								$dts[ $ri ][ $ci ] = true;
							}
						}
					}
					$vals[ $ci ] = $v;
				}
				if ( $vals ) {
					$max  = max( array_keys( $vals ) );
					$line = array();
					for ( $i = 0; $i <= $max; $i++ ) {
						$line[] = array_key_exists( $i, $vals ) ? $vals[ $i ] : null;
					}
					$rows[ $ri ] = $line;
				}
			}
			$out[ (string) $sheet['name'] ] = $rows;
			$mg = array();
			if ( isset( $sx->mergeCells ) ) {
				foreach ( $sx->mergeCells->mergeCell as $m ) {
					if ( preg_match( '/^([A-Z]+)(\d+):([A-Z]+)(\d+)$/', (string) $m['ref'], $p ) ) {
						$mg[] = array( (int) $p[2] - 1, self::col_index( $p[1] ), (int) $p[4] - 1, self::col_index( $p[3] ) );
					}
				}
			}
			self::$merges[ (string) $sheet['name'] ] = $mg;
			self::$dates[ (string) $sheet['name'] ]  = $dts;
		}
		$zip->close();
		libxml_use_internal_errors( $prev );
		return $out;
	}

	/** Indeksy stylów (cellXfs) z formatem daty – wbudowane 14–22, 45–47 i własne z d/m/y. */
	private static function date_styles( $zip ) {
		$xml = $zip->getFromName( 'xl/styles.xml' );
		$x   = false !== $xml ? simplexml_load_string( $xml, 'SimpleXMLElement', LIBXML_NONET ) : false;
		if ( ! $x || ! isset( $x->cellXfs ) ) {
			return array();
		}
		$custom = array();
		if ( isset( $x->numFmts ) ) {
			foreach ( $x->numFmts->numFmt as $f ) {
				$code = preg_replace( '/"[^"]*"|\[[^\]]*\]|\\./', '', (string) $f['formatCode'] );
				if ( preg_match( '/[dy]/i', $code ) || preg_match( '/m.*[dy]|[dy].*m/i', $code ) ) {
					$custom[ (int) $f['numFmtId'] ] = true;
				}
			}
		}
		$out = array();
		$i   = 0;
		foreach ( $x->cellXfs->xf as $xf ) {
			$id = (int) $xf['numFmtId'];
			if ( ( $id >= 14 && $id <= 22 ) || ( $id >= 45 && $id <= 47 ) || isset( $custom[ $id ] ) ) {
				$out[ $i ] = true;
			}
			$i++;
		}
		return $out;
	}

	private static function si_text( $si ) {
		if ( isset( $si->t ) ) {
			$s = (string) $si->t;
			if ( ! isset( $si->r ) ) {
				return $s;
			}
		}
		$s = '';
		foreach ( $si->r as $r ) {
			$s .= (string) $r->t;
		}
		if ( '' === $s && isset( $si->t ) ) {
			$s = (string) $si->t;
		}
		return $s;
	}

	private static function col_index( $letters ) {
		$n = 0;
		foreach ( str_split( strtoupper( $letters ) ) as $ch ) {
			$n = $n * 26 + ( ord( $ch ) - 64 );
		}
		return $n - 1;
	}

	private static function col_letter( $i ) {
		$s = '';
		$i++;
		while ( $i > 0 ) {
			$m = ( $i - 1 ) % 26;
			$s = chr( 65 + $m ) . $s;
			$i = (int) ( ( $i - $m ) / 26 );
		}
		return $s;
	}

	/**
	 * Zapisuje jeden arkusz do pliku. $rows[0] = nagłówki.
	 */
	public static function write( $path, $sheet_name, array $rows, array $widths = array() ) {
		$esc = function ( $s ) {
			$s = preg_replace( '/[\x00-\x08\x0B\x0C\x0E-\x1F]/', '', (string) $s );
			if ( strlen( $s ) > 32000 && mb_strlen( $s ) > 32700 ) {
				$s = mb_substr( $s, 0, 32700 ) . '…'; // limit komórki Excela (32 767 znaków)
			}
			return htmlspecialchars( $s, ENT_XML1 | ENT_QUOTES, 'UTF-8' );
		};

		$sheet  = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';
		$sheet .= '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">';
		$sheet .= '<sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>';
		if ( $widths ) {
			$sheet .= '<cols>';
			foreach ( array_values( $widths ) as $i => $w ) {
				$sheet .= '<col min="' . ( $i + 1 ) . '" max="' . ( $i + 1 ) . '" width="' . (float) $w . '" customWidth="1"/>';
			}
			$sheet .= '</cols>';
		}
		$sheet .= '<sheetData>';
		$ncols  = 0;
		foreach ( array_values( $rows ) as $ri => $row ) {
			$sheet .= '<row r="' . ( $ri + 1 ) . '">';
			foreach ( array_values( $row ) as $ci => $v ) {
				$ncols = max( $ncols, $ci + 1 );
				$ref   = self::col_letter( $ci ) . ( $ri + 1 );
				$style = 0 === $ri ? ' s="1"' : '';
				if ( null === $v || '' === $v ) {
					continue;
				}
				if ( ( is_int( $v ) || is_float( $v ) ) && 0 !== $ri ) {
					$sheet .= '<c r="' . $ref . '"' . $style . '><v>' . ( is_float( $v ) ? rtrim( rtrim( sprintf( '%.6F', $v ), '0' ), '.' ) : $v ) . '</v></c>';
				} else {
					$sheet .= '<c r="' . $ref . '" t="inlineStr"' . $style . '><is><t xml:space="preserve">' . $esc( $v ) . '</t></is></c>';
				}
			}
			$sheet .= '</row>';
		}
		$sheet .= '</sheetData>';
		if ( $ncols && count( $rows ) > 1 ) {
			$sheet .= '<autoFilter ref="A1:' . self::col_letter( $ncols - 1 ) . count( $rows ) . '"/>';
		}
		$sheet .= '</worksheet>';

		$name = $esc( mb_substr( preg_replace( '/[\\\\\/\?\*\[\]:]/u', ' ', $sheet_name ), 0, 31 ) );

		$zip = new ZipArchive();
		if ( true !== $zip->open( $path, ZipArchive::CREATE | ZipArchive::OVERWRITE ) ) {
			return false;
		}
		$zip->addFromString( '[Content_Types].xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>' );
		$zip->addFromString( '_rels/.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>' );
		$zip->addFromString( 'xl/workbook.xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="' . $name . '" sheetId="1" r:id="rId1"/></sheets>' . ( $ncols && count( $rows ) > 1 ? '<definedNames><definedName name="_xlnm._FilterDatabase" localSheetId="0" hidden="1">\'' . $name . '\'!$A$1:$' . self::col_letter( $ncols - 1 ) . '$' . count( $rows ) . '</definedName></definedNames>' : '' ) . '</workbook>' );
		$zip->addFromString( 'xl/_rels/workbook.xml.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>' );
		$zip->addFromString( 'xl/styles.xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><name val="Calibri"/></font></fonts><fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FFE7ECF2"/><bgColor indexed="64"/></patternFill></fill></fills><borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="2"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1"/></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>' );
		$zip->addFromString( 'xl/worksheets/sheet1.xml', $sheet );
		$zip->close();
		return true;
	}

	/**
	 * Skoroszyt wieloarkuszowy. $sheets = array( 'Nazwa' => array( wiersze ) ); wiersz[0] = nagłówki.
	 */
	public static function write_book( $path, array $sheets ) {
		$esc = function ( $s ) {
			$s = preg_replace( '/[\x00-\x08\x0B\x0C\x0E-\x1F]/', '', (string) $s );
			if ( strlen( $s ) > 32000 && mb_strlen( $s ) > 32700 ) {
				$s = mb_substr( $s, 0, 32700 ) . '…'; // limit komórki Excela (32 767 znaków)
			}
			return htmlspecialchars( $s, ENT_XML1 | ENT_QUOTES, 'UTF-8' );
		};
		if ( ! $sheets ) {
			$sheets = array( 'Arkusz' => array( array( '' ) ) );
		}
		$zip = new ZipArchive();
		if ( true !== $zip->open( $path, ZipArchive::CREATE | ZipArchive::OVERWRITE ) ) {
			return false;
		}
		$names = array();
		$used  = array();
		$idx   = 0;
		$ct_overrides = '';
		$wb_sheets    = '';
		$wb_rels      = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">';
		foreach ( $sheets as $name => $rows ) {
			$idx++;
			$safe = mb_substr( preg_replace( '/[\\\\\/\?\*\[\]:]/u', ' ', (string) $name ), 0, 31 );
			$safe = $safe === '' ? ( 'Arkusz' . $idx ) : $safe;
			$orig = $safe; $n = 2;
			while ( isset( $used[ mb_strtolower( $safe ) ] ) ) { $safe = mb_substr( $orig, 0, 28 ) . ' ' . $n; $n++; }
			$used[ mb_strtolower( $safe ) ] = true;

			$sheet  = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';
			$sheet .= '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><sheetData>';
			foreach ( array_values( $rows ) as $ri => $row ) {
				$sheet .= '<row r="' . ( $ri + 1 ) . '">';
				foreach ( array_values( (array) $row ) as $ci => $v ) {
					if ( null === $v || '' === $v ) { continue; }
					$ref   = self::col_letter( $ci ) . ( $ri + 1 );
					$style = 0 === $ri ? ' s="1"' : '';
					if ( ( is_int( $v ) || is_float( $v ) ) && 0 !== $ri ) {
						$sheet .= '<c r="' . $ref . '"' . $style . '><v>' . ( is_float( $v ) ? rtrim( rtrim( sprintf( '%.6F', $v ), '0' ), '.' ) : $v ) . '</v></c>';
					} else {
						$sheet .= '<c r="' . $ref . '" t="inlineStr"' . $style . '><is><t xml:space="preserve">' . $esc( $v ) . '</t></is></c>';
					}
				}
				$sheet .= '</row>';
			}
			$sheet .= '</sheetData></worksheet>';
			$zip->addFromString( "xl/worksheets/sheet{$idx}.xml", $sheet );
			$ct_overrides .= '<Override PartName="/xl/worksheets/sheet' . $idx . '.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>';
			$wb_sheets    .= '<sheet name="' . $esc( $safe ) . '" sheetId="' . $idx . '" r:id="rId' . $idx . '"/>';
			$wb_rels      .= '<Relationship Id="rId' . $idx . '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet' . $idx . '.xml"/>';
		}
		$style_rid = $idx + 1;
		$wb_rels  .= '<Relationship Id="rId' . $style_rid . '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>';

		$zip->addFromString( '[Content_Types].xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>' . $ct_overrides . '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>' );
		$zip->addFromString( '_rels/.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>' );
		$zip->addFromString( 'xl/workbook.xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>' . $wb_sheets . '</sheets></workbook>' );
		$zip->addFromString( 'xl/_rels/workbook.xml.rels', $wb_rels );
		$zip->addFromString( 'xl/styles.xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><name val="Calibri"/></font></fonts><fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FFE7ECF2"/><bgColor indexed="64"/></patternFill></fill></fills><borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="2"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1"/></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>' );
		$zip->close();
		return true;
	}

	/**
	 * Arkusz z układem: komórka = wartość albo [wartość, styl]; style: h, b, wz, th, td, tdn.
	 */
	public static function write_layout( $path, $sheet_name, array $rows, array $widths, array $merges ) {
		$esc    = function ( $s ) {
			return htmlspecialchars( preg_replace( '/[\x00-\x08\x0B\x0C\x0E-\x1F]/', '', (string) $s ), ENT_XML1 | ENT_QUOTES, 'UTF-8' );
		};
		$styles = array( '' => 0, 'h' => 1, 'b' => 2, 'wz' => 3, 'th' => 4, 'td' => 5, 'tdn' => 6 );
		$xml    = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><cols>';
		foreach ( array_values( $widths ) as $i => $wd ) {
			$xml .= '<col min="' . ( $i + 1 ) . '" max="' . ( $i + 1 ) . '" width="' . (float) $wd . '" customWidth="1"/>';
		}
		$xml .= '</cols><sheetData>';
		foreach ( array_values( $rows ) as $ri => $row ) {
			$xml .= '<row r="' . ( $ri + 1 ) . '">';
			foreach ( array_values( $row ) as $ci => $cell ) {
				$v  = is_array( $cell ) ? $cell[0] : $cell;
				$st = is_array( $cell ) ? ( $styles[ $cell[1] ] ?? 0 ) : 0;
				$ref = self::col_letter( $ci ) . ( $ri + 1 );
				if ( ( null === $v || '' === $v ) && ! $st ) {
					continue;
				}
				if ( is_int( $v ) || is_float( $v ) ) {
					$xml .= '<c r="' . $ref . '" s="' . $st . '"><v>' . ( 0 + $v ) . '</v></c>';
				} elseif ( null === $v || '' === $v ) {
					$xml .= '<c r="' . $ref . '" s="' . $st . '"/>';
				} else {
					$xml .= '<c r="' . $ref . '" s="' . $st . '" t="inlineStr"><is><t xml:space="preserve">' . $esc( $v ) . '</t></is></c>';
				}
			}
			$xml .= '</row>';
		}
		$xml .= '</sheetData>';
		if ( $merges ) {
			$xml .= '<mergeCells count="' . count( $merges ) . '">';
			foreach ( $merges as $m ) {
				$xml .= '<mergeCell ref="' . $m . '"/>';
			}
			$xml .= '</mergeCells>';
		}
		$xml .= '<pageMargins left="0.5" right="0.5" top="0.6" bottom="0.6" header="0.3" footer="0.3"/><pageSetup paperSize="9" orientation="portrait"/></worksheet>';

		$style_xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
			. '<fonts count="4"><font><sz val="10"/><name val="Calibri"/></font><font><sz val="8"/><color rgb="FF5A6274"/><name val="Calibri"/></font><font><b/><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="16"/><name val="Calibri"/></font></fonts>'
			. '<fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FFEEF1F6"/><bgColor indexed="64"/></patternFill></fill></fills>'
			. '<borders count="2"><border><left/><right/><top/><bottom/><diagonal/></border><border><left style="thin"/><right style="thin"/><top style="thin"/><bottom style="thin"/><diagonal/></border></borders>'
			. '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
			. '<cellXfs count="7">'
			. '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>'
			. '<xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/>'
			. '<xf numFmtId="0" fontId="2" fillId="0" borderId="0" xfId="0" applyFont="1"/>'
			. '<xf numFmtId="0" fontId="3" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>'
			. '<xf numFmtId="0" fontId="2" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment wrapText="1" vertical="center"/></xf>'
			. '<xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1" applyAlignment="1"><alignment wrapText="1" vertical="top"/></xf>'
			. '<xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1"/>'
			. '</cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>';

		$name = $esc( mb_substr( $sheet_name, 0, 31 ) );
		$zip  = new ZipArchive();
		if ( true !== $zip->open( $path, ZipArchive::CREATE | ZipArchive::OVERWRITE ) ) {
			return false;
		}
		$zip->addFromString( '[Content_Types].xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>' );
		$zip->addFromString( '_rels/.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>' );
		$zip->addFromString( 'xl/workbook.xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="' . $name . '" sheetId="1" r:id="rId1"/></sheets></workbook>' );
		$zip->addFromString( 'xl/_rels/workbook.xml.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>' );
		$zip->addFromString( 'xl/styles.xml', $style_xml );
		$zip->addFromString( 'xl/worksheets/sheet1.xml', $xml );
		$zip->close();
		return true;
	}
}
