<?php
/**
 * Rezerwacje materiału (stal, blachy, kręgi): blokują materiał pod zlecenie bez zdejmowania go ze stanu.
 * Przeglądający składa prośbę, administrator ją zatwierdza (rezerwacja aktywna).
 * Pobranie/WZ nie może sięgnąć po materiał zarezerwowany (twarda blokada).
 * Odcinek rezerwuje 1 sztukę (z której zostanie ucięty). Termin ważności jest opcjonalny.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MSM_Rezerwacje {

	const ST_NEW      = 'nowa';
	const ST_ACTIVE   = 'aktywna';
	const ST_ISSUED   = 'wydana';
	const ST_CANCELED = 'anulowana';
	const ST_REJECTED = 'odrzucona';
	const ST_EXPIRED  = 'wygasla';

	/** Magazyny, w których można rezerwować. Kręgi w kg, pozostałe w sztukach. */
	const TABLES = array( 'stal', 'blachy_pelne', 'blachy_niepelne', 'kregi' );

	public static function table( $t ) {
		return in_array( $t, self::TABLES, true ) ? $t : 'stal';
	}

	private static function kg( $t ) {
		return 'kg' === msm_unit( $t );
	}

	public static function labels() {
		return array(
			self::ST_NEW      => 'Oczekuje',
			self::ST_ACTIVE   => 'Aktywna',
			self::ST_ISSUED   => 'Wydana',
			self::ST_CANCELED => 'Anulowana',
			self::ST_REJECTED => 'Odrzucona',
			self::ST_EXPIRED  => 'Wygasła',
		);
	}

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
		add_action( 'msm_rez_expire', array( __CLASS__, 'expire' ) );
		if ( ! wp_next_scheduled( 'msm_rez_expire' ) ) {
			wp_schedule_event( time() + 300, 'daily', 'msm_rez_expire' );
		}
	}

	public static function T() {
		return msm_table( 'rezerwacje' );
	}

	/* ------------------------------------------------------------------ *
	 * Ilości zarezerwowane / dostępne
	 * ------------------------------------------------------------------ */

	/** Zarezerwowana ilość pozycji (szt.; kręgi – kg; odcinek = 1 szt.). $exclude pomija jedną rezerwację. */
	public static function reserved_pieces( $item_id, $exclude = 0, $table = 'stal' ) {
		global $wpdb;
		$table = self::table( $table );
		$sql   = 'SELECT COALESCE(SUM(CASE WHEN tryb = %s THEN 1 ELSE ilosc END), 0) FROM `' . self::T() . '` WHERE item_table = %s AND item_id = %d AND status = %s AND (termin IS NULL OR termin >= %s)';
		$args  = array( 'odcinek', $table, (int) $item_id, self::ST_ACTIVE, current_time( 'Y-m-d' ) );
		if ( $exclude ) {
			$sql   .= ' AND id <> %d';
			$args[] = (int) $exclude;
		}
		$v = $wpdb->get_var( $wpdb->prepare( $sql, $args ) ); // phpcs:ignore
		return self::kg( $table ) ? round( (float) $v, 3 ) : (int) $v;
	}

	/** Mapa [item_id => zarezerwowane szt.] dla podanych pozycji (jedno zapytanie). */
	public static function reserved_map( array $ids, $table = 'stal' ) {
		global $wpdb;
		$ids = array_values( array_filter( array_map( 'intval', $ids ) ) );
		if ( ! $ids ) {
			return array();
		}
		$in  = implode( ',', $ids );
		$table = self::table( $table );
		$rows  = $wpdb->get_results( $wpdb->prepare( 'SELECT item_id, COALESCE(SUM(CASE WHEN tryb = %s THEN 1 ELSE ilosc END), 0) r FROM `' . self::T() . "` WHERE item_table = %s AND status = %s AND (termin IS NULL OR termin >= %s) AND item_id IN ($in) GROUP BY item_id", 'odcinek', $table, self::ST_ACTIVE, current_time( 'Y-m-d' ) ), ARRAY_A ); // phpcs:ignore
		$out   = array();
		foreach ( $rows as $r ) {
			$out[ (int) $r['item_id'] ] = self::kg( $table ) ? round( (float) $r['r'], 3 ) : (int) $r['r'];
		}
		return $out;
	}

	/** Info o rezerwacjach pozycji: stan, zarezerwowane, dostępne + aktywne rezerwacje. */
	public static function item_info( $item_id, $table = 'stal' ) {
		global $wpdb;
		self::expire();
		$table = self::table( $table );
		$kg    = self::kg( $table );
		$item  = MSM_Repo::get( $table, (int) $item_id );
		if ( ! $item ) {
			return new WP_Error( 'msm_not_found', 'Pozycja nie istnieje.', array( 'status' => 404 ) );
		}
		$res  = self::reserved_pieces( $item_id, 0, $table );
		$stan = $kg ? (float) $item['ilosc'] : (int) $item['ilosc'];
		$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT id, zlecenie, tryb, ilosc, odc_szt, odc_dl, termin, user_name FROM `' . self::T() . '` WHERE item_table = %s AND item_id = %d AND status = %s ORDER BY id', $table, (int) $item_id, self::ST_ACTIVE ), ARRAY_A ); // phpcs:ignore
		return array(
			'table'         => $table,
			'jednostka'     => $kg ? 'kg' : 'szt',
			'stan'          => $stan,
			'zarezerwowane' => $res,
			'dostepne'      => max( 0, $stan - $res ),
			'rezerwacje'    => array_map( function ( $r ) {
				return array(
					'id'       => (int) $r['id'],
					'zlecenie' => $r['zlecenie'],
					'ilosc'    => (float) $r['ilosc'],
					'jednostka' => 'odcinek' === $r['tryb'] ? 'm' : ( 'kg' === $r['tryb'] ? 'kg' : 'szt' ),
					'odc_txt'  => MSM_Calc::odc_txt( $r ),
					'termin'   => $r['termin'],
					'user'     => $r['user_name'],
				);
			}, $rows ),
		);
	}

	/* ------------------------------------------------------------------ *
	 * Tworzenie
	 * ------------------------------------------------------------------ */

	public static function create( array $in ) {
		global $wpdb;
		$table = self::table( (string) ( $in['item_table'] ?? 'stal' ) );
		$kg    = self::kg( $table );
		$item  = MSM_Repo::get( $table, (int) ( $in['item_id'] ?? 0 ) );
		if ( ! $item ) {
			return new WP_Error( 'msm_not_found', 'Pozycja nie istnieje.', array( 'status' => 404 ) );
		}
		$tryb     = $kg ? 'kg' : ( 'stal' === $table && 'odcinek' === ( $in['tryb'] ?? '' ) ? 'odcinek' : 'szt' );
		$zlecenie = mb_substr( mb_strtoupper( trim( sanitize_text_field( wp_unslash( (string) ( $in['zlecenie'] ?? '' ) ) ) ), 'UTF-8' ), 0, 60 );
		if ( '' === $zlecenie ) {
			return new WP_Error( 'msm_invalid', 'Podaj numer zlecenia.', array( 'status' => 400, 'fields' => array( 'zlecenie' => 'Wymagany' ) ) );
		}
		$termin = '';
		if ( ! empty( $in['termin'] ) ) {
			$termin = preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $in['termin'] ) ? $in['termin'] : '';
			if ( $termin && $termin < current_time( 'Y-m-d' ) ) {
				return new WP_Error( 'msm_invalid', 'Termin ważności nie może być w przeszłości.', array( 'status' => 400, 'fields' => array( 'termin' => 'Data z przeszłości' ) ) );
			}
		}
		$uwagi = mb_substr( sanitize_textarea_field( wp_unslash( (string) ( $in['uwagi'] ?? '' ) ) ), 0, 2000 );

		$odc = null;
		if ( 'odcinek' === $tryb ) {
			$odc = MSM_Calc::odcinki( $in );
			if ( is_wp_error( $odc ) ) {
				return $odc;
			}
			$len = MSM_Calc::f( $item['dlugosc'] );
			if ( null === $len || $odc[2] > $len + 1e-9 ) {
				return new WP_Error( 'msm_stock', 'Odcinki nie mieszczą się w jednej sztuce (' . MSM_Calc::fmt( $len ) . ' m).', array( 'status' => 400, 'fields' => array( 'dlugosc' => 'Za długi' ) ) );
			}
			$ilosc = $odc[2];
			$need  = 1;
		} elseif ( $kg ) {
			$n = MSM_Calc::f( $in['ilosc'] ?? null );
			if ( null === $n || $n <= 0 ) {
				return new WP_Error( 'msm_invalid', 'Podaj ilość w kg.', array( 'status' => 400, 'fields' => array( 'ilosc' => 'Podaj ilość w kg' ) ) );
			}
			$ilosc = round( $n, 3 );
			$need  = $ilosc;
		} else {
			$n = MSM_Calc::f( $in['ilosc'] ?? null );
			if ( null === $n || $n < 1 || floor( $n ) != $n ) { // phpcs:ignore
				return new WP_Error( 'msm_invalid', 'Podaj liczbę sztuk.', array( 'status' => 400, 'fields' => array( 'ilosc' => 'Podaj liczbę sztuk' ) ) );
			}
			$ilosc = (int) $n;
			$need  = (int) $n;
		}

		$stan  = $kg ? (float) $item['ilosc'] : (int) $item['ilosc'];
		$avail = max( 0, $stan - self::reserved_pieces( (int) $item['id'], 0, $table ) );
		if ( $need > $avail + 1e-9 ) {
			$u = $kg ? ' kg' : ' szt.';
			return new WP_Error( 'msm_stock', 'Za mało dostępnego materiału: dostępne ' . MSM_Calc::fmt( $avail ) . ' z ' . MSM_Calc::fmt( $stan ) . $u . ' (reszta już zarezerwowana).', array( 'status' => 400, 'fields' => array( 'ilosc' => 'Dostępne ' . MSM_Calc::fmt( $avail ) ) ) );
		}
		$det_id = (int) ( $in['prod_det_id'] ?? 0 );

		$admin  = current_user_can( 'msm_edit' );
		$status = $admin ? self::ST_ACTIVE : self::ST_NEW;
		$now    = current_time( 'mysql' );
		$wpdb->insert( self::T(), array(
			'item_table'   => $table,
			'item_id'      => (int) $item['id'],
			'material'     => mb_substr( MSM_Calc::describe( $table, $item ), 0, 255 ),
			'prod_det_id'  => $det_id ? $det_id : null,
			'user_id'      => get_current_user_id(),
			'user_name'    => MSM_Repo::user_name(),
			'tryb'         => $tryb,
			'ilosc'        => $ilosc,
			'odc_szt'      => $odc ? $odc[0] : null,
			'odc_dl'       => $odc ? $odc[1] : null,
			'zlecenie'     => $zlecenie,
			'termin'       => $termin ? $termin : null,
			'uwagi'        => '' === $uwagi ? null : $uwagi,
			'status'       => $status,
			'created_at'   => $now,
			'decided_by'   => $admin ? get_current_user_id() : null,
			'decided_name' => $admin ? MSM_Repo::user_name() : null,
			'decided_at'   => $admin ? $now : null,
		) );
		$id = (int) $wpdb->insert_id;
		MSM_Repo::log( $admin ? 'rezerwacja: utworzona' : 'rezerwacja: prośba', 'rezerwacje', $id, self::summary( self::get( $id ) ), null, array( $table, (int) $item['id'] ) );
		$w = self::get( $id );
		if ( ! empty( $in['cicho'] ) ) {
			// Rezerwacja automatyczna (zapotrzebowanie / dostawa) – bez e-maili.
		} elseif ( $admin ) {
			self::notify_requester( $w, 'Rezerwacja ' . $zlecenie . ' została utworzona.' );
		} else {
			self::notify_admins( $w );
		}
		return array( 'ok' => true, 'id' => $id, 'message' => $admin ? 'Zarezerwowano ' . self::qtytxt( $w ) . '.' : 'Prośba o rezerwację wysłana – czeka na akceptację administratora.' );
	}

	/* ------------------------------------------------------------------ *
	 * Decyzje administratora
	 * ------------------------------------------------------------------ */

	public static function action( $id, $action, $note = '' ) {
		global $wpdb;
		$w = self::get( $id );
		if ( ! $w ) {
			return new WP_Error( 'msm_not_found', 'Rezerwacja nie istnieje.', array( 'status' => 404 ) );
		}
		$admin = current_user_can( 'msm_edit' );
		$note  = mb_substr( sanitize_text_field( wp_unslash( (string) $note ) ), 0, 500 );
		$now   = current_time( 'mysql' );

		if ( 'anuluj' === $action ) {
			$own = (int) $w['user_id'] === get_current_user_id();
			if ( ! $admin && ! ( $own && self::ST_NEW === $w['status'] ) ) {
				return new WP_Error( 'msm_forbidden', 'Brak uprawnień.', array( 'status' => 403 ) );
			}
			if ( ! in_array( $w['status'], array( self::ST_NEW, self::ST_ACTIVE ), true ) ) {
				return new WP_Error( 'msm_state', 'Tej rezerwacji nie można anulować.', array( 'status' => 400 ) );
			}
			$wpdb->update( self::T(), array( 'status' => self::ST_CANCELED, 'admin_note' => $note ? $note : null ), array( 'id' => $id ) );
			MSM_Repo::log( 'rezerwacja: anulowana', 'rezerwacje', $id, self::summary( $w ) . ( $note ? ' (' . $note . ')' : '' ), null, array( self::table( $w['item_table'] ), (int) $w['item_id'] ) );
			if ( $admin && (int) $w['user_id'] !== get_current_user_id() ) {
				self::notify_requester( $w, 'Rezerwacja ' . $w['zlecenie'] . ' została anulowana.' . ( $note ? ' ' . $note : '' ) );
			}
			return array( 'ok' => true, 'message' => 'Rezerwacja anulowana – materiał zwolniony.' );
		}

		if ( ! $admin ) {
			return new WP_Error( 'msm_forbidden', 'Brak uprawnień.', array( 'status' => 403 ) );
		}

		if ( 'akceptuj' === $action ) {
			if ( self::ST_NEW !== $w['status'] ) {
				return new WP_Error( 'msm_state', 'Tę prośbę już rozpatrzono.', array( 'status' => 409 ) );
			}
			$wt    = self::table( $w['item_table'] );
			$item  = MSM_Repo::get( $wt, (int) $w['item_id'] );
			if ( ! $item ) {
				return new WP_Error( 'msm_not_found', 'Pozycja już nie istnieje.', array( 'status' => 404 ) );
			}
			$kg    = self::kg( $wt );
			$need  = 'odcinek' === $w['tryb'] ? 1 : ( $kg ? (float) $w['ilosc'] : (int) $w['ilosc'] );
			$stan  = $kg ? (float) $item['ilosc'] : (int) $item['ilosc'];
			$avail = max( 0, $stan - self::reserved_pieces( (int) $w['item_id'], 0, $wt ) );
			if ( $need > $avail + 1e-9 ) {
				return new WP_Error( 'msm_stock', 'Nie można zatwierdzić – dostępne tylko ' . MSM_Calc::fmt( $avail ) . ' z ' . MSM_Calc::fmt( $stan ) . ( $kg ? ' kg.' : ' szt.' ), array( 'status' => 400 ) );
			}
			$wpdb->update( self::T(), array( 'status' => self::ST_ACTIVE, 'decided_by' => get_current_user_id(), 'decided_name' => MSM_Repo::user_name(), 'decided_at' => $now, 'admin_note' => $note ? $note : null ), array( 'id' => $id ) );
			MSM_Repo::log( 'rezerwacja: zatwierdzona', 'rezerwacje', $id, self::summary( $w ), null, array( self::table( $w['item_table'] ), (int) $w['item_id'] ) );
			self::notify_requester( self::get( $id ), 'Rezerwacja ' . $w['zlecenie'] . ' została zatwierdzona.' . ( $note ? ' ' . $note : '' ) );
			return array( 'ok' => true, 'message' => 'Rezerwacja zatwierdzona – materiał zablokowany pod zlecenie ' . $w['zlecenie'] . '.' );
		}

		if ( 'odrzuc' === $action ) {
			if ( self::ST_NEW !== $w['status'] ) {
				return new WP_Error( 'msm_state', 'Tę prośbę już rozpatrzono.', array( 'status' => 409 ) );
			}
			$wpdb->update( self::T(), array( 'status' => self::ST_REJECTED, 'decided_by' => get_current_user_id(), 'decided_name' => MSM_Repo::user_name(), 'decided_at' => $now, 'admin_note' => $note ? $note : null ), array( 'id' => $id ) );
			MSM_Repo::log( 'rezerwacja: odrzucona', 'rezerwacje', $id, self::summary( $w ) . ( $note ? ' (' . $note . ')' : '' ), null, array( self::table( $w['item_table'] ), (int) $w['item_id'] ) );
			self::notify_requester( self::get( $id ), 'Prośba o rezerwację ' . $w['zlecenie'] . ' została odrzucona.' . ( $note ? ' ' . $note : '' ) );
			return array( 'ok' => true, 'message' => 'Prośbę odrzucono.' );
		}

		if ( 'wydaj' === $action ) {
			if ( self::ST_ACTIVE !== $w['status'] ) {
				return new WP_Error( 'msm_state', 'Wydać można tylko aktywną rezerwację.', array( 'status' => 400 ) );
			}
			$res = MSM_Repo::pobranie( array(
				'tabela'          => self::table( $w['item_table'] ),
				'item_id'         => (int) $w['item_id'],
				'tryb'            => 'kg' === $w['tryb'] ? 'szt' : $w['tryb'],
				'ilosc'           => $w['ilosc'],
				'dlugosc'         => ! empty( $w['odc_dl'] ) ? $w['odc_dl'] : $w['ilosc'],
				'odc_szt'         => ! empty( $w['odc_szt'] ) ? $w['odc_szt'] : 1,
				'zlecenie'        => $w['zlecenie'],
				'odbiorca'        => $w['user_name'],
				'uwagi'           => trim( 'Rezerwacja #' . (int) $w['id'] . ', zlecenie ' . $w['zlecenie'] . ( $note ? ' | ' . $note : ( $w['uwagi'] ? ' | ' . $w['uwagi'] : '' ) ) ),
				'data'            => current_time( 'Y-m-d' ),
				'from_rezerwacja' => (int) $w['id'],
			) );
			if ( is_wp_error( $res ) ) {
				$res->add_data( array( 'status' => 400 ) );
				return new WP_Error( $res->get_error_code(), 'Nie można wydać: ' . $res->get_error_message(), array( 'status' => 400 ) );
			}
			$wpdb->update( self::T(), array( 'status' => self::ST_ISSUED, 'pobranie_id' => (int) $res['pobranie']['id'] ), array( 'id' => $id ) );
			MSM_Repo::log( 'rezerwacja: wydana', 'rezerwacje', $id, self::summary( $w ), null, array( self::table( $w['item_table'] ), (int) $w['item_id'] ) );
			return array( 'ok' => true, 'message' => 'Wydano z rezerwacji. ' . $res['message'] );
		}

		return new WP_Error( 'msm_invalid', 'Nieznana akcja.', array( 'status' => 400 ) );
	}

	/** Oznacza przeterminowane rezerwacje jako wygasłe i zwalnia materiał. */
	public static function expire() {
		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM `' . self::T() . '` WHERE status = %s AND termin IS NOT NULL AND termin < %s', self::ST_ACTIVE, current_time( 'Y-m-d' ) ), ARRAY_A ); // phpcs:ignore
		foreach ( $rows as $w ) {
			$wpdb->update( self::T(), array( 'status' => self::ST_EXPIRED ), array( 'id' => (int) $w['id'] ) );
			MSM_Repo::log( 'rezerwacja: wygasła', 'rezerwacje', (int) $w['id'], self::summary( $w ), null, array( self::table( $w['item_table'] ), (int) $w['item_id'] ) );
			self::notify_requester( $w, 'Rezerwacja ' . $w['zlecenie'] . ' wygasła (minął termin ' . mysql2date( 'd.m.Y', $w['termin'] ) . ') – materiał został zwolniony.' );
		}
	}

	/* ------------------------------------------------------------------ *
	 * Pomocnicze
	 * ------------------------------------------------------------------ */

	public static function get( $id ) {
		global $wpdb;
		$r = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM `' . self::T() . '` WHERE id = %d', (int) $id ), ARRAY_A ); // phpcs:ignore
		return $r ? $r : null;
	}

	public static function qtytxt( $w ) {
		$t = MSM_Calc::odc_txt( $w );
		return MSM_Calc::fmt( $w['ilosc'] ) . ' ' . ( 'odcinek' === $w['tryb'] ? 'm' : ( 'kg' === $w['tryb'] ? 'kg' : 'szt.' ) ) . ( $t ? ' (' . $t . ')' : '' );
	}

	private static function summary( $w ) {
		return 'Rezerwacja #' . (int) $w['id'] . ': ' . self::qtytxt( $w ) . ' – ' . $w['material'] . ' (zlecenie ' . $w['zlecenie'] . ')' . ( ! empty( $w['termin'] ) ? ', termin ' . mysql2date( 'd.m.Y', $w['termin'] ) : '' );
	}

	public static function counts() {
		global $wpdb;
		self::expire();
		$T   = self::T();
		$out = array(
			'nowe'    => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM `$T` WHERE status = %s", self::ST_NEW ) ), // phpcs:ignore
			'aktywne' => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM `$T` WHERE status = %s", self::ST_ACTIVE ) ), // phpcs:ignore
		);
		if ( ! current_user_can( 'msm_edit' ) ) {
			$out['moje'] = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM `$T` WHERE status IN (%s,%s) AND user_id = %d", self::ST_NEW, self::ST_ACTIVE, get_current_user_id() ) ); // phpcs:ignore
		}
		return $out;
	}

	/* ------------------------------------------------------------------ *
	 * E-maile
	 * ------------------------------------------------------------------ */

	public static function notify_admins( $w ) {
		$t = MSM_Mail::render( 'rez_admin', array(
			'user_name' => $w['user_name'],
			'material'  => $w['material'],
			'ilosc'     => self::qtytxt( $w ),
			'zlecenie'  => $w['zlecenie'],
			'termin'    => $w['termin'] ? mysql2date( 'd.m.Y', $w['termin'] ) : 'bez terminu',
			'uwagi'     => $w['uwagi'] ? $w['uwagi'] : '—',
			'url'       => '<a href="' . esc_url( MSM_Access::app_url() . '#rezerwacje' ) . '">Otwórz rezerwacje</a>',
		) );
		return MSM_Mail::send( MSM_Wnioski::admin_emails(), $t['subject'], $t['body'], array( 'footer' => true, 'logo' => true ) );
	}

	public static function notify_requester( $w, $msg ) {
		$u = get_userdata( (int) $w['user_id'] );
		if ( ! $u || ! is_email( $u->user_email ) ) {
			return false;
		}
		$t = MSM_Mail::render( 'rez_status', array(
			'komunikat' => $msg,
			'status'    => self::labels()[ self::get( (int) $w['id'] )['status'] ] ?? '',
			'material'  => $w['material'],
			'ilosc'     => self::qtytxt( $w ),
			'zlecenie'  => $w['zlecenie'],
			'url'       => '<a href="' . esc_url( MSM_Access::app_url() . '#rezerwacje' ) . '">Otwórz rezerwacje</a>',
		) );
		return MSM_Mail::send( $u->user_email, $t['subject'], $t['body'], array( 'footer' => true, 'logo' => true ) );
	}

	/* ------------------------------------------------------------------ *
	 * REST
	 * ------------------------------------------------------------------ */

	public static function routes() {
		$ns   = MSM_Rest::NS;
		$view = array( 'MSM_Rest', 'can_view' );
		register_rest_route( $ns, '/rezerwacje', array(
			'methods' => 'POST', 'permission_callback' => $view,
			'callback' => function ( WP_REST_Request $r ) { return rest_ensure_response( MSM_Rezerwacje::create( (array) $r->get_json_params() ) ); },
		) );
		register_rest_route( $ns, '/rezerwacje/count', array(
			'methods' => 'GET', 'permission_callback' => $view,
			'callback' => function () { return rest_ensure_response( MSM_Rezerwacje::counts() ); },
		) );
		register_rest_route( $ns, '/rezerwacje/item/(?P<id>\d+)', array(
			'methods' => 'GET', 'permission_callback' => $view,
			'callback' => function ( WP_REST_Request $r ) { return rest_ensure_response( MSM_Rezerwacje::item_info( (int) $r['id'], (string) ( $r->get_param( 'table' ) ?: 'stal' ) ) ); },
		) );
		register_rest_route( $ns, '/rezerwacje/(?P<id>\d+)/(?P<action>akceptuj|odrzuc|anuluj|wydaj)', array(
			'methods' => 'POST', 'permission_callback' => $view,
			'callback' => function ( WP_REST_Request $r ) {
				return rest_ensure_response( MSM_Rezerwacje::action( (int) $r['id'], (string) $r['action'], (string) ( ( (array) $r->get_json_params() )['note'] ?? '' ) ) );
			},
		) );
	}
}
