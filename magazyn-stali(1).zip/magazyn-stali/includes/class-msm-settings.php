<?php
/**
 * Ustawienia systemu edytowane w aplikacji (Techniczne → Ustawienia):
 * dane firmy na wydrukach i w e-mailach, konta „super administratora”,
 * odbiorcy powiadomień o pobraniu blachy pełnej.
 *
 * Filtry 'msm_super_logins' i 'msm_blachy_pelne_notify' nadal działają – dostają wartości z ustawień.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MSM_Settings {

	const OPT = 'msm_settings';

	/** Wartości domyślne = dotychczasowe wpisy w kodzie (zachowanie bez zmian po aktualizacji). */
	public static function defaults() {
		return array(
			'firma_nazwa'    => 'Kisielewski sp. z o.o.',
			'firma_skrot'    => 'KISIELEWSKI',
			'firma_adres'    => 'Ligota Wołczyńska 70, 46-250 Wołczyn',
			'firma_nip'      => '751-177-18-02',
			'magazyn_nazwa'  => 'Ligota Wołczyńska',
			'pal_kontakt'    => 'Damian Marweg  tel. 607 069 020',
			'super_logins'   => array(), // 1.84.0: bez loginu wpisanego w kod – lista żyje w ustawieniach
			'blachy_notify'  => array( 'damian.marweg' ),
			'prog_zlecenia'  => 7,
			'prog_elektro'   => 14,
			'prog_pomiar'    => 60,
			'lokalizacje'    => array( 'Ligota Wołczyńska', 'Wrocław' ),
			'pracownicy_zmian' => array( 'Dróbka Michał', 'Garbowski Marcin', 'Grzegorz Skorny', 'Kuryło Dariusz', 'Rybka Dariusz', 'Miłosz Garbowski', 'Żurawski Krzysztof', 'Tymoteusz Śpiewak', 'Krystian Bielski', 'Oliver Marweg', 'Zofia Kisielewska' ),
		);
	}

	/** Lokalizacje przyrządów pomiarowych i elektronarzędzi (lista z Ustawień). */
	public static function lokalizacje() {
		$l = array_values( array_filter( array_map( 'strval', (array) ( self::all()['lokalizacje'] ?? array() ) ), 'strlen' ) );
		return $l ? $l : self::defaults()['lokalizacje'];
	}

	/** Lista do wyboru w formularzu: z Ustawień + nazwy już użyte w tabeli (usunięta z listy nie znika z kart). */
	public static function lokalizacje_z( $table ) {
		global $wpdb;
		$used = (array) $wpdb->get_col( "SELECT DISTINCT lokalizacja FROM `$table` WHERE lokalizacja <> ''" ); // phpcs:ignore
		return array_values( array_unique( array_merge( self::lokalizacje(), $used ) ) );
	}

	/** Lokalizacja z formularza – musi być z listy (lub już użyta wcześniej). */
	public static function lokalizacja_in( $v, $table ) {
		$v = trim( sanitize_text_field( (string) $v ) );
		if ( '' === $v ) {
			return new WP_Error( 'msm_400', 'Wybierz lokalizację.', array( 'status' => 400, 'fields' => array( 'lokalizacja' => 'Wymagana' ) ) );
		}
		return in_array( $v, self::lokalizacje_z( $table ), true ) ? $v : new WP_Error( 'msm_400', 'Nieznana lokalizacja – dodaj ją najpierw w Ustawieniach.', array( 'status' => 400, 'fields' => array( 'lokalizacja' => 'Spoza listy' ) ) );
	}

	/** Progi ostrzeżeń w dniach (pola liczbowe w Ustawieniach). */
	public static function num_fields() {
		return array(
			'prog_zlecenia' => 'Zlecenie zagrożone – tyle dni (lub mniej) przed terminem zakończenia',
			'prog_elektro'  => 'Elektronarzędzia – ostrzeżenie tyle dni przed terminem sprawdzenia',
			'prog_pomiar'   => 'Przyrządy pomiarowe – ostrzeżenie tyle dni przed terminem wzorcowania',
		);
	}

	/** Próg ostrzeżenia (dni) – zawsze liczba 1–365. */
	public static function prog( $key ) {
		$v = (int) ( self::all()[ $key ] ?? 0 );
		return $v >= 1 && $v <= 365 ? $v : (int) self::defaults()[ $key ];
	}

	/** Etykiety pól tekstowych (kolejność = kolejność w formularzu). */
	public static function text_fields() {
		return array(
			'firma_nazwa'   => 'Pełna nazwa firmy (wydruki, stopki e-maili)',
			'firma_skrot'   => 'Skrót nazwy (nagłówki wydruków BHP)',
			'firma_adres'   => 'Adres firmy',
			'firma_nip'     => 'NIP firmy (przy odczycie WZ/PZ pomijany – to nie NIP dostawcy)',
			'magazyn_nazwa' => 'Nazwa magazynu / lokalizacji (wydruki, dokumenty WZ)',
			'pal_kontakt'   => 'Kontakt u nadawcy na paletówkach (osoba i telefon)',
		);
	}

	public static function all() {
		$saved = get_option( self::OPT, array() );
		return array_merge( self::defaults(), is_array( $saved ) ? $saved : array() );
	}

	/** Powiązanie login => ID konta dla super administratorów (ustalone przy zapisie ustawień). */
	public static function super_ids() {
		$saved = get_option( self::OPT, array() );
		$ids   = is_array( $saved ) && isset( $saved['super_ids'] ) && is_array( $saved['super_ids'] ) ? $saved['super_ids'] : array();
		return array_map( 'intval', $ids );
	}

	/** Loginy => ID istniejących kont (brakujące loginy są pomijane). */
	public static function bind_ids( array $logins ) {
		$out = array();
		foreach ( $logins as $login ) {
			$login = strtolower( trim( (string) $login ) );
			if ( '' === $login ) {
				continue;
			}
			$u = get_user_by( 'login', $login );
			if ( $u ) {
				$out[ $login ] = (int) $u->ID;
			}
		}
		return $out;
	}

	/** Czy login jest zarezerwowany dla super administratora (na liście w ustawieniach). */
	public static function is_super_login( $login ) {
		$list = array_map( function ( $v ) { return strtolower( trim( (string) $v ) ); }, (array) self::get( 'super_logins' ) );
		return in_array( strtolower( trim( (string) $login ) ), $list, true );
	}

	public static function get( $key ) {
		$all = self::all();
		return $all[ $key ] ?? '';
	}

	/** Kto może zmieniać ustawienia: administrator WordPressa albo super administrator magazynu. */
	public static function can_manage() {
		if ( MSM_Perms::is_wp_admin() || ( MSM_Install::can_purge() && MSM_Perms::menu_on( 'ustawienia' ) ) ) {
			return true;
		}
		return new WP_Error( 'msm_forbidden', 'Ustawienia może zmieniać tylko administrator WordPressa lub super administrator.', array( 'status' => 403 ) );
	}

	/** Lista loginów/e-maili z pola tekstowego lub tablicy. */
	private static function list_from( $v ) {
		$items = is_array( $v ) ? $v : preg_split( '/[\s,;]+/', (string) $v );
		$out   = array();
		foreach ( $items as $i ) {
			$i = trim( (string) $i );
			if ( '' === $i ) {
				continue;
			}
			$out[] = is_email( $i ) ? sanitize_email( $i ) : sanitize_user( $i, true );
		}
		return array_values( array_unique( array_filter( $out ) ) );
	}

	public static function for_admin() {
		$all     = self::all();
		$missing = array();
		$ids     = self::super_ids();
		foreach ( array( 'super_logins', 'blachy_notify' ) as $k ) {
			foreach ( $all[ $k ] as $login ) {
				$u = is_email( $login ) ? null : get_user_by( 'login', $login );
				if ( ! is_email( $login ) && ! $u ) {
					$missing[ $k ][] = $login;
				} elseif ( 'super_logins' === $k && $u && ( $ids[ strtolower( $login ) ] ?? 0 ) !== (int) $u->ID ) {
					$missing[ $k ][] = $login . ' (konto założone po zapisie listy – zapisz ustawienia ponownie, aby je potwierdzić)';
				}
			}
		}
		return array(
			'values'   => $all,
			'labels'   => self::text_fields(),
			'nums'     => self::num_fields(),
			'missing'  => $missing,
			'wp_admin' => MSM_Perms::is_wp_admin(),
			'me'       => wp_get_current_user()->user_login,
			'users'    => array_map( function ( $u ) { // podpowiedzi w polach z loginami
				return array( 'login' => $u->user_login, 'name' => $u->display_name, 'email' => $u->user_email );
			}, get_users( array( 'number' => 500, 'orderby' => 'display_name', 'fields' => array( 'user_login', 'display_name', 'user_email' ) ) ) ),
		);
	}

	public static function save( array $in ) {
		$cur    = self::all();
		$new    = $cur;
		foreach ( array_keys( self::text_fields() ) as $k ) {
			if ( isset( $in[ $k ] ) ) {
				$v = sanitize_text_field( (string) $in[ $k ] );
				$new[ $k ] = '' === $v ? self::defaults()[ $k ] : mb_substr( $v, 0, 200 );
			}
		}
		foreach ( array_keys( self::num_fields() ) as $k ) {
			if ( isset( $in[ $k ] ) ) {
				$v = (int) $in[ $k ];
				if ( $v < 1 || $v > 365 ) {
					return new WP_Error( 'msm_settings', 'Próg ostrzeżenia musi być liczbą dni od 1 do 365.', array( 'status' => 400, 'fields' => array( $k => 'Podaj od 1 do 365 dni' ) ) );
				}
				$new[ $k ] = $v;
			}
		}
		if ( isset( $in['lokalizacje'] ) ) {
			$items = is_array( $in['lokalizacje'] ) ? $in['lokalizacje'] : preg_split( '/\r\n|\r|\n/', (string) $in['lokalizacje'] );
			$lok   = array();
			foreach ( $items as $i ) {
				$i = mb_substr( trim( sanitize_text_field( (string) $i ) ), 0, 60 );
				if ( '' !== $i && ! in_array( mb_strtolower( $i ), array_map( 'mb_strtolower', $lok ), true ) ) {
					$lok[] = $i;
				}
			}
			if ( ! $lok ) {
				return new WP_Error( 'msm_settings', 'Podaj co najmniej jedną lokalizację.', array( 'status' => 400, 'fields' => array( 'lokalizacje' => 'Wymagana co najmniej jedna' ) ) );
			}
			$new['lokalizacje'] = array_slice( $lok, 0, 30 );
		}
		if ( isset( $in['pracownicy_zmian'] ) ) {
			$items = is_array( $in['pracownicy_zmian'] ) ? $in['pracownicy_zmian'] : preg_split( '/\r\n|\r|\n/', (string) $in['pracownicy_zmian'] );
			$pr    = array();
			foreach ( $items as $i ) {
				$i = mb_substr( trim( sanitize_text_field( (string) $i ) ), 0, 120 );
				if ( '' !== $i && ! in_array( mb_strtolower( $i ), array_map( 'mb_strtolower', $pr ), true ) ) {
					$pr[] = $i;
				}
			}
			$new['pracownicy_zmian'] = array_slice( $pr, 0, 200 );
		}
		if ( isset( $in['blachy_notify'] ) ) {
			$new['blachy_notify'] = self::list_from( $in['blachy_notify'] );
		}
		if ( isset( $in['super_logins'] ) ) {
			$list = self::list_from( $in['super_logins'] );
			// Super administrator nie może przypadkiem odebrać uprawnień samemu sobie (zablokowałby ustawienia).
			$me = strtolower( wp_get_current_user()->user_login );
			if ( ! MSM_Perms::is_wp_admin() && ! in_array( $me, array_map( 'strtolower', $list ), true ) ) {
				return new WP_Error( 'msm_settings', 'Nie możesz usunąć z listy własnego loginu („' . $me . '”). Zrobi to administrator WordPressa.', array( 'status' => 400, 'fields' => array( 'super_logins' => 'Brakuje Twojego loginu.' ) ) );
			}
			// Tylko istniejące konta: wpisanie loginu „na zapas” pozwalało przejąć uprawnienia, zakładając później konto o tej nazwie.
			$list  = array_values( array_filter( $list, function ( $l ) { return ! is_email( $l ); } ) );
			$bound = self::bind_ids( $list );
			$miss  = array_values( array_filter( $list, function ( $l ) use ( $bound ) { return ! isset( $bound[ strtolower( $l ) ] ); } ) );
			if ( $miss ) {
				return new WP_Error( 'msm_settings', 'Na liście super administratorów mogą być tylko istniejące konta. Brak kont: ' . implode( ', ', $miss ) . '.', array( 'status' => 400, 'fields' => array( 'super_logins' => 'Nieistniejące loginy: ' . implode( ', ', $miss ) ) ) );
			}
			$new['super_logins'] = $list;
			$new['super_ids']    = $bound;
		}
		$diff = array( 'przed' => array(), 'po' => array() );
		foreach ( $new as $k => $v ) {
			if ( $v !== ( $cur[ $k ] ?? null ) ) {
				$diff['przed'][ $k ] = $cur[ $k ] ?? null;
				$diff['po'][ $k ]    = $v;
			}
		}
		if ( ! $diff['po'] ) {
			return array( 'message' => 'Brak zmian.' ) + self::for_admin();
		}
		update_option( self::OPT, $new, false );
		MSM_Repo::log( 'Ustawienia: zmiana', 'ustawienia', 0, 'Zmieniono ustawienia: ' . implode( ', ', array_keys( $diff['po'] ) ), $diff );
		return array( 'message' => 'Zapisano ustawienia.' ) + self::for_admin();
	}
}

/** Skrót do ustawień (szablony wydruków, e-maile). */
function msm_opt( $key ) {
	return MSM_Settings::get( $key );
}

/** Stopka e-maili tekstowych. */
function msm_mail_footer() {
	return "\n\n— \nSystem K-ERP · " . msm_opt( 'firma_nazwa' ) . "\n";
}
