<?php
/**
 * Przesyłki – rejestr przesyłek przychodzących (kontrola dostaw).
 *
 * Pola jak na papierowym formularzu: data/godzina sprawdzenia, nadawca, zlecenie, faktura (tak/nie),
 * zawartość, ilość, uwagi (np. uszkodzenia), sprawdził. Dodaje każdy z dostępem do zakładki,
 * poprawia i usuwa tylko administrator magazynu.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MSM_Przesylki {

	const JEDN = array( 'szt.', 'kpl.', 'kg', 'palet', 'paczek', 'kartonów', 'kręgów', 'arkuszy' );

	public static function T() {
		global $wpdb;
		return $wpdb->prefix . 'msm_przesylki';
	}

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
		add_action( 'template_redirect', array( __CLASS__, 'maybe_print' ), 1 );
	}

	public static function create_tables() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$c = $wpdb->get_charset_collate();
		dbDelta( 'CREATE TABLE ' . self::T() . " (
id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
data_spr datetime NOT NULL,
nadawca varchar(255) NOT NULL DEFAULT '',
zlec_id bigint(20) unsigned NULL,
zlecenie varchar(190) NOT NULL DEFAULT '',
faktura tinyint(1) NOT NULL DEFAULT 0,
zawartosc text NULL,
pozycje longtext NULL,
ilosc decimal(14,3) NULL,
jedn varchar(20) NOT NULL DEFAULT '',
uwagi text NULL,
uszkodzona tinyint(1) NOT NULL DEFAULT 0,
sprawdzil varchar(190) NOT NULL DEFAULT '',
created_at datetime NULL,
created_by bigint(20) unsigned NOT NULL DEFAULT 0,
updated_at datetime NULL,
updated_by bigint(20) unsigned NOT NULL DEFAULT 0,
PRIMARY KEY  (id),
KEY data_spr (data_spr),
KEY zlec (zlec_id)
) $c;" );
	}

	private static function ready() {
		global $wpdb;
		static $ok = null;
		if ( null === $ok ) {
			$ok = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', self::T() ) ) === self::T();
		}
		return $ok;
	}

	/* ---------------- uprawnienia ---------------- */

	public static function can_view() {
		if ( ! is_user_logged_in() || ! current_user_can( 'msm_view' ) ) {
			return new WP_Error( 'msm_forbidden', 'Brak dostępu.', array( 'status' => 403 ) );
		}
		return MSM_Perms::menu_on( 'przesylki' ) ? true : new WP_Error( 'msm_forbidden', 'Zakładka Przesyłki jest dla Ciebie wyłączona.', array( 'status' => 403 ) );
	}

	/**
	 * Poprawianie i usuwanie wpisów – akcja „Przesyłki – poprawianie i usuwanie wpisów”
	 * (domyślnie tylko administrator magazynu; można nadać/odebrać w Użytkownicy → Uprawnienia).
	 */
	public static function is_admin() {
		return MSM_Perms::is_wp_admin() || MSM_Perms::cap_on( 'przesylki' );
	}

	public static function can_admin() {
		$c = self::can_view();
		if ( is_wp_error( $c ) ) {
			return $c;
		}
		return self::is_admin() ? true : new WP_Error( 'msm_forbidden', 'Nie masz uprawnienia do poprawiania i usuwania przesyłek.', array( 'status' => 403 ) );
	}

	public static function routes() {
		$ns = MSM_Rest::NS;
		register_rest_route( $ns, '/przesylki', array(
			array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'list_r' ), 'permission_callback' => array( __CLASS__, 'can_view' ) ),
			array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'add_r' ), 'permission_callback' => array( __CLASS__, 'can_view' ) ),
		) );
		register_rest_route( $ns, '/przesylki/(?P<id>\d+)', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'save_r' ), 'permission_callback' => array( __CLASS__, 'can_admin' ) ) );
		register_rest_route( $ns, '/przesylki/(?P<id>\d+)/delete', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'delete_r' ), 'permission_callback' => array( __CLASS__, 'can_admin' ) ) );
		register_rest_route( $ns, '/przesylki/export', array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'export_r' ), 'permission_callback' => array( __CLASS__, 'can_view' ) ) );
	}

	/* ---------------- dane ---------------- */

	/**
	 * Pozycje przesyłki [ {opis, ilosc, jedn, zlec_id, zlecenie} ]. Każda pozycja ma własne zlecenie;
	 * starsze wpisy: zlecenie przesyłki dla wszystkich pozycji, a jedno pole zawartości → jedna pozycja.
	 */
	public static function pozycje( array $r ) {
		$zid = $r['zlec_id'] ? (int) $r['zlec_id'] : null;
		$zl  = (string) $r['zlecenie'];
		$p   = json_decode( (string) ( $r['pozycje'] ?? '' ), true );
		if ( is_array( $p ) && $p ) {
			return array_values( array_map( function ( $x ) use ( $zid, $zl ) {
				$own = array_key_exists( 'zlecenie', $x );
				return array(
					'opis'     => (string) ( $x['opis'] ?? '' ),
					'ilosc'    => isset( $x['ilosc'] ) && '' !== $x['ilosc'] && null !== $x['ilosc'] ? (float) $x['ilosc'] : null,
					'jedn'     => (string) ( $x['jedn'] ?? '' ),
					'zlec_id'  => $own ? ( empty( $x['zlec_id'] ) ? null : (int) $x['zlec_id'] ) : $zid,
					'zlecenie' => $own ? (string) $x['zlecenie'] : $zl,
					'uwagi'    => (string) ( $x['uwagi'] ?? '' ),
				);
			}, $p ) );
		}
		if ( '' === (string) $r['zawartosc'] && null === $r['ilosc'] ) {
			return array();
		}
		return array( array( 'opis' => (string) $r['zawartosc'], 'ilosc' => null === $r['ilosc'] ? null : (float) $r['ilosc'], 'jedn' => (string) $r['jedn'], 'zlec_id' => $zid, 'zlecenie' => $zl, 'uwagi' => '' ) );
	}

	/** Zlecenie wpisane w pozycji → [id, numer] (id tylko dla istniejącego zlecenia Produkcji). */
	private static function resolve_order( $zid, $txt ) {
		$zid = (int) $zid;
		$txt = mb_substr( sanitize_text_field( (string) $txt ), 0, 190 );
		if ( $zid && class_exists( 'MSM_Prod' ) ) {
			$o = MSM_Prod::get_order_public( $zid );
			if ( $o ) {
				return array( (int) $o['id'], (string) $o['nr_zlec'] );
			}
		}
		return array( null, $txt );
	}

	public static function cast( array $r ) {
		return array(
			'id'         => (int) $r['id'],
			'data_spr'   => substr( (string) $r['data_spr'], 0, 16 ),
			'nadawca'    => (string) $r['nadawca'],
			'zlec_id'    => $r['zlec_id'] ? (int) $r['zlec_id'] : null,
			'zlecenie'   => (string) $r['zlecenie'],
			'faktura'    => (bool) $r['faktura'],
			'pozycje'    => self::pozycje( $r ),
			'uwagi'      => (string) $r['uwagi'],
			'uszkodzona' => (bool) $r['uszkodzona'],
			'sprawdzil'  => (string) $r['sprawdzil'],
		);
	}

	/**
	 * Przesyłki do numeru zlecenia (Karta zlecenia, 1.85.0) – tak jak pozostałe sekcje karty: numer zawiera wpisany tekst,
	 * bez rozróżniania wielkości liter. Zwraca tylko pozycje do tego zlecenia; 'inne' = liczba pozostałych pozycji przesyłki.
	 */
	public static function for_number( $nr ) {
		global $wpdb;
		$nr = trim( (string) $nr );
		if ( '' === $nr || ! self::ready() ) {
			return array();
		}
		$T    = self::T();
		$like = '%' . $wpdb->esc_like( $nr ) . '%';
		$rows = (array) $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `$T` WHERE zlecenie LIKE %s OR pozycje LIKE %s ORDER BY data_spr DESC, id DESC LIMIT 500", $like, $like ), ARRAY_A ); // phpcs:ignore
		$needle = mb_strtolower( $nr );
		$out    = array();
		foreach ( $rows as $r ) {
			$p   = self::cast( $r );
			$hit = array_values( array_filter( $p['pozycje'], function ( $x ) use ( $needle ) {
				return '' !== (string) $x['zlecenie'] && false !== mb_strpos( mb_strtolower( (string) $x['zlecenie'] ), $needle );
			} ) );
			if ( ! $hit ) {
				continue;
			}
			$p['inne']    = count( $p['pozycje'] ) - count( $hit );
			$p['pozycje'] = $hit;
			$out[]        = $p;
		}
		return $out;
	}

	/** Przesyłki (najnowsze na górze); opcjonalnie tylko do zlecenia. */
	public static function rows( $zlec_id = 0 ) {
		global $wpdb;
		if ( ! self::ready() ) {
			return array();
		}
		$T   = self::T();
		$all = array_map( array( __CLASS__, 'cast' ), (array) $wpdb->get_results( "SELECT * FROM `$T` ORDER BY data_spr DESC, id DESC", ARRAY_A ) ); // phpcs:ignore
		if ( ! $zlec_id ) {
			return $all;
		}
		// Przesyłki z co najmniej jedną pozycją do zlecenia.
		return array_values( array_filter( $all, function ( $p ) use ( $zlec_id ) {
			foreach ( $p['pozycje'] as $x ) {
				if ( (int) $x['zlec_id'] === (int) $zlec_id ) {
					return true;
				}
			}
			return false;
		} ) );
	}

	/** Zlecenia Produkcji do wyboru (wszystkie lata, najnowsze na górze). */
	private static function orders() {
		global $wpdb;
		if ( ! class_exists( 'MSM_Prod' ) || ! MSM_Perms::menu_on( 'produkcja' ) ) {
			return array();
		}
		$T = MSM_Prod::TZ();
		if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $T ) ) !== $T ) {
			return array();
		}
		$rows = (array) $wpdb->get_results( "SELECT id, nr_zlec, klient, arkusz FROM `$T` WHERE nr_zlec <> '' ORDER BY arkusz DESC, poz DESC", ARRAY_A ); // phpcs:ignore
		return array_map( function ( $z ) { return array( 'id' => (int) $z['id'], 'nr' => (string) $z['nr_zlec'], 'klient' => (string) $z['klient'], 'rok' => (string) $z['arkusz'] ); }, $rows );
	}

	/** Podpowiedzi: wcześniejsi nadawcy i osoby sprawdzające (+ użytkownicy systemu). */
	private static function hints( array $rows ) {
		$nad = array();
		$spr = array();
		foreach ( $rows as $r ) {
			if ( '' !== $r['nadawca'] ) {
				$nad[ $r['nadawca'] ] = ( $nad[ $r['nadawca'] ] ?? 0 ) + 1;
			}
			if ( '' !== $r['sprawdzil'] ) {
				$spr[ $r['sprawdzil'] ] = ( $spr[ $r['sprawdzil'] ] ?? 0 ) + 1;
			}
		}
		foreach ( get_users( array( 'capability' => 'msm_view', 'fields' => array( 'display_name' ) ) ) as $u ) {
			if ( ! isset( $spr[ $u->display_name ] ) ) {
				$spr[ $u->display_name ] = 0;
			}
		}
		arsort( $nad );
		arsort( $spr );
		return array( 'nadawcy' => array_keys( $nad ), 'sprawdzajacy' => array_map( 'strval', array_keys( $spr ) ) );
	}

	/** Dane z formularza → wiersz bazy (z walidacją). */
	private static function input( WP_REST_Request $r ) {
		$p    = (array) $r->get_json_params();
		$data = trim( (string) ( $p['data_spr'] ?? '' ) );
		if ( ! preg_match( '/^(\d{4}-\d{2}-\d{2})[T ](\d{2}:\d{2})$/', $data, $m ) || ! strtotime( $m[1] . ' ' . $m[2] ) ) {
			return new WP_Error( 'msm_400', 'Podaj datę i godzinę sprawdzenia.', array( 'status' => 400, 'field' => 'data_spr' ) );
		}
		$nad = sanitize_text_field( (string) ( $p['nadawca'] ?? '' ) );
		if ( '' === $nad ) {
			return new WP_Error( 'msm_400', 'Podaj nadawcę przesyłki.', array( 'status' => 400, 'field' => 'nadawca' ) );
		}
		$poz = array();
		foreach ( array_slice( (array) ( $p['pozycje'] ?? array() ), 0, 100 ) as $i => $x ) {
			$opis = mb_substr( sanitize_text_field( (string) ( $x['opis'] ?? '' ) ), 0, 500 );
			$il   = $x['ilosc'] ?? '';
			$il   = '' === $il || null === $il ? null : str_replace( array( ' ', ',' ), array( '', '.' ), (string) $il );
			$uw   = mb_substr( sanitize_text_field( (string) ( $x['uwagi'] ?? '' ) ), 0, 500 );
			if ( '' === $opis && null === $il && '' === $uw ) {
				continue; // pusty wiersz
			}
			if ( '' === $opis ) {
				return new WP_Error( 'msm_400', 'Pozycja ' . ( $i + 1 ) . ': opisz, co przyszło.', array( 'status' => 400, 'field' => 'pozycje' ) );
			}
			if ( null !== $il && ( ! is_numeric( $il ) || $il < 0 ) ) {
				return new WP_Error( 'msm_400', 'Pozycja ' . ( $i + 1 ) . ': ilość musi być liczbą.', array( 'status' => 400, 'field' => 'pozycje' ) );
			}
			list( $zid, $zl ) = self::resolve_order( $x['zlec_id'] ?? 0, $x['zlecenie'] ?? '' );
			$poz[] = array( 'opis' => $opis, 'ilosc' => null === $il ? null : (float) $il, 'jedn' => null === $il ? '' : mb_substr( sanitize_text_field( (string) ( $x['jedn'] ?? '' ) ), 0, 20 ), 'zlec_id' => $zid, 'zlecenie' => $zl, 'uwagi' => $uw );
		}
		if ( ! $poz ) {
			return new WP_Error( 'msm_400', 'Dodaj co najmniej jedną pozycję zawartości przesyłki.', array( 'status' => 400, 'field' => 'pozycje' ) );
		}
		$spr = sanitize_text_field( (string) ( $p['sprawdzil'] ?? '' ) );
		if ( '' === $spr ) {
			return new WP_Error( 'msm_400', 'Podaj, kto sprawdził przesyłkę.', array( 'status' => 400, 'field' => 'sprawdzil' ) );
		}
		// Zlecenia przesyłki = zlecenia z pozycji (pierwsze powiązane – do szybkiego wyszukiwania; numery – tekst).
		$zid = null;
		$zls = array();
		foreach ( $poz as $x ) {
			if ( $x['zlec_id'] && ! $zid ) {
				$zid = $x['zlec_id'];
			}
			if ( '' !== $x['zlecenie'] && ! in_array( $x['zlecenie'], $zls, true ) ) {
				$zls[] = $x['zlecenie'];
			}
		}
		$zl = implode( ', ', $zls );
		return array(
			'data_spr'   => $m[1] . ' ' . $m[2] . ':00',
			'nadawca'    => mb_substr( $nad, 0, 255 ),
			'zlec_id'    => $zid ?: null,
			'zlecenie'   => mb_substr( $zl, 0, 190 ),
			'faktura'    => empty( $p['faktura'] ) ? 0 : 1,
			'zawartosc'  => mb_substr( implode( "\n", wp_list_pluck( $poz, 'opis' ) ), 0, 5000 ), // tekst do wyszukiwania i zgodności
			'pozycje'    => wp_json_encode( $poz, JSON_UNESCAPED_UNICODE ),
			'ilosc'      => null,
			'jedn'       => '',
			'uwagi'      => mb_substr( sanitize_textarea_field( (string) ( $p['uwagi'] ?? '' ) ), 0, 5000 ),
			'uszkodzona' => empty( $p['uszkodzona'] ) ? 0 : 1,
			'sprawdzil'  => mb_substr( $spr, 0, 190 ),
		);
	}

	private static function get( $id ) {
		global $wpdb;
		$r = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM `' . self::T() . '` WHERE id = %d', (int) $id ), ARRAY_A ); // phpcs:ignore
		return $r ?: null;
	}

	private static function label( array $r ) {
		return 'Przesyłka od ' . $r['nadawca'] . ' z ' . mysql2date( 'd.m.Y H:i', $r['data_spr'] ) . ( '' !== (string) $r['zlecenie'] ? ' (zlecenie ' . $r['zlecenie'] . ')' : '' );
	}

	/* ---------------- REST ---------------- */

	public static function list_r( WP_REST_Request $r ) {
		$rows = self::rows( (int) $r->get_param( 'zlec' ) );
		$all  = $r->get_param( 'zlec' ) ? self::rows() : $rows;
		return rest_ensure_response( array_merge(
			array(
				'przesylki' => $rows,
				'admin'     => self::is_admin(),
				'jedn'      => self::JEDN,
				'ja'        => wp_get_current_user()->display_name,
				'zlecenia'  => self::orders(),
			),
			self::hints( $all )
		) );
	}

	public static function add_r( WP_REST_Request $r ) {
		global $wpdb;
		$row = self::input( $r );
		if ( is_wp_error( $row ) ) {
			return $row;
		}
		$now = current_time( 'mysql' );
		$uid = get_current_user_id();
		$wpdb->insert( self::T(), $row + array( 'created_at' => $now, 'created_by' => $uid, 'updated_at' => $now, 'updated_by' => $uid ) );
		$id = (int) $wpdb->insert_id;
		if ( ! $id ) {
			return new WP_Error( 'msm_500', 'Nie udało się zapisać przesyłki.', array( 'status' => 500 ) );
		}
		MSM_Repo::log( 'Przesyłki: nowa', 'przesylki', $id, 'Dodano: ' . self::label( $row ) . ' – ' . mb_substr( $row['zawartosc'], 0, 80 ) . ( $row['uszkodzona'] ? ' [USZKODZONA]' : '' ), array( 'po' => $row ) );
		return rest_ensure_response( array( 'przesylka' => self::cast( self::get( $id ) ) ) );
	}

	public static function save_r( WP_REST_Request $r ) {
		global $wpdb;
		$old = self::get( (int) $r['id'] );
		if ( ! $old ) {
			return new WP_Error( 'msm_404', 'Przesyłka nie istnieje (mogła zostać usunięta).', array( 'status' => 404 ) );
		}
		$row = self::input( $r );
		if ( is_wp_error( $row ) ) {
			return $row;
		}
		$wpdb->update( self::T(), $row + array( 'updated_at' => current_time( 'mysql' ), 'updated_by' => get_current_user_id() ), array( 'id' => (int) $old['id'] ) );
		$diff = array();
		foreach ( $row as $k => $v ) {
			if ( (string) $v !== (string) $old[ $k ] && ! ( 'ilosc' === $k && (float) $v === (float) $old[ $k ] && null !== $old[ $k ] ) && ! ( 'data_spr' === $k && substr( $v, 0, 16 ) === substr( $old[ $k ], 0, 16 ) ) ) {
				$diff[ $k ] = array( $old[ $k ], $v );
			}
		}
		if ( $diff ) {
			MSM_Repo::log( 'Przesyłki: edycja', 'przesylki', (int) $old['id'], 'Zmieniono: ' . self::label( $row ) . ' – pola: ' . implode( ', ', array_keys( $diff ) ), array( 'przed' => array_map( function ( $d ) { return $d[0]; }, $diff ), 'po' => array_map( function ( $d ) { return $d[1]; }, $diff ) ) );
		}
		return rest_ensure_response( array( 'przesylka' => self::cast( self::get( (int) $old['id'] ) ) ) );
	}

	public static function delete_r( WP_REST_Request $r ) {
		global $wpdb;
		$old = self::get( (int) $r['id'] );
		if ( ! $old ) {
			return new WP_Error( 'msm_404', 'Przesyłka nie istnieje (mogła zostać usunięta).', array( 'status' => 404 ) );
		}
		$wpdb->delete( self::T(), array( 'id' => (int) $old['id'] ) );
		MSM_Repo::log( 'Przesyłki: usunięcie', 'przesylki', (int) $old['id'], 'Usunięto: ' . self::label( $old ), array( 'przed' => $old ) );
		return rest_ensure_response( array( 'deleted' => (int) $old['id'] ) );
	}

	/** Po usunięciu zlecenia: przesyłki zostają (z numerem zlecenia jako tekst), bez powiązania. */
	public static function unlink_order( $zid ) {
		global $wpdb;
		if ( ! self::ready() ) {
			return;
		}
		$wpdb->update( self::T(), array( 'zlec_id' => null ), array( 'zlec_id' => (int) $zid ) );
		foreach ( (array) $wpdb->get_results( $wpdb->prepare( 'SELECT id, pozycje FROM `' . self::T() . '` WHERE pozycje LIKE %s', '%"zlec_id":' . (int) $zid . '%' ), ARRAY_A ) as $r ) { // phpcs:ignore
			$p = json_decode( (string) $r['pozycje'], true );
			if ( ! is_array( $p ) ) {
				continue;
			}
			foreach ( $p as &$x ) {
				if ( isset( $x['zlec_id'] ) && (int) $x['zlec_id'] === (int) $zid ) {
					$x['zlec_id'] = null;
				}
			}
			unset( $x );
			$wpdb->update( self::T(), array( 'pozycje' => wp_json_encode( $p, JSON_UNESCAPED_UNICODE ) ), array( 'id' => (int) $r['id'] ) );
		}
	}

	/* ---------------- eksport / kopia ---------------- */

	private static function fmt_il( $v ) {
		if ( null === $v ) {
			return '';
		}
		$s = number_format( (float) $v, 3, ',', ' ' );
		return rtrim( rtrim( $s, '0' ), ',' );
	}

	/** Wiersze arkusza (nagłówek + dane) – eksport i kopia danych. */
	public static function export_rows( $od = '', $do = '' ) {
		$out = array( array( 'Data / godzina sprawdzenia', 'Nadawca przesyłki', 'Zlecenie', 'Faktura', 'Lp.', 'Zawartość przesyłki', 'Ilość', 'J.m.', 'Uwagi do pozycji', 'Uwagi do przesyłki', 'Uszkodzona', 'Sprawdził' ) );
		foreach ( array_reverse( self::rows() ) as $p ) {
			$d = substr( $p['data_spr'], 0, 10 );
			if ( ( $od && $d < $od ) || ( $do && $d > $do ) ) {
				continue;
			}
			// Jeden wiersz na pozycję (łatwe sumowanie w Excelu); dane przesyłki powtórzone.
			foreach ( ( $p['pozycje'] ?: array( array( 'opis' => '', 'ilosc' => null, 'jedn' => '', 'zlecenie' => $p['zlecenie'] ) ) ) as $i => $x ) {
				$out[] = array( mysql2date( 'd.m.Y H:i', $p['data_spr'] ), $p['nadawca'], $x['zlecenie'] ?? '', $p['faktura'] ? 'TAK' : 'NIE', $i + 1, $x['opis'], null === $x['ilosc'] ? '' : (float) $x['ilosc'], $x['jedn'], $x['uwagi'] ?? '', $p['uwagi'], $p['uszkodzona'] ? 'TAK' : '', $p['sprawdzil'] );
			}
		}
		return $out;
	}

	private static function range( WP_REST_Request $r ) {
		$od = (string) $r->get_param( 'od' );
		$do = (string) $r->get_param( 'do' );
		return array( preg_match( '/^\d{4}-\d{2}-\d{2}$/', $od ) ? $od : '', preg_match( '/^\d{4}-\d{2}-\d{2}$/', $do ) ? $do : '' );
	}

	public static function export_r( WP_REST_Request $r ) {
		list( $od, $do ) = self::range( $r );
		$rows   = self::export_rows( $od, $do );
		$format = 'csv' === $r->get_param( 'format' ) ? 'csv' : 'xlsx';
		$fname  = 'przesylki-' . current_time( 'Y-m-d' ) . '.' . $format;
		nocache_headers();
		if ( 'csv' === $format ) {
			header( 'Content-Type: text/csv; charset=UTF-8' );
			header( 'Content-Disposition: attachment; filename="' . $fname . '"' );
			$out = fopen( 'php://output', 'w' ); // phpcs:ignore
			fwrite( $out, "\xEF\xBB\xBF" ); // phpcs:ignore
			foreach ( $rows as $line ) {
				fputcsv( $out, array_map( function ( $v ) { return is_float( $v ) ? str_replace( '.', ',', (string) $v ) : msm_csv_safe( $v ); }, $line ), ';', '"', '\\' );
			}
			fclose( $out ); // phpcs:ignore
			exit;
		}
		if ( ! function_exists( 'wp_tempnam' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		$tmp = wp_tempnam( 'msm-przes' );
		if ( ! MSM_Xlsx::write( $tmp, 'Przesyłki', $rows, array( 18, 30, 14, 9, 5, 44, 10, 9, 36, 36, 11, 24 ) ) ) {
			return new WP_Error( 'msm_500', 'Nie udało się utworzyć pliku.', array( 'status' => 500 ) );
		}
		header( 'Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' );
		header( 'Content-Disposition: attachment; filename="' . $fname . '"' );
		header( 'Content-Length: ' . filesize( $tmp ) );
		readfile( $tmp ); // phpcs:ignore
		@unlink( $tmp ); // phpcs:ignore
		exit;
	}

	/* ---------------- Pulpit ---------------- */

	public static function tablica() {
		global $wpdb;
		if ( ! self::ready() ) {
			return null;
		}
		$T     = self::T();
		$today = current_time( 'Y-m-d' );
		$od    = gmdate( 'Y-m-d', strtotime( $today . ' -14 days' ) );
		$dz    = (array) $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `$T` WHERE data_spr >= %s AND data_spr < %s", $today . ' 00:00:00', gmdate( 'Y-m-d', strtotime( $today . ' +1 day' ) ) . ' 00:00:00' ), ARRAY_A ); // phpcs:ignore
		$poz   = 0;
		foreach ( $dz as $r ) {
			$poz += count( self::pozycje( $r ) );
		}
		$usz   = (array) $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `$T` WHERE uszkodzona = 1 AND data_spr >= %s ORDER BY data_spr DESC LIMIT 5", $od . ' 00:00:00' ), ARRAY_A ); // phpcs:ignore
		return array(
			'dzis'       => count( $dz ),
			'dzis_poz'   => $poz,
			'uszkodzone' => array_map( array( __CLASS__, 'cast' ), $usz ),
		);
	}

	/* ---------------- wydruk rejestru (A4 poziomo, jak formularz) ---------------- */

	public static function maybe_print() {
		if ( ! isset( $_GET['msm_print'] ) || 'przesylki' !== sanitize_key( wp_unslash( $_GET['msm_print'] ) ) || ! is_user_logged_in() ) { // phpcs:ignore
			return;
		}
		if ( is_wp_error( self::can_view() ) ) {
			wp_die( 'Brak dostępu.', 403 );
		}
		$od  = preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) ( $_GET['od'] ?? '' ) ) ? (string) $_GET['od'] : ''; // phpcs:ignore
		$do  = preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) ( $_GET['do'] ?? '' ) ) ? (string) $_GET['do'] : ''; // phpcs:ignore
		$ids = array_filter( array_map( 'intval', explode( ',', (string) ( $_GET['ids'] ?? '' ) ) ) ); // phpcs:ignore
		$all = array_reverse( self::rows() ); // od najstarszej, jak wpisy w segregatorze
		$L   = array_values( array_filter( $all, function ( $p ) use ( $od, $do, $ids ) {
			$d = substr( $p['data_spr'], 0, 10 );
			return ( ! $ids || in_array( $p['id'], $ids, true ) ) && ( ! $od || $d >= $od ) && ( ! $do || $d <= $do );
		} ) );
		nocache_headers();
		self::print_doc( $L, ! empty( $_GET['auto'] ), $od, $do ); // phpcs:ignore
		exit;
	}

	private static function print_doc( array $L, $auto, $od, $do ) {
		$fonts = MSM_URL . 'assets/fonts/';
		$pages = self::paginate( $L );
		$okres = $od || $do ? ( $od ? mysql2date( 'd.m.Y', $od ) : '…' ) . ' – ' . ( $do ? mysql2date( 'd.m.Y', $do ) : '…' ) : '';
		$e     = function ( $s ) { return nl2br( esc_html( (string) $s ) ); };
		echo '<!DOCTYPE html><html lang="pl"><head><meta charset="utf-8"><meta name="robots" content="noindex,nofollow"><title>Rejestr przesyłek' . ( $okres ? ' ' . esc_html( $okres ) : '' ) . '</title><style>'
			. '@font-face{font-family:PJS;font-weight:400;src:url(' . esc_url( $fonts ) . 'plus-jakarta-sans-latin-ext-400-normal.woff2) format("woff2");unicode-range:U+0100-02BA,U+1E00-1E9F}'
			. '@font-face{font-family:PJS;font-weight:400;src:url(' . esc_url( $fonts ) . 'plus-jakarta-sans-latin-400-normal.woff2) format("woff2");unicode-range:U+0000-00FF,U+2000-206F}'
			. '@font-face{font-family:PJS;font-weight:700;src:url(' . esc_url( $fonts ) . 'plus-jakarta-sans-latin-ext-800-normal.woff2) format("woff2");unicode-range:U+0100-02BA,U+1E00-1E9F}'
			. '@font-face{font-family:PJS;font-weight:700;src:url(' . esc_url( $fonts ) . 'plus-jakarta-sans-latin-800-normal.woff2) format("woff2");unicode-range:U+0000-00FF,U+2000-206F}'
			. self::css() . '</style></head><body>'
			. '<div class="bar"><button onclick="window.print()">Pobierz PDF / drukuj</button><a class="g" href="' . esc_url( MSM_Access::app_url() . '#przesylki' ) . '">Zamknij</a></div>';
		$n = count( $pages );
		foreach ( $pages as $i => $rows ) {
			echo '<section class="pg"><header class="ph"><img src="' . esc_url( MSM_URL . 'assets/logo-wz.svg?v=' . MSM_VERSION ) . '" alt=""><div class="pt"><b>Rejestr przesyłek przychodzących</b>' . ( $okres ? '<span>' . esc_html( $okres ) . '</span>' : '' ) . '</div></header>'
				. '<table><colgroup><col style="width:11%"><col style="width:13%"><col style="width:8%"><col style="width:7%"><col style="width:22%"><col style="width:7%"><col style="width:18%"><col style="width:14%"></colgroup>'
				. '<thead><tr><th>Data<br>/ godzina<br>sprawdzenia</th><th>Nadawca<br>przesyłki</th><th>Zlecenie</th><th>Faktura<br>(tak / nie)</th><th>Zawartość przesyłki</th><th>Ilość</th><th>Uwagi<br>(np. uszkodzenia)</th><th>Sprawdził<br>(czytelny podpis)</th></tr></thead><tbody>';
			$used = 0;
			foreach ( $rows as $p ) {
				$used += self::row_mm( $p );
				echo '<tr' . ( $p['uszkodzona'] ? ' class="u"' : '' ) . '><td class="c">' . esc_html( mysql2date( 'd.m.Y', $p['data_spr'] ) ) . '<br>' . esc_html( mysql2date( 'H:i', $p['data_spr'] ) ) . '</td>'
					. '<td>' . $e( $p['nadawca'] ) . '</td><td class="c pz">' . implode( '', array_map( function ( $x ) { return '<div>' . esc_html( $x['zlecenie'] ) . '&nbsp;</div>'; }, $p['pozycje'] ) ) . '</td><td class="c">' . ( $p['faktura'] ? 'TAK' : 'NIE' ) . '</td>'
					. '<td class="pz">' . implode( '', array_map( function ( $x ) { return '<div>' . esc_html( $x['opis'] ) . '</div>'; }, $p['pozycje'] ) ) . '</td>'
					. '<td class="c pz">' . implode( '', array_map( function ( $x ) { return '<div>' . esc_html( trim( self::fmt_il( $x['ilosc'] ) . ' ' . $x['jedn'] ) ) . '&nbsp;</div>'; }, $p['pozycje'] ) ) . '</td>'
					. '<td class="pz">' . ( array_filter( wp_list_pluck( $p['pozycje'], 'uwagi' ) ) ? implode( '', array_map( function ( $x ) { return '<div>' . esc_html( $x['uwagi'] ?? '' ) . '&nbsp;</div>'; }, $p['pozycje'] ) ) : '' )
					. ( $p['uszkodzona'] || '' !== $p['uwagi'] ? '<div class="og">' . ( $p['uszkodzona'] ? '<b>USZKODZONA</b>' . ( '' !== $p['uwagi'] ? '<br>' : '' ) : '' ) . $e( $p['uwagi'] ) . '</div>' : '' ) . '</td><td class="c">' . esc_html( $p['sprawdzil'] ) . '</td></tr>';
			}
			for ( $k = 0; $used + self::ROW_MM <= self::PAGE_MM; $k++, $used += self::ROW_MM ) { // puste wiersze do ręcznego wpisu – jak na formularzu
				echo '<tr class="e"><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>';
			}
			echo '</tbody></table><footer class="pf"><div><b>' . esc_html( msm_opt( 'firma_nazwa' ) ) . '</b><br>' . esc_html( msm_opt( 'firma_adres' ) ) . '</div><div class="r">Strona ' . ( $i + 1 ) . ' z ' . $n . '</div></footer></section>';
		}
		/*
		 * Podział na strony liczony na serwerze jest tylko szacunkiem – gdy tekst zawija się bardziej (długie nazwy, numery zleceń,
		 * wiele pozycji), wiersze wychodziły poza kartkę i były ucinane. Po wczytaniu czcionek układamy strony od nowa
		 * według rzeczywistej wysokości wierszy: każdy wiersz trafia na stronę, na której się mieści.
		 */
		echo '<script>(function(){'
			. 'function fit(){var pgs=[].slice.call(document.querySelectorAll(".pg"));if(!pgs.length)return;'
			. 'var rows=[].slice.call(document.querySelectorAll(".pg tbody tr:not(.e)"));'
			. 'var tpl=pgs[0].cloneNode(true);tpl.querySelector("tbody").innerHTML="";var empty=document.createElement("tr");empty.className="e";empty.innerHTML=new Array(9).join("<td></td>");'
			. 'pgs.forEach(function(p){p.remove()});var host=document.body,list=[];'
			. 'function add(){var p=tpl.cloneNode(true);host.appendChild(p);list.push(p);return p}'
			. 'function over(p){var t=p.querySelector("table").getBoundingClientRect(),f=p.querySelector(".pf").getBoundingClientRect();return t.bottom>f.top-2}'
			. 'var cur=add(),tb=cur.querySelector("tbody");'
			. 'rows.forEach(function(r){tb.appendChild(r);if(over(cur)&&tb.children.length>1){tb.removeChild(r);cur=add();tb=cur.querySelector("tbody");tb.appendChild(r)}});'
			. 'list.forEach(function(p){var b=p.querySelector("tbody");for(var k=0;k<40;k++){var e=empty.cloneNode(true);b.appendChild(e);if(over(p)){b.removeChild(e);break}}});'
			. 'list.forEach(function(p,i){var r=p.querySelector(".pf .r");if(r)r.textContent="Strona "+(i+1)+" z "+list.length})}'
			. 'function go(){try{fit()}catch(e){}' . ( $auto ? 'setTimeout(function(){window.print()},300)' : '' ) . '}'
			. 'if(document.fonts&&document.fonts.ready){document.fonts.ready.then(go)}else{window.addEventListener("load",go)}'
			. '})()</script>';
		echo '</body></html>';
	}

	const PAGE_MM = 146; // wysokość na wiersze tabeli (A4 poziomo bez nagłówka i stopki)
	const ROW_MM  = 18;  // minimalna wysokość wiersza – jak na formularzu

	/** Szacowana wysokość wiersza wydruku [mm]: pozycje zawartości, uwagi i nadawca w liniach po ~4,6 mm. */
	private static function row_mm( array $p ) {
		$lines = 0;
		foreach ( $p['pozycje'] as $x ) {
			$lines += max( 1, (int) ceil( mb_strlen( $x['opis'] ) / 34 ), (int) ceil( mb_strlen( (string) ( $x['uwagi'] ?? '' ) ) / 26 ) );
		}
		$uw    = (int) ceil( mb_strlen( (string) $p['uwagi'] ) / 26 ) + substr_count( (string) $p['uwagi'], "\n" ) + ( $p['uszkodzona'] ? 1 : 0 );
		$nad   = (int) ceil( mb_strlen( (string) $p['nadawca'] ) / 18 );
		$lines = max( $lines + max( 0, count( $p['pozycje'] ) - 1 ) * 0.5, $uw, $nad, 2 );
		return max( self::ROW_MM, (int) ceil( $lines * 4.6 + 4 ) );
	}

	/** Podział na strony wg wysokości wierszy (długie przesyłki nie wychodzą poza kartkę). */
	private static function paginate( array $L ) {
		$pages = array( array() );
		$h     = 0;
		foreach ( $L as $p ) {
			$m = min( self::PAGE_MM, self::row_mm( $p ) );
			if ( $h + $m > self::PAGE_MM && end( $pages ) ) {
				$pages[] = array();
				$h       = 0;
			}
			$pages[ count( $pages ) - 1 ][] = $p;
			$h += $m;
		}
		return $pages;
	}

	private static function css() {
		return '@page{size:A4 landscape;margin:0}*{box-sizing:border-box}html,body{margin:0;background:#e9ebef}'
			. 'body{font:9pt/1.3 PJS,system-ui,sans-serif;color:#000;-webkit-print-color-adjust:exact;print-color-adjust:exact}'
			. '.bar{position:sticky;top:0;display:flex;gap:10px;justify-content:center;padding:10px;background:#0b1020;z-index:5}'
			. '.bar button,.bar a{font:700 13px PJS,system-ui;padding:8px 18px;border-radius:99px;border:0;background:#3d4bff;color:#fff;cursor:pointer;text-decoration:none}.bar .g{background:transparent;border:1px solid rgba(255,255,255,.4)}'
			. '.pg{position:relative;width:297mm;height:210mm;padding:9mm 12mm 22mm;margin:16px auto;background:#fff;box-shadow:0 4px 24px rgba(0,0,0,.14);page-break-after:always;break-after:page;overflow:hidden}.pg:last-of-type{page-break-after:auto;break-after:auto}'
			. '@media print{html,body{background:#fff}.bar{display:none}.pg{margin:0;box-shadow:none}}'
			. '.ph{display:flex;align-items:center;gap:8mm;padding-bottom:2.5mm;margin-bottom:4mm;border-bottom:1px solid #000}.ph img{height:10mm;width:auto}'
			. '.pt{flex:1;display:flex;justify-content:space-between;align-items:baseline}.pt b{font-size:14pt;letter-spacing:.02em;text-transform:uppercase}.pt span{font-size:10pt}'
			. 'table{width:100%;border-collapse:collapse;table-layout:fixed}th,td{border:1px solid #000;padding:1.5mm 2mm;vertical-align:middle;overflow-wrap:anywhere}'
			. 'th{font-size:8pt;font-weight:400;text-transform:uppercase;text-align:center;line-height:1.2}td{height:18mm;font-size:8.5pt}td.c{text-align:center}'
			. 'td.pz div+div{border-top:1px dotted #999;margin-top:1mm;padding-top:1mm}td.pz div.og{border-top:1px solid #000}td.pz div.og:first-child{border-top:0;margin-top:0;padding-top:0}tr.u td{background:#fff1f0}tr.u b{color:#c62828}'
			. '.pf{position:absolute;left:12mm;right:12mm;bottom:8mm;display:flex;justify-content:space-between;align-items:flex-end;padding-top:2.5mm;border-top:1px solid #000;font-size:8pt}.pf .r{font-size:9pt}';
	}
}
