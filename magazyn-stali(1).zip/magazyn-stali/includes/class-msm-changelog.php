<?php
/**
 * Historia wersji (Techniczne → Historia wersji).
 *
 * - Opis zmian: data/changelog.json (dostarczany z wtyczką, dopisywany przy każdej wersji).
 * - Daty instalacji na TYM serwerze: zapisywane automatycznie przy każdej zmianie wersji
 *   (opcja msm_version_log) + wpis w Historii zmian.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MSM_Changelog {

	const OPT = 'msm_version_log';

	public static function init() {
		add_action( 'plugins_loaded', array( __CLASS__, 'track' ), 20 );
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
	}

	/** Rejestr instalacji: dopisuje wersję Magazynu i OCR, gdy zmieniła się od ostatniego razu. */
	public static function track() {
		$log     = get_option( self::OPT, array() );
		$log     = is_array( $log ) ? $log : array();
		$current = array( 'magazyn' => MSM_VERSION );
		$ocr     = has_filter( 'msm_ocr_version' ) ? (string) apply_filters( 'msm_ocr_version', '' ) : '';
		if ( '' !== $ocr ) {
			$current['ocr'] = $ocr;
		}
		if ( defined( 'MG_VERSION' ) ) {
			$current['grafik'] = (string) MG_VERSION; // wtyczka „Magazyn grafik”
		}
		$changed = false;
		foreach ( $current as $plugin => $ver ) {
			$last = null;
			foreach ( $log as $row ) {
				if ( $row['plugin'] === $plugin ) {
					$last = $row['version']; // ostatni wpis tej wtyczki (lista chronologiczna)
				}
			}
			if ( $last === $ver ) {
				continue;
			}
			$log[]   = array( 'plugin' => $plugin, 'version' => $ver, 'from' => $last, 'at' => current_time( 'mysql' ) );
			$changed = true;
			if ( null !== $last && class_exists( 'MSM_Repo' ) ) {
				$name = 'ocr' === $plugin ? 'Magazyn OCR' : ( 'grafik' === $plugin ? 'Magazyn grafik' : 'System K-ERP' );
				MSM_Repo::log( 'System: aktualizacja', 'system', 0, $name . ': ' . $last . ' → ' . $ver );
			}
		}
		if ( $changed ) {
			update_option( self::OPT, array_slice( $log, -200 ), false );
		}
	}

	public static function routes() {
		register_rest_route( MSM_Rest::NS, '/changelog', array(
			'methods'             => 'GET',
			'callback'            => array( __CLASS__, 'payload' ),
			'permission_callback' => function () {
				if ( ! current_user_can( 'msm_view' ) ) {
					return new WP_Error( 'msm_forbidden', 'Brak dostępu.', array( 'status' => 401 ) );
				}
				return MSM_Perms::is_wp_admin() || MSM_Perms::menu_on( 'zmiany' ) ? true : new WP_Error( 'msm_forbidden', 'Historia wersji jest dla Ciebie wyłączona.', array( 'status' => 403 ) );
			},
		) );
	}

	public static function entries() {
		$file = MSM_DIR . 'data/changelog.json';
		$data = is_readable( $file ) ? json_decode( (string) file_get_contents( $file ), true ) : null; // phpcs:ignore
		return is_array( $data ) && isset( $data['entries'] ) ? $data['entries'] : array();
	}

	public static function payload() {
		$log = get_option( self::OPT, array() );
		$ocr = has_filter( 'msm_ocr_version' ) ? (string) apply_filters( 'msm_ocr_version', '' ) : '';
		$out = array(
			'entries'   => self::entries(),
			'installs'  => array_reverse( is_array( $log ) ? $log : array() ),
			'installed' => array(
				'magazyn' => MSM_VERSION,
				'ocr'     => '' !== $ocr ? $ocr : null,
				'grafik'  => defined( 'MG_VERSION' ) ? (string) MG_VERSION : null,
			),
		);
		// Szczegóły techniczne – tylko dla administratorów.
		if ( current_user_can( 'msm_edit' ) ) {
			global $wp_version;
			$out['tech'] = array(
				'db'        => get_option( 'msm_db_version' ),
				'wordpress' => $wp_version,
				'php'       => PHP_VERSION,
			);
		}
		return rest_ensure_response( $out );
	}
}
