<?php
/**
 * Przyjęcia zewnętrzne (PZ): skany/zdjęcia dokumentu, rozpoznawanie tekstu w przeglądarce (OCR),
 * formularz pozycji, przyjęcie na stan (nowe pozycje albo zwiększenie istniejących), rejestr i anulowanie.
 * Tylko administrator magazynu.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MSM_PZ {

	const ST_OK       = 'przyjety';
	const ST_CANCELED = 'anulowany';
	const MAX_FILE    = 15728640; // 15 MB

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
		add_action( 'template_redirect', array( __CLASS__, 'maybe_file' ), 1 );
	}

	public static function T() {
		return msm_table( 'pz' );
	}

	public static function TP() {
		global $wpdb;
		return $wpdb->prefix . 'msm_pz_poz';
	}

	public static function TF() {
		global $wpdb;
		return $wpdb->prefix . 'msm_pz_pliki';
	}

	public static function create_tables() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$c = $wpdb->get_charset_collate();
		dbDelta( 'CREATE TABLE ' . self::TP() . " (
id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
pz_id bigint(20) unsigned NOT NULL,
lp int(11) NOT NULL DEFAULT 0,
item_table varchar(30) NOT NULL,
item_id bigint(20) unsigned NULL,
akcja varchar(10) NOT NULL DEFAULT 'dodano',
ilosc decimal(14,3) NOT NULL DEFAULT 0,
jednostka varchar(10) NULL,
opis varchar(255) NULL,
dane longtext NULL,
PRIMARY KEY  (id),
KEY pz_id (pz_id)
) ENGINE=InnoDB $c;" );
		dbDelta( 'CREATE TABLE ' . self::TF() . " (
id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
pz_id bigint(20) unsigned NULL,
plik varchar(190) NOT NULL,
nazwa varchar(255) NULL,
mime varchar(60) NULL,
rozmiar bigint(20) unsigned NULL,
user_id bigint(20) unsigned NULL,
created_at datetime NULL,
PRIMARY KEY  (id),
KEY pz_id (pz_id)
) ENGINE=InnoDB $c;" );
		self::dir();
	}

	/* ---------------- pliki (skany) ---------------- */

	/** Katalog na skany – poza dostępem z sieci (pliki podaje tylko aplikacja po zalogowaniu). */
	public static function dir() {
		$up  = wp_upload_dir();
		$dir = trailingslashit( $up['basedir'] ) . 'msm-pz';
		if ( ! is_dir( $dir ) ) {
			wp_mkdir_p( $dir );
		}
		if ( ! file_exists( $dir . '/.htaccess' ) ) {
			@file_put_contents( $dir . '/.htaccess', "Require all denied\nDeny from all\n" ); // phpcs:ignore
		}
		if ( ! file_exists( $dir . '/index.php' ) ) {
			@file_put_contents( $dir . '/index.php', "<?php // Silence.\n" ); // phpcs:ignore
		}
		return $dir;
	}

	public static function upload( WP_REST_Request $r ) {
		$files = $r->get_file_params();
		$f     = $files['file'] ?? null;
		if ( ! $f || ! empty( $f['error'] ) || ! is_uploaded_file( $f['tmp_name'] ) ) {
			return new WP_Error( 'msm_upload', 'Nie udało się wgrać pliku.', array( 'status' => 400 ) );
		}
		if ( $f['size'] > self::MAX_FILE ) {
			return new WP_Error( 'msm_upload', 'Plik jest za duży (max 15 MB).', array( 'status' => 400 ) );
		}
		$check = wp_check_filetype_and_ext( $f['tmp_name'], $f['name'], array(
			'jpg|jpeg' => 'image/jpeg',
			'png'      => 'image/png',
			'webp'     => 'image/webp',
			'pdf'      => 'application/pdf',
		) );
		if ( empty( $check['ext'] ) ) {
			return new WP_Error( 'msm_upload', 'Dozwolone pliki: JPG, PNG, WEBP, PDF.', array( 'status' => 400 ) );
		}
		$name = wp_generate_password( 24, false ) . '.' . $check['ext'];
		if ( ! @move_uploaded_file( $f['tmp_name'], self::dir() . '/' . $name ) ) { // phpcs:ignore
			return new WP_Error( 'msm_upload', 'Nie udało się zapisać pliku na serwerze.', array( 'status' => 500 ) );
		}
		global $wpdb;
		$wpdb->insert( self::TF(), array(
			'plik'       => $name,
			'nazwa'      => mb_substr( sanitize_file_name( $f['name'] ), 0, 255 ),
			'mime'       => $check['type'],
			'rozmiar'    => (int) $f['size'],
			'user_id'    => get_current_user_id(),
			'created_at' => current_time( 'mysql' ),
		) );
		return self::file_out( $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM `' . self::TF() . '` WHERE id = %d', $wpdb->insert_id ), ARRAY_A ) ); // phpcs:ignore
	}

	private static function file_out( $f ) {
		return array(
			'id'    => (int) $f['id'],
			'nazwa' => $f['nazwa'],
			'mime'  => $f['mime'],
			'url'   => add_query_arg( array( 'msm_pz_file' => (int) $f['id'] ), MSM_Access::app_url() ),
		);
	}

	/** Podaje plik skanu zalogowanemu administratorowi: ?msm_pz_file=ID. */
	public static function maybe_file() {
		if ( empty( $_GET['msm_pz_file'] ) ) { // phpcs:ignore
			return;
		}
		if ( ! current_user_can( 'msm_edit' ) || ( ! MSM_Perms::is_wp_admin() && ! MSM_Perms::menu_on( 'pz' ) ) ) {
			wp_die( 'Brak dostępu.', 403 );
		}
		global $wpdb;
		$f = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM `' . self::TF() . '` WHERE id = %d', (int) $_GET['msm_pz_file'] ), ARRAY_A ); // phpcs:ignore
		$path = $f ? self::dir() . '/' . basename( $f['plik'] ) : '';
		if ( ! $f || ! is_file( $path ) ) {
			wp_die( 'Plik nie istnieje.', 404 );
		}
		nocache_headers();
		header( 'Content-Type: ' . $f['mime'] );
		header( 'Content-Length: ' . filesize( $path ) );
		header( 'Content-Disposition: inline; filename="' . rawurlencode( $f['nazwa'] ) . '"' );
		header( 'X-Content-Type-Options: nosniff' );
		readfile( $path ); // phpcs:ignore
		exit;
	}

	/* ---------------- odczyt ---------------- */

	public static function get( $id ) {
		global $wpdb;
		$p = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM `' . self::T() . '` WHERE id = %d', $id ), ARRAY_A ); // phpcs:ignore
		if ( ! $p ) {
			return null;
		}
		$p['lines'] = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM `' . self::TP() . '` WHERE pz_id = %d ORDER BY lp, id', $id ), ARRAY_A ); // phpcs:ignore
		$p['files'] = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM `' . self::TF() . '` WHERE pz_id = %d ORDER BY id', $id ), ARRAY_A ); // phpcs:ignore
		return $p;
	}

	public static function public_doc( $p ) {
		$schema = msm_schema();
		$out    = MSM_Repo::cast_row( 'pz', $p );
		foreach ( array( 'uwagi', 'created_at', 'canceled_name', 'canceled_at', 'updated_name', 'updated_at' ) as $k ) {
			$out[ $k ] = $p[ $k ] ?? null;
		}
		global $wpdb;
		$zq = array(); // ilości zaliczone na zamówienia do dostawców – dolna granica przy edycji
		if ( class_exists( 'MSM_Zam' ) && MSM_Zam::ready() ) {
			foreach ( (array) $wpdb->get_results( $wpdb->prepare( 'SELECT item_table, item_id, SUM(ilosc) q FROM `' . MSM_Zam::TL() . '` WHERE pz_id = %d GROUP BY item_table, item_id', (int) $p['id'] ), ARRAY_A ) as $z ) { // phpcs:ignore
				$zq[ $z['item_table'] . ':' . (int) $z['item_id'] ] = (float) $z['q'];
			}
		}
		$out['lines'] = array_map( function ( $l ) use ( $schema, $zq ) {
			$item = MSM_Repo::get( $l['item_table'], (int) $l['item_id'] );
			return array(
				'id'         => (int) $l['id'],
				'lp'         => (int) $l['lp'],
				'item_table' => $l['item_table'],
				'magazyn'    => $schema[ $l['item_table'] ]['label'] ?? $l['item_table'],
				'item_id'    => $l['item_id'] ? (int) $l['item_id'] : null,
				'akcja'      => $l['akcja'],
				'ilosc'      => (float) $l['ilosc'],
				'jednostka'  => $l['jednostka'],
				'opis'       => $l['opis'],
				'stock'      => $item ? (float) $item['ilosc'] : null,
				'zam'        => $zq[ $l['item_table'] . ':' . (int) $l['item_id'] ] ?? 0,
			);
		}, $p['lines'] );
		$out['files'] = array_map( array( __CLASS__, 'file_out' ), $p['files'] );
		$out['zam']   = class_exists( 'MSM_Zam' ) ? MSM_Zam::for_pz( (int) $p['id'] ) : array();
		return $out;
	}

	/* ---------------- dopasowanie do istniejących pozycji ---------------- */

	/** Klucze, po których porównujemy pozycje (bez ilości i uwag). */
	private static function match_keys( $table ) {
		$map = array(
			'stal'            => array( 'opis', 'szer', 'wys', 'scianka', 'gatunek', 'dlugosc' ),
			'blachy_pelne'    => array( 'gatunek', 'grubosc', 'wymiar_a', 'wymiar_b', 'material' ),
			'blachy_niepelne' => array( 'gatunek', 'grubosc', 'ksztalt', 'wymiar_a', 'wymiar_b' ),
			'kregi'           => array( 'oznaczenie', 'izolacja', 'grubosc', 'szerokosc', 'lokalizacja' ),
		);
		return $map[ $table ] ?? array();
	}

	/** Zwraca do 6 pozycji o tych samych parametrach (najpierw identyczne). */
	public static function match( $table, array $fields ) {
		global $wpdb;
		if ( ! in_array( $table, msm_stock_tables(), true ) ) {
			return array();
		}
		$T     = msm_table( $table );
		$where = array();
		$args  = array();
		$cols  = array();
		foreach ( msm_schema()[ $table ]['cols'] as $c ) {
			$cols[ $c['key'] ] = $c;
		}
		foreach ( self::match_keys( $table ) as $k ) {
			$v = $fields[ $k ] ?? '';
			if ( '' === $v || null === $v ) {
				continue;
			}
			if ( in_array( $cols[ $k ]['type'] ?? '', array( 'num', 'int' ), true ) ) {
				$n = MSM_Calc::f( $v );
				if ( null !== $n ) {
					$where[] = "ABS(`$k` - %f) < 0.0005";
					$args[]  = $n;
				}
			} else {
				$where[] = "LOWER(`$k`) = LOWER(%s)";
				$args[]  = MSM_Calc::normalize( $table, $k, $v );
			}
		}
		if ( ! $where ) {
			return array();
		}
		$sql  = "SELECT * FROM `$T` WHERE " . implode( ' AND ', $where ) . ' ORDER BY ilosc DESC, id LIMIT 6';
		$rows = $wpdb->get_results( $wpdb->prepare( $sql, $args ), ARRAY_A ); // phpcs:ignore
		return array_map( function ( $r ) use ( $table ) {
			return array(
				'id'    => (int) $r['id'],
				'opis'  => MSM_Calc::describe( $table, $r ),
				'ilosc' => (float) $r['ilosc'],
				'uwagi' => (string) ( $r['uwagi'] ?? '' ),
			);
		}, $rows );
	}

	/* ---------------- przyjęcie ---------------- */

	/**
	 * Walidacja nowych wierszy PZ (magazyn, ilość, istniejąca pozycja albo pola nowej).
	 *
	 * @param array $raw    Wiersze z formularza.
	 * @param array $errors Lista błędów (uzupełniana).
	 * @param int   $offset Numeracja wierszy w komunikatach (przy edycji – po istniejących).
	 * @return array Wiersze gotowe do przyjęcia.
	 */
	private static function check_lines( array $raw, array &$errors, $offset = 0 ) {
		$lines = array();
		foreach ( array_slice( $raw, 0, 200 ) as $i => $l ) {
			$no    = $i + 1 + $offset;
			$table = (string) ( $l['tabela'] ?? '' );
			if ( ! in_array( $table, msm_stock_tables(), true ) ) {
				$errors[] = 'Wiersz ' . $no . ': wybierz magazyn.';
				continue;
			}
			$kg  = 'kg' === msm_unit( $table );
			$qty = MSM_Calc::f( $l['ilosc'] ?? null );
			if ( null === $qty || $qty <= 0 || ( ! $kg && floor( $qty ) != $qty ) ) { // phpcs:ignore
				$errors[] = 'Wiersz ' . $no . ': podaj ilość' . ( $kg ? ' w kg' : ' (całe sztuki)' ) . '.';
				continue;
			}
			$item_id = (int) ( $l['item_id'] ?? 0 );
			if ( $item_id ) {
				if ( ! MSM_Repo::get( $table, $item_id ) ) {
					$errors[] = 'Wiersz ' . $no . ': wybrana pozycja magazynowa już nie istnieje.';
					continue;
				}
				$lines[] = array( 'table' => $table, 'item_id' => $item_id, 'qty' => $qty, 'fields' => null );
			} else {
				$fields          = (array) ( $l['fields'] ?? array() );
				$fields['ilosc'] = $qty;
				$clean           = MSM_Repo::sanitize( $table, $fields );
				if ( is_wp_error( $clean ) ) {
					$list     = (array) ( $clean->get_error_data()['fields'] ?? array() );
					$errors[] = 'Wiersz ' . $no . ': ' . ( $list ? implode( ', ', array_map( function ( $k, $v ) use ( $table ) {
						$c = msm_col( $table, $k );
						return ( $c ? $c['label'] : $k ) . ' – ' . $v;
					}, array_keys( $list ), $list ) ) : $clean->get_error_message() );
					continue;
				}
				$lines[] = array( 'table' => $table, 'item_id' => 0, 'qty' => $qty, 'fields' => $fields );
			}
		}
		return $lines;
	}

	/**
	 * Przyjęcie jednego wiersza na stan i zapis w pozycjach PZ.
	 *
	 * @return array|null [magazyn, id pozycji, ilość] albo null przy błędzie.
	 */
	private static function put_line( $pz_id, $lp, array $l, $ref ) {
		global $wpdb;
		$unit = 'kg' === msm_unit( $l['table'] ) ? 'kg' : 'szt';
		if ( $l['item_id'] ) {
			$after = MSM_Repo::receive( $l['table'], $l['item_id'], $l['qty'], $ref, array( 'pz' => $pz_id ) );
			$akcja = 'dodano';
			$id    = $l['item_id'];
		} else {
			$f          = $l['fields'];
			$f['uwagi'] = trim( (string) ( $f['uwagi'] ?? '' ) );
			$after      = MSM_Repo::create( $l['table'], $f );
			$akcja      = 'nowa';
			$id         = is_wp_error( $after ) ? 0 : (int) $after['id'];
		}
		if ( is_wp_error( $after ) ) {
			return null;
		}
		$item = MSM_Repo::get( $l['table'], $id );
		$wpdb->insert( self::TP(), array(
			'pz_id'      => $pz_id,
			'lp'         => $lp,
			'item_table' => $l['table'],
			'item_id'    => $id,
			'akcja'      => $akcja,
			'ilosc'      => $l['qty'],
			'jednostka'  => $unit,
			'opis'       => mb_substr( MSM_Calc::describe( $l['table'], $item ), 0, 255 ),
			'dane'       => $l['fields'] ? wp_json_encode( $l['fields'] ) : null,
		) );
		if ( 'nowa' === $akcja ) {
			$wpdb->query( $wpdb->prepare( 'UPDATE `' . msm_table( 'historia' ) . "` SET opis = CONCAT(opis, %s) WHERE tabela_key = %s AND item_id = %d AND akcja = 'PZ: dodanie' ORDER BY id DESC LIMIT 1", ' (' . $ref . ')', $l['table'], $id ) ); // phpcs:ignore
		}
		return array( $l['table'], $id, $l['qty'] );
	}

	public static function create( array $in ) {
		global $wpdb;
		if ( class_exists( 'MSM_Perms' ) && ! MSM_Perms::user_can( 'pz' ) ) {
			return new WP_Error( 'msm_forbidden', 'Brak uprawnień do przyjęć (PZ).', array( 'status' => 403 ) );
		}
		$h        = (array) ( $in['header'] ?? array() );
		$t        = function ( $k, $max = 190 ) use ( $h ) {
			return mb_substr( trim( sanitize_text_field( wp_unslash( (string) ( $h[ $k ] ?? '' ) ) ) ), 0, $max );
		};
		$data     = preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) ( $h['data'] ?? '' ) ) ? $h['data'] : current_time( 'Y-m-d' );
		$dostawca = $t( 'dostawca' );
		$nr_dok   = $t( 'nr_dok', 120 );
		$uwagi    = mb_substr( sanitize_textarea_field( wp_unslash( (string) ( $h['uwagi'] ?? '' ) ) ), 0, 2000 );
		$ocr      = mb_substr( (string) ( $in['ocr'] ?? '' ), 0, 60000 );
		$errors   = array();
		if ( '' === $dostawca ) {
			$errors[] = 'Podaj dostawcę.';
		}

		// Walidacja pozycji.
		$lines = self::check_lines( (array) ( $in['lines'] ?? array() ), $errors );
		if ( ! $lines && ! $errors ) {
			$errors[] = 'Dodaj co najmniej jedną pozycję.';
		}
		if ( $errors ) {
			return new WP_Error( 'msm_invalid', implode( "\n", $errors ), array( 'status' => 400 ) );
		}

		// Numer PZ: NN/MM/RRRR wg daty przyjęcia.
		$y = (int) substr( $data, 0, 4 );
		$m = (int) substr( $data, 5, 2 );
		$wpdb->query( 'START TRANSACTION' );
		$seq = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT MAX(nr_seq) FROM `' . self::T() . '` WHERE rok = %d AND miesiac = %d FOR UPDATE', $y, $m ) ) + 1; // phpcs:ignore
		$nr  = sprintf( 'PZ %02d/%02d/%04d', $seq, $m, $y );
		$wpdb->insert( self::T(), array(
			'numer'        => $nr,
			'nr_seq'       => $seq,
			'rok'          => $y,
			'miesiac'      => $m,
			'data'         => $data,
			'dostawca'     => $dostawca,
			'nr_dok'       => '' === $nr_dok ? null : $nr_dok,
			'uwagi'        => '' === $uwagi ? null : $uwagi,
			'ocr'          => '' === $ocr ? null : $ocr,
			'pozycji'      => count( $lines ),
			'skanow'       => 0,
			'status'       => self::ST_OK,
			'created_by'   => get_current_user_id(),
			'created_name' => MSM_Repo::user_name(),
			'created_at'   => current_time( 'mysql' ),
		) );
		$pz_id = (int) $wpdb->insert_id;
		$wpdb->query( 'COMMIT' );
		if ( ! $pz_id ) {
			return new WP_Error( 'msm_db', 'Nie udało się zapisać PZ.', array( 'status' => 500 ) );
		}
		$ref = $nr . ( $dostawca ? ', ' . $dostawca : '' ) . ( $nr_dok ? ', dok. ' . $nr_dok : '' );

		// Przyjęcie na stan.
		MSM_Repo::$prefix = 'PZ: ';
		$lp               = 0;
		$got              = array(); // indeks wiersza → [magazyn, id pozycji, ilość] – do zamówień
		foreach ( $lines as $li => $l ) {
			$g = self::put_line( $pz_id, ++$lp, $l, $ref );
			if ( $g ) {
				$got[ $li ] = $g;
			}
		}
		MSM_Repo::$prefix = '';

		// Skany.
		$files = array_filter( array_map( 'intval', (array) ( $in['files'] ?? array() ) ) );
		if ( $files ) {
			$wpdb->query( $wpdb->prepare( 'UPDATE `' . self::TF() . '` SET pz_id = %d WHERE pz_id IS NULL AND user_id = %d AND id IN (' . implode( ',', $files ) . ')', $pz_id, get_current_user_id() ) ); // phpcs:ignore
		}
		$wpdb->update( self::T(), array( 'skanow' => (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM `' . self::TF() . '` WHERE pz_id = %d', $pz_id ) ) ), array( 'id' => $pz_id ) ); // phpcs:ignore

		MSM_Repo::log( 'PZ: przyjęto', 'pz', $pz_id, $nr . ' – ' . $dostawca . ( $nr_dok ? ' (dok. ' . $nr_dok . ')' : '' ) . ', pozycji: ' . count( $lines ) );
		// Zamówienia do dostawców: zaliczenie dostawy i rezerwacje dla zleceń.
		$zam = class_exists( 'MSM_Zam' ) && ! empty( $in['zam'] ) ? MSM_Zam::pz_receive( $pz_id, $nr, (array) $in['zam'], $got ) : '';
		return array(
			'doc'     => self::public_doc( self::get( $pz_id ) ),
			'message' => 'Przyjęto ' . $nr . ' – ' . count( $lines ) . ' poz. na stan.' . $zam,
		);
	}

	/** Anulowanie PZ – cofa przyjęte ilości (wszystko albo nic). */
	/**
	 * Edycja przyjętego PZ: nagłówek, ilości wierszy (różnica koryguje stan), usuwanie i dodawanie wierszy, skany.
	 * Najpierw sprawdzamy wszystko, dopiero potem zmieniamy stany – albo całość, albo nic.
	 *
	 * @param int   $id PZ.
	 * @param array $in header{data,dostawca,nr_dok,uwagi}, lines[{id, ilosc, usun}], add[] (jak przy tworzeniu), files[] (nowe skany), drop_files[].
	 */
	public static function update( $id, array $in ) {
		global $wpdb;
		if ( class_exists( 'MSM_Perms' ) && ! MSM_Perms::user_can( 'pz' ) ) {
			return new WP_Error( 'msm_forbidden', 'Brak uprawnień do przyjęć (PZ).', array( 'status' => 403 ) );
		}
		$p = self::get( $id );
		if ( ! $p ) {
			return new WP_Error( 'msm_not_found', 'PZ nie istnieje.', array( 'status' => 404 ) );
		}
		if ( self::ST_OK !== $p['status'] ) {
			return new WP_Error( 'msm_state', 'Anulowanego PZ nie można edytować.', array( 'status' => 400 ) );
		}
		$h        = (array) ( $in['header'] ?? array() );
		$t        = function ( $k, $max = 190 ) use ( $h ) {
			return mb_substr( trim( sanitize_text_field( wp_unslash( (string) ( $h[ $k ] ?? '' ) ) ) ), 0, $max );
		};
		$data     = preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) ( $h['data'] ?? '' ) ) ? $h['data'] : $p['data'];
		$dostawca = $t( 'dostawca' );
		$nr_dok   = $t( 'nr_dok', 120 );
		$uwagi    = mb_substr( sanitize_textarea_field( wp_unslash( (string) ( $h['uwagi'] ?? '' ) ) ), 0, 2000 );
		$errors   = array();
		if ( '' === $dostawca ) {
			$errors[] = 'Podaj dostawcę.';
		}

		// Ilości zaliczone na zamówienia do dostawców (wiersz → ilość) – poniżej nich nie schodzimy.
		$zam = array();
		if ( class_exists( 'MSM_Zam' ) && MSM_Zam::ready() ) {
			foreach ( (array) $wpdb->get_results( $wpdb->prepare( 'SELECT item_table, item_id, SUM(ilosc) q FROM `' . MSM_Zam::TL() . '` WHERE pz_id = %d GROUP BY item_table, item_id', (int) $id ), ARRAY_A ) as $z ) { // phpcs:ignore
				$zam[ $z['item_table'] . ':' . (int) $z['item_id'] ] = (float) $z['q'];
			}
		}

		// Zmiany istniejących wierszy.
		$want = array();
		foreach ( (array) ( $in['lines'] ?? array() ) as $l ) {
			$want[ (int) ( $l['id'] ?? 0 ) ] = $l;
		}
		$ops = array(); // [wiersz, nowa ilość|null (usunięcie), różnica]
		foreach ( $p['lines'] as $l ) {
			$w   = $want[ (int) $l['id'] ] ?? null;
			$old = (float) $l['ilosc'];
			$no  = 'Wiersz ' . $l['lp'] . ' (' . $l['opis'] . ')';
			if ( ! $w ) {
				continue;
			}
			$del = ! empty( $w['usun'] );
			$kg  = 'kg' === msm_unit( $l['item_table'] );
			$qty = $del ? 0.0 : MSM_Calc::f( $w['ilosc'] ?? null );
			if ( ! $del && ( null === $qty || $qty <= 0 || ( ! $kg && floor( $qty ) != $qty ) ) ) { // phpcs:ignore
				$errors[] = $no . ': podaj ilość' . ( $kg ? ' w kg' : ' (całe sztuki)' ) . ' albo usuń wiersz.';
				continue;
			}
			$diff = $qty - $old;
			if ( abs( $diff ) < 1e-9 ) {
				continue;
			}
			$item = MSM_Repo::get( $l['item_table'], (int) $l['item_id'] );
			if ( ! $item ) {
				$errors[] = $no . ': pozycja została usunięta z magazynu – tego wiersza nie można już zmienić.';
				continue;
			}
			$zq = $zam[ $l['item_table'] . ':' . (int) $l['item_id'] ] ?? 0;
			if ( $zq > 0 && $qty + 1e-9 < $zq ) {
				$errors[] = $no . ': ' . MSM_Calc::fmt( $zq ) . ' ' . $l['jednostka'] . ' zaliczono na zamówienie do dostawcy – nie można zejść niżej (w razie potrzeby anuluj cały PZ).';
				continue;
			}
			if ( $diff < 0 && (float) $item['ilosc'] + 1e-9 < -$diff ) {
				$errors[] = $no . ': na stanie jest ' . MSM_Calc::fmt( $item['ilosc'] ) . ' ' . $l['jednostka'] . ', nie można cofnąć ' . MSM_Calc::fmt( -$diff ) . ' ' . $l['jednostka'] . ' (materiał już pobrano).';
				continue;
			}
			$ops[] = array( $l, $del ? null : $qty, $diff, $item );
		}

		// Nowe wiersze – walidacja jak przy przyjęciu.
		$add = self::check_lines( (array) ( $in['add'] ?? array() ), $errors, count( $p['lines'] ) );
		$left = count( $p['lines'] ) - count( array_filter( $ops, function ( $o ) { return null === $o[1]; } ) ) + count( $add );
		if ( ! $errors && $left < 1 ) {
			$errors[] = 'PZ musi mieć co najmniej jedną pozycję – aby wycofać cały dokument, użyj „Anuluj PZ”.';
		}
		if ( $errors ) {
			return new WP_Error( 'msm_invalid', implode( "\n", $errors ), array( 'status' => 400 ) );
		}

		// Zapis.
		$ref  = 'korekta ' . $p['numer'] . ( $dostawca ? ', ' . $dostawca : '' );
		$log  = array();
		$head = array(
			'data'     => $data,
			'dostawca' => $dostawca,
			'nr_dok'   => '' === $nr_dok ? null : $nr_dok,
			'uwagi'    => '' === $uwagi ? null : $uwagi,
		);
		$names = array( 'data' => 'data', 'dostawca' => 'dostawca', 'nr_dok' => 'nr dokumentu', 'uwagi' => 'uwagi' );
		foreach ( $head as $k => $v ) {
			if ( (string) $v !== (string) $p[ $k ] ) {
				$log[] = $names[ $k ] . ': ' . ( '' === (string) $p[ $k ] ? '—' : ( 'uwagi' === $k ? '…' : $p[ $k ] ) ) . ' → ' . ( '' === (string) $v ? '—' : ( 'uwagi' === $k ? 'zmienione' : $v ) );
			}
		}
		MSM_Repo::$prefix = 'PZ: ';
		foreach ( $ops as $o ) {
			list( $l, $qty, $diff, $item ) = $o;
			if ( null === $qty && 'nowa' === $l['akcja'] && abs( (float) $item['ilosc'] - (float) $l['ilosc'] ) < 1e-9 ) {
				MSM_Repo::delete( $l['item_table'], array( (int) $l['item_id'] ) ); // pozycja powstała z tego PZ i nic z niej nie pobrano
			} else {
				MSM_Repo::receive( $l['item_table'], (int) $l['item_id'], $diff, $ref, array( 'pz' => (int) $p['id'] ) );
			}
			if ( null === $qty ) {
				$wpdb->delete( self::TP(), array( 'id' => (int) $l['id'] ) );
				$log[] = 'usunięto wiersz ' . $l['lp'] . ' (' . $l['opis'] . ', ' . MSM_Calc::fmt( $l['ilosc'] ) . ' ' . $l['jednostka'] . ')';
			} else {
				$wpdb->update( self::TP(), array( 'ilosc' => $qty ), array( 'id' => (int) $l['id'] ) );
				$log[] = 'wiersz ' . $l['lp'] . ' (' . $l['opis'] . '): ' . MSM_Calc::fmt( $l['ilosc'] ) . ' → ' . MSM_Calc::fmt( $qty ) . ' ' . $l['jednostka'];
			}
		}
		$lp = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT MAX(lp) FROM `' . self::TP() . '` WHERE pz_id = %d', (int) $p['id'] ) ); // phpcs:ignore
		foreach ( $add as $l ) {
			$g = self::put_line( (int) $p['id'], ++$lp, $l, $ref );
			if ( $g ) {
				$log[] = 'dodano wiersz ' . $lp . ' (' . MSM_Calc::fmt( $l['qty'] ) . ' ' . ( 'kg' === msm_unit( $l['table'] ) ? 'kg' : 'szt' ) . ')';
			}
		}
		MSM_Repo::$prefix = '';
		// Kolejne numery wierszy bez dziur.
		$n = 0;
		foreach ( (array) $wpdb->get_col( $wpdb->prepare( 'SELECT id FROM `' . self::TP() . '` WHERE pz_id = %d ORDER BY lp, id', (int) $p['id'] ) ) as $lid ) { // phpcs:ignore
			$wpdb->update( self::TP(), array( 'lp' => ++$n ), array( 'id' => (int) $lid ) );
		}

		// Skany: nowe (wgrane w tej edycji) i odłączone.
		$files = array_filter( array_map( 'intval', (array) ( $in['files'] ?? array() ) ) );
		if ( $files ) {
			$wpdb->query( $wpdb->prepare( 'UPDATE `' . self::TF() . '` SET pz_id = %d WHERE pz_id IS NULL AND user_id = %d AND id IN (' . implode( ',', $files ) . ')', (int) $p['id'], get_current_user_id() ) ); // phpcs:ignore
			$log[] = 'dołączono skany: ' . count( $files );
		}
		$drop = array_filter( array_map( 'intval', (array) ( $in['drop_files'] ?? array() ) ) );
		if ( $drop ) {
			foreach ( (array) $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM `' . self::TF() . '` WHERE pz_id = %d AND id IN (' . implode( ',', $drop ) . ')', (int) $p['id'] ), ARRAY_A ) as $f ) { // phpcs:ignore
				$path = trailingslashit( self::dir() ) . basename( (string) $f['plik'] );
				if ( is_file( $path ) ) {
					wp_delete_file( $path );
				}
				$wpdb->delete( self::TF(), array( 'id' => (int) $f['id'] ) );
				$log[] = 'usunięto skan ' . $f['nazwa'];
			}
		}
		$head['pozycji']    = $n;
		$head['skanow']     = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM `' . self::TF() . '` WHERE pz_id = %d', (int) $p['id'] ) ); // phpcs:ignore
		$head['updated_name'] = MSM_Repo::user_name();
		$head['updated_at']   = current_time( 'mysql' );
		$wpdb->update( self::T(), $head, array( 'id' => (int) $p['id'] ) );
		if ( $log ) {
			MSM_Repo::log( 'PZ: zmieniono', 'pz', (int) $p['id'], $p['numer'] . ' – ' . implode( '; ', $log ) );
		}
		return array(
			'doc'     => self::public_doc( self::get( (int) $p['id'] ) ),
			'message' => $log ? 'Zapisano zmiany w ' . $p['numer'] . '.' : 'Bez zmian.',
		);
	}

	public static function cancel( $id, $note ) {
		global $wpdb;
		$p = self::get( $id );
		if ( ! $p ) {
			return new WP_Error( 'msm_not_found', 'PZ nie istnieje.', array( 'status' => 404 ) );
		}
		if ( self::ST_OK !== $p['status'] ) {
			return new WP_Error( 'msm_state', 'Ten dokument jest już anulowany.', array( 'status' => 400 ) );
		}
		$problems = array();
		foreach ( $p['lines'] as $l ) {
			$item = MSM_Repo::get( $l['item_table'], (int) $l['item_id'] );
			if ( ! $item ) {
				$problems[] = 'Wiersz ' . $l['lp'] . ' (' . $l['opis'] . '): pozycja została usunięta z magazynu.';
			} elseif ( (float) $item['ilosc'] + 1e-9 < (float) $l['ilosc'] ) {
				$problems[] = 'Wiersz ' . $l['lp'] . ' (' . $l['opis'] . '): na stanie jest ' . MSM_Calc::fmt( $item['ilosc'] ) . ' ' . $l['jednostka'] . ', a PZ przyjął ' . MSM_Calc::fmt( $l['ilosc'] ) . ' – część została już pobrana.';
			}
		}
		if ( $problems ) {
			return new WP_Error( 'msm_state', "Nie można anulować PZ – stan został już zmieniony:\n" . implode( "\n", $problems ), array( 'status' => 400 ) );
		}
		$ref = 'anulowanie ' . $p['numer'];
		foreach ( $p['lines'] as $l ) {
			$item = MSM_Repo::get( $l['item_table'], (int) $l['item_id'] );
			if ( 'nowa' === $l['akcja'] && abs( (float) $item['ilosc'] - (float) $l['ilosc'] ) < 1e-9 ) {
				MSM_Repo::$prefix = 'PZ: ';
				MSM_Repo::delete( $l['item_table'], array( (int) $l['item_id'] ) );
				MSM_Repo::$prefix = '';
			} else {
				MSM_Repo::receive( $l['item_table'], (int) $l['item_id'], - (float) $l['ilosc'], $ref, array( 'pz' => (int) $p['id'] ) );
			}
		}
		$note = mb_substr( sanitize_text_field( wp_unslash( (string) $note ) ), 0, 500 );
		$wpdb->update( self::T(), array(
			'status'        => self::ST_CANCELED,
			'canceled_name' => MSM_Repo::user_name(),
			'canceled_at'   => current_time( 'mysql' ),
			'uwagi'         => trim( (string) $p['uwagi'] . ( $note ? "\nAnulowano: " . $note : '' ) ),
		), array( 'id' => (int) $p['id'] ) );
		if ( class_exists( 'MSM_Zam' ) ) {
			MSM_Zam::pz_cancel( (int) $p['id'] );
		}
		MSM_Repo::log( 'PZ: anulowano', 'pz', (int) $p['id'], $p['numer'] . ' – ' . $p['dostawca'] . ' – przyjęte ilości cofnięte ze stanu' . ( $note ? ' (' . $note . ')' : '' ) );
		return array( 'doc' => self::public_doc( self::get( (int) $p['id'] ) ), 'message' => $p['numer'] . ' anulowany, ilości cofnięte ze stanu.' );
	}

	/* ---------------- REST ---------------- */

	public static function routes() {
		$ns   = MSM_Rest::NS;
		$edit = array( 'MSM_Rest', 'can_edit' );
		register_rest_route( $ns, '/pz', array(
			'methods' => 'POST', 'permission_callback' => $edit,
			'callback' => function ( WP_REST_Request $r ) { return rest_ensure_response( MSM_PZ::create( (array) $r->get_json_params() ) ); },
		) );
		register_rest_route( $ns, '/pz/upload', array(
			'methods' => 'POST', 'permission_callback' => $edit,
			'callback' => function ( WP_REST_Request $r ) { return rest_ensure_response( MSM_PZ::upload( $r ) ); },
		) );
		register_rest_route( $ns, '/pz/match', array(
			'methods' => 'POST', 'permission_callback' => $edit,
			'callback' => function ( WP_REST_Request $r ) {
				$p = (array) $r->get_json_params();
				return rest_ensure_response( MSM_PZ::match( (string) ( $p['tabela'] ?? '' ), (array) ( $p['fields'] ?? array() ) ) );
			},
		) );
		register_rest_route( $ns, '/pz/(?P<id>\d+)', array(
			'methods' => 'GET', 'permission_callback' => $edit,
			'callback' => function ( WP_REST_Request $r ) {
				$p = MSM_PZ::get( (int) $r['id'] );
				return $p ? rest_ensure_response( MSM_PZ::public_doc( $p ) ) : new WP_Error( 'msm_not_found', 'PZ nie istnieje.', array( 'status' => 404 ) );
			},
		) );
		register_rest_route( $ns, '/pz/(?P<id>\d+)/edytuj', array(
			'methods' => 'POST', 'permission_callback' => $edit,
			'callback' => function ( WP_REST_Request $r ) { return rest_ensure_response( MSM_PZ::update( (int) $r['id'], (array) $r->get_json_params() ) ); },
		) );
		register_rest_route( $ns, '/pz/(?P<id>\d+)/anuluj', array(
			'methods' => 'POST', 'permission_callback' => $edit,
			'callback' => function ( WP_REST_Request $r ) { return rest_ensure_response( MSM_PZ::cancel( (int) $r['id'], (string) ( ( (array) $r->get_json_params() )['note'] ?? '' ) ) ); },
		) );
	}
}
