<?php
/**
 * Narzędziownia → Przyrządy pomiarowe: ewidencja (Załącznik nr 3 do KSJ715001) + historia wzorcowań ze świadectwami.
 *
 * Każdy przyrząd ma okres wzorcowania w miesiącach (odczytany z Excela); po zapisaniu wzorcowania
 * data kolejnego = data + okres (można ustawić ręcznie). Ostrzeżenie 60 dni przed terminem (jak w Excelu).
 * Przeglądanie: zakładka „Przyrządy pomiarowe”; zmiany: akcja „pomiar” (domyślnie administrator magazynu).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MSM_Pomiar {

	const SOON     = 60; // dni – domyślnie; wartość z Ustawień: soon()

	public static function soon() {
		return class_exists( 'MSM_Settings' ) && method_exists( 'MSM_Settings', 'prog' ) ? MSM_Settings::prog( 'prog_pomiar' ) : self::SOON;
	}
	const MAX_FILE = 15728640;
	const FIELDS   = array( 'nr_ew', 'nazwa', 'producent', 'typ', 'nr_fabr', 'rok_prod', 'miejsce', 'wzorc_wew', 'wzorc_zew', 'klasa', 'rozdzielczosc', 'zakres', 'data_wzorc', 'sprawny', 'data_nast', 'okres_mies', 'uwagi', 'lokalizacja' );
	const DATES    = array( 'data_wzorc', 'data_nast' );
	const MIEJSCA  = array( 'P' => 'Produkcja', 'S' => 'Dział Serwisu', 'T' => 'Dział Techniczny' );

	public static function T() {
		global $wpdb;
		return $wpdb->prefix . 'msm_pomiar';
	}

	public static function TW() {
		global $wpdb;
		return $wpdb->prefix . 'msm_pomiar_wz';
	}

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
		add_action( 'template_redirect', array( __CLASS__, 'maybe_file' ), 1 );
	}

	public static function create_tables() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$c = $wpdb->get_charset_collate();
		dbDelta( 'CREATE TABLE ' . self::T() . " (
id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
nr_ew varchar(40) NOT NULL DEFAULT '',
nazwa varchar(255) NOT NULL DEFAULT '',
producent varchar(120) NOT NULL DEFAULT '',
typ varchar(120) NOT NULL DEFAULT '',
nr_fabr varchar(120) NOT NULL DEFAULT '',
rok_prod varchar(20) NOT NULL DEFAULT '',
miejsce varchar(40) NOT NULL DEFAULT '',
lokalizacja varchar(60) NOT NULL DEFAULT '',
wzorc_wew varchar(10) NOT NULL DEFAULT '',
wzorc_zew varchar(10) NOT NULL DEFAULT '',
klasa varchar(40) NOT NULL DEFAULT '',
rozdzielczosc varchar(60) NOT NULL DEFAULT '',
zakres varchar(120) NOT NULL DEFAULT '',
data_wzorc date NULL,
sprawny varchar(40) NOT NULL DEFAULT '',
data_nast date NULL,
okres_mies smallint(5) unsigned NULL,
nast_recznie tinyint(1) NOT NULL DEFAULT 0,
wycofany tinyint(1) NOT NULL DEFAULT 0,
uwagi text NULL,
created_at datetime NULL,
updated_at datetime NULL,
updated_by bigint(20) unsigned NOT NULL DEFAULT 0,
PRIMARY KEY  (id),
KEY nr_ew (nr_ew),
KEY data_nast (data_nast),
KEY lokalizacja (lokalizacja)
) $c;" );
		dbDelta( 'CREATE TABLE ' . self::TW() . " (
id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
pm_id bigint(20) unsigned NOT NULL,
data date NOT NULL,
wynik varchar(10) NOT NULL DEFAULT '',
rodzaj varchar(20) NOT NULL DEFAULT '',
wykonal varchar(190) NOT NULL DEFAULT '',
nr_swiad varchar(120) NOT NULL DEFAULT '',
uwagi text NULL,
plik varchar(80) NOT NULL DEFAULT '',
plik_nazwa varchar(255) NOT NULL DEFAULT '',
plik_mime varchar(60) NOT NULL DEFAULT '',
created_at datetime NULL,
created_by bigint(20) unsigned NOT NULL DEFAULT 0,
PRIMARY KEY  (id),
KEY pm (pm_id)
) $c;" );
		self::seed();
		self::fill_lokalizacja();
	}

	/** 1.95.0: lokalizacja istniejących przyrządów – miejsce „P/Wr…” = Wrocław, reszta = pierwsza z listy (Ligota Wołczyńska). Jednorazowo. */
	public static function fill_lokalizacja() {
		global $wpdb;
		if ( get_option( 'msm_pomiar_lok_filled' ) ) {
			return;
		}
		$T   = self::T();
		$lok = MSM_Settings::lokalizacje();
		$wr  = in_array( 'Wrocław', $lok, true ) ? 'Wrocław' : '';
		if ( '' !== $wr ) {
			$wpdb->query( $wpdb->prepare( "UPDATE `$T` SET lokalizacja = %s WHERE lokalizacja = '' AND miejsce LIKE %s", $wr, 'P/Wr%' ) ); // phpcs:ignore
		}
		$wpdb->query( $wpdb->prepare( "UPDATE `$T` SET lokalizacja = %s WHERE lokalizacja = ''", $lok[0] ) ); // phpcs:ignore
		update_option( 'msm_pomiar_lok_filled', 1 );
	}

	/** Jednorazowy import ewidencji z Excela (data/pomiar.json) – tylko do pustej tabeli. */
	public static function seed() {
		global $wpdb;
		if ( get_option( 'msm_pomiar_seeded' ) ) {
			return;
		}
		$f = MSM_DIR . 'data/pomiar.json';
		if ( ! is_readable( $f ) || (int) $wpdb->get_var( 'SELECT COUNT(*) FROM `' . self::T() . '`' ) > 0 ) { // phpcs:ignore
			update_option( 'msm_pomiar_seeded', 1 );
			return;
		}
		$data = json_decode( (string) file_get_contents( $f ), true ); // phpcs:ignore
		$now  = current_time( 'mysql' );
		foreach ( (array) ( $data['pozycje'] ?? array() ) as $x ) {
			$row = array();
			foreach ( self::FIELDS as $k ) {
				if ( in_array( $k, self::DATES, true ) ) {
					$row[ $k ] = empty( $x[ $k ] ) ? null : (string) $x[ $k ];
				} elseif ( 'okres_mies' === $k ) {
					$row[ $k ] = empty( $x[ $k ] ) ? null : (int) $x[ $k ];
				} else {
					$row[ $k ] = (string) ( $x[ $k ] ?? '' );
				}
			}
			$row['nast_recznie'] = $row['data_nast'] && self::auto_nast( $row['data_wzorc'], $row['okres_mies'] ) !== $row['data_nast'] ? 1 : 0; // termin z Excela zostaje
			$row['wycofany']     = empty( $x['wycofany'] ) ? 0 : 1;
			$row['created_at']   = $now;
			$row['updated_at']   = $now;
			$wpdb->insert( self::T(), $row );
		}
		update_option( 'msm_pomiar_seeded', 1 );
	}

	/* ---------------- uprawnienia ---------------- */

	public static function can_view() {
		if ( ! is_user_logged_in() || ! current_user_can( 'msm_view' ) ) {
			return new WP_Error( 'msm_forbidden', 'Brak dostępu.', array( 'status' => 403 ) );
		}
		return MSM_Perms::menu_on( 'narz_pomiarowe' ) ? true : new WP_Error( 'msm_forbidden', 'Zakładka Przyrządy pomiarowe jest dla Ciebie wyłączona.', array( 'status' => 403 ) );
	}

	public static function is_editor() {
		return MSM_Perms::is_wp_admin() || MSM_Perms::cap_on( 'pomiar' );
	}

	public static function can_edit() {
		$c = self::can_view();
		if ( is_wp_error( $c ) ) {
			return $c;
		}
		return self::is_editor() ? true : new WP_Error( 'msm_forbidden', 'Nie masz uprawnienia do zmian w przyrządach pomiarowych.', array( 'status' => 403 ) );
	}

	public static function routes() {
		$ns = MSM_Rest::NS;
		$v  = array( __CLASS__, 'can_view' );
		$e  = array( __CLASS__, 'can_edit' );
		register_rest_route( $ns, '/pomiar', array(
			array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'list_r' ), 'permission_callback' => $v ),
			array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'add_r' ), 'permission_callback' => $e ),
		) );
		register_rest_route( $ns, '/pomiar/(?P<id>\d+)', array(
			array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'get_r' ), 'permission_callback' => $v ),
			array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'save_r' ), 'permission_callback' => $e ),
		) );
		register_rest_route( $ns, '/pomiar/(?P<id>\d+)/delete', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'delete_r' ), 'permission_callback' => $e ) );
		register_rest_route( $ns, '/pomiar/(?P<id>\d+)/wzorcowanie', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'wz_r' ), 'permission_callback' => $e ) );
		register_rest_route( $ns, '/pomiar/wz/(?P<id>\d+)/delete', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'wz_delete_r' ), 'permission_callback' => $e ) );
		register_rest_route( $ns, '/pomiar/export', array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'export_r' ), 'permission_callback' => $v ) );
	}

	/* ---------------- pomocnicze ---------------- */

	/** Data + okres (miesiące) → Y-m-d; null, gdy brak daty lub okresu. */
	public static function auto_nast( $data, $okres ) {
		$okres = (int) $okres;
		if ( empty( $data ) || $okres <= 0 || ! preg_match( '/^(\d{4})-(\d{2})-(\d{2})$/', (string) $data, $m ) ) {
			return null;
		}
		$y   = (int) $m[1];
		$mo  = (int) $m[2] + $okres;
		$y  += intdiv( $mo - 1, 12 );
		$mo  = ( ( $mo - 1 ) % 12 ) + 1;
		$day = min( (int) $m[3], (int) gmdate( 't', gmmktime( 0, 0, 0, $mo, 1, $y ) ) ); // 31.01 + 1 mies. → 28/29.02
		return sprintf( '%04d-%02d-%02d', $y, $mo, $day );
	}

	/** Prefiks numeru ewidencyjnego (Su-018 → Su). */
	public static function prefix( $nr ) {
		return preg_match( '/^\s*([^\d\s\-]+)/u', (string) $nr, $m ) ? $m[1] : '';
	}

	/** Kolejny wolny numer dla prefiksu (Su → Su-024), format jak w ewidencji: Xx-000. */
	public static function next_nr( $prefix, array $nrs ) {
		$max = 0;
		foreach ( $nrs as $n ) {
			if ( preg_match( '/^' . preg_quote( $prefix, '/' ) . '\s*-?\s*(\d+)$/iu', trim( (string) $n ), $m ) ) {
				$max = max( $max, (int) $m[1] );
			}
		}
		return $prefix . '-' . str_pad( (string) ( $max + 1 ), 3, '0', STR_PAD_LEFT );
	}

	private static function date_in( $v ) {
		$v = trim( (string) $v );
		if ( '' === $v ) {
			return null;
		}
		if ( preg_match( '/^(\d{1,2})[.\-\/](\d{1,2})[.\-\/](\d{4})$/', $v, $m ) ) {
			$v = sprintf( '%04d-%02d-%02d', $m[3], $m[2], $m[1] );
		}
		if ( ! preg_match( '/^(\d{4})-(\d{2})-(\d{2})$/', $v, $m ) || ! checkdate( (int) $m[2], (int) $m[3], (int) $m[1] ) ) {
			return false;
		}
		return $v;
	}

	public static function cast( array $r ) {
		$out = array( 'id' => (int) $r['id'] );
		foreach ( self::FIELDS as $k ) {
			if ( in_array( $k, self::DATES, true ) ) {
				$out[ $k ] = $r[ $k ] ? substr( (string) $r[ $k ], 0, 10 ) : null;
			} elseif ( 'okres_mies' === $k ) {
				$out[ $k ] = null === $r[ $k ] ? null : (int) $r[ $k ];
			} else {
				$out[ $k ] = (string) $r[ $k ];
			}
		}
		$out['nast_recznie'] = (bool) $r['nast_recznie'];
		$out['wycofany']     = (bool) $r['wycofany'];
		return $out;
	}

	private static function get( $id ) {
		global $wpdb;
		$r = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM `' . self::T() . '` WHERE id = %d', (int) $id ), ARRAY_A ); // phpcs:ignore
		return $r ?: null;
	}

	public static function rows() {
		global $wpdb;
		return array_map( array( __CLASS__, 'cast' ), (array) $wpdb->get_results( 'SELECT * FROM `' . self::T() . '` ORDER BY nr_ew, id', ARRAY_A ) ); // phpcs:ignore
	}

	private static function nrs( $except = 0 ) {
		global $wpdb;
		return (array) $wpdb->get_col( $wpdb->prepare( 'SELECT nr_ew FROM `' . self::T() . '` WHERE id <> %d', (int) $except ) ); // phpcs:ignore
	}

	private static function wz_list( $id ) {
		global $wpdb;
		$rows = (array) $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM `' . self::TW() . '` WHERE pm_id = %d ORDER BY data DESC, id DESC', (int) $id ), ARRAY_A ); // phpcs:ignore
		return array_map( function ( $w ) {
			return array(
				'id'       => (int) $w['id'],
				'data'     => (string) $w['data'],
				'wynik'    => (string) $w['wynik'],
				'rodzaj'   => (string) $w['rodzaj'],
				'wykonal'  => (string) $w['wykonal'],
				'nr_swiad' => (string) $w['nr_swiad'],
				'uwagi'    => (string) $w['uwagi'],
				'plik'     => '' !== $w['plik'] ? array( 'nazwa' => $w['plik_nazwa'], 'url' => add_query_arg( array( 'msm_pomiar_file' => (int) $w['id'] ), MSM_Access::app_url() ) ) : null,
			);
		}, $rows );
	}

	private static function label( array $r ) {
		return $r['nr_ew'] . ' ' . $r['nazwa'];
	}

	/** Dane formularza → wiersz bazy. */
	private static function input( WP_REST_Request $r, $id = 0, $old_nr = '' ) {
		$p   = (array) $r->get_json_params();
		$row = array();
		foreach ( array( 'nazwa' => 255, 'producent' => 120, 'typ' => 120, 'nr_fabr' => 120, 'rok_prod' => 20, 'miejsce' => 40, 'klasa' => 40, 'rozdzielczosc' => 60, 'zakres' => 120, 'sprawny' => 40 ) as $k => $len ) {
			$row[ $k ] = mb_substr( sanitize_text_field( (string) ( $p[ $k ] ?? '' ) ), 0, $len );
		}
		foreach ( array( 'wzorc_wew', 'wzorc_zew' ) as $k ) {
			$v         = mb_strtoupper( trim( (string) ( $p[ $k ] ?? '' ) ) );
			$row[ $k ] = in_array( $v, array( 'TAK', 'NIE', 'ND' ), true ) ? $v : '';
		}
		$row['uwagi'] = mb_substr( sanitize_textarea_field( (string) ( $p['uwagi'] ?? '' ) ), 0, 5000 );
		$lok          = MSM_Settings::lokalizacja_in( $p['lokalizacja'] ?? '', self::T() );
		if ( is_wp_error( $lok ) ) {
			return $lok;
		}
		$row['lokalizacja'] = $lok;
		$nr           = mb_substr( preg_replace( '/\s+/u', '', sanitize_text_field( (string) ( $p['nr_ew'] ?? '' ) ) ), 0, 40 );
		if ( '' === $nr ) {
			return new WP_Error( 'msm_400', 'Podaj numer ewidencyjny.', array( 'status' => 400, 'fields' => array( 'nr_ew' => 'Wymagany' ) ) );
		}
		if ( '' === $row['nazwa'] ) {
			return new WP_Error( 'msm_400', 'Podaj nazwę przyrządu.', array( 'status' => 400, 'fields' => array( 'nazwa' => 'Wymagana' ) ) );
		}
		// Numer unikalny (zaimportowane z Excela duplikaty można edytować bez zmiany numeru).
		if ( mb_strtolower( $nr ) !== mb_strtolower( (string) $old_nr ) && in_array( mb_strtolower( $nr ), array_map( 'mb_strtolower', self::nrs( $id ) ), true ) ) {
			return new WP_Error( 'msm_dup', 'Numer ' . $nr . ' ma już inny przyrząd. Kolejny wolny: ' . self::next_nr( self::prefix( $nr ), self::nrs( $id ) ) . '.', array( 'status' => 409, 'fields' => array( 'nr_ew' => 'Zajęty' ) ) );
		}
		$row['nr_ew'] = $nr;
		foreach ( self::DATES as $k ) {
			$d = self::date_in( $p[ $k ] ?? '' );
			if ( false === $d ) {
				return new WP_Error( 'msm_400', 'Nieprawidłowa data.', array( 'status' => 400, 'fields' => array( $k => 'Nieprawidłowa data' ) ) );
			}
			$row[ $k ] = $d;
		}
		$ok                = (int) ( $p['okres_mies'] ?? 0 );
		$row['okres_mies'] = $ok > 0 && $ok <= 240 ? $ok : null;
		$row['nast_recznie'] = empty( $p['nast_recznie'] ) ? 0 : 1;
		$row['wycofany']     = empty( $p['wycofany'] ) ? 0 : 1;
		if ( ! $row['nast_recznie'] ) {
			$row['data_nast'] = self::auto_nast( $row['data_wzorc'], $row['okres_mies'] );
		}
		return $row;
	}

	private static function meta() {
		$ss  = self::nrs();
		$pre = array();
		foreach ( $ss as $n ) {
			$x = self::prefix( $n );
			if ( '' !== $x ) {
				$pre[ $x ] = self::next_nr( $x, $ss );
			}
		}
		ksort( $pre );
		return array( 'nastepne' => $pre, 'ostrzezenie' => self::soon(), 'miejsca' => self::MIEJSCA, 'lokalizacje' => MSM_Settings::lokalizacje_z( self::T() ), 'edycja' => self::is_editor(), 'ja' => wp_get_current_user()->display_name, 'dzis' => current_time( 'Y-m-d' ) );
	}

	/* ---------------- REST ---------------- */

	public static function list_r() {
		return rest_ensure_response( array_merge( array( 'pozycje' => self::rows() ), self::meta() ) );
	}

	public static function get_r( WP_REST_Request $r ) {
		$e = self::get( (int) $r['id'] );
		if ( ! $e ) {
			return new WP_Error( 'msm_404', 'Przyrząd nie istnieje (mógł zostać usunięty).', array( 'status' => 404 ) );
		}
		$all  = self::rows();
		$uniq = function ( $k ) use ( $all ) {
			$v = array_values( array_unique( array_filter( wp_list_pluck( $all, $k ), function ( $x ) { return '' !== $x && '-' !== $x; } ) ) );
			sort( $v );
			return $v;
		};
		$wyk = array();
		global $wpdb;
		foreach ( (array) $wpdb->get_col( 'SELECT DISTINCT wykonal FROM `' . self::TW() . "` WHERE wykonal <> ''" ) as $w ) { // phpcs:ignore
			$wyk[] = $w;
		}
		return rest_ensure_response( array_merge( array(
			'pozycja'      => self::cast( $e ),
			'wzorcowania'  => self::wz_list( $e['id'] ),
			'dubel'        => in_array( mb_strtolower( $e['nr_ew'] ), array_map( 'mb_strtolower', self::nrs( $e['id'] ) ), true ),
			'producenci'   => $uniq( 'producent' ),
			'miejsca_list' => $uniq( 'miejsce' ),
			'wykonawcy'    => $wyk,
		), self::meta() ) );
	}

	public static function add_r( WP_REST_Request $r ) {
		global $wpdb;
		$row = self::input( $r );
		if ( is_wp_error( $row ) ) {
			return $row;
		}
		$now = current_time( 'mysql' );
		$wpdb->insert( self::T(), $row + array( 'created_at' => $now, 'updated_at' => $now, 'updated_by' => get_current_user_id() ) );
		$id = (int) $wpdb->insert_id;
		if ( ! $id ) {
			return new WP_Error( 'msm_500', 'Nie udało się zapisać.', array( 'status' => 500 ) );
		}
		MSM_Repo::log( 'Przyrządy pomiarowe: nowy', 'pomiar', $id, 'Dodano: ' . self::label( $row ), array( 'po' => $row ) );
		return rest_ensure_response( array( 'id' => $id ) );
	}

	public static function save_r( WP_REST_Request $r ) {
		global $wpdb;
		$old = self::get( (int) $r['id'] );
		if ( ! $old ) {
			return new WP_Error( 'msm_404', 'Przyrząd nie istnieje (mógł zostać usunięty).', array( 'status' => 404 ) );
		}
		$row = self::input( $r, (int) $old['id'], $old['nr_ew'] );
		if ( is_wp_error( $row ) ) {
			return $row;
		}
		$diff = array();
		foreach ( $row as $k => $v ) {
			if ( (string) $v !== (string) $old[ $k ] ) {
				$diff[ $k ] = array( $old[ $k ], $v );
			}
		}
		if ( $diff ) {
			$wpdb->update( self::T(), $row + array( 'updated_at' => current_time( 'mysql' ), 'updated_by' => get_current_user_id() ), array( 'id' => (int) $old['id'] ) );
			MSM_Repo::log( 'Przyrządy pomiarowe: edycja', 'pomiar', (int) $old['id'], 'Zmieniono: ' . self::label( $row ) . ' – ' . implode( ', ', array_keys( $diff ) ), array( 'przed' => array_map( function ( $d ) { return $d[0]; }, $diff ), 'po' => array_map( function ( $d ) { return $d[1]; }, $diff ) ) );
		}
		return self::get_r( $r );
	}

	public static function delete_r( WP_REST_Request $r ) {
		global $wpdb;
		$old = self::get( (int) $r['id'] );
		if ( ! $old ) {
			return new WP_Error( 'msm_404', 'Przyrząd nie istnieje (mógł zostać usunięty).', array( 'status' => 404 ) );
		}
		$wz = (array) $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM `' . self::TW() . '` WHERE pm_id = %d', (int) $old['id'] ), ARRAY_A ); // phpcs:ignore
		foreach ( $wz as $w ) {
			self::unlink_file( $w['plik'] );
		}
		$wpdb->delete( self::TW(), array( 'pm_id' => (int) $old['id'] ) );
		$wpdb->delete( self::T(), array( 'id' => (int) $old['id'] ) );
		MSM_Repo::log( 'Przyrządy pomiarowe: usunięcie', 'pomiar', (int) $old['id'], 'Usunięto: ' . self::label( $old ) . ( $wz ? ' (z historią ' . count( $wz ) . ' wzorcowań)' : '' ), array( 'przed' => $old, 'wzorcowania' => $wz ) );
		return rest_ensure_response( array( 'deleted' => (int) $old['id'] ) );
	}

	/**
	 * Zapis wzorcowania / sprawdzenia (multipart: pola + opcjonalny plik świadectwa JPG/PNG/PDF).
	 * Najnowsze wzorcowanie ustawia datę wzorcowania, „sprawny” i datę kolejnego (data + okres przyrządu,
	 * albo data podana ręcznie).
	 */
	public static function wz_r( WP_REST_Request $r ) {
		global $wpdb;
		$e = self::get( (int) $r['id'] );
		if ( ! $e ) {
			return new WP_Error( 'msm_404', 'Przyrząd nie istnieje (mógł zostać usunięty).', array( 'status' => 404 ) );
		}
		$p = $r->get_params();
		$d = self::date_in( $p['data'] ?? '' );
		if ( ! $d ) {
			return new WP_Error( 'msm_400', 'Podaj datę wzorcowania.', array( 'status' => 400, 'fields' => array( 'data' => 'Wymagana' ) ) );
		}
		if ( $d > current_time( 'Y-m-d' ) ) {
			return new WP_Error( 'msm_400', 'Data wzorcowania nie może być z przyszłości.', array( 'status' => 400, 'fields' => array( 'data' => 'Z przyszłości' ) ) );
		}
		$wynik = in_array( $p['wynik'] ?? '', array( 'T', 'N' ), true ) ? $p['wynik'] : '';
		if ( '' === $wynik ) {
			return new WP_Error( 'msm_400', 'Wybierz wynik: sprawny albo niesprawny.', array( 'status' => 400, 'fields' => array( 'wynik' => 'Wymagany' ) ) );
		}
		$rodzaj = in_array( $p['rodzaj'] ?? '', array( 'zewnętrzne', 'wewnętrzne' ), true ) ? $p['rodzaj'] : 'zewnętrzne';
		$wyk    = mb_substr( sanitize_text_field( (string) ( $p['wykonal'] ?? '' ) ), 0, 190 );
		if ( '' === $wyk ) {
			return new WP_Error( 'msm_400', 'Podaj, kto wykonał wzorcowanie (firma lub osoba).', array( 'status' => 400, 'fields' => array( 'wykonal' => 'Wymagane' ) ) );
		}
		$okres = (int) ( $p['okres_mies'] ?? 0 );
		$okres = $okres > 0 && $okres <= 240 ? $okres : ( $e['okres_mies'] ? (int) $e['okres_mies'] : null );
		$nast  = self::date_in( $p['data_nast'] ?? '' );
		if ( false === $nast ) {
			return new WP_Error( 'msm_400', 'Nieprawidłowa data kolejnego wzorcowania.', array( 'status' => 400, 'fields' => array( 'data_nast' => 'Nieprawidłowa data' ) ) );
		}
		$auto = self::auto_nast( $d, $okres );
		$file = array( 'plik' => '', 'plik_nazwa' => '', 'plik_mime' => '' );
		$fp   = $r->get_file_params();
		if ( ! empty( $fp['file']['name'] ) ) {
			$file = self::store_file( $fp['file'] );
			if ( is_wp_error( $file ) ) {
				return $file;
			}
		}
		$wpdb->insert( self::TW(), array(
			'pm_id'      => (int) $e['id'],
			'data'       => $d,
			'wynik'      => $wynik,
			'rodzaj'     => $rodzaj,
			'wykonal'    => $wyk,
			'nr_swiad'   => mb_substr( sanitize_text_field( (string) ( $p['nr_swiad'] ?? '' ) ), 0, 120 ),
			'uwagi'      => mb_substr( sanitize_textarea_field( (string) ( $p['uwagi'] ?? '' ) ), 0, 2000 ),
			'created_at' => current_time( 'mysql' ),
			'created_by' => get_current_user_id(),
		) + $file );
		if ( ! $e['data_wzorc'] || $d >= $e['data_wzorc'] ) {
			$wpdb->update( self::T(), array(
				'data_wzorc'   => $d,
				'sprawny'      => $wynik,
				'okres_mies'   => $okres,
				'data_nast'    => $nast ? $nast : $auto,
				'nast_recznie' => $nast && $nast !== $auto ? 1 : 0,
				'wzorc_zew'    => 'zewnętrzne' === $rodzaj ? 'TAK' : $e['wzorc_zew'],
				'wzorc_wew'    => 'wewnętrzne' === $rodzaj ? 'TAK' : $e['wzorc_wew'],
				'updated_at'   => current_time( 'mysql' ),
				'updated_by'   => get_current_user_id(),
			), array( 'id' => (int) $e['id'] ) );
		}
		MSM_Repo::log( 'Przyrządy pomiarowe: wzorcowanie', 'pomiar', (int) $e['id'], self::label( $e ) . ' – ' . mysql2date( 'd.m.Y', $d ) . ' (' . $rodzaj . ', ' . $wyk . '): ' . ( 'T' === $wynik ? 'sprawny' : 'niesprawny' ) . ( '' !== $file['plik'] ? ' + świadectwo' : '' ) );
		return self::get_r( $r );
	}

	public static function wz_delete_r( WP_REST_Request $r ) {
		global $wpdb;
		$w = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM `' . self::TW() . '` WHERE id = %d', (int) $r['id'] ), ARRAY_A ); // phpcs:ignore
		if ( ! $w ) {
			return new WP_Error( 'msm_404', 'Wpis nie istnieje.', array( 'status' => 404 ) );
		}
		$e = self::get( (int) $w['pm_id'] );
		self::unlink_file( $w['plik'] );
		$wpdb->delete( self::TW(), array( 'id' => (int) $w['id'] ) );
		MSM_Repo::log( 'Przyrządy pomiarowe: usunięto wzorcowanie', 'pomiar', (int) $w['pm_id'], ( $e ? self::label( $e ) : '#' . $w['pm_id'] ) . ' – wpis z ' . mysql2date( 'd.m.Y', $w['data'] ) . ' (' . $w['wykonal'] . ')', array( 'przed' => $w ) );
		$r2 = new WP_REST_Request( 'GET' );
		$r2->set_url_params( array( 'id' => (int) $w['pm_id'] ) );
		return self::get_r( $r2 );
	}

	/* ---------------- świadectwa (pliki chronione) ---------------- */

	public static function dir() {
		$up  = wp_upload_dir();
		$dir = trailingslashit( $up['basedir'] ) . 'msm-pomiar';
		if ( ! is_dir( $dir ) ) {
			wp_mkdir_p( $dir );
		}
		if ( ! file_exists( $dir . '/.htaccess' ) ) {
			@file_put_contents( $dir . '/.htaccess', "Require all denied\nDeny from all\n" ); // phpcs:ignore
		}
		if ( ! file_exists( $dir . '/index.php' ) ) {
			@file_put_contents( $dir . '/index.php', "<?php // Silence.\n" ); // phpcs:ignore
		}
		return $dir;
	}

	private static function store_file( array $f ) {
		if ( ! empty( $f['error'] ) || ! is_uploaded_file( $f['tmp_name'] ) ) {
			return new WP_Error( 'msm_upload', 'Nie udało się wgrać pliku świadectwa.', array( 'status' => 400 ) );
		}
		if ( $f['size'] > self::MAX_FILE ) {
			return new WP_Error( 'msm_upload', 'Plik jest za duży (max 15 MB).', array( 'status' => 400 ) );
		}
		$check = wp_check_filetype_and_ext( $f['tmp_name'], $f['name'], array( 'jpg|jpeg' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp', 'pdf' => 'application/pdf' ) );
		if ( empty( $check['ext'] ) ) {
			return new WP_Error( 'msm_upload', 'Świadectwo: dozwolone pliki PDF, JPG, PNG, WEBP.', array( 'status' => 400 ) );
		}
		$name = wp_generate_password( 24, false ) . '.' . $check['ext'];
		if ( ! @move_uploaded_file( $f['tmp_name'], self::dir() . '/' . $name ) ) { // phpcs:ignore
			return new WP_Error( 'msm_upload', 'Nie udało się zapisać pliku na serwerze.', array( 'status' => 500 ) );
		}
		return array( 'plik' => $name, 'plik_nazwa' => mb_substr( sanitize_file_name( $f['name'] ), 0, 255 ), 'plik_mime' => $check['type'] );
	}

	private static function unlink_file( $name ) {
		$name = basename( (string) $name );
		if ( '' !== $name && is_file( self::dir() . '/' . $name ) ) {
			@unlink( self::dir() . '/' . $name ); // phpcs:ignore
		}
	}

	/** ?msm_pomiar_file=ID – świadectwo dla osoby z dostępem do zakładki. */
	public static function maybe_file() {
		if ( empty( $_GET['msm_pomiar_file'] ) ) { // phpcs:ignore
			return;
		}
		if ( is_wp_error( self::can_view() ) ) {
			wp_die( 'Brak dostępu.', 403 );
		}
		global $wpdb;
		$w    = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM `' . self::TW() . '` WHERE id = %d', (int) $_GET['msm_pomiar_file'] ), ARRAY_A ); // phpcs:ignore
		$path = $w && '' !== $w['plik'] ? self::dir() . '/' . basename( $w['plik'] ) : '';
		if ( ! $path || ! is_file( $path ) ) {
			wp_die( 'Plik nie istnieje.', 404 );
		}
		nocache_headers();
		header( 'Content-Type: ' . $w['plik_mime'] );
		header( 'Content-Length: ' . filesize( $path ) );
		header( 'Content-Disposition: inline; filename="' . rawurlencode( $w['plik_nazwa'] ) . '"' );
		header( 'X-Content-Type-Options: nosniff' );
		readfile( $path ); // phpcs:ignore
		exit;
	}

	/* ---------------- eksport / Pulpit ---------------- */

	public static function export_rows() {
		$out = array( array( 'Lp.', 'Nr ewidencyjny', 'Nazwa przyrządu', 'Producent', 'TYP', 'Nr fabryczny', 'Rok produkcji', 'Lokalizacja', 'Miejsce użytkowania', 'Wzorcowanie wewnętrznie', 'Wzorcowanie na zewnątrz', 'Klasa dokładności', 'Rozdzielczość', 'Zakres pomiarowy', 'Data wzorcowania', 'Sprawny metrologicznie T/N', 'Data kolejnego wzorcowania / sprawdzenia', 'Okres [mies.]', 'Wycofany', 'Uwagi' ) );
		$d   = function ( $v ) { return $v ? mysql2date( 'd.m.Y', $v ) : ''; };
		foreach ( self::rows() as $i => $e ) {
			$out[] = array( $i + 1, $e['nr_ew'], $e['nazwa'], $e['producent'], $e['typ'], $e['nr_fabr'], $e['rok_prod'], $e['lokalizacja'], $e['miejsce'], $e['wzorc_wew'], $e['wzorc_zew'], $e['klasa'], $e['rozdzielczosc'], $e['zakres'], $d( $e['data_wzorc'] ), $e['sprawny'], $d( $e['data_nast'] ), $e['okres_mies'], $e['wycofany'] ? 'TAK' : '', $e['uwagi'] );
		}
		return $out;
	}

	public static function export_r() {
		if ( ! function_exists( 'wp_tempnam' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		$tmp = wp_tempnam( 'msm-pomiar' );
		if ( ! MSM_Xlsx::write( $tmp, 'Ewidencja', self::export_rows(), array( 5, 11, 28, 14, 14, 14, 9, 16, 11, 11, 11, 9, 11, 16, 13, 11, 15, 8, 9, 30 ) ) ) {
			return new WP_Error( 'msm_500', 'Nie udało się utworzyć pliku.', array( 'status' => 500 ) );
		}
		nocache_headers();
		header( 'Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' );
		header( 'Content-Disposition: attachment; filename="przyrzady-pomiarowe-' . current_time( 'Y-m-d' ) . '.xlsx"' );
		header( 'Content-Length: ' . filesize( $tmp ) );
		readfile( $tmp ); // phpcs:ignore
		@unlink( $tmp ); // phpcs:ignore
		exit;
	}

	/** Pulpit: przyrządy po terminie wzorcowania i w ciągu 60 dni (bez wycofanych). */
	public static function tablica() {
		global $wpdb;
		$T = self::T();
		if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $T ) ) !== $T ) {
			return null;
		}
		$today = current_time( 'Y-m-d' );
		$soon  = gmdate( 'Y-m-d', strtotime( $today . ' +' . self::soon() . ' days' ) );
		$po    = (array) $wpdb->get_results( $wpdb->prepare( "SELECT id, nr_ew, nazwa, miejsce, lokalizacja, data_nast FROM `$T` WHERE wycofany = 0 AND data_nast IS NOT NULL AND data_nast < %s ORDER BY data_nast ASC, nr_ew ASC", $today ), ARRAY_A ); // phpcs:ignore
		$wk    = (array) $wpdb->get_results( $wpdb->prepare( "SELECT id, nr_ew, nazwa, miejsce, lokalizacja, data_nast FROM `$T` WHERE wycofany = 0 AND data_nast >= %s AND data_nast <= %s ORDER BY data_nast ASC", $today, $soon ), ARRAY_A ); // phpcs:ignore
		$map   = function ( $x ) use ( $today ) {
			return array( 'id' => (int) $x['id'], 'nr_ew' => $x['nr_ew'], 'nazwa' => $x['nazwa'], 'miejsce' => $x['miejsce'], 'lokalizacja' => $x['lokalizacja'], 'data_nast' => $x['data_nast'], 'dni' => (int) round( ( strtotime( $x['data_nast'] ) - strtotime( $today ) ) / DAY_IN_SECONDS ) );
		};
		return array(
			'po_terminie' => count( $po ),
			'wkrotce'     => count( $wk ),
			'lista'       => array_map( $map, array_slice( array_merge( $po, $wk ), 0, 8 ) ),
		);
	}
}
