<?php
/**
 * Tablica kierownika – jedna strona z tym, co wymaga uwagi:
 * zlecenia zagrożone i po terminie, braki magazynowe, wnioski i rezerwacje do decyzji,
 * wymiana BHP, kopia danych i dzisiejsza aktywność. Każda sekcja tylko dla osób z dostępem do jej zakładki.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MSM_Tablica {

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
	}

	public static function routes() {
		register_rest_route( MSM_Rest::NS, '/tablica', array(
			'methods'             => 'GET',
			'callback'            => array( __CLASS__, 'data' ),
			'permission_callback' => function () {
				return current_user_can( 'msm_view' ) && MSM_Perms::menu_on( 'tablica' );
			},
		) );
		register_rest_route( MSM_Rest::NS, '/tablica/uklad', array(
			'methods'             => 'POST',
			'callback'            => array( __CLASS__, 'save_layout' ),
			'permission_callback' => function () {
				return current_user_can( 'msm_view' ) && MSM_Perms::menu_on( 'tablica' );
			},
		) );
	}

	const LAYOUT_META = 'msm_tablica_uklad';

	/** Układ modułów Pulpitu danej osoby: { top: [klucze], cols: [[…], […], […]] } albo null (domyślny). */
	public static function layout( $uid = 0 ) {
		$l = get_user_meta( $uid ? $uid : get_current_user_id(), self::LAYOUT_META, true );
		return is_array( $l ) && isset( $l['top'], $l['cols'] ) ? $l : null;
	}

	/** Czyści układ: tylko klucze modułów (litery/cyfry/_), bez powtórzeń, 3 kolumny. */
	public static function clean_layout( $in ) {
		if ( ! is_array( $in ) ) {
			return null;
		}
		$seen  = array();
		$pick  = function ( $list ) use ( &$seen ) {
			$out = array();
			foreach ( array_slice( (array) $list, 0, 30 ) as $k ) {
				$k = preg_replace( '/[^a-z0-9_]/', '', strtolower( (string) $k ) );
				if ( '' !== $k && ! isset( $seen[ $k ] ) ) {
					$seen[ $k ] = true;
					$out[]      = $k;
				}
			}
			return $out;
		};
		$top  = $pick( $in['top'] ?? array() );
		$cols = array();
		for ( $i = 0; $i < 3; $i++ ) {
			$cols[] = $pick( $in['cols'][ $i ] ?? array() );
		}
		$prop = (string) ( $in['prop'] ?? '1-1-1' );
		$out  = array( 'top' => $top, 'cols' => $cols, 'prop' => in_array( $prop, self::PROPS, true ) ? $prop : '1-1-1' );
		// Moduły (2.3.0): kolejność i szerokość w siatce 12 kolumn (1/6 … cała szerokość).
		if ( isset( $in['mods'] ) && is_array( $in['mods'] ) ) {
			$seen        = array();
			$out['mods'] = array( 'order' => $pick( $in['mods']['order'] ?? array() ), 'w' => array() );
			foreach ( array_slice( (array) ( $in['mods']['w'] ?? array() ), 0, 30, true ) as $key => $w ) {
				$key = preg_replace( '/[^a-z0-9_]/', '', strtolower( (string) $key ) );
				if ( '' !== $key && in_array( (int) $w, self::MOD_W, true ) ) {
					$out['mods']['w'][ $key ] = (int) $w;
				}
			}
			if ( ! $out['mods']['w'] ) {
				$out['mods']['w'] = new stdClass();
			}
		}
		// Kafelki z liczbami: kolejność, szerokość (2/3/4/6 z 12), ukryte, „ukryj zerowe”.
		if ( isset( $in['kpi'] ) && is_array( $in['kpi'] ) ) {
			$k    = $in['kpi'];
			$seen = array();
			$out['kpi'] = array( 'order' => $pick( $k['order'] ?? array() ), 'w' => array(), 'hide' => array(), 'zero' => ! empty( $k['zero'] ) );
			foreach ( array_slice( (array) ( $k['w'] ?? array() ), 0, 30, true ) as $key => $w ) {
				$key = preg_replace( '/[^a-z0-9_]/', '', strtolower( (string) $key ) );
				if ( '' !== $key && in_array( (int) $w, array( 2, 3, 4, 6 ), true ) ) {
					$out['kpi']['w'][ $key ] = (int) $w;
				}
			}
			$seen               = array(); // $pick pamięta użyte klucze – osobno dla listy ukrytych
			$out['kpi']['hide'] = $pick( $k['hide'] ?? array() );
			if ( ! $out['kpi']['w'] ) {
				$out['kpi']['w'] = new stdClass(); // JSON: {} zamiast []
			}
		}
		return $out;
	}

	/** Dozwolone proporcje kolumn Pulpitu (części szerokości): 3 albo 2 kolumny. */
	const PROPS = array( '1-1-1', '2-1-1', '1-2-1', '1-1-2', '2-1', '1-2', '1-1' );

	/** Dozwolone szerokości modułów Pulpitu (części 12-kolumnowej siatki): 1/6, 1/4, 1/3, 1/2, 2/3, 3/4, całość. */
	const MOD_W = array( 2, 3, 4, 6, 8, 9, 12 );

	/** POST /tablica/uklad { uklad } – zapis; { uklad: null } – przywrócenie domyślnego. */
	public static function save_layout( WP_REST_Request $r ) {
		$p   = (array) $r->get_json_params();
		$uid = get_current_user_id();
		$l   = self::clean_layout( $p['uklad'] ?? null );
		if ( null === $l ) {
			delete_user_meta( $uid, self::LAYOUT_META );
		} else {
			update_user_meta( $uid, self::LAYOUT_META, $l );
		}
		return rest_ensure_response( array( 'uklad' => $l ) );
	}

	private static function on( $key ) {
		return MSM_Perms::menu_on( $key );
	}

	private static function table_ok( $T ) {
		global $wpdb;
		return $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $T ) ) === $T;
	}

	public static function data() {
		$out = array( 'dzis' => current_time( 'Y-m-d' ), 'uklad' => self::layout() );
		if ( class_exists( 'MSM_Prod' ) && self::on( 'produkcja' ) ) {
			$out['produkcja'] = self::produkcja();
		}
		if ( self::on( 'zamowienia' ) && current_user_can( 'msm_edit' ) ) {
			$out['braki'] = self::braki();
		}
		if ( self::on( 'wnioski' ) ) {
			$out['wnioski'] = self::wnioski();
		}
		if ( self::on( 'rezerwacje' ) && class_exists( 'MSM_Rezerwacje' ) ) {
			$out['rezerwacje'] = self::rezerwacje();
		}
		if ( self::on( 'bhp' ) && self::on( 'bhp_wymiana' ) && class_exists( 'MSM_Bhp_Util' ) ) {
			$w            = MSM_Bhp_Util::do_wymiany();
			$out['bhp']   = array( 'n' => count( $w ), 'lista' => array_slice( $w, 0, 5 ) );
		}
		if ( self::on( 'kopia' ) && current_user_can( 'msm_edit' ) && class_exists( 'MSM_Backup' ) ) {
			$out['kopia'] = array(
				'enabled' => (bool) get_option( 'msm_backup_enabled', 1 ),
				'last'    => (int) get_option( 'msm_backup_last', 0 ),
				'error'   => (string) get_option( 'msm_backup_error', '' ),
			);
		}
		if ( self::on( 'zamowienia' ) && class_exists( 'MSM_Zam' ) ) {
			$out['zam'] = MSM_Zam::tablica();
		}
		if ( self::on( 'narz_pomiarowe' ) && class_exists( 'MSM_Pomiar' ) ) {
			$out['pomiar'] = MSM_Pomiar::tablica();
		}
		if ( self::on( 'narz_elektro' ) && class_exists( 'MSM_Elektro' ) ) {
			$out['elektro'] = MSM_Elektro::tablica();
		}
		if ( self::on( 'przesylki' ) && class_exists( 'MSM_Przesylki' ) ) {
			$out['przesylki'] = MSM_Przesylki::tablica();
		}
		if ( class_exists( 'MSM_Karty_Zmian' ) && MSM_Karty_Zmian::can_view() ) {
			$out['karty_zmian'] = MSM_Karty_Zmian::tablica();
		}
		$out['aktywnosc'] = self::aktywnosc();
		return rest_ensure_response( $out );
	}

	/* ---------------- Produkcja: termin vs. realizacja ---------------- */

	/** Data „dd.mm.rrrr” → znacznik czasu (północ) albo null. */
	public static function pdate( $s ) {
		if ( ! preg_match( '/^(\d{1,2})[.\-\/](\d{1,2})[.\-\/](\d{4})$/', trim( (string) $s ), $m ) || ! checkdate( (int) $m[2], (int) $m[1], (int) $m[3] ) ) {
			return null;
		}
		return gmmktime( 0, 0, 0, (int) $m[2], (int) $m[1], (int) $m[3] );
	}

	/**
	 * Stan terminu zlecenia – te same zasady co na liście Produkcji:
	 * done (100%), late (po terminie), wait (przed startem), risk (≤3 dni albo czas wyprzedza postęp o >15 pkt), ok, none (brak daty).
	 */
	const RISK_DAYS = 7; // domyślnie; wartość z Ustawień: risk_days()

	/** Zlecenie zagrożone: tyle dni (lub mniej) do terminu i niezrealizowane (Ustawienia → progi ostrzeżeń). */
	public static function risk_days() {
		return class_exists( 'MSM_Settings' ) && method_exists( 'MSM_Settings', 'prog' ) ? MSM_Settings::prog( 'prog_zlecenia' ) : self::RISK_DAYS;
	}

	/** Stan terminu zlecenia: none | done | late | risk | slow | ok | wait. */
	public static function termin( $start, $koniec, $zam, $wyk, $today_ts ) {
		$end  = self::pdate( $koniec );
		$st   = self::pdate( $start );
		$proc = $zam > 0 ? 100 * $wyk / $zam : 0;
		if ( null === $end ) {
			return array( 'state' => 'none', 'left' => null, 'proc' => $proc );
		}
		$left = (int) round( ( $end - $today_ts ) / DAY_IN_SECONDS );
		if ( $zam > 0 && $proc >= 100 ) {
			return array( 'state' => 'done', 'left' => $left, 'proc' => $proc );
		}
		if ( $left < 0 ) {
			return array( 'state' => 'late', 'left' => $left, 'proc' => $proc );
		}
		if ( null !== $st && $today_ts < $st ) {
			return array( 'state' => 'wait', 'left' => $left, 'proc' => $proc );
		}
		// Zagrożone: do N dni do terminu (Ustawienia), a zlecenie niezrealizowane.
		if ( $left <= self::risk_days() ) {
			return array( 'state' => 'risk', 'left' => $left, 'proc' => $proc );
		}
		// Więcej czasu, ale postęp wyraźnie za upływem czasu – „postęp poniżej planu” (informacyjnie, nie alarm).
		$pct = null !== $st && $end > $st ? max( 0, min( 100, 100 * ( $today_ts - $st ) / ( $end - $st ) ) ) : 0;
		if ( $pct - $proc > 15 ) {
			return array( 'state' => 'slow', 'left' => $left, 'proc' => $proc );
		}
		return array( 'state' => 'ok', 'left' => $left, 'proc' => $proc );
	}

	private static function produkcja() {
		global $wpdb;
		$TZ = MSM_Prod::TZ();
		$TD = MSM_Prod::TD();
		if ( ! self::table_ok( $TZ ) ) {
			return null;
		}
		$rows  = (array) $wpdb->get_results( $wpdb->prepare( "SELECT z.id, z.arkusz, z.nr_zlec, z.klient, z.start_zlec, z.koniec_zlec, z.uwagi_ogolne, z.karta, COALESCE(SUM(d.ilosc_zam),0) zam, COALESCE(SUM(d.wykonano),0) wyk FROM `$TZ` z LEFT JOIN `$TD` d ON d.zlec_id = z.id WHERE z.id > %d GROUP BY z.id", 0 ), ARRAY_A ); // phpcs:ignore – wszystkie lata
		$today = self::pdate( current_time( 'd.m.Y' ) );
		$cnt   = array( 'late' => 0, 'risk' => 0, 'slow' => 0, 'ok' => 0, 'wait' => 0, 'done' => 0, 'none' => 0 );
		$alert = array();
		$lata  = array(); // stan → [rok arkusza → liczba] – żeby kafelek otwierał właściwy rok listy
		foreach ( $rows as $r ) {
			$t = self::termin( $r['start_zlec'], $r['koniec_zlec'], (int) $r['zam'], (int) $r['wyk'], $today );
			$cnt[ $t['state'] ]++;
			$lata[ $t['state'] ][ (string) $r['arkusz'] ] = ( $lata[ $t['state'] ][ (string) $r['arkusz'] ] ?? 0 ) + 1;
			if ( in_array( $t['state'], array( 'late', 'risk' ), true ) ) {
				$alert[] = array(
					'id'     => (int) $r['id'],
					'nr'     => (string) $r['nr_zlec'],
					'klient' => (string) $r['klient'],
					'koniec' => (string) $r['koniec_zlec'],
					'state'  => $t['state'],
					'left'   => $t['left'],
					'proc'   => round( $t['proc'], 1 ),
					'uwagi'  => self::uwagi( $r ),
				);
			}
		}
		usort( $alert, function ( $a, $b ) { return $a['left'] <=> $b['left']; } );
		foreach ( $lata as &$ly ) {
			krsort( $ly );
		}
		unset( $ly );
		return array( 'n' => count( $rows ), 'stany' => $cnt, 'lata' => $lata, 'lista' => array_slice( $alert, 0, 8 ), 'alert_n' => count( $alert ) );
	}

	/** Uwagi do projektu: „Uwagi ogólne” zlecenia i „Uwagi” z karty projektu (zwykły tekst). */
	private static function uwagi( array $r ) {
		$out = array();
		$u   = trim( class_exists( 'MSM_Rich' ) ? MSM_Rich::text( (string) $r['uwagi_ogolne'] ) : wp_strip_all_tags( (string) $r['uwagi_ogolne'] ) );
		if ( '' !== $u ) {
			$out[] = $u;
		}
		if ( ! empty( $r['karta'] ) && class_exists( 'MSM_Karta' ) ) {
			$k  = MSM_Karta::decode( $r['karta'] );
			$kr = trim( (string) ( $k['uwagi_kr'] ?? '' ) );
			if ( '' !== $kr && $kr !== $u ) {
				$out[] = $kr;
			}
		}
		return implode( "\n", $out );
	}

	/* ---------------- Magazyn ---------------- */

	private static function braki() {
		$low = class_exists( 'MSM_Reports' ) ? MSM_Reports::low_stock() : array();
		return array(
			'n'     => count( $low ),
			'lista' => array_map( function ( $g ) {
				return array( 'nazwa' => $g['nazwa'] ?? '', 'brak' => $g['brak'] ?? 0 );
			}, array_slice( $low, 0, 5 ) ),
		);
	}

	private static function wnioski() {
		global $wpdb;
		$W = msm_table( 'wnioski' );
		return array(
			'nowe'       => (int) $wpdb->get_var( "SELECT COUNT(*) FROM `$W` WHERE status = 'nowy'" ), // phpcs:ignore
			'do_wydania' => (int) $wpdb->get_var( "SELECT COUNT(*) FROM `$W` WHERE status = 'zaakceptowany'" ), // phpcs:ignore
		);
	}

	private static function rezerwacje() {
		global $wpdb;
		MSM_Rezerwacje::expire();
		$T    = MSM_Rezerwacje::T();
		$soon = gmdate( 'Y-m-d', strtotime( current_time( 'Y-m-d' ) . ' +7 days' ) );
		return array(
			'nowe'     => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM `$T` WHERE status = %s", MSM_Rezerwacje::ST_NEW ) ), // phpcs:ignore
			'aktywne'  => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM `$T` WHERE status = %s", MSM_Rezerwacje::ST_ACTIVE ) ), // phpcs:ignore
			'wygasaja' => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM `$T` WHERE status = %s AND termin IS NOT NULL AND termin <= %s", MSM_Rezerwacje::ST_ACTIVE, $soon ) ), // phpcs:ignore
		);
	}

	/* ---------------- Dzisiaj ---------------- */

	private static function aktywnosc() {
		global $wpdb;
		$today = current_time( 'Y-m-d' );
		$out   = array();
		if ( self::on( 'pobrania' ) ) {
			$P               = msm_table( 'pobrania' );
			$out['pobrania'] = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM `$P` WHERE data = %s", $today ) ); // phpcs:ignore
		}
		if ( self::on( 'wz' ) && self::on( 'wz_dok' ) ) {
			$W         = msm_table( 'wz' );
			$out['wz'] = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM `$W` WHERE DATE(created_at) = %s", $today ) ); // phpcs:ignore
		}
		if ( self::on( 'pz' ) && current_user_can( 'msm_edit' ) ) {
			$Z         = msm_table( 'pz' );
			$out['pz'] = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM `$Z` WHERE DATE(created_at) = %s", $today ) ); // phpcs:ignore
		}
		if ( self::on( 'historia' ) ) {
			$L             = msm_table( 'historia' );
			$out['zmiany'] = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM `$L` WHERE DATE(czas) = %s", $today ) ); // phpcs:ignore
		}
		return $out;
	}
}
