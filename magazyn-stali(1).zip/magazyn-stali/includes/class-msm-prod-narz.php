<?php
/**
 * Produkcja – „Dostępność przyrządów / sprawdzianów” połączona z ewidencją Sprawdzianów i przyrządów.
 *
 * Wpis „PO12 29.93 (3 szt)”: PO = przyrząd okrągły, 12 = numer przyrządu (opcjonalny), 29.93 = Ø lub T, (3 szt) = ile takich samych.
 * Prefiksy: PO – przyrządy okrągłe, SO – sprawdziany okrągłe, PP – przyrządy prostokątne, SP – sprawdziany prostokątne.
 * Status: jest (na regale) / wypożyczony (wydany na HALĘ) / częściowo (mniej sztuk niż potrzeba) / brak.
 * Numery dopisywane są automatycznie tylko w nowych zleceniach – starych opisów nie zmieniamy.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MSM_Prod_Narz {

	const PREFIX = array( 'PO' => 'prz_okr', 'SO' => 'spr_okr', 'PP' => 'prz_prost', 'SP' => 'spr_prost' );
	const TOL    = 0.02; // tolerancja wymiaru [mm]
	const OPT    = 'msm_prod_narz_from'; // zlecenia o id > tej wartości to „nowe” (dopisywanie numerów)
	const RX     = '/(?<![A-Za-z])(PO|SO|PP|SP)(?:(\d+)\s+(?=\d))?\s*(\d+(?:[.,]\d+)?)(?:\s*\(\s*(\d+)\s*szt\.?\s*\))?/iu';

	private static $tools = null;

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
	}

	public static function routes() {
		register_rest_route( MSM_Rest::NS, '/prod/order/(?P<id>\d+)/narzedzia', array(
			'methods'             => 'GET',
			'callback'            => array( __CLASS__, 'order_tools' ),
			'permission_callback' => array( 'MSM_Prod', 'can' ),
		) );
	}

	/** Przy instalacji / aktualizacji: zapamiętuje ostatnie istniejące zlecenie – dalsze to „nowe”. */
	public static function mark_existing() {
		global $wpdb;
		if ( false !== get_option( self::OPT, false ) ) {
			return;
		}
		$T = MSM_Prod::TZ();
		if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $T ) ) !== $T ) {
			return;
		}
		update_option( self::OPT, (int) $wpdb->get_var( "SELECT COALESCE(MAX(id),0) FROM `$T`" ) ); // phpcs:ignore
	}

	public static function is_new_order( $zlec_id ) {
		$from = get_option( self::OPT, false );
		return false !== $from && (int) $zlec_id > (int) $from;
	}

	/* ---------------- ewidencja ---------------- */

	/** Wszystkie sprawdziany i przyrządy: [tabela => [ {id, numer, nr, wym, regal, hala, zlec} ]]. */
	public static function tools() {
		global $wpdb;
		if ( null !== self::$tools ) {
			return self::$tools;
		}
		self::$tools = array();
		foreach ( array_unique( array_values( self::PREFIX ) ) as $t ) {
			$T = msm_table( $t );
			if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $T ) ) !== $T ) {
				self::$tools[ $t ] = array();
				continue;
			}
			$rows = (array) $wpdb->get_results( "SELECT id, numer, regal, wym, nr_zlecenia, uzyty FROM `$T`", ARRAY_A ); // phpcs:ignore
			self::$tools[ $t ] = self::cast_tools( $rows );
		}
		return self::$tools;
	}

	public static function cast_tools( array $rows ) {
		return array_map( function ( $r ) {
			$regal = trim( (string) ( $r['regal'] ?? '' ) );
			return array(
				'id'    => (int) $r['id'],
				'numer' => (string) $r['numer'],
				'nr'    => preg_replace( '/\D+/', '', (string) $r['numer'] ),
				'wym'   => null === $r['wym'] || '' === $r['wym'] ? null : (float) $r['wym'],
				'regal' => $regal,
				'hala'  => 'HALA' === mb_strtoupper( $regal, 'UTF-8' ),
				'zlec'  => implode( ', ', array_values( array_unique( preg_split( '/[\s,;]+/u', trim( (string) ( $r['nr_zlecenia'] ?? '' ) . ' ' . (string) ( $r['uzyty'] ?? '' ) ), -1, PREG_SPLIT_NO_EMPTY ) ) ) ),
			);
		}, $rows );
	}

	/** Do testów: podmiana ewidencji. */
	public static function set_tools( $tools ) {
		self::$tools = $tools;
	}

	/* ---------------- analiza wpisu ---------------- */

	private static function num( $s ) {
		return (float) str_replace( ',', '.', (string) $s );
	}

	/**
	 * Rozbiór wpisu na odnośniki. Zwraca listę: {text, pos, prefix, nr, dim, need, table, state, avail, hala, items}.
	 */
	public static function analyze( $text, $nr_zlec = '' ) {
		$text  = (string) $text;
		$tools = self::tools();
		$out   = array();
		if ( ! preg_match_all( self::RX, $text, $mm, PREG_SET_ORDER | PREG_OFFSET_CAPTURE ) ) {
			return $out;
		}
		foreach ( $mm as $m ) {
			$prefix = strtoupper( $m[1][0] );
			$table  = self::PREFIX[ $prefix ];
			$nr     = isset( $m[2] ) && -1 !== $m[2][1] ? $m[2][0] : '';
			$dim    = self::num( $m[3][0] );
			$need   = isset( $m[4] ) && -1 !== $m[4][1] && '' !== $m[4][0] ? max( 1, (int) $m[4][0] ) : 1;
			$items  = array();
			foreach ( $tools[ $table ] ?? array() as $t ) {
				$by_dim = null !== $t['wym'] && abs( $t['wym'] - $dim ) <= self::TOL + 1e-9;
				$by_nr  = '' !== $nr && $t['nr'] === ltrim( $nr, '0' );
				if ( $by_dim || $by_nr ) {
					$t['dla_zlecenia'] = '' !== $nr_zlec && false !== mb_stripos( $t['zlec'], $nr_zlec );
					$t['wskazany']     = $by_nr;
					$items[]           = $t;
				}
			}
			usort( $items, function ( $a, $b ) {
				return array( ! $a['wskazany'], ! $a['dla_zlecenia'], $a['hala'], (int) $a['nr'] ) <=> array( ! $b['wskazany'], ! $b['dla_zlecenia'], $b['hala'], (int) $b['nr'] );
			} );
			$avail = count( array_filter( $items, function ( $t ) { return ! $t['hala']; } ) );
			$hala  = count( $items ) - $avail;
			if ( ! $items ) {
				$state = 'brak';
			} elseif ( $avail >= $need ) {
				$state = 'jest';
			} elseif ( $avail > 0 ) {
				$state = 'czesciowo';
			} else {
				$state = 'hala';
			}
			$out[] = array(
				'text'   => $m[0][0],
				'pos'    => mb_strlen( substr( $text, 0, $m[0][1] ) ),
				'prefix' => $prefix,
				'nr'     => $nr,
				'dim'    => $dim,
				'need'   => $need,
				'table'  => $table,
				'state'  => $state,
				'avail'  => $avail,
				'hala'   => $hala,
				'items'  => array_slice( $items, 0, 30 ),
			);
		}
		return $out;
	}

	/**
	 * Dopisuje numery przyrządów w wpisach bez numeru („PO 29.93 (3szt)” → „PO12 29.93 (3szt)”).
	 * Wybór: przyrząd przypisany do tego zlecenia, potem dostępny na regale, potem najniższy numer. Reszta tekstu bez zmian.
	 */
	public static function fill_numbers( $text, $nr_zlec = '' ) {
		$text   = (string) $text;
		$tokens = self::analyze( $text, $nr_zlec );
		if ( ! $tokens ) {
			return $text;
		}
		$offset = 0;
		foreach ( $tokens as $t ) {
			if ( '' !== $t['nr'] || ! $t['items'] || '' === $t['items'][0]['nr'] ) {
				continue;
			}
			$at   = $t['pos'] + 2 + $offset; // za prefiksem
			$rest = mb_substr( $text, $at );
			$ws   = preg_match( '/^\s*/u', $rest, $w ) ? mb_strlen( $w[0] ) : 0;
			$text = mb_substr( $text, 0, $at ) . $t['items'][0]['nr'] . ' ' . mb_substr( $text, $at + $ws );
			$offset += mb_strlen( $t['items'][0]['nr'] ) + 1 - $ws;
		}
		return $text;
	}

	/* ---------------- REST ---------------- */

	/** GET /prod/order/{id}/narzedzia → { det_id: [odnośniki] } dla wszystkich pozycji zlecenia. */
	public static function order_tools( WP_REST_Request $r ) {
		global $wpdb;
		$id = (int) $r['id'];
		$nr = (string) $wpdb->get_var( $wpdb->prepare( 'SELECT nr_zlec FROM `' . MSM_Prod::TZ() . '` WHERE id = %d', $id ) ); // phpcs:ignore
		$ds = (array) $wpdb->get_results( $wpdb->prepare( 'SELECT id, dostepnosc FROM `' . MSM_Prod::TD() . '` WHERE zlec_id = %d', $id ), ARRAY_A ); // phpcs:ignore
		$out = array();
		foreach ( $ds as $d ) {
			$out[ (int) $d['id'] ] = self::analyze( (string) $d['dostepnosc'], $nr );
		}
		return rest_ensure_response( array( 'det' => (object) $out, 'auto' => self::is_new_order( $id ) ) );
	}
}
