<?php
/**
 * Definicje tabel magazynu. Jedno źródło prawdy dla bazy, API, interfejsu, importu i eksportu.
 *
 * Typy kolumn: text, enum (stała lista), num (liczba dziesiętna), int, bool, date, datetime.
 * filter: select (lista wartości), range (od–do), brak = tylko wyszukiwarka.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function msm_opis_options() {
	return array(
		'PROFIL',
		'PROFIL OTWARTY',
		'KĄTOWNIK L',
		'PŁASKOWNIK',
		'PRĘT KWADRATOWY',
		'PRĘT OKRĄGŁY',
		'PRĘT CIĄGNIONY',
		'PRĘT SZEŚCIOKĄTNY',
		'RURA',
		'PRZYGOTÓWKA',
	);
}

function msm_schema() {
	static $schema = null;
	if ( null !== $schema ) {
		return $schema;
	}

	$schema = array(
		'stal'            => array(
			'label'   => 'Stal',
			'stock'   => true,
			'unit'    => 'szt',
			'default_order' => array( 'opis', 'ASC' ),
			'cols'    => array(
				array( 'key' => 'opis', 'label' => 'Opis', 'type' => 'enum', 'options' => msm_opis_options(), 'filter' => 'select', 'required' => true, 'aliases' => array( 'OPIS' ) ),
				array( 'key' => 'szer', 'label' => 'Szer. / śr. [mm]', 'type' => 'num', 'filter' => 'range', 'exact_single' => true, 'required' => true, 'aliases' => array( 'SZERŚR', 'SZER', 'ŚR', 'SZEROKOŚĆ', 'ŚREDNICA' ) ),
				array( 'key' => 'wys', 'label' => 'Wys. [mm]', 'type' => 'num', 'filter' => 'range', 'exact_single' => true, 'aliases' => array( 'WYS', 'WYSOKOŚĆ' ) ),
				array( 'key' => 'scianka', 'label' => 'Gr. ścianki [mm]', 'type' => 'num', 'filter' => 'range', 'exact_single' => true, 'aliases' => array( 'GRŚCIANKI', 'ŚCIANKA', 'GRUBOŚĆŚCIANKI' ) ),
				array( 'key' => 'gatunek', 'label' => 'Gatunek', 'type' => 'text', 'filter' => 'select', 'suggest' => true, 'aliases' => array( 'GATUNEK' ) ),
				array( 'key' => 'ilosc', 'label' => 'Ilość [szt]', 'type' => 'int', 'filter' => 'range', 'sum' => true, 'aliases' => array( 'ILOŚĆ', 'ILOŚĆSZT' ) ),
				array( 'key' => 'min_stan', 'label' => 'Stan minimalny [szt]', 'type' => 'int', 'hidden' => true ),
				array( 'key' => 'dlugosc', 'label' => 'Długość [m]', 'type' => 'num', 'filter' => 'range', 'aliases' => array( 'DŁUGOŚĆMB', 'DŁUGOŚĆ', 'DŁUGOŚĆM' ) ),
				array( 'key' => 'uwagi', 'label' => 'Uwagi', 'type' => 'text', 'long' => true, 'aliases' => array( 'UWAGI' ) ),
				array( 'key' => 'suma_mb', 'label' => 'Suma mb', 'type' => 'num', 'computed' => true, 'sum' => true ),
				array( 'key' => 'kg_m', 'label' => 'kg/m', 'type' => 'num', 'computed' => true, 'decimals' => 3 ),
				array( 'key' => 'suma_kg', 'label' => 'Suma kg', 'type' => 'num', 'computed' => true, 'sum' => true, 'decimals' => 2 ),
			),
		),
		'blachy_pelne'    => array(
			'label'   => 'Blachy pełne',
			'stock'   => true,
			'unit'    => 'szt',
			'default_order' => array( 'gatunek', 'ASC' ),
			'cols'    => array(
				array( 'key' => 'gatunek', 'label' => 'Gatunek', 'type' => 'text', 'filter' => 'select', 'suggest' => true, 'required' => true, 'aliases' => array( 'GATUNEK' ) ),
				array( 'key' => 'grubosc', 'label' => 'Grubość [mm]', 'type' => 'num', 'filter' => 'select', 'required' => true, 'aliases' => array( 'GRUBOŚĆ' ) ),
				array( 'key' => 'wymiar_a', 'label' => 'Wymiar A [mm]', 'type' => 'num', 'filter' => 'select', 'aliases' => array( 'WYMIARA' ) ),
				array( 'key' => 'wymiar_b', 'label' => 'Wymiar B [mm]', 'type' => 'num', 'filter' => 'select', 'aliases' => array( 'WYMIARB' ) ),
				array( 'key' => 'ilosc', 'label' => 'Ilość [szt]', 'type' => 'int', 'filter' => 'range', 'sum' => true, 'aliases' => array( 'ILOŚĆ', 'ILOŚĆSZT' ) ),
				array( 'key' => 'min_stan', 'label' => 'Stan minimalny [szt]', 'type' => 'int', 'hidden' => true ),
				array( 'key' => 'material', 'label' => 'Materiał', 'type' => 'text', 'filter' => 'select', 'suggest' => true, 'aliases' => array( 'MATERIAŁ' ) ),
				array( 'key' => 'uwagi', 'label' => 'Uwagi', 'type' => 'text', 'long' => true, 'aliases' => array( 'UWAGI' ) ),
				array( 'key' => 'kg_szt', 'label' => 'kg/szt', 'type' => 'num', 'computed' => true, 'decimals' => 2 ),
				array( 'key' => 'suma_kg', 'label' => 'Suma kg', 'type' => 'num', 'computed' => true, 'sum' => true, 'decimals' => 2 ),
			),
		),
		'blachy_niepelne' => array(
			'label'   => 'Blachy niepełne',
			'stock'   => true,
			'unit'    => 'szt',
			'default_order' => array( 'gatunek', 'ASC' ),
			'cols'    => array(
				array( 'key' => 'gatunek', 'label' => 'Gatunek', 'type' => 'text', 'filter' => 'select', 'suggest' => true, 'required' => true, 'aliases' => array( 'GATUNEK' ) ),
				array( 'key' => 'grubosc', 'label' => 'Grubość [mm]', 'type' => 'num', 'filter' => 'select', 'required' => true, 'aliases' => array( 'GRUBOŚĆ' ) ),
				array( 'key' => 'ksztalt', 'label' => 'Kształt', 'type' => 'enum', 'options' => array( 'prostokąt', 'koło' ), 'filter' => 'select', 'default' => 'prostokąt', 'aliases' => array( 'KSZTAŁT' ) ),
				array( 'key' => 'wymiar_a', 'label' => 'Wymiar A / śr. [mm]', 'type' => 'num', 'filter' => 'range', 'aliases' => array( 'WYMIARA', 'WYMIARAŚR' ) ),
				array( 'key' => 'wymiar_b', 'label' => 'Wymiar B [mm]', 'type' => 'num', 'filter' => 'range', 'aliases' => array( 'WYMIARB' ) ),
				array( 'key' => 'ilosc', 'label' => 'Ilość [szt]', 'type' => 'int', 'filter' => 'range', 'sum' => true, 'aliases' => array( 'ILOŚĆ', 'ILOŚĆSZT' ) ),
				array( 'key' => 'min_stan', 'label' => 'Stan minimalny [szt]', 'type' => 'int', 'hidden' => true ),
				array( 'key' => 'uwagi', 'label' => 'Uwagi', 'type' => 'text', 'long' => true, 'aliases' => array( 'UWAGI' ) ),
				array( 'key' => 'kg_szt', 'label' => 'kg/szt', 'type' => 'num', 'computed' => true, 'decimals' => 2 ),
				array( 'key' => 'suma_kg', 'label' => 'Suma kg', 'type' => 'num', 'computed' => true, 'sum' => true, 'decimals' => 2 ),
			),
		),
		'kregi'           => array(
			'label'   => 'Kręgi',
			'stock'   => true,
			'unit'    => 'kg',
			'default_order' => array( 'oznaczenie', 'ASC' ),
			'cols'    => array(
				array( 'key' => 'oznaczenie', 'label' => 'Oznaczenie blachy', 'type' => 'text', 'filter' => 'select', 'suggest' => true, 'required' => true, 'aliases' => array( 'OZNACZENIEBLACHY', 'OZNACZENIE' ) ),
				array( 'key' => 'izolacja', 'label' => 'Izolacja', 'type' => 'text', 'filter' => 'select', 'suggest' => true, 'aliases' => array( 'IZOLACJA' ) ),
				array( 'key' => 'grubosc', 'label' => 'Grubość [mm]', 'type' => 'num', 'filter' => 'range', 'aliases' => array( 'GRUBOŚĆ' ) ),
				array( 'key' => 'szerokosc', 'label' => 'Szerokość [mm]', 'type' => 'num', 'filter' => 'range', 'aliases' => array( 'SZEROKOŚĆ' ) ),
				array( 'key' => 'lokalizacja', 'label' => 'Lokalizacja', 'type' => 'enum', 'options' => array( 'Magazyn Ligota', 'Magazyn Kuniów' ), 'filter' => 'select', 'default' => 'Magazyn Ligota', 'required' => true, 'aliases' => array( 'LOKALIZACJA', 'MAGAZYN' ) ),
				array( 'key' => 'ilosc', 'label' => 'Ilość [kg]', 'type' => 'num', 'filter' => 'range', 'sum' => true, 'default' => 1, 'aliases' => array( 'ILOŚĆKG', 'ILOŚĆ', 'ILOŚĆSZT', 'WAGA', 'MASA' ) ),
				array( 'key' => 'min_stan', 'label' => 'Stan minimalny [kg]', 'type' => 'num', 'hidden' => true ),
				array( 'key' => 'uwagi', 'label' => 'Uwagi', 'type' => 'text', 'long' => true, 'aliases' => array( 'UWAGI' ) ),
			),
		),
		'bhp'             => array(
			'label'   => 'Magazyn BHP',
			'edit'    => true,
			'bhp'     => true,
			'unit'    => 'szt',
			'default_order' => array( 'kategoria', 'ASC' ),
			'cols'    => array(
				array( 'key' => 'kategoria', 'label' => 'Asortyment', 'type' => 'text', 'filter' => 'select', 'suggest' => true, 'required' => true, 'aliases' => array( 'ASORTYMENT' ) ),
				array( 'key' => 'nazwa', 'label' => 'Nazwa / producent', 'type' => 'text', 'filter' => 'select', 'suggest' => true, 'aliases' => array( 'NAZWAASORTYMENTUPRODUCENT', 'NAZWA', 'PRODUCENT' ) ),
				array( 'key' => 'producent_id', 'label' => 'Identyfikator / nr', 'type' => 'text', 'aliases' => array( 'IDENTYFIKATORPRODUCENTANUMERY', 'IDENTYFIKATOR', 'NUMER' ) ),
				array( 'key' => 'rozmiar', 'label' => 'Rozmiar', 'type' => 'text', 'filter' => 'select', 'suggest' => true, 'aliases' => array( 'ROZMIAR' ) ),
				array( 'key' => 'st_mag_nowy', 'label' => 'Magazyn — nowy [szt]', 'type' => 'int', 'default' => 0, 'hidden' => true, 'pool' => true, 'aliases' => array( 'LICZBASZTUKNASTANIE', 'ILOŚĆ', 'ILOŚĆSZT', 'MAGAZYNNOWY', 'MAGAZYN' ) ),
				array( 'key' => 'st_mag_uzywany', 'label' => 'Magazyn — używany [szt]', 'type' => 'int', 'default' => 0, 'hidden' => true, 'pool' => true, 'aliases' => array( 'MAGAZYNUŻYWANY' ) ),
				array( 'key' => 'st_szafa_nowy', 'label' => 'Szafa BHP — nowy [szt]', 'type' => 'int', 'default' => 0, 'hidden' => true, 'pool' => true, 'aliases' => array( 'SZAFANOWY', 'SZAFABHP' ) ),
				array( 'key' => 'st_szafa_uzywany', 'label' => 'Szafa BHP — używany [szt]', 'type' => 'int', 'default' => 0, 'hidden' => true, 'pool' => true, 'aliases' => array( 'SZAFAUŻYWANY' ) ),
				array( 'key' => 'ilosc_nowy', 'label' => 'Nowy łącznie [szt]', 'type' => 'int', 'default' => 0, 'computed' => true, 'hidden' => true ),
				array( 'key' => 'ilosc_uzywany', 'label' => 'Używany łącznie [szt]', 'type' => 'int', 'default' => 0, 'computed' => true, 'hidden' => true ),
				array( 'key' => 'ilosc', 'label' => 'Stan łączny [szt]', 'type' => 'int', 'filter' => 'range', 'sum' => true, 'default' => 0, 'computed' => true ),
				array( 'key' => 'lokacja', 'label' => 'Lokacja', 'type' => 'text', 'default' => 'magazyn', 'hidden' => true, 'aliases' => array( 'LOKACJA', 'LOKALIZACJA' ) ),
				array( 'key' => 'norma', 'label' => 'Norma przydziału', 'type' => 'text', 'filter' => 'select', 'normapick' => true ),
				array( 'key' => 'min_stan', 'label' => 'Stan minimalny [szt]', 'type' => 'int', 'hidden' => true ),
				array( 'key' => 'uwagi', 'label' => 'Uwagi', 'type' => 'text', 'long' => true, 'aliases' => array( 'UWAGI' ) ),
			),
		),
		'bhp_osoby'       => array(
			'label'   => 'Osoby (BHP)',
			'edit'    => true,
			'bhp'     => true,
			'default_order' => array( 'imie_nazwisko', 'ASC' ),
			'cols'    => array(
				array( 'key' => 'imie_nazwisko', 'label' => 'Imię i nazwisko', 'type' => 'text', 'filter' => 'select', 'suggest' => true, 'required' => true ),
				array( 'key' => 'dzial', 'label' => 'Dział / brygada', 'type' => 'text', 'filter' => 'select', 'suggest' => true ),
				array( 'key' => 'nr_ewid', 'label' => 'Nr ewidencyjny', 'type' => 'text' ),
				array( 'key' => 'aktywny', 'label' => 'Aktywny', 'type' => 'bool', 'filter' => 'select', 'default' => 1 ),
				array( 'key' => 'uwagi', 'label' => 'Uwagi', 'type' => 'text', 'long' => true ),
			),
		),
		'bhp_normy'       => array(
			'label'   => 'Normy przydziału BHP',
			'edit'    => true,
			'bhp'     => true,
			'default_order' => array( 'kategoria', 'ASC' ),
			'cols'    => array(
				array( 'key' => 'kategoria', 'label' => 'Nazwa normy (np. T-shirt)', 'type' => 'text', 'filter' => 'select', 'suggest' => true, 'required' => true ),
				array( 'key' => 'limit_szt', 'label' => 'Maks. na wyposażeniu [szt]', 'type' => 'int', 'default' => 0 ),
				array( 'key' => 'wymiana_mies', 'label' => 'Wymiana co [mies.]', 'type' => 'int', 'default' => 0 ),
				array( 'key' => 'uwagi', 'label' => 'Uwagi', 'type' => 'text', 'long' => true ),
			),
		),
		'pobrania'        => array(
			'label'    => 'Pobrania',
			'readonly' => true,
			'default_order' => array( 'id', 'DESC' ),
			'editable' => array( 'data', 'zlecenie', 'odbiorca', 'uwagi', 'wpisana' ),
			'cols'     => array(
				array( 'key' => 'data', 'label' => 'Data', 'type' => 'date', 'filter' => 'range' ),
				array( 'key' => 'tabela', 'label' => 'Magazyn', 'type' => 'text', 'filter' => 'select' ),
				array( 'key' => 'material', 'label' => 'Materiał', 'type' => 'text' ),
				array( 'key' => 'ilosc', 'label' => 'Ilość', 'type' => 'num', 'sum' => false ),
				array( 'key' => 'jednostka', 'label' => 'J.m.', 'type' => 'text' ),
				array( 'key' => 'zlecenie', 'label' => 'Nr zlecenia', 'type' => 'text', 'filter' => 'select', 'suggest' => true ),
				array( 'key' => 'odbiorca', 'label' => 'Pobrał / dla kogo', 'type' => 'text', 'filter' => 'select', 'suggest' => true ),
				array( 'key' => 'uwagi', 'label' => 'Uwagi / cel', 'type' => 'text', 'long' => true ),
				array( 'key' => 'wpisana', 'label' => 'Wpisana do systemu', 'type' => 'bool', 'filter' => 'select' ),
				array( 'key' => 'user_name', 'label' => 'Wprowadził', 'type' => 'text', 'filter' => 'select' ),
			),
		),
		'wnioski'         => array(
			'label'    => 'Wnioski o pobranie',
			'readonly' => true,
			'default_order' => array( 'id', 'DESC' ),
			'editable' => array(),
			'cols'     => array(
				array( 'key' => 'data', 'label' => 'Złożono', 'type' => 'datetime', 'filter' => 'range' ),
				array( 'key' => 'typ', 'label' => 'Typ', 'type' => 'text', 'filter' => 'select' ),
				array( 'key' => 'user_name', 'label' => 'Wnioskujący', 'type' => 'text', 'filter' => 'select' ),
				array( 'key' => 'material', 'label' => 'Materiał', 'type' => 'text' ),
				array( 'key' => 'ilosc', 'label' => 'Ilość', 'type' => 'num' ),
				array( 'key' => 'jednostka', 'label' => 'J.m.', 'type' => 'text' ),
				array( 'key' => 'zlecenie', 'label' => 'Nr zlecenia', 'type' => 'text' ),
				array( 'key' => 'rysunek', 'label' => 'Nr rysunku', 'type' => 'text' ),
				array( 'key' => 'uwagi', 'label' => 'Cel / uwagi', 'type' => 'text', 'long' => true ),
				array( 'key' => 'status', 'label' => 'Status', 'type' => 'text', 'filter' => 'select' ),
				array( 'key' => 'decided_name', 'label' => 'Rozpatrzył', 'type' => 'text', 'filter' => 'select' ),
				array( 'key' => 'admin_note', 'label' => 'Odpowiedź', 'type' => 'text', 'long' => true ),
			),
		),
		'wz'              => array(
			'label'    => 'Dokumenty WZ',
			'readonly' => true,
			'default_order' => array( 'id', 'DESC' ),
			'editable' => array(),
			'cols'     => array(
				array( 'key' => 'numer', 'label' => 'Numer WZ', 'type' => 'text' ),
				array( 'key' => 'data_wysylki', 'label' => 'Data wysyłki', 'type' => 'date', 'filter' => 'range' ),
				array( 'key' => 'odbiorca', 'label' => 'Odbiorca', 'type' => 'text', 'filter' => 'select', 'suggest' => true ),
				array( 'key' => 'przeznaczenie', 'label' => 'Przeznaczenie', 'type' => 'text', 'suggest' => true ),
				array( 'key' => 'zlecenia', 'label' => 'Zlecenia', 'type' => 'text', 'long' => true ),
				array( 'key' => 'pozycji', 'label' => 'Pozycji', 'type' => 'int' ),
				array( 'key' => 'status', 'label' => 'Status', 'type' => 'text', 'filter' => 'select' ),
				array( 'key' => 'created_name', 'label' => 'Utworzył', 'type' => 'text', 'filter' => 'select' ),
				array( 'key' => 'transport', 'label' => 'Środek transportu', 'type' => 'text', 'suggest' => true, 'hidden' => true ),
				array( 'key' => 'wystawil', 'label' => 'Wystawił', 'type' => 'text', 'suggest' => true, 'hidden' => true ),
				array( 'key' => 'wydal', 'label' => 'Wydał', 'type' => 'text', 'suggest' => true, 'hidden' => true ),
			),
		),
		'spr_prost'        => array(
			'label'   => 'Sprawdziany prostokątne',
			'narzedzia' => true,
			'edit'    => true,
			'default_order' => array( 'numer', 'ASC' ),
			'cols'    => array(
				array( 'key' => 'nr_zlecenia', 'label' => 'Nr zlecenia', 'type' => 'text', 'filter' => 'text', 'suggest' => true, 'aliases' => array( 'NRZLECENIA' ) ),
				array( 'key' => 'numer', 'label' => 'Numer sprawdzianu', 'type' => 'text', 'required' => true, 'aliases' => array() ),
				array( 'key' => 'regal', 'label' => 'Regał', 'type' => 'text', 'aliases' => array( 'REGAŁ' ) ),
				array( 'key' => 'wym', 'label' => 'T ±0,01 [mm]', 'type' => 'num', 'filter' => 'range', 'exact_single' => true, 'decimals' => 2, 'aliases' => array( 'T', 'WYMIART' ) ),
				array( 'key' => 'w', 'label' => 'W [mm]', 'type' => 'num', 'decimals' => 2 ),
				array( 'key' => 'l', 'label' => 'L [mm]', 'type' => 'num', 'decimals' => 1 ),
				array( 'key' => 'cr', 'label' => 'C, R [mm]', 'type' => 'num', 'decimals' => 3 ),
				array( 'key' => 'g', 'label' => 'G', 'type' => 'text' ),
				array( 'key' => 'material', 'label' => 'Materiał', 'type' => 'text', 'suggest' => true ),
				array( 'key' => 'uzyty', 'label' => 'Użyty w zleceniu', 'type' => 'text', 'filter' => 'text', 'long' => true, 'taglist' => true ),
				array( 'key' => 'zmierzony_min', 'label' => 'Zmierz. min [mm]', 'type' => 'num', 'decimals' => 2 ),
				array( 'key' => 'zmierzony_max', 'label' => 'Zmierz. max [mm]', 'type' => 'num', 'decimals' => 2 ),
			),
		),
		'prz_prost'        => array(
			'label'   => 'Przyrządy prostokątne',
			'narzedzia' => true,
			'edit'    => true,
			'default_order' => array( 'numer', 'ASC' ),
			'cols'    => array(
				array( 'key' => 'nr_zlecenia', 'label' => 'Nr zlecenia', 'type' => 'text', 'filter' => 'text', 'suggest' => true, 'aliases' => array( 'NRZLECENIA' ) ),
				array( 'key' => 'numer', 'label' => 'Numer przyrządu', 'type' => 'text', 'required' => true, 'aliases' => array() ),
				array( 'key' => 'regal', 'label' => 'Regał', 'type' => 'text', 'aliases' => array( 'REGAŁ' ) ),
				array( 'key' => 'wym', 'label' => 'T ±0,02 [mm]', 'type' => 'num', 'filter' => 'range', 'exact_single' => true, 'decimals' => 2, 'aliases' => array( 'T', 'WYMIART' ) ),
				array( 'key' => 'w', 'label' => 'W [mm]', 'type' => 'num', 'decimals' => 2 ),
				array( 'key' => 'l', 'label' => 'L [mm]', 'type' => 'num', 'decimals' => 1 ),
				array( 'key' => 'cr', 'label' => 'C, R [mm]', 'type' => 'num', 'decimals' => 3 ),
				array( 'key' => 'g', 'label' => 'G', 'type' => 'text' ),
				array( 'key' => 'material', 'label' => 'Materiał', 'type' => 'text', 'suggest' => true ),
				array( 'key' => 'uzyty', 'label' => 'Użyty w zleceniu', 'type' => 'text', 'filter' => 'text', 'long' => true, 'taglist' => true ),
				array( 'key' => 'zmierzony_min', 'label' => 'Zmierz. min [mm]', 'type' => 'num', 'decimals' => 2 ),
				array( 'key' => 'zmierzony_max', 'label' => 'Zmierz. max [mm]', 'type' => 'num', 'decimals' => 2 ),
			),
		),
		'spr_okr'        => array(
			'label'   => 'Sprawdziany okrągłe',
			'narzedzia' => true,
			'edit'    => true,
			'default_order' => array( 'numer', 'ASC' ),
			'cols'    => array(
				array( 'key' => 'nr_zlecenia', 'label' => 'Nr zlecenia', 'type' => 'text', 'filter' => 'text', 'suggest' => true, 'aliases' => array( 'NRZLECENIA' ) ),
				array( 'key' => 'numer', 'label' => 'Numer sprawdzianu', 'type' => 'text', 'required' => true, 'aliases' => array() ),
				array( 'key' => 'regal', 'label' => 'Regał', 'type' => 'text', 'aliases' => array( 'REGAŁ' ) ),
				array( 'key' => 'wym', 'label' => 'Ø ±0,01 [mm]', 'type' => 'num', 'filter' => 'range', 'exact_single' => true, 'decimals' => 2, 'aliases' => array( 'Ø', 'SR', 'SREDNICA' ) ),
				array( 'key' => 'l', 'label' => 'L [mm]', 'type' => 'num', 'decimals' => 1 ),
				array( 'key' => 'c', 'label' => 'C [mm]', 'type' => 'num', 'decimals' => 3 ),
				array( 'key' => 'g', 'label' => 'G', 'type' => 'text' ),
				array( 'key' => 'material', 'label' => 'Materiał', 'type' => 'text', 'suggest' => true ),
				array( 'key' => 'uzyty', 'label' => 'Użyty w zleceniu', 'type' => 'text', 'filter' => 'text', 'long' => true, 'taglist' => true ),
				array( 'key' => 'zmierzony_min', 'label' => 'Zmierz. min [mm]', 'type' => 'num', 'decimals' => 2 ),
				array( 'key' => 'zmierzony_max', 'label' => 'Zmierz. max [mm]', 'type' => 'num', 'decimals' => 2 ),
			),
		),
		'prz_okr'        => array(
			'label'   => 'Przyrządy okrągłe',
			'narzedzia' => true,
			'edit'    => true,
			'default_order' => array( 'numer', 'ASC' ),
			'cols'    => array(
				array( 'key' => 'nr_zlecenia', 'label' => 'Nr zlecenia', 'type' => 'text', 'filter' => 'text', 'suggest' => true, 'aliases' => array( 'NRZLECENIA' ) ),
				array( 'key' => 'numer', 'label' => 'Numer przyrządu', 'type' => 'text', 'required' => true, 'aliases' => array() ),
				array( 'key' => 'regal', 'label' => 'Regał', 'type' => 'text', 'aliases' => array( 'REGAŁ' ) ),
				array( 'key' => 'wym', 'label' => 'Ø ±0,02 [mm]', 'type' => 'num', 'filter' => 'range', 'exact_single' => true, 'decimals' => 2, 'aliases' => array( 'Ø', 'SR', 'SREDNICA' ) ),
				array( 'key' => 'l', 'label' => 'L [mm]', 'type' => 'num', 'decimals' => 1 ),
				array( 'key' => 'c', 'label' => 'C [mm]', 'type' => 'num', 'decimals' => 3 ),
				array( 'key' => 'g', 'label' => 'G', 'type' => 'text' ),
				array( 'key' => 'material', 'label' => 'Materiał', 'type' => 'text', 'suggest' => true ),
				array( 'key' => 'uzyty', 'label' => 'Użyty w zleceniu', 'type' => 'text', 'filter' => 'text', 'long' => true, 'taglist' => true ),
				array( 'key' => 'zmierzony_min', 'label' => 'Zmierz. min [mm]', 'type' => 'num', 'decimals' => 2 ),
				array( 'key' => 'zmierzony_max', 'label' => 'Zmierz. max [mm]', 'type' => 'num', 'decimals' => 2 ),
			),
		),
		'rezerwacje'      => array(
			'label'    => 'Rezerwacje',
			'readonly' => true,
			'default_order' => array( 'id', 'DESC' ),
			'editable' => array(),
			'cols'     => array(
				array( 'key' => 'created_at', 'label' => 'Złożono', 'type' => 'datetime', 'filter' => 'range' ),
				array( 'key' => 'zlecenie', 'label' => 'Zlecenie', 'type' => 'text', 'filter' => 'select', 'suggest' => true ),
				array( 'key' => 'material', 'label' => 'Materiał', 'type' => 'text' ),
				array( 'key' => 'ilosc', 'label' => 'Ilość', 'type' => 'num' ),
				array( 'key' => 'termin', 'label' => 'Termin', 'type' => 'date', 'filter' => 'range' ),
				array( 'key' => 'user_name', 'label' => 'Zarezerwował', 'type' => 'text', 'filter' => 'select' ),
				array( 'key' => 'status', 'label' => 'Status', 'type' => 'text', 'filter' => 'select' ),
				array( 'key' => 'decided_name', 'label' => 'Zatwierdził', 'type' => 'text', 'filter' => 'select' ),
			),
		),
		'pz'              => array(
			'label'    => 'Przyjęcia (PZ)',
			'readonly' => true,
			'default_order' => array( 'id', 'DESC' ),
			'editable' => array(),
			'cols'     => array(
				array( 'key' => 'numer', 'label' => 'Numer PZ', 'type' => 'text' ),
				array( 'key' => 'data', 'label' => 'Data przyjęcia', 'type' => 'date', 'filter' => 'range' ),
				array( 'key' => 'dostawca', 'label' => 'Dostawca', 'type' => 'text', 'filter' => 'select', 'suggest' => true ),
				array( 'key' => 'nr_dok', 'label' => 'Nr dokumentu dostawcy', 'type' => 'text' ),
				array( 'key' => 'pozycji', 'label' => 'Pozycji', 'type' => 'int' ),
				array( 'key' => 'skanow', 'label' => 'Skany', 'type' => 'int' ),
				array( 'key' => 'status', 'label' => 'Status', 'type' => 'text', 'filter' => 'select' ),
				array( 'key' => 'created_name', 'label' => 'Przyjął', 'type' => 'text', 'filter' => 'select' ),
			),
		),
		'historia'        => array(
			'label'    => 'Historia zmian',
			'readonly' => true,
			'default_order' => array( 'id', 'DESC' ),
			'editable' => array(),
			'cols'     => array(
				array( 'key' => 'czas', 'label' => 'Kiedy', 'type' => 'datetime', 'filter' => 'range' ),
				array( 'key' => 'user_name', 'label' => 'Kto', 'type' => 'text', 'filter' => 'select' ),
				array( 'key' => 'akcja', 'label' => 'Akcja', 'type' => 'text', 'filter' => 'select' ),
				array( 'key' => 'tabela', 'label' => 'Magazyn', 'type' => 'text', 'filter' => 'select' ),
				array( 'key' => 'opis', 'label' => 'Opis', 'type' => 'text', 'long' => true ),
				array( 'key' => 'uwagi', 'label' => 'Uwagi', 'type' => 'text', 'long' => true ),
			),
		),
	);

	return $schema;
}

function msm_table( $key ) {
	global $wpdb;
	$map = array( 'historia' => 'log' );
	return $wpdb->prefix . 'msm_' . ( isset( $map[ $key ] ) ? $map[ $key ] : $key );
}

function msm_stock_tables() {
	return array_keys( array_filter( msm_schema(), function ( $t ) {
		return ! empty( $t['stock'] );
	} ) );
}

function msm_col( $table, $key ) {
	$s = msm_schema();
	foreach ( $s[ $table ]['cols'] as $c ) {
		if ( $c['key'] === $key ) {
			return $c;
		}
	}
	return null;
}

/** Jednostka stanu magazynu: 'szt' albo 'kg' (kręgi). */
function msm_unit( $table ) {
	$s = msm_schema();
	return isset( $s[ $table ]['unit'] ) && 'kg' === $s[ $table ]['unit'] ? 'kg' : 'szt';
}

/** Tabele ewidencji sprawdzianów i przyrządów. */
function msm_narzedzia_tables() {
	return array_keys( array_filter( msm_schema(), function ( $t ) {
		return ! empty( $t['narzedzia'] );
	} ) );
}

/** Tabele, które można dodawać/edytować/usuwać i drukować listą (magazyn + ewidencja + BHP). */
function msm_editable_tables() {
	$edit = array_keys( array_filter( msm_schema(), function ( $t ) {
		return ! empty( $t['edit'] );
	} ) );
	return array_values( array_unique( array_merge( msm_stock_tables(), msm_narzedzia_tables(), $edit ) ) );
}

/**
 * 1.84.0: neutralizacja formuł w CSV (=, +, -, @, tab, CR na początku tekstu) – Excel nie wykona wpisu jako formuły.
 * Liczby (także ujemne) zostają bez zmian.
 */
function msm_csv_safe( $v ) {
	if ( is_string( $v ) && '' !== $v && ! is_numeric( str_replace( ',', '.', $v ) ) && preg_match( '/^[=+\-@\t\r]/', $v ) ) {
		return "'" . $v;
	}
	return $v;
}
